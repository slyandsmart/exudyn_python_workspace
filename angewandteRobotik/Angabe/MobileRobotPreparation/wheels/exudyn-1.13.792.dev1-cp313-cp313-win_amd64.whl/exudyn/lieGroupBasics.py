#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# This is an EXUDYN python utility library
#
# Details:  Lie group methods and formulas for Lie group integration.
# References:   \\
#               For details on Lie group methods used here, see the references \cite{Henderson1977, Simo1988, Bruels2011, Sonneville2014, Sonneville2017, Terze2016, Mueller2017}.
#               Lie group methods for rotation vector are described in Holzinger and Gerstmayr \cite{HolzingerGerstmayr2020, Holzinger2021}.
#               
# Author:   Stefan Holzinger, Johannes Gerstmayr
# Date:     2020-09-11
#
# Copyright:This file is part of Exudyn. Exudyn is free software. You can redistribute it and/or modify it under the terms of the Exudyn license. See 'LICENSE.txt' for more details.
#
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



from exudyn.misc.docmeta import docmeta
import numpy as np
from exudyn.cMath import norm #the same bits on every platform (#2962)
from exudyn.cMath import sin, cos, tan, atan2, sqrt

#import exudyn as exu
import exudyn.cMath as cMath #the math functions of the C++ code, the same bits on every platform (#2962)
import exudyn.cUtilities as cu #ExpSO3, LogSO3 in C++ (#2962)
from exudyn.rigidBodyUtilities import EulerParameters2RotationMatrix, RotXYZ2RotationMatrix, HT2rotationMatrix, HT2translation, \
            HomogeneousTransformation, Skew, Skew2Vec, ComputeRotationAxisFromRotationVector


# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#       HELPER METHODS FOR BASIC LIE GROUP METHODS
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
#public API of this module; kept complete by tools/checkAll.py (#2444)
__all__ = [
    'Sinc', 'Cot', 'R3xSO3Matrix2RotationMatrix', 'R3xSO3Matrix2Translation', 'R3xSO3Matrix',
    'ExpSO3', 'ExpS3', 'LogSO3', 'TExpSO3', 'TExpSO3Inv', 'ExpSE3', 'LogSE3', 'TExpSE3',
    'TExpSE3Inv', 'ExpR3xSO3', 'TExpR3xSO3', 'TExpR3xSO3Inv', 'CompositionRuleDirectProductR3AndS3',
    'CompositionRuleSemiDirectProductR3AndS3', 'CompositionRuleDirectProductR3AndR3RotVec',
    'CompositionRuleSemiDirectProductR3AndR3RotVec',
    'CompositionRuleDirectProductR3AndR3RotXYZAngles',
    'CompositionRuleSemiDirectProductR3AndR3RotXYZAngles', 'CompositionRuleForEulerParameters',
    'CompositionRuleForRotationVectors', 'CompositionRuleRotXYZAnglesRotationVector',
    ]

@docmeta(author='Stefan Holzinger')
def Sinc(x):
    """compute the cardinal sine function in radians

    Args:
        scalar float or int value

    Returns:
        float value in radians
    """
    if x == 0.:
        s = 1.0
    else:
        s = sin(x)/x
#    s = np.sinc(x/np.pi) # is not more accurate than our implementation!
    return s


@docmeta(author='Stefan Holzinger')
def Cot(x):
    """compute the cotangent function cot(x)=1/tan(x) in radians

    Args:
        scalar float or int value

    Returns:
        float value in radians
    """
    return 1/tan(x)


@docmeta(author='Stefan Holzinger')
def R3xSO3Matrix2RotationMatrix(G): 
    """computes 3x3 rotation matrix from 7x7 R3xSO(3) matrix, see [Bruels2011]

    Args:
        G: 7x7 matrix as np.array

    Returns:
        3x3 rotation matrix as np.array
    """
    return G[0:3,0:3]


@docmeta(author='Stefan Holzinger')
def R3xSO3Matrix2Translation(G):
    """computes translation part of R3xSO(3) matrix, see [Bruels2011]

    Args:
        G: 7x7 matrix as np.array

    Returns:
        3D vector as np.array containg translational part of R3xSO(3)
    """
    return G[3:6,6]


@docmeta(author='Stefan Holzinger')
def R3xSO3Matrix(x,R):
    """builds 7x7 matrix as element of the Lie group R3xSO(3), see [Bruels2011]

    Args:
        x: 3D vector as np.array representing the translation part corresponding to R3
        R: 3x3 rotation matrix as np.array

    Returns:
        7x7 matrix as np.array
    """
    G = np.eye(7)
    G[0:3,0:3] = R
    G[3:6,6] = x
    return G









#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#       EXPONENTIAL MAPS AND TANGENT OPERATORS
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


@docmeta(author='Stefan Holzinger')
def ExpSO3(Omega):
    """compute the matrix exponential map on the Lie group SO(3), see [Mueller2017]; computed in C++ by exudyn.cUtilities.ExpSO3

    Args:
        3D rotation vector as np.array

    Returns:
        3x3 matrix as np.array
    """
    return cu.ExpSO3(Omega)


@docmeta(author='Stefan Holzinger')
def ExpS3(Omega):
    """compute the quaternion exponential map on the Lie group S(3), see [Terze2016, Mueller2017]

    Args:
        3D rotation vector as np.array

    Returns:
        4D vector as np.array containing four Euler parameters
        entry zero of output represent the scalar part of Euler parameters
    """
    phi = norm(Omega)
    q0 = cos(0.5*phi)
    qV = 0.5*Sinc(0.5*phi)*Omega
    return np.array([q0, qV[0], qV[1], qV[2]])     


@docmeta(author='Johannes Gerstmayr')
def LogSO3(R):
    """compute the matrix logarithmic map on the Lie group SO(3); computed in C++ by exudyn.cUtilities.LogSO3

    Args:
        3x3 rotation matrix as np.array

    Returns:
        3x3 skew symmetric matrix as np.array

    Note:
        improved accuracy for very small angles as well as angles phi close to pi AS WELL AS at phi=pi
    """
    return cu.LogSO3(R)
    


# #**function: compute the matrix logarithmic map on the Lie group SO(3), see \cite{Sonneville2014, Sonneville2017}
# #**input: 3x3 rotation matrix as np.array
# #**output: 3x3 skew symmetric matrix as np.array
# #**author: Stefan Holzinger
# def LogSO3(R):
#     val = 0.5*(np.trace(R)-1) #if slightly larger than 1, due to numerical differentiation
#     if abs(val)>1:
#         val = val/abs(val)
#     phi = acos(val)
#     if phi == 0.:
#         X = np.zeros((3,3))
#     else:
#         X = (phi/(2*sin(phi)))*(R - np.transpose(R))
#     return X


@docmeta(author='Stefan Holzinger')
def TExpSO3(Omega):
    """compute the tangent operator corresponding to ExpSO3, see [Bruels2011]

    Args:
        3D rotation vector as np.array

    Returns:
        3x3 matrix as np.array
    """
    #not all of these terms are needed (as implemented in C++ code):

    phi = norm(Omega)
    I = np.eye(3)
    if phi == 0.:
        T = I
    else:
        OmegaSkew = Skew(Omega)
        t1 = -0.5*Sinc(phi/2)**2 #(np.cos(phi)-1)/(phi**2)
        if phi < 0.01:
            t2 = 1 / 6 - (1 / 120)*phi**2 + (1 / 5040)*phi**4
            #termExpanded = lambda x: 1/6 - (1/120)*x**2 + (1/5040)*x**4 - (1/362880)*x**6 + (1/39916800)*x**8 - (1/6227020800)*x**10 + (1/1307674368000)*x**12 
        else:
            t2 = (1/(phi**2))*(1-(sin(phi)/phi))
        T = I + t1*OmegaSkew + t2*np.dot(OmegaSkew, OmegaSkew)
    return T


@docmeta(author='Stefan Holzinger')
def TExpSO3Inv(Omega):
    """compute the inverse of the tangent operator TExpSO3, see [Sonneville2014]
    this function was improved, see coordinateMaps.pdf by Stefan Holzinger

    Args:
        3D rotation vector as np.array

    Returns:
        3x3 matrix as np.array
    """
    phi = norm(Omega)
    if phi == 0.0: 
        Tinv = np.eye(3)
    elif phi <= 0.02: 
        c = (1/12) + (1/720)*phi**2 + (1/30240)*phi**4 # + (1/1209600)*phi**6 # + (1/47900160)*phi**8
        b = 1 - c*phi**2
        A = np.diag([b, b, b])
        OmegaSkew = Skew(0.5*Omega)
        Tinv = A + OmegaSkew + c*np.outer(Omega,Omega)
    else:
        OmegaSkew = Skew(0.5*Omega)
        epsilon = 0.5*phi
        beta = epsilon*Cot( epsilon )
        gamma = (1 - beta)/(phi**2)
        Tinv = np.diag([beta, beta, beta]) + OmegaSkew + gamma*np.outer(Omega,Omega)
    return Tinv 


@docmeta(author='Stefan Holzinger')
def ExpSE3(x):
    """compute the matrix exponential map on the Lie group SE(3), see [Bruels2011]

    Args:
        6D incremental motion vector as np.array

    Returns:
        4x4 homogeneous transformation matrix as np.array
    """
    U     = x[0:3]
    Omega = x[3:6]
    R = ExpSO3(Omega)
    x = np.dot(np.transpose(TExpSO3(Omega)), U)
    return HomogeneousTransformation(R, x)


@docmeta(author='Stefan Holzinger')
def LogSE3(H):
    """compute the matrix logarithm on the Lie group SE(3), see [Sonneville2014]

    Args:
        4x4 homogeneous transformation matrix as np.array

    Returns:
        4x4 skew symmetric matrix as np.array
    """
    R = HT2rotationMatrix(H)
    aSkew = LogSO3(R)
    a = Skew2Vec(aSkew)   
    A = np.transpose(TExpSO3Inv(a))
    x = np.dot(A,HT2translation(H))
    log = np.zeros((4,4))
    log[0:3,0:3] = aSkew
    log[0:3,3] = x
    return log
    

@docmeta(author='Stefan Holzinger')
def TExpSE3(x):
    """compute the tangent operator corresponding to ExpSE3, see [Bruels2011]

    Args:
        6D incremental motion vector as np.array

    Returns:
        6x6 matrix as np.array

    Note:
        improved accuracy for very small angles as well as angles phi
    """
    U     = x[0:3]
    Omega = x[3:6]
    USkew     = Skew(U)
    OmegaSkew = Skew(Omega)
    phi = norm(Omega)
   # phiOverTwo = 0.5*phi
    
    # coefficient f2, see Phd thesis Stefan Hante, Table. 1, page 121
    if phi >= 1e-2:
        f2 = (cMath.cos(phi) - 1) / phi**2
    else:
        f2 = -0.5 + (1/24)*phi**2 - (1/720)*phi**4

    # coefficient f3, see Phd thesis Stefan Hante, Table. 1, page 121
    if phi >= 1e-4:
        f3 = (phi - cMath.sin(phi)) / phi**3
    else:
        f3 = 1/6 - (1/24)*phi**2 - (1/720)*phi**4     

    # coefficient f4, see Phd thesis Stefan Hante, Table. 1, page 121
    if phi >= 1e-1:
        f4 = (2 - 2*cMath.cos(phi) - phi*cMath.sin(phi)) / phi**4
    else:
        f4 = 1/12 - (1/180)*phi**2 + (1/6720)*phi**4 - (1/453600)*phi**6
        
    # coefficient f5, see Phd thesis Stefan Hante, Table. 1, page 121
    if phi >= 1e-1:
        f5 = ( phi*(2 + cMath.cos(phi)) - 3*cMath.sin(phi)) / phi**5
    else:
        f5 = 1/60 - (1/1260)*phi**2 + (1/60480)*phi**4 - (1/4989600)*phi**6     
    
    TUOmegaPlus = f2*USkew + f3*( USkew @ OmegaSkew + OmegaSkew @ USkew ) + f4*np.dot(Omega,U)*OmegaSkew - f5*np.dot(Omega,U)*OmegaSkew**2
    
    TexpSO3 = TExpSO3(Omega)
    T = np.block([[TexpSO3,         TUOmegaPlus],
                  [np.zeros((3,3)), TexpSO3]])
    return T



@docmeta(author='Stefan Holzinger')
def TExpSE3Inv(x):
    """compute the inverse of tangent operator TExpSE3, see [Sonneville2014]

    Args:
        6D incremental motion vector as np.array

    Returns:
        6x6 matrix as np.array

    Note:
        improved accuracy for very small angles as well as angles phi
    """
    U     = x[0:3]
    Omega = x[3:6]
    USkew     = Skew(U)
    OmegaSkew = Skew(Omega)
    phi = norm(Omega)
    phiOverTwo = 0.5*phi
    
    # coefficient f6, see Phd thesis Stefan Hante, Table. 1, page 121
    if phi >= 1e-2:
        f6 = (2 - Cot(phiOverTwo)) / (2*phi**2)
    else:
        f6 = 1/12 + (1/720)*phi**2 + (1/30240)*phi**4
    
    # coefficient f8, see Phd thesis Stefan Hante, Table. 1, page 121
    if phi >= 2e-1:
        f8 = (phi*cMath.sin(phi) + 4*cMath.cos(phi) + phi**2 - 4) / (4*cMath.sin(phiOverTwo)**2 * phi**4)
    else:
        f8 = 1/360 + (1/7560)*phi**2 + (1/201600)*phi**4 + (1/5987520)*phi**6 + (691/130767436800)*phi**8
    
    # Matrix C2, see Phd thesis Stefan Hante, Sect.A.3, page 117
    Tuwm = 0.5*USkew + f6*( USkew @ OmegaSkew + OmegaSkew @ USkew ) + f8*np.dot(Omega,U)*OmegaSkew**2
    TexpSO3Inv = TExpSO3Inv(Omega) #NOTE: overrides the function TexpSO3Inv
    Tinv = np.block([[TexpSO3Inv,      Tuwm],
                     [np.zeros((3,3)), TexpSO3Inv]])
    return Tinv
    

@docmeta(author='Stefan Holzinger')
def ExpR3xSO3(x):
    """compute the matrix exponential map on the Lie group R3xSO(3), see [Bruels2011]

    Args:
        6D incremental motion vector as np.array

    Returns:
        7x7 matrix as np.array
    """
    G = np.eye(7)
    G[0:3,0:3] = ExpSO3(x[3:6])
    G[3:6,6] = x[0:3]
    return G


@docmeta(author='Stefan Holzinger')
def TExpR3xSO3(x):
    """compute the tangent operator corresponding to ExpR3xSO3, see [Bruels2011]

    Args:
        6D incremental motion vector as np.array

    Returns:
        6x6 matrix as np.array
    """
    T = np.eye(6)
    T[3:6,3:6] = TExpSO3(x[3:6])
    return T


@docmeta(author='Stefan Holzinger')
def TExpR3xSO3Inv(x):
    """compute the inverse of tangent operator TExpR3xSO3

    Args:
        6D incremental motion vector as np.array

    Returns:
        6x6 matrix as np.array
    """
    T = np.eye(6)
    T[3:6,3:6] = TExpSO3Inv(x[3:6])
    return T








#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#       COMPOSITION OPERATIONS FOR LIE GROUP TIME INTEGRATION METHODS 
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



@docmeta(author='Stefan Holzinger')
def CompositionRuleDirectProductR3AndS3(q0, incrementalMotionVector):
    """compute composition operation for pairs in the Lie group R3xS3

    Args:
        q0: 7D vector as np.array containing position coordinates and Euler parameters
        incrementalMotionVector: 6D incremental motion vector as np.array

    Returns:
        7D vector as np.array containing composed position coordinates and composed Euler parameters
    """
    
    # pair (x0, theta0)
    x0     = q0[0:3]  # global COM position at time step t0
    theta0 = q0[3:7]  # Euler parameters at time step t0
    
    # pair (delta x, incremental rotation vector)
    delta_x   = incrementalMotionVector[0:3] # global position increment of COM at time step t
    incRotVec = incrementalMotionVector[3:6] # incremental rotation vector at time step t
    
    # compososition rule
    x   = x0 + delta_x
    theta = CompositionRuleForEulerParameters(theta0, ExpS3(incRotVec))
    
    return np.block([x, theta])


@docmeta(author='Stefan Holzinger')
def CompositionRuleSemiDirectProductR3AndS3(q0, incrementalMotionVector):
    """compute composition operation for pairs in the Lie group R3 semiTimes S3 (corresponds to SE(3))

    Args:
        q0: 7D vector as np.array containing position coordinates and Euler parameters
        incrementalMotionVector: 6D incremental motion vector as np.array

    Returns:
        7D vector as np.array containing composed position coordinates and composed Euler parameters
    """
    
    # pair (x0, theta0)
    x0     = q0[0:3]  # global COM position at time step t0
    theta0 = q0[3:7]  # Euler parameters at time step t0
    
    # pair (delta x, incremental rotation vector)
    delta_x   = incrementalMotionVector[0:3] # global position increment of COM at time step t
    incRotVec = incrementalMotionVector[3:6] # incremental rotation vector at time step t
    
    # compososition rule
    R0  = EulerParameters2RotationMatrix(theta0)
    x   = x0 + np.dot(R0, np.dot(np.transpose(TExpSO3(incRotVec)), delta_x))
    theta = CompositionRuleForEulerParameters(theta0, ExpS3(incRotVec))
    
    return np.block([x, theta])


@docmeta(author='Stefan Holzinger')
def CompositionRuleDirectProductR3AndR3RotVec(q0, incrementalMotionVector):
    """compute composition operation for pairs in the group obtained from the direct product of R3 and R3, see [HolzingerGerstmayr2020]
    the rotation vector is used as rotation parametrizations
    this composition operation can be used in formulations which represent the translational velocities in the global (inertial) frame

    Args:
        q0: 6D vector as np.array containing position coordinates and rotation vector
        incrementalMotionVector: 6D incremental motion vector as np.array

    Returns:
        7D vector as np.array containing composed position coordinates and composed rotation vector
    """
    
    # pair (x0, psi0)
    x0   = q0[0:3]  # global COM position at time step t0
    psi0 = q0[3:6]  # rotation vector at time step t0
    
    # pair (delta x, delta theta)
    delta_x   = incrementalMotionVector[0:3] # global position increment of COM at time step t
    incRotVec = incrementalMotionVector[3:6] # incremental rotation vector at time step t
    
    # compososition rule
    x   = x0 + delta_x
    psi = CompositionRuleForRotationVectors(psi0, incRotVec)
    
    return np.block([x, psi])


@docmeta(author='Stefan Holzinger')
def CompositionRuleSemiDirectProductR3AndR3RotVec(q0, incrementalMotionVector):
    """compute composition operation for pairs in the group obtained from the direct product of R3 and R3.
    the rotation vector is used as rotation parametrizations
    this composition operation can be used in formulations which represent the translational velocities in the local (body-attached) frame

    Args:
        q0: 6D vector as np.array containing position coordinates and rotation vector
        incrementalMotionVector: 6D incremental motion vector as np.array

    Returns:
        6D vector as np.array containing composed position coordinates and composed rotation vector
    """
    
    # pair (x0, psi0)
    x0   = q0[0:3]  # global COM position at time step t0
    psi0 = q0[3:6]  # rotation vector at time step t0
    
    # pair (delta x, delta theta)
    delta_x   = incrementalMotionVector[0:3] # global position increment of COM at time step t
    incRotVec = incrementalMotionVector[3:6] # incremental rotation vector at time step t
    
    # compososition rule
    R0  = ExpSO3(psi0)
    x   = x0 + np.dot(R0, np.dot(np.transpose(TExpSO3(incRotVec)), delta_x))
    psi = CompositionRuleForRotationVectors(psi0, incRotVec)
    
    return np.block([x, psi])


@docmeta(author='Stefan Holzinger')
def CompositionRuleDirectProductR3AndR3RotXYZAngles(q0, incrementalMotionVector):
    """compute composition operation for pairs in the group obtained from the direct product of R3 and R3.
    Cardan-Tait/Bryan (CTB) angles are used as rotation parametrizations
    this composition operation can be used in formulations which represent the translational velocities in the global (inertial) frame

    Args:
        q0: 6D vector as np.array containing position coordinates and Cardan-Tait/Bryan angles
        incrementalMotionVector: 6D incremental motion vector as np.array

    Returns:
        6D vector as np.array containing composed position coordinates and composed Cardan-Tait/Bryan angles
    """
    
    # pair (x0, psi0)
    x0     = q0[0:3]  # global COM position at time step t0
    alpha0 = q0[3:6]  # Cardan-Tait/Bryan angles at time step t0
    
    # pair (delta x, delta theta)
    delta_x   = incrementalMotionVector[0:3] # global position increment of COM at time step t
    incRotVec = incrementalMotionVector[3:6] # incremental rotation vector at time step t
    
    # compososition rule
    x   = x0 + delta_x
    alpha = CompositionRuleRotXYZAnglesRotationVector(alpha0, incRotVec)
    
    return np.block([x, alpha])


@docmeta(author='Stefan Holzinger')
def CompositionRuleSemiDirectProductR3AndR3RotXYZAngles(q0, incrementalMotionVector):
    """compute composition operation for pairs in the group obtained from the direct product of R3 and R3.
    Cardan-Tait/Bryan (CTB) angles are used as rotation parametrizations
    this composition operation can be used in formulations which represent the translational velocities in the local (body-attached) frame

    Args:
        q0: 6D vector as np.array containing position coordinates and Cardan-Tait/Bryan angles
        incrementalMotionVector: 6D incremental motion vector as np.array

    Returns:
        6D vector as np.array containing composed position coordinates and composed Cardan-Tait/Bryan angles
    """
    
    # pair (x0, psi0)
    x0     = q0[0:3]  # global COM position at time step t0
    alpha0 = q0[3:6]  # Cardan-Tait/Bryan angles at time step t0
    
    # pair (delta x, delta theta)
    delta_x   = incrementalMotionVector[0:3] # global position increment of COM at time step t
    incRotVec = incrementalMotionVector[3:6] # incremental rotation vector at time step t
    
    # compososition rule
    R0    = RotXYZ2RotationMatrix(alpha0)
    x     = x0 + np.dot(R0, np.dot(np.transpose(TExpSO3(incRotVec)), delta_x))
    alpha = CompositionRuleRotXYZAnglesRotationVector(alpha0, incRotVec)
    
    return np.block([x, alpha])
 

@docmeta(author='Stefan Holzinger')
def CompositionRuleForEulerParameters(q, p):
    """compute composition operation for Euler parameters (unit quaternions)
    this composition operation is quaternion multiplication, see [Terze2016]

    Args:
        q: 4D vector as np.array containing Euler parameters
        p: 4D vector as np.array containing Euler parameters

    Returns:
        4D vector as np.array containing composed (multiplied) Euler parameters
    """
    p0 = p[0]
    pV = p[1:4]
    q0 = q[0]
    qV = q[1:4]
    x0 = q0*p0 - np.dot(qV,pV)
    xV = q0*pV + p0*qV + np.cross(qV,pV)
    return np.array([x0, xV[0], xV[1], xV[2]])


@docmeta(author='Stefan Holzinger')
def CompositionRuleForRotationVectors(v0, Omega):
    """compute composition operation for rotation vectors v0 and Omega, see [Holzinger2021]

    The composed vector is NOT mapped into the principal range: its norm lies in [0, 2*pi] and may
    therefore exceed pi. It always describes the correct rotation - ExpSO3 of it is the intended
    rotation matrix - but it need not be the shortest representative of it. Composing pi*n with
    itself, for example, gives a vector of norm 2*pi rather than 0; both are the identity rotation.
    This matches the C++ implementation EXUlie::CompositionRotationVector (src/Linalg/RigidBodyMath.h),
    which is the verified one used by the Lie group integrator, and is a deliberate decision
    (#2494): the formulas accept and pass on such noise rather than snapping to a boundary, which
    keeps every existing result unchanged. A caller who needs the principal range must map it - for
    a norm w > pi, use (2*pi - w) about the negated axis.

    Note also that accuracy degrades towards w = 2*pi, which is the singularity of the tangent
    operator: TExpSO3Inv() returns entries of order 1e15 there. Composing pi*n with itself is exact to
    about 1e-15 for any axis n; small rotation increments are kept down to the precision of the
    rotation vector (#3288).

    Args:
        v0: 3D rotation vector as np.array
        Omega: 3D (incremental) rotation vector as np.array

    Returns:
        3D vector as np.array containing composed rotation vector v; norm in [0, 2*pi], see above
    """
    w1Half = 0.5*norm(v0)
    w2Half = 0.5*norm(Omega)
    c0 = cos(w1Half)
    c1 = cos(w2Half)
    s0 = Sinc(w1Half)
    s1 = Sinc(w2Half)
    x = c0*c1 - 0.25*s0*s1*np.dot(v0,Omega)
    rho = s0*c1*v0 + c0*s1*Omega + 0.5*s0*s1*np.cross(v0, Omega)
    #x and rho/2 are the scalar and the vector part of the product of the unit quaternions: sin(w/2) = |rho|/2,
    #which keeps small angles that sqrt(1 - x**2) rounds to 0 below about 1e-8, as the C++ implementation
    #EXUlie::CompositionRotationVector (#3288)
    w = 2*atan2(0.5*norm(rho), x) #in [0, 2*pi], as pi - 2*atan2(x, sin(w/2)), without its cancellation
    n = ComputeRotationAxisFromRotationVector(rho)
    v = w*n
    return v


@docmeta(author='Stefan Holzinger')
def CompositionRuleRotXYZAnglesRotationVector(alpha0, Omega):
    """compute composition operation for RotXYZ angles, see [Holzinger2021]

    Args:
        alpha0: 3D vector as np.array containing RotXYZ angles
        Omega:  3D vector as np.array containing the (incremental) rotation vector

    Returns:
        3D vector as np.array containing composed RotXYZ angles
    """
  
    # Cardan-Tait/Bryan angles
    psi0   = alpha0[0]
    theta0 = alpha0[1]
    phi0   = alpha0[2]
    
    # define unit vectors
    e1 = np.array([1, 0, 0])
    e2 = np.array([0, 1, 0])
    e3 = np.array([0, 0, 1])
    
    # compute vectors u and v
    R0 = RotXYZ2RotationMatrix(alpha0)
    exp = ExpSO3(Omega)
    u1 = np.dot(e1, R0) 
    u2 = np.dot(e2, R0)
    u3 = np.dot(e3, R0)
    v1 = np.dot(exp, e1)
    v2 = np.dot(exp, e2)
    v3 = np.dot(exp, e3)
    u1v3 = np.dot(u1,v3)
    cosTheta = sqrt(1 - u1v3**2)
    
    # compute mu
    if cosTheta == 0.0:
        mu = 0
    else:
        mu = 1 / cosTheta
    
    # compute sine and cosine terms of incremental angle changes
    sinPsi0 = sin(psi0)
    cosPsi0 = cos(psi0)
    sinTheta0 = sin(theta0)
    cosTheta0 = cos(theta0)
    sinPhi0 = sin(phi0)
    cosPhi0 = cos(phi0)    
    u2v3 = np.dot(u2,v3)
    u3v3 = np.dot(u3,v3)
    u1v2 = np.dot(u1,v2)
    u1v1 = np.dot(u1,v1)    
    y1 = -u2v3*cosPsi0 - u3v3*sinPsi0
    x1 =  u3v3*cosPsi0 - u2v3*sinPsi0
    y2 = u1v3*cosTheta0 - cosTheta*sinTheta0
    x2 = cosTheta*cosTheta0 + u1v3*sinTheta0
    y3 = -u1v2*cosPhi0 - u1v1*sinPhi0
    x3 = u1v1*cosPhi0 - u1v2*sinPhi0
    
    # compute incremental angles changes
    deltaPsi   = atan2(mu*y1, mu*x1)
    deltaTheta = atan2(y2, x2)
    deltaPhi   = atan2(mu*y3, mu*x3)
    deltaAlpha = np.array([deltaPsi, deltaTheta, deltaPhi])
    
    return alpha0 + deltaAlpha




