#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# This is an EXUDYN python utility library
#
# Details:  Utilities for interactive simulation and results monitoring; NOTE: does not work on MacOS!
#
# Author:   Johannes Gerstmayr
# Date:     2021-01-17 (created)
#
# Copyright:This file is part of Exudyn. Exudyn is free software. You can redistribute it and/or modify it under the terms of the Exudyn license. See 'LICENSE.txt' for more details.
#
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Utility functions and structures for Exudyn

import numpy as np #LoadSolutionFile
from exudyn.cMath import sin, pi #for animation
#import time        
import copy           #copy numpy objects
import sys
import exudyn
from exudyn.basicUtilities import UIWindowSuppressed #exudyn.special.userInterface (#2477)
from exudyn.misc.extensionRegistry import extends

#inside a tkinter callback on macOS the renderer must not pump the events: tkinter and GLFW share one Cocoa event loop,
#and glfwPollEvents would run the dialog's own events (closing it, ...) nested in the callback, which aborts (#2878)
_pollEventsInTkCallback = sys.platform != 'darwin'

#%%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#THE INTERACTIVE DIALOGS THAT ARE OPEN - the SolutionViewer, the mode shapes, an interactive
#simulation - so that the store positions button of the settings dialog can store them with the
#other windows while they are open (#2720); a dialog removes itself when it closes
openDialogs = []

#THE COLUMNS OF A DIALOG TAKE THE WIDTH OF THE WINDOW (#2720): every widget is placed sticky in
#all directions, but a column without a weight keeps the width of its widest widget, so a wider
#window only added empty space on the right. Only the columns in which a slider starts take the
#width - and give it back when the window is narrower than the dialog asks for, which Tk takes
#from the weighted columns only: a weighted column of buttons was squeezed to nothing (#2722). A
#dialog without sliders stretches all columns but the first. And no column becomes narrower than
#the buttons and labels in it: Tk takes the missing width from a weighted column down to nothing,
#and a slider that spans into the next columns is what asks for the width, so the columns get the
#widths of their other widgets as their minimum
def ConfigureDialogColumns(tkWindow):
    """give the columns of a dialog's grid their weights and minimum widths; returns the number of
    columns"""
    import tkinter                                                          # noqa: PLC0415
    tkWindow.update_idletasks()                                             #the requested widths
    (nColumns, nRows) = tkWindow.grid_size()
    sliderColumns = set()
    minimumWidths = [0]*max(1, nColumns)
    for widget in tkWindow.grid_slaves():
        info = widget.grid_info()
        column = int(info['column'])
        if isinstance(widget, tkinter.Scale):
            sliderColumns.add(column)
        elif int(info.get('columnspan', 1)) == 1:
            minimumWidths[column] = max(minimumWidths[column], widget.winfo_reqwidth())
    for column in range(max(1, nColumns)):
        if sliderColumns:
            weight = 1 if column in sliderColumns else 0
        else:
            weight = 0 if (column == 0 and nColumns > 1) else 1
        tkWindow.columnconfigure(column, weight=weight, minsize=minimumWidths[column])
    return nColumns

#public API of this module; kept complete by tools/checkAll.py (#2444)
__all__ = [
    'openDialogs', 'ConfigureDialogColumns', 'WindowControls', 'InteractiveDialog', 'AnimateModes',
    'SolutionViewer', 'ShowImage', 'ConvertImages2Video', 'ExportedImagesLocation', 'InteractiveImages2Video',
    ]

class WindowControls:
    """The buttons and sliders of the render window, each with its own Python function (#3400): the class sets the one
    user function of SC.renderer (SetControlUserFunction) and calls the function of the element that changed, with its
    state - 0 or 1 for a button, the value of a slider. The functions are called in the main thread while a simulation
    runs or in SC.renderer.DoIdleTasks. An element without a location is placed in a column at the left side of the
    window, one below the other, starting below the texts which the renderer writes at the top left corner (#3402).

    Args:
        systemContainer: the SystemContainer whose render window shows the elements
        columnWidth: the width of the column of the elements without location, relative to the window width
        rowHeight: the height of each of them, relative to the window height
        top: the upper edge of the column, relative to the window height from its top

    Example:
        controls = WindowControls(SC)
        controls.Button('reset', function=lambda state: mbs.systemData.SetODE2Coordinates(q0))
        controls.Slider('stiffness', minMax=[100, 1000], value=500, function=lambda value: mbs.SetObjectParameter(oSpring, 'stiffness', value))
    """
    def __init__(self, systemContainer, columnWidth=0.22, rowHeight=0.055, top=0.25):
        self.systemContainer = systemContainer
        self.functions = {}  #the function of each element by its ID
        self.columnWidth = columnWidth
        self.rowHeight = rowHeight
        self.top = top
        self.nextRow = 0  #the row of the next element without location
        systemContainer.renderer.SetControlUserFunction(self._UserFunction)

    def _UserFunction(self, controlID, data):
        function = self.functions.get(controlID)
        if function is not None:
            function(data[0])

    def _Location(self, location):
        if location is not None:
            return location
        y0 = self.top + self.nextRow*(self.rowHeight + 0.01)
        self.nextRow += 1
        return [[0.01, y0], [0.01 + self.columnWidth, y0 + self.rowHeight]]

    def Button(self, text, location=None, function=None, toggle=False, state=0, **kwargs):
        """Add a button (SC.renderer.AddButton; fontSize, color, backgroundColor and view as keyword arguments as there);
        function(state) is called when it is released: with 1 for a push button,
        with the new state 0 or 1 for a toggle button

        Args:
            text: the label of the button
            location: [[x0, y0], [x1, y1]] relative to the window, from its top left corner; None: the next row of the column
            function: function(state), or None
            toggle: True: the button switches between 0 and 1
            state: the initial state of a toggle button

        Returns:
            the ID of the button
        """
        controlID = self.systemContainer.renderer.AddButton(text, location=self._Location(location), toggle=toggle, state=state, **kwargs)
        self.functions[controlID] = function
        return controlID

    def Slider(self, text, location=None, function=None, minMax=[0., 1.], value=None, format='= {:.3g}', **kwargs):
        """Add a slider (SC.renderer.AddSlider; fontSize, color, backgroundColor and view as keyword arguments as there);
        function(value) is called with each new value

        Args:
            text: the label of the slider, before its value
            location: [[x0, y0], [x1, y1]] relative to the window, from its top left corner; None: the next row of the column
            function: function(value), or None
            minMax: [min, max], the range of the value
            value: the initial value; None: min
            format: the value in the label, a Python format with {} or {:.Nf}, {:.Ne}, {:.Ng}; empty: no value

        Returns:
            the ID of the slider
        """
        controlID = self.systemContainer.renderer.AddSlider(text, location=self._Location(location), minMax=minMax, value=value,
                                                            format=format, **kwargs)
        self.functions[controlID] = function
        return controlID

    def State(self, controlID):
        """the state of a button, 0 or 1, or the value of a slider"""
        return self.systemContainer.renderer.GetControlState(controlID)[0]

    def SetState(self, controlID, state, callFunction=False):
        """set the state of a button or the value of a slider; with callFunction, its function is called as a click would"""
        self.systemContainer.renderer.SetControlState(controlID, state, callUserFunction=callFunction)

    def Delete(self, controlID):
        """remove an element and its function"""
        self.systemContainer.renderer.DeleteControl(controlID)
        self.functions.pop(controlID, None)

    def Clear(self):
        """remove all elements and their functions; the next element without location is in the first row again"""
        self.systemContainer.renderer.ClearControls()
        self.functions = {}
        self.nextRow = 0

class InteractiveDialog:
    """create an interactive dialog, which allows to interact with simulations
    the dialog has a 'Run' button, which initiates the simulation and a 'Stop' button which stops/pauses simulation; 'Quit' closes the simulation model
    for examples, see `simulateInteractively.py` and `massSpringFrictionInteractive.py`
    use __init__ method to setup this class with certain buttons, edit boxes and sliders

    Example:
        #the following example is only demonstrating the structure of dialogItems and plots
        #dialogItems structure:
        #general items:
        #    'type' can be out of:
        #               'label' (simple text),
        #               'button' (button with callback function),
        #               'radio' (a radio button with several alternative options),
        #               'slider' (with an adjustable range to choose a value)
        #    'grid': (row, col, colspan) specifies the row, column and (optionally) the span of columns the item is placed at;
        #            exception in 'radio', where grid is a list of (row, col) for every choice
        #    'options': text options, where 'L' means flush left, 'R' means flush right
        #suboptions of 'label':
        #               'text': a text to be drawn
        #suboptions of 'button':
        #               'text': a text to be drawn on button
        #               'callFunction': function which is called on button-press
        #suboptions of 'radio':
        #               'textValueList': [('text1',0),('text2',1)] a list of texts with according values
        #               'value': default value (choice) of radio buttons
        #               'variable': according variable in mbs.variables (or mbs.sys), which is set to current radio button value
        #suboptions of 'slider':
        #               'range': (min, max) a tuple containing minimum and maximum value of slider
        #               'value': default value of slider
        #               'steps': number of steps in slider
        #               'variable': according variable in mbs.variables (or mbs.sys), which is set to current slider value
        #example:
        dialogItems = [{'type':'label', 'text':'Nonlinear oscillation simulator', 'grid':(0,0,2), 'options':['L']},
                       {'type':'button', 'text':'test button','callFunction':ButtonCall, 'grid':(1,0,2)},
                       {'type':'radio', 'textValueList':[('linear',0),('nonlinear',1)], 'value':0, 'variable':'mode', 'grid': [(2,0),(2,1)]},
                       {'type':'label', 'text':'excitation frequency (Hz):', 'grid':(5,0)},
                       {'type':'slider', 'range':(3*f1/800, 3*f1), 'value':omegaInit/(2*pi), 'steps':800, 'variable':'frequency', 'grid':(5,1)},
                       {'type':'label', 'text':'damping:', 'grid':(6,0)},
                       {'type':'slider', 'range': (0, 40), 'value':damper, 'steps':800, 'variable':'damping', 'grid':(6,1)},
                       {'type':'label', 'text':'stiffness:', 'grid':(7,0)},
                       {'type':'slider', 'range':(0, 10000), 'value':spring, 'steps':800, 'variable':'stiffness', 'grid':(7,1)}]
        #plots structure:
        plots={'nPoints':500,              #number of stored points in subplots (higher means slower drawing)
               'subplots':(2,1),           #(rows, columns) arrangement of subplots (for every sensor)
               #sensors defines per subplot (sensor, coordinate), xlabel and ylabel; if coordinate=0, time is used:
               'sensors':[[(sensPos,0),(sensPos,1),'time','mass position'],
                          [(sensFreq,0),(sensFreq,1),'time','excitation frequency']],
               'limitsX':[(0,2),(-5,5)],   #x-range per subplot; if not provided, autoscale is applied
               'limitsY':[(-5,5),(0,10),], #y-range per subplot; if not provided, autoscale is applied
               'fontSize':16,              #custom font size for figure
               'subplots':False,           #if not specified, subplots are created; if False, all plots go into one window
               'lineStyles':['r-','b-'],    #if not specified, uses default '-b', otherwise define list of line styles [string for matplotlib.pyplot.plot] per sensor
               'sizeInches':(12,12)}       #specific x and y size of figure in inches (using 100 dpi)
    """
    def __init__(self, mbs, simulationSettings, simulationFunction, 
                 dialogItems, plots = None, period = 0.04, 
                 realtimeFactor = 1, userStartSimulation=None, 
                 title='',  showTime=False, fontSize = 12,
                 doTimeIntegration = True, runOnStart = False, 
                 addLabelStringVariables=False, addSliderVariables=False, 
                 checkRenderEngineStopFlag = True, userOnChange=None, useSysVariables=False,
                 windowSize=None, userSpaceKey=None):
        """initialize an InteractiveDialog

        Args:
            mbs: a multibody system to be simulated
            simulationSettings: exudyn.SimulationSettings() according to user settings
            simulationFunction: a user function(mbs, self) which is called before a simulation for the short period is started (e.g, assign special values, etc.); the arguments are the MainSystem mbs and the InteractiveDialog (self)
            dialogItems: a list of dictionaries, which describe the contents of the interactive items, where every dict has the structure {'type':[label, entry, button, slider, check] ... according to tkinter widgets, 'callFunction': a function to be called, if item is changed/button pressed, 'grid': (row,col) of item to be placed, 'rowSpan': number of rows to be used, 'columnSpan': number of columns to be used; for special item options see notes}
            plots: list of dictionaries to specify a sensor to be plotted live, see example; otherwise use default None
            period: a simulation time span in seconds which is simulated with the simulationFunction in every iteration
            realtimeFactor: if 1, the simulation is nearly performed in realtime (except for computation time); if > 1, it runs faster than realtime, if < 1, than it is slower
            userStartSimulation: a function F(flag) which is called every time after Run/Stop is pressed. The argument flag = False if button "Run" has been pressed, flag = True, if "Stop" has been pressed
            title: title text for interactive dialog
            showTime: shows current time in dialog
            fontSize: adjust font size for all dialog items
            doTimeIntegration: performs internal time integration with given parameters
            runOnStart: immediately activate 'Run' button on start
            addLabelStringVariables: True: adds a list labelStringVariables containing the (modifiable) list of string variables for label (text) widgets
            addSliderVariables: True: adds a list sliderVariables containing the (modifiable) list of variables for slider (=tkinter scale) widgets; this is not necessarily needed for changing slider values, as they can also be modified with dialog.widgets[..].set(...) method
            checkRenderEngineStopFlag: if True, stopping renderer (pressing Q or Escape) also causes stopping the interactive dialog
            userOnChange: a user function(mbs, self) which is called after period, if widget values are different from values stored in mbs.variables; this usually occurs if buttons are pressed or sliders are moved; the arguments are the MainSystem mbs and the InteractiveDialog (self)
            useSysVariables: for internal visualization functions: in this case, variables are written to mbs.sys instead of mbs.variables
            windowSize: [width, height] of the dialog in pixels; None gives the size stored in ~/.exudyn/config.json, or the size of the layout if nothing is stored. A size given here wins over a stored one, as a position given in a script wins for the render window
            userSpaceKey: a function F(dialog) called on the space key instead of starting or stopping the dialog; it calls dialog.StartSimulation() where it starts or stops, and dialog.simulationStopped says whether the dialog runs

        Note:
            detailed description of dialogItems and plots list/dictionary is given in commented the example below
        """
        #an automated run must not open a dialog that waits for a human (#2477); the object is
        #created but does nothing, so that a caller holding on to it does not fail
        self.suppressed = UIWindowSuppressed('Dialogs', 'InteractiveDialog')
        if self.suppressed: return

        try:
            import tkinter
            import tkinter.font as tkFont
            from exudyn.misc.GUI import (GetTkRootAndNewWindow, RestoreWindowGeometry,
                                        RememberWindowGeometry)
        except ImportError:
            raise ValueError('ERROR: InteractiveDialog: tkinter is not installed; InteractiveDialog or SolutionViewer are therefore not available')

        
        #store init arguments
        self.mbs = mbs
        self.SC = mbs.GetSystemContainer()
        self.simulationFunction = simulationFunction
        self.simulationSettings = simulationSettings
        self.title = title
        self.dialogItems = dialogItems
        self.period = period
        self.realtimeFactor = realtimeFactor
        self.stepSize = simulationSettings.timeIntegration.endTime/simulationSettings.timeIntegration.numberOfSteps
        self.doTimeIntegration = doTimeIntegration

        self.plots = plots
        self.userStartSimulation = userStartSimulation
        self.userSpaceKey = userSpaceKey
        self.userOnChange = userOnChange
        self.showTime = showTime
        self.fontSize = fontSize
        self.useSysVariables = useSysVariables
        
        self.checkRenderStop = checkRenderEngineStopFlag

        if self.plots is None:
            self.plots = []

        if self.mbs.GetRenderEngineStopFlag() and self.checkRenderStop: #avoid immediate quit
            self.mbs.SetRenderEngineStopFlag(False)


        #create tkinter instance
        [self.root, self.tkWindow, tkRuns] = GetTkRootAndNewWindow()

        # root = self.root = tkinter.Tk()
        #exudyn.sys['tkinterRoot'] = root #not needed anymore, as GUI.GetTkRootAndNewWindow() is used
        self.tkWindow.protocol("WM_DELETE_WINDOW", self.OnQuit) #always leave app with OnQuit
        self.tkWindow.title(title)
        try:
            systemScaling = self.tkWindow.call('tk', 'scaling') #obtains current scaling?
        except Exception:
            pass
        systemScaling = 1

        if (self.doTimeIntegration 
            and self.simulationSettings.solution.file.writeInitialValues 
            and mbs.systemData.AEsize() != 0):
            exudyn.Print('WARNING: InteractiveDialog:\nyou should set simulationSettings.solution.file.writeInitialValues = False in order to avoid erroneous constraint outputs during time integration periods.\n')

        #change global font size
        if True:
            defaultFont = tkFont.Font(root=self.tkWindow, family = "TkDefaultFont")#,weight = "bold")
            defaultFont.configure(size=int(systemScaling*self.fontSize))
            self.tkWindow.option_add("*Font", "TkDefaultFont") #all widgets should use TkDefaultFont; does not work
        
        self.counter = 0 #counter for simulationFunction
        self.simulationStopped = True
        self.variableList = [] #list of tuples: (widget, mbs variable name); value obtained with widget.get()

        self.itemBorder = 2 #common border to items

        tkinterNESW = tkinter.N+tkinter.E+tkinter.S+tkinter.W
        
        self.widgets = [] #store tk widgets as list, for later access
        self.labelStringVariables = [] #store string variables to modify widget text hereafter
        self.sliderVariables = [] #store string variables to modify widget text hereafter

        for item in dialogItems:
            text = ''
            setGrid = False
            # sticky = 'NSEW'
           
            if 'text' in item:
                text = item['text']
            # if 'sticky' in item:
            #     sticky = item['sticky']
            #++++++++++++++++++++++++++++++++++
            if item['type'] == 'label':
                setGrid = True
                if addLabelStringVariables:
                    stringVar = tkinter.StringVar()
                    widget = tkinter.Label(self.tkWindow, textvariable = stringVar, 
                                           borderwidth = self.itemBorder, 
                                           #justify=tkinter.LEFT, #needed?
                                           font=defaultFont)
                    stringVar.set(text)
                    self.labelStringVariables += [stringVar] #store in list
                else:
                    widget = tkinter.Label(self.tkWindow, text = text, 
                                           borderwidth = self.itemBorder, 
                                           font=defaultFont)

            #++++++++++++++++++++++++++++++++++
            elif item['type'] == 'button':
                setGrid = True
                widget = tkinter.Button(self.tkWindow, text = text, 
                                       borderwidth = self.itemBorder, 
                                       font=defaultFont)
                if 'callFunction' in item:
                    widget['command'] = item['callFunction']
            #++++++++++++++++++++++++++++++++++
            elif item['type'] == 'slider':
                setGrid = True
                steps = 400
                minValue = 0
                maxValue = 1
                initialValue = 0.5
                if 'steps' in item:
                    steps = item['steps']
                if 'range' in item:
                    minValue = item['range'][0]
                    maxValue = item['range'][1]
                if 'value' in item:
                    initialValue = item['value']
                if initialValue < minValue or initialValue > maxValue:
                    initialValue = 0.5*(minValue+maxValue)
                resolutionItem = (maxValue-minValue)/max(1,(steps-1))
                if 'resolution' in item: #resolution is needed, if we want to do bi-directional set/get of slider values (otherwise digits are lost)
                     resolutionItem = item['resolution']

                nDigits = 4
                if maxValue-minValue == steps-1:
                    nDigits = 0
                
                if not addSliderVariables:
                    widget = tkinter.Scale(self.tkWindow, from_=minValue, to=maxValue,
                                           length = steps, digits=nDigits, resolution=resolutionItem,
                                           orient=tkinter.HORIZONTAL,
                                           font=defaultFont)
                    widget.set(initialValue)
                else:
                    #add option to modify scale from outside
                    tkVariable = tkinter.DoubleVar()
                    tkVariable.set(initialValue)
                    widget = tkinter.Scale(self.tkWindow, from_=minValue, to=maxValue,
                                           length = steps, digits=nDigits, resolution=resolutionItem,
                                           orient=tkinter.HORIZONTAL,
                                           variable=tkVariable,
                                           font=defaultFont)
                    self.sliderVariables += [tkVariable]
                    #but using widget.set(..) also allows to adjust widget from external function!
                    
                if 'callFunction' in item:
                    widget['command'] = self.item['callFunction']
                if 'variable' in item:
                    self.variableList += [(widget, item['variable'])]

            #++++++++++++++++++++++++++++++++++
            elif item['type'] == 'radio':
                var = tkinter.IntVar()
                var.set(item['value'])
                cnt = 0
                for opt in item['textValueList']:
                    widget = tkinter.Radiobutton(self.tkWindow, 
                                                text=opt[0],
                                                padx = 20, 
                                                variable=var, 
                                                value=opt[1], 
                                                #height=1, width=1, 
                                                indicatoron=0, #use highlighting instead of checkboxes
                                                font=defaultFont)
                    if 'grid' in item:
                        grid = item['grid'][cnt] #must be list of grid values
                        if len(grid) == 2:
                            widget.grid(row=grid[0], column=grid[1], sticky=tkinterNESW)
                        elif len(grid) == 3:
                            widget.grid(row=grid[0], column=grid[1], columnspan=grid[2], sticky=tkinterNESW)
                    # not needed, all flush left
                    # if 'options' in item:
                    #     if 'L' in item['options']:
                    #         widget['anchor'] = 'w'
                    #     if 'R' in item['options']:
                    #         widget['anchor'] = 'e'
                    else:
                        widget.grid(column=0, sticky=tkinter.W)
                    cnt+=1
                self.variableList += [(var, item['variable'])] #store widget variable and mbs variable
            #++++++++++++++++++++++++++++++++++
            if setGrid:
                if 'grid' in item:
                    grid = item['grid']
                    if len(grid) == 2:
                        widget.grid(row=grid[0], column=grid[1], sticky=tkinterNESW)
                    elif len(grid) == 3:
                        widget.grid(row=grid[0], column=grid[1], columnspan=grid[2], sticky=tkinterNESW)
                    elif len(grid) == 4:
                        widget.grid(row=grid[0], column=grid[1], columnspan=grid[2], rowspan=grid[3], sticky=tkinterNESW)
                    else:
                        raise ValueError("ERROR: InteractiveDialog: grid must have 2, 3, or 4 components")
                else:
                    widget.grid(column=0, sticky=tkinterNESW)
                if 'options' in item:
                    if 'L' in item['options']:
                        widget['anchor'] = 'w'
                    if 'R' in item['options']:
                        widget['anchor'] = 'e'
            self.widgets += [widget]
            # if item['type'] == 'entry' and firstEntry: #entry may get focus
            #     firstEntry = False
            #     widget.focus_set() #set focus to first item
                
        #show current time 
        if self.showTime:
            self.currentTime = tkinter.StringVar()
            widget = tkinter.Label(self.tkWindow, textvariable = self.currentTime, 
                                   borderwidth = self.itemBorder, justify=tkinter.LEFT,
                                   font=defaultFont)
            self.currentTime.set('t = ')
            widget.grid(column=0, sticky=tkinter.W)

        nColumns = ConfigureDialogColumns(self.tkWindow)

        #add run button into last row:
        self.RunButtonText = tkinter.StringVar()
        self.Run = tkinter.Button(self.tkWindow, textvariable=self.RunButtonText,
                                  borderwidth = self.itemBorder, font=defaultFont)
        self.RunButtonText.set('Run')
        
        #across all columns, so that it follows the width of the window as the sliders do
        self.Run.grid(column=0, columnspan=max(1, nColumns), sticky=tkinterNESW)
        self.Run['command'] = self.StartSimulation
        self.Run.focus_set() #does not work
        
        self.tkWindow.bind('<space>', func=self.OnSpaceKey)
        #the Run button runs its command on the space key by itself when it has the focus (macOS); this binding comes
        #first and 'break' ends the handling there, so the key acts once (#2931)
        self.Run.bind('<space>', lambda event: (self.OnSpaceKey(event), 'break')[1])
        self.tkWindow.bind('<Escape>', self.OnQuit) #Escape causes immediate quit (no further checks)
        self.tkWindow.bind('q', self.OnQuit) #Button 'Q' causes immediate quit (no further checks)

        self.tkWindow.update()
        if self.tkWindow.winfo_width() < 320:
            self.tkWindow.minsize(320,self.tkWindow.winfo_height())
        #self.tkWindow.minsize(280,50) #will create windows which are too small

        #WHERE THIS DIALOG WAS LEFT (#2689). The SolutionViewer, the
        #mode shapes and an interactive simulation are all this window, so all of them remember
        #themselves, each under its own title. The size is only overridden if something IS stored -
        #otherwise the layout above decides, which is why width and height are not given - and the
        #position only if the window would still be reachable. Storing happens when the dialog
        #closes and only if visualizationSettings.dialogs.storeDialogPositions is on
        self.dialogName = title
        try:
            RestoreWindowGeometry(self.tkWindow, self.dialogName)
            if windowSize is not None:               #given in the script: it wins over a stored size
                self.tkWindow.geometry(str(int(windowSize[0])) + 'x' + str(int(windowSize[1])))
            self.recordedGeometry = RememberWindowGeometry(self.tkWindow, self.dialogName)
        except Exception as error:                                           # noqa: BLE001
            self.recordedGeometry = {}
            exudyn.Print('WARNING: InteractiveDialog could not restore its window: ' + str(error))

        openDialogs.append(self)

        self.InitializeSolver() #solver gets ready to be called repeatedly
        self.InitializePlots()  #set up all structures for plots
        self.UpdatePlots()      #update all subplots with new sensor values

        if runOnStart:          #immediately activate run function on startup
            self.StartSimulation()
        self.tkWindow.deiconify()
        # self.tkWindow.mainloop()
        tkinter.mainloop()

    def OnQuit(self, event=None):
        """function called when pressing escape or closing dialog
        """
        self.simulationStopped = True
        self.RunButtonText.set('Stop')
        self.FinalizeSolver()
        #where it was, before it is gone: the geometry cannot be read
        #after the window is destroyed, which is what RememberWindowGeometry recorded it for
        try:
            from exudyn.misc.GUI import StoreWindowGeometry                  # noqa: PLC0415

            StoreWindowGeometry(self.recordedGeometry, self.dialogName)
        except Exception as error:                                           # noqa: BLE001
            exudyn.Print('WARNING: InteractiveDialog could not store its window: ' + str(error))
        if self in openDialogs:
            openDialogs.remove(self)
        #del exudyn.sys['tkinterRoot'] #this is not thread safe, but interuption should not happen ...
        self.tkWindow.quit()
        self.tkWindow.destroy()
        if sys.platform == 'darwin':
            #on macOS the window stays on the screen, empty, until Tk processes its events (#2906)
            import tkinter                                                   # noqa: PLC0415
            if tkinter._default_root is not None:
                try:
                    tkinter._default_root.update()
                except tkinter.TclError:
                    pass

    def OnSpaceKey(self, event=None):
        """the space key starts or stops, as the button does - or does what userSpaceKey says"""
        if self.userSpaceKey is not None:
            self.userSpaceKey(self)
        else:
            self.StartSimulation()

    def StartSimulation(self, event=None):
        """function called on button 'Run'
        """
        self.simulationStopped = not self.simulationStopped
        if not self.simulationStopped:
            self.RunButtonText.set('Stop')
        else:
            self.RunButtonText.set('Run')

        if self.userStartSimulation is not None:
            self.userStartSimulation(self.simulationStopped)
        #self.ProcessWidgetStates() #do this finally, to update states, which may have changed in last step (SolutionViewer!)
        self.ContinuousRunFunction()

    def ProcessWidgetStates(self):
        """assign current values of radio buttons and sliders to mbs.variables or mbs.sys
        """
        changed = False
        for var in self.variableList:
            v = var[0].get()
            if self.useSysVariables:
                destinationDict = self.mbs.sys #this is a link!
            else:
                destinationDict = self.mbs.variables
            if var[1] not in destinationDict or v != destinationDict[var[1]]:
                destinationDict[var[1]] = v
                changed = True
        if changed and self.userOnChange is not None:
            self.userOnChange(self.mbs, self) #this user function is called every time a value has changed, within update period

    def ContinuousRunFunction(self, event=None):
        """function which is repeatedly called when button 'Run' is pressed
        """
        if not self.simulationStopped:
            self.ProcessWidgetStates()
            self.SC.renderer.DoIdleTasks(0, pollEvents=_pollEventsInTkCallback) #for MacOS, but also to open visualization dialog, etc.

            if self.mbs.GetRenderEngineStopFlag() and self.checkRenderStop:
                self.OnQuit()
            else:
                t = self.RunSimulationPeriod()
                if self.showTime:
                    self.currentTime.set('t = '+str(round(t,6)))
                self.counter += 1
                delay = max(1, int(self.period*1000/self.realtimeFactor))
                self.tkWindow.after(delay, self.ContinuousRunFunction)
                # self.Run.after(delay, self.ContinuousRunFunction)

    #%%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    def InitializePlots(self):
        """initialize figure and subplots for plots structure
        """
        if len(self.plots) != 0:
            import matplotlib.pyplot as plt
            plt.rcParams.update({'font.size': self.plots['fontSize']})
        
            fig = plt.figure()
            fig.dpi = 100 #in terminal, initially set to 200
            fig.tight_layout()
            if 'sizeInches' in self.plots: #otherwise use default figure size
                fig.set_size_inches(self.plots['sizeInches'][0], self.plots['sizeInches'][1], forward=True)
            nPoints = self.plots['nPoints']
            self.plots['fig'] = fig
            self.plots['currentIndex'] = 0
            nSensors = len(self.plots['sensors'])
            self.plots['data'] = [np.zeros((nPoints,2))]*nSensors
            self.plots['line'] = [0]*nSensors
            self.plots['marker'] = [0]*nSensors
            self.plots['ax'] = [0]*nSensors
            lineStyle = 'b-'
            doSubplots = True
            if 'subplots' in self.plots:
                doSubplots = self.plots['subplots']
            if not doSubplots:
                axPlot = fig.add_subplot(1,1,1)
        
            for j in range(nSensors):
                if doSubplots:
                    self.plots['ax'][j] = fig.add_subplot(self.plots['subplots'][0],self.plots['subplots'][1],j+1)
                else:
                    self.plots['ax'][j] = axPlot
                self.plots['ax'][j].grid(True, 'major', 'both')
                self.plots['ax'][j].set_xlabel(self.plots['sensors'][j][2])
                self.plots['ax'][j].set_ylabel(self.plots['sensors'][j][3])
                
                data = np.zeros((nPoints,2))
                if self.plots['sensors'][j][0][1] == 0: #time of sensor
                    data[:,0] = np.linspace(self.period,nPoints*self.period,num=nPoints)
                #data[:,1] = 0 #not needed
                self.plots['data'][j] = copy.deepcopy(data)
                
                if 'lineStyles' in self.plots:
                    lineStyle = self.plots['lineStyles'][j]
                self.plots['line'][j], = self.plots['ax'][j].plot(data[:,0],data[:,1], lineStyle)
                self.plots['marker'][j], = self.plots['ax'][j].plot(0,0, 'ro') #red circle
                self.plots['ax'][j].set_xlim(min(data[:,0]), max(data[:,0]))

    def UpdatePlots(self):
        """update all subplots with current sensor values
        """
        if len(self.plots) != 0:
            n = self.plots['nPoints']
            i = self.plots['currentIndex']
            t = self.simulationSettings.timeIntegration.startTime #current time
    
            for j in range(len(self.plots['sensors'])):
                data = self.plots['data'][j]
                
                sensorNum = [0,0]
                sensorCoord = [0,0]
                for k in range(2):
                    sensorNum = self.plots['sensors'][j][k][0]
                    sensorCoord = self.plots['sensors'][j][k][1]
                    if sensorCoord == 0:
                        data[i,k] = t
                    else:
                        value = self.mbs.GetSensorValues(sensorNum)
                        if type(value)==np.ndarray:
                            data[i,k] = value[sensorCoord-1]
                        elif sensorCoord == 1:
                            data[i,k] = value
                        else:
                            raise ValueError('ERROR: InteractiveDialog: plots.sensor '+str(j)+': access to invalid coordinate')
                            
                self.plots['line'][j].set_data(data[:,0], data[:,1]) 
                self.plots['marker'][j].set_data([data[i,0]], [data[i,1]]) 
    
                self.plots['ax'][j].set_xlim(min(data[:,0]), max(data[:,0]))
                
                if 'limitsX' in self.plots:
                    if len(self.plots['limitsX'][j]):
                        self.plots['ax'][j].set_xlim(self.plots['limitsX'][j][0],self.plots['limitsX'][j][1])
                if 'limitsY' in self.plots:
                    if len(self.plots['limitsY'][j]):
                        self.plots['ax'][j].set_ylim(self.plots['limitsY'][j][0],self.plots['limitsY'][j][1])
                #autoscale, if no limits given
                self.plots['ax'][j].relim(visible_only=True)
                self.plots['ax'][j].autoscale_view(tight=True)
            
            #update figure:
            self.plots['fig'].canvas.draw()
            self.plots['fig'].canvas.flush_events()
    
            if i < n-1:
                self.plots['currentIndex'] += 1
    
            for j in range(len(self.plots['sensors'])):
                data = self.plots['data'][j]
                if i == n-1:
                    data = np.roll(data, -1, axis=0)
                self.plots['data'][j] = data #data references mbs variable


    #%%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    def InitializeSolver(self):
        """function to initialize solver for repeated calls
        """
        if self.doTimeIntegration:
            self.mbs.sys['solver'] = exudyn.MainSolverImplicitSecondOrder()
            self.mbs.sys['solver'].InitializeSolver(self.mbs, self.simulationSettings)

    def FinalizeSolver(self):
        """stop solver (finalize correctly)
        """
        if self.doTimeIntegration:
            self.mbs.sys['solver'].FinalizeSolver(self.mbs, self.simulationSettings) #shut down solver correctly (finalize files, ...)


    def RunSimulationPeriod(self):
        """function which performs short simulation for given period
        """
        deltaT = self.period
        h = self.stepSize
        mbs = self.mbs

        #+++++++++++++++++++++++++++++++++++++++++
        #this is the USER PART
        self.simulationFunction(self.mbs, self)
        #+++++++++++++++++++++++++++++++++++++++++
    
        if self.doTimeIntegration and False: #slow way, always start/stop simulation; resets sensor data ...
            self.simulationSettings.timeIntegration.numberOfSteps = max(int(deltaT/h),1)
            self.simulationSettings.timeIntegration.endTime = self.simulationSettings.timeIntegration.startTime+deltaT
            exudyn.SolveDynamic(mbs, self.simulationSettings, updateInitialValues=True)
            self.simulationSettings.timeIntegration.startTime += deltaT
    
        #+++++++++++++++++++++++++++++++++++++++++
        #PLOT PART, done every time before simulation starts
        self.UpdatePlots()
    
        #+++++++++++++++++++++++++++++++++++++++++
        #TIME STEPPING PART
        if self.doTimeIntegration and True:
        
            self.simulationSettings.timeIntegration.numberOfSteps = max(int(deltaT/h),1)
            self.simulationSettings.timeIntegration.endTime = self.simulationSettings.timeIntegration.startTime+deltaT

            #update 2023-01-06: also update accelerations, needed for implicit solvers!
            #initial accelerations are set sero in initialization ...
            initAcc = mbs.systemData.GetODE2Coordinates_tt(configuration = exudyn.ConfigurationType.Current)
            #not needed, if simulationSettings.solution.file.writeInitialValues = False 
            #initAE = mbs.systemData.GetAECoordinates(configuration = exudyn.ConfigurationType.Current) 

            mbs.sys['solver'].InitializeSolverInitialConditions(mbs, self.simulationSettings) #needed to update simulationSettings in solver

            mbs.systemData.SetODE2Coordinates_tt(coordinates = initAcc)
            #mbs.systemData.SetAECoordinates(coordinates = initAE)

            mbs.sys['solver'].SolveSteps(mbs, self.simulationSettings)
            
            #get current values and update initial conditions for next step:
            currentState = mbs.systemData.GetSystemState()
            mbs.systemData.SetSystemState(systemStateList=currentState, configuration = exudyn.ConfigurationType.Initial)
            # mbs.systemData.SetODE2Coordinates_tt(coordinates = mbs.systemData.GetODE2Coordinates_tt(), 
            #                                         configuration = exudyn.ConfigurationType.Initial)
        
            self.simulationSettings.timeIntegration.startTime += deltaT
    
        return self.simulationSettings.timeIntegration.endTime #return current time for dialog


#%%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def AnimateModes(systemContainer, mainSystem, nodeNumber, period = 0.04, stepsPerPeriod = 30, showTime = True, 
                 renderWindowText = '', runOnStart = False, runMode=0, scaleAmplitude = 1, title='', fontSize = 12,
                 checkRenderEngineStopFlag = True, systemEigenVectors=None):
    r"""animate modes of ObjectFFRFreducedOrder, of nodal coordinates (changes periodically one nodal coordinate) or of a list of system modes provided as list of lists; for creating snapshots, press 'Static' and 'Record frames' and press 'Run' to save one figure in the image subfolder; for creating animations for one mode, use the same procedure but use 'One Cycle'. Modes may be inverted by pressing according '+' and '-' buttons next to Amplitude.

    Args:
        systemContainer: system container (usually SC) of your model, containing visualization settings
        mainSystem: system (usually mbs) containing your model
        nodeNumber: node number of which the coordinates shall be animated. In case of ObjectFFRFreducedOrder, this is the generic node, e.g., 'nGenericODE2' in the dictionary returned by the function AddObjectFFRFreducedOrderWithUserFunctions(...); if nodeNumber=None, then the systemEigenVectors list is used
        period: delay for animation of every frame; the default of 0.04 results in approximately 25 frames per second
        stepsPerPeriod: number of steps into which the animation of one cycle of the mode is split into
        showTime: show a virtual time running from 0 to 2*pi during one mode cycle
        renderWindowText: additional text written into renderwindow before 'Mode X' (use $\backslash$n to add line breaks)
        runOnStart: immediately go into 'Run' mode
        runMode: 0=continuous run, 1=static continuous, 2=one cycle, 3=static (use slider/mouse to vary time steps)
        scaleAmplitude: additional scaling for amplitude if necessary
        fontSize: define font size for labels in InteractiveDialog
        title: if empty, it uses default; otherwise define specific title
        checkRenderEngineStopFlag: if True, stopping renderer (pressing Q or Escape) also causes stopping the interactive dialog
        systemEigenVectors: may be a list of lists of system eigenvectors for ODE2 (and possibly ODE1) coordinates or a eigenvector matrix containing mode vectors in columns; if nodeNumber=None, these eigenvectors are then used to be animated

    Returns:
        opens interactive dialog with further settings

    Note:
        Uses class InteractiveDialog in the background, which can be used to adjust animation creation. If meshes are large, animation artifacts may appear, which are resolved by using a larger update period.
        Press 'Run' to start animation; Chose 'Mode shape', according component for contour plot; to record one cycle for animation, choose 'One cycle', run once to get the according range in the contour plot, press 'Record frames' and press 'Run', now images can be found in subfolder 'images' (for further info on animation creation see [Section](#sec:overview:basics:animations)); now deactivate 'Record frames' by pressing 'Off' and chose another mode
    """
    SC = systemContainer
    mbs = mainSystem
    SC.visualizationSettings.general.graphicsUpdateInterval = 0.25*min(period, 2e-3) #set according update interval!
    SC.visualizationSettings.general.showSolverTime = showTime
    #SC.visualizationSettings.view0.window.showComputationInfo = False
    SC.visualizationSettings.general.showSolverInformation = False
    SC.visualizationSettings.general.renderWindowString = renderWindowText+'mode 0'
    
    if nodeNumber is not None:
        coordIndex = mbs.GetNodeODE2Index(nodeNumber)
        nodeCoords = mbs.GetNodeOutput(nodeNumber,exudyn.OutputVariableType.Coordinates,exudyn.ConfigurationType.Reference)
        numberOfModes = len(nodeCoords)
    else:
        if type(systemEigenVectors) == np.ndarray:
            systemEigenVectors = systemEigenVectors.T.tolist()

        if type(systemEigenVectors) != list or len(systemEigenVectors)==0:
            raise ValueError('AnimateModes: in case that nodeNumber=None, systemEigenVectors must be non-empty list of system eigenvectors, but received ',systemEigenVectors)
                
        numberOfModes = len(systemEigenVectors)
        coordIndex = None #this indicates that systemEigenVectors are used
        for vec in systemEigenVectors:
            if type(vec) != list or len(vec) < mbs.systemData.ODE2Size():
                raise ValueError('AnimateModes: in case that nodeNumber=None, systemEigenVectors must at least have ODE2 size components')

    if UIWindowSuppressed('SolutionViewer', 'AnimateModes'): return

    if (runMode < 0 or runMode > 3):
        raise ValueError('AnimateModes: illegal run mode:', runMode)
    
    #use interactive dialog:
    dialogItems = [
                   {'type':'label', 'text':'Mode shape:', 'grid':(1,0)},
                   {'type':'slider', 'range':(0, numberOfModes-1), 'value':0, 'steps':numberOfModes, 'variable':'modeShapeModeNumber', 'grid':(1,1,3)},
                   {'type':'label', 'text':'Contour plot:', 'grid':(2,0)},
                   {'type':'radio', 'textValueList':[('None',int(exudyn.OutputVariableType._None)),
                                                     ('DisplacementLocal',int(exudyn.OutputVariableType.DisplacementLocal)),
                                                      ('Displacement',int(exudyn.OutputVariableType.Displacement)),
                                                      ('StressLocal',int(exudyn.OutputVariableType.StressLocal)),
                                                      ('StrainLocal',int(exudyn.OutputVariableType.StrainLocal))], 
                    'value':int(exudyn.OutputVariableType.DisplacementLocal), 'variable':'modeShapeOutputVariable', 'grid': [(3,0),(3,1),(3,2),(3,3),(3,4)]},
                   {'type':'label', 'text':'Contour Component (use -1 for norm):', 'grid':(4,0)},
                   {'type':'slider', 'range':(-1, 5), 'value':0, 'steps':7, 'variable':'modeShapeComponent', 'grid':(4,1,3)},
                   {'type':'label', 'text':'Amplitude:', 'grid':(5,0)},
                   {'type':'slider', 'range':(0, 1), 'value':0.05, 'steps':501, 'variable':'modeShapeAmplitude', 'grid':(5,1)},
                   {'type':'radio', 'textValueList':[('positive',1), ('negative',-1)],'value':1, 'variable':'modeSignAmplitude', 'grid': [(5,2),(5,3)]},
                   {'type':'label', 'text':'update period:', 'grid':(6,0)},
                   {'type':'slider', 'range':(0.01, 2), 'value':0.04, 'steps':200, 'variable':'modeShapePeriod', 'grid':(6,1,3)},
                   {'type':'radio', 'textValueList':[('Continuous run',0), ('Static continuous',1), ('One cycle',2), ('Static once',3)],'value':runMode, 'variable':'modeShapeRunModus', 'grid': [(7,0),(7,1),(7,2),(7,3)]},
                   {'type':'radio', 'textValueList':[('Mesh+Faces',3), ('Faces only',1), ('Mesh only',2)],'value':3, 'variable':'modeShapeMesh', 'grid': [(8,0),(8,1),(8,2)]},
                   {'type':'radio', 'textValueList':[('Record frames',0), ('No recording',1)],'value':1, 'variable':'modeShapeSaveImages', 'grid': [(9,0),(9,1)]},
                   ]

    mbs.sys['modeShapePeriod'] = period
    mbs.sys['modeShapeStepsPerPeriod'] = stepsPerPeriod
    mbs.sys['modeShapeTimeIndex'] = 0
    mbs.sys['modeShapeLastSetting'] = [-1,0,0,0]
    mbs.sys['modeShapeNodeCoordIndex'] = coordIndex
    mbs.sys['modeShapeSystemEigenVectors'] = systemEigenVectors
    mbs.sys['modeShapeScaleAmplitude'] = scaleAmplitude
    mbs.sys['modeSignAmplitude'] = 1

    def UFshowModes(mbs, dialog):
        i = mbs.sys['modeShapeTimeIndex']
        mbs.sys['modeShapeTimeIndex'] += 1
        stepsPerPeriod = mbs.sys['modeShapeStepsPerPeriod']
        amplitude = mbs.sys['modeShapeAmplitude']*mbs.sys['modeSignAmplitude']
        if amplitude == 0:
            SC.visualizationSettings.bodies.deformationScaleFactor = 0
            amplitude = 1
        else:
            SC.visualizationSettings.bodies.deformationScaleFactor = 1

        if mbs.sys['modeShapeRunModus'] == 1 or mbs.sys['modeShapeRunModus'] == 3: #no sin(t) in static case
            stepsPerPeriod = 1
            t = 0
        else:
            t = i/stepsPerPeriod * 2 * pi
            amplitude *= sin(t)
        mbs.systemData.SetTime(t, exudyn.ConfigurationType.Visualization)
        
        selectedMode = int(mbs.sys['modeShapeModeNumber'])
        outputVariable = exudyn.OutputVariableType(int(mbs.sys['modeShapeOutputVariable']))
       
        if mbs.sys['modeShapeNodeCoordIndex'] is not None:
            ode2Coords = mbs.systemData.GetODE2Coordinates()
            ode2Coords[mbs.sys['modeShapeNodeCoordIndex']+selectedMode] = amplitude * mbs.sys['modeShapeScaleAmplitude']
            mbs.systemData.SetODE2Coordinates(ode2Coords, exudyn.ConfigurationType.Visualization)
        else:
            ode2Size = mbs.systemData.ODE2Size()
            ode1Size = mbs.systemData.ODE1Size()
            modeVector = np.array(mbs.sys['modeShapeSystemEigenVectors'][selectedMode])
            ode2Coords = amplitude * modeVector[0:ode2Size]
            mbs.systemData.SetODE2Coordinates(ode2Coords, exudyn.ConfigurationType.Visualization)
            if ode1Size != 0 and len(modeVector) >= ode2Size+ode1Size:
                ode1Coords = amplitude * modeVector[ode2Size:ode2Size+ode1Size]
                mbs.systemData.SetODE1Coordinates(ode1Coords, exudyn.ConfigurationType.Visualization)


        SC.visualizationSettings.contour.reduceRange = False
        #check, if automatic range of contour colors shall be recomputed:
        if (  mbs.sys['modeShapeLastSetting'][0] != int(mbs.sys['modeShapeModeNumber']) or 
              mbs.sys['modeShapeLastSetting'][1] != int(mbs.sys['modeShapeOutputVariable']) or
              mbs.sys['modeShapeLastSetting'][2] != mbs.sys['modeShapeAmplitude'] or
              mbs.sys['modeShapeLastSetting'][3] != int(mbs.sys['modeShapeComponent'])):
            SC.visualizationSettings.contour.reduceRange = True
            SC.visualizationSettings.general.renderWindowString = renderWindowText+'mode '+str(int(mbs.sys['modeShapeModeNumber']))
        
        mbs.sys['modeShapeLastSetting'] = [int(mbs.sys['modeShapeModeNumber']),
                                           int(mbs.sys['modeShapeOutputVariable']),
                                           mbs.sys['modeShapeAmplitude'],
                                           int(mbs.sys['modeShapeComponent'])]


        SC.visualizationSettings.contour.outputVariable = outputVariable
        SC.visualizationSettings.contour.outputVariableComponent = int(mbs.sys['modeShapeComponent']) #component

        #SC.visualizationSettings.view0.scene.showFaces = (mbs.sys['modeShapeMesh'] & 1) == 1
        SC.visualizationSettings.view0.scene.showMeshFaces = (mbs.sys['modeShapeMesh'] & 1) == 1

        #SC.visualizationSettings.view0.scene.showFaceEdges = (mbs.sys['modeShapeMesh'] & 2) == 2
        SC.visualizationSettings.view0.scene.showMeshEdges = (mbs.sys['modeShapeMesh'] & 2) == 2
        

        SC.renderer.SendRedrawSignal()
        if not SC.visualizationSettings.general.useMultiThreadedRendering:
            SC.renderer.DoIdleTasks(0, pollEvents=_pollEventsInTkCallback)
        if mbs.sys['modeShapeSaveImages'] == 0:
            SC.renderer.RedrawAndSaveImage() #create images for animation
        else:
            SC.visualizationSettings.exportImages.saveImageFileCounter = 0 #for next mode ...

        dialog.period = mbs.sys['modeShapePeriod']

        if mbs.sys['modeShapeTimeIndex']>=stepsPerPeriod:
           mbs.sys['modeShapeTimeIndex'] = 0
           if mbs.sys['modeShapeRunModus'] > 1: #one cylce or static once
               dialog.StartSimulation()
        
    if not SC.renderer.IsActive():
        SC.renderer.Start()
        SC.renderer.RestoreSavedState() #load last model view

    simulationSettings = exudyn.SimulationSettings() #not used, but needed in dialog
     #   self.mbs.sys['solver'].InitializeSolver(self.mbs, self.simulationSettings)
    simulationSettings.solution.file.information = 'Mode X'

    if not SC.visualizationSettings.general.useMultiThreadedRendering:
        SC.renderer.DoIdleTasks(0) #do an update once

    titleDialog = 'Animate mode shapes'
    if title != '': 
        titleDialog = title
    
    #dialog = 
    InteractiveDialog(mbs, simulationSettings=simulationSettings, 
                      simulationFunction=UFshowModes, 
                      dialogItems=dialogItems,
                      title=titleDialog,
                      doTimeIntegration=False, period=period,
                      showTime=False,#done in UFshowModes
                      runOnStart=runOnStart, 
                      checkRenderEngineStopFlag=checkRenderEngineStopFlag,
                      fontSize=fontSize,
                      useSysVariables=True, #use mbs.sys, not to bloat the mbs.variables of the user
                      )
    
    SC.renderer.Stop() #safely close rendering window!


#++++++++++++++++++++++++++++++++++++++++++++
@extends(exudyn.MainSystem)
def SolutionViewer(mainSystem, solution=None, rowIncrement = 1, timeout=0.04, runOnStart = True, runMode=2, 
                   fontSize=12, title='', checkRenderEngineStopFlag=True, windowSize=None,
                   callPreStepUserFunction=False) -> None:
    """open interactive dialog and visulation (animate) solution loaded with LoadSolutionFile(...); Change slider 'Increment' to change the automatic increment of time frames; Change mode between continuous run, one cycle (fits perfect for animation recording) or 'Static' (to change Solution steps manually with the mouse); update period also lets you change the speed of animation; Press Run / Stop button to start/stop interactive mode (updating of grpahics)

    Args:
        mainSystem: the system used for visualization of solution (solution is loaded into visualization state of that system)
        solution: solution dictionary previously loaded with exudyn.utilities.LoadSolutionFile(...); will be played from first to last row; if solution==None, it tries to load the file coordinatesSolutionFileName as stored in mbs.sys['simulationSettings'], which are the simulationSettings of the previous simulation
        rowIncrement: can be set larger than 1 in order to skip solution frames: e.g. rowIncrement=10 visualizes every 10th row (frame)
        timeout: in seconds is used between frames in order to limit the speed of animation; e.g. use timeout=0.04 to achieve approximately 25 frames per second
        runOnStart: immediately go into 'Run' mode
        runMode: 0=continuous run, 1=one cycle, 2=static (use slider/mouse to vary time steps)
        fontSize: define font size for labels in InteractiveDialog
        title: if empty, it uses default; otherwise define specific title
        checkRenderEngineStopFlag: if True, stopping renderer (pressing Q or Escape) also causes stopping the interactive dialog
        windowSize: [width, height] of the dialog in pixels; None gives the size stored in ~/.exudyn/config.json, or the size of the layout
        callPreStepUserFunction: if True, the PreStepUserFunction of mainSystem is called with the time of each shown solution step before it is drawn; it may move graphics or set prescribed values (e.g. the reference position of a ground object), as it does in the simulation

    Returns:
        :None: updates current visualization state, renders the scene continuously (after pressing button 'Run'); the space key starts in 'Continuous run' and stops in 'Static'

    Example:
        #HERE, mbs must contain same model as solution stored in solution/coordinatesSolution.txt
        #adjust autoFitScence, otherwise it may lead to unwanted fit to scene
        SC.visualizationSettings.general.autoFitScene = False
        from exudyn.interactive import SolutionViewer #import function
        sol = LoadSolutionFile('solution/coordinatesSolution.txt') #the default solution file
        mbs.SolutionViewer(sol) #call via MainSystem
    """
    if UIWindowSuppressed('SolutionViewer', 'SolutionViewer'): return

    from exudyn.basicUtilities import SetSolutionState, LoadSolutionFile, OutputFilePath
    
    mbs = mainSystem
    SC = mbs.GetSystemContainer()

    if solution is None: #'is' also works for numpy.array
        if 'simulationSettings' not in mbs.sys:
            raise ValueError('SolutionViewer: no solution file found (already simulated?)!')
        sims = mbs.sys['simulationSettings']
        if not sims.solution.file.write:
            raise ValueError('SolutionViewer: previous simulation has solution.file.write==False; no solution file available!')
        filename = sims.solution.file.name
        if filename.find('.')==-1:
            if sims.solution.file.binary:
                filename+='.sol' #this is the default ending for binary file
            else:
                filename+='.txt' #this is the default ending for text
                
        #the name comes from the simulation settings, i.e. it is the name the SOLVER wrote with,
        #so it is resolved with exudyn.config.outputDirectory here; LoadSolutionFile itself reads a
        #file name given by the user as it is (#2454)
        solution = LoadSolutionFile(OutputFilePath(filename, 'SolutionViewer'))

    nRows = solution['nRows']
    if nRows == 0:
        exudyn.Print('ERROR in SolutionViewer: solution file is empty')
        return
    if (runMode != 0 and runMode != 1 and runMode != 2):
        exudyn.Print('ERROR in SolutionViewer: illegal run mode:', runMode)
        return
    if (rowIncrement < 1) or (rowIncrement > nRows):
        exudyn.Print('ERROR in SolutionViewer: rowIncrement must be at least 1 and must not be larger than the number of rows in the solution file')
    oldUpdateInterval = SC.visualizationSettings.general.graphicsUpdateInterval
    SC.visualizationSettings.general.graphicsUpdateInterval = 0.5*min(timeout, 2e-3) #avoid too small values to run multithreading properly
    mbs.SetRenderEngineStopFlag(False) #not to stop right at the beginning

    SetSolutionState(mainSystem, solution, 0, exudyn.ConfigurationType.Visualization)
    SC.renderer.DoIdleTasks(timeout)

    nSteps = int(nRows)              #only make these steps available in slider!
    maxNSteps = max(500,min(nSteps,1200))     #do not allow more steps, because dialog may be too large ...
    resolution = min(1.,maxNSteps/nSteps) #do not use values smaller than 1
                
    #+++++++++++++++++++++++++++++++++
    #call other dialog, create video and get back
    def UFmakeMP4():
        try:
            import ffmpeg # noqa # pylint: disable=unused-import
        except ImportError:
            messagebox.showinfo('Warning', 'FFMPEG is not installed, therefore mp4 files cannot be generated.\nUse: "conda install ffmpeg" and "pip install ffmpeg-python"')
            return
        
        #the images of 'Record frames', where the renderer writes them (#3403)
        workingDir, inputPattern = ExportedImagesLocation(SC.visualizationSettings)
        InteractiveImages2Video(closeAfterCreation=True, workingDir=workingDir, inputPattern=inputPattern) #goes back to SolutionViewer
        # res=messagebox.askquestion('Leave SolutionViewer', 'Do you like to leave SolutionViewer and create an mp4 video?')
        # if res == 'yes':
        #     # dialog.OnQuit() #this does not work
        #     InteractiveImages2Video()
    #+++++++++++++++++++++++++++++++++
    
    dialogItems = [
                   {'type':'label', 'text':'Solution steps:', 'grid':(1,0)},
                   {'type':'slider', 'range':(0, nSteps-1), 'value':0, 'steps':maxNSteps, 'variable':'solutionViewerStep','resolution': resolution, 'grid':(1,1,2)},
                   {'type':'label', 'text':'Increment:', 'grid':(2,0)},
                   {'type':'slider', 'range':(1, 200), 'value':rowIncrement, 'steps':200, 'variable':'solutionViewerRowIncrement', 'grid':(2,1,2)},
                   {'type':'label', 'text':'update period:', 'grid':(3,0)},
                   {'type':'slider', 'range':(0.005, 1), 'value':timeout, 'steps':200, 'variable':'solutionViewerPeriod', 'grid':(3,1,2)},
                   {'type':'radio', 'textValueList':[('Continuous run',0), ('One cycle',1), ('Static',2)],'value':runMode, 'variable':'solutionViewerRunModus', 'grid': [(4,0),(4,1),(4,2)]},
                   {'type':'radio', 'textValueList':[('Record frames',0), ('No recording',1)],'value':1, 'variable':'solutionViewerSaveImages', 'grid': [(5,0),(5,1)]},
                   {'type':'button', 'text':'Make mp4', 'callFunction':UFmakeMP4, 'grid': (5,2)},
                   ]

    mbs.sys['solutionViewerRowIncrement'] = float(rowIncrement)
    mbs.sys['solutionViewerNSteps'] = nSteps
    mbs.sys['solutionViewerSolution'] = solution
    # mbs.sys['solutionViewerStep'] = 0
    # mbs.sys['solutionViewerPeriod'] = timeout

    from tkinter import messagebox

    def CallPreStepUserFunction(i):
        """the PreStepUserFunction of the system at the time of row i, if asked for (#2930)"""
        if not callPreStepUserFunction:
            return
        userFunction = mainSystem.GetPreStepUserFunction()
        if isinstance(userFunction, dict) and callable(userFunction.get('function', None)):
            userFunction['function'](mainSystem, float(mbs.sys['solutionViewerSolution']['data'][i][0]))

    def UFspaceKey(dialog):
        """the space key: start in 'Continuous run', stop in 'Static' (#2931); running in 'Static' or 'One cycle', it
        switches to 'Continuous run' and keeps running (#2940)"""
        if dialog.simulationStopped or mbs.sys['solutionViewerRunModus'] == 0:
            dialog.StartSimulation()
        modus = 2 if dialog.simulationStopped else 0
        for (variable, name) in dialog.variableList:
            if name == 'solutionViewerRunModus':
                variable.set(modus)
        mbs.sys['solutionViewerRunModus'] = modus

    def UFviewer(mbs, dialog):
        i = int(mbs.sys['solutionViewerStep'])

        # mbs.systemData.SetTime(t, exudyn.ConfigurationType.Visualization)
        SetSolutionState(mainSystem, mbs.sys['solutionViewerSolution'], i, exudyn.ConfigurationType.Visualization)
        CallPreStepUserFunction(i)
        
        SC.renderer.SendRedrawSignal()
        SC.renderer.DoIdleTasks(0, pollEvents=_pollEventsInTkCallback) #as there is no simulation, we must do this for singlethreaded renderer to draw graphicsDataUserFunctions

        dialog.period = mbs.sys['solutionViewerPeriod']

        if mbs.sys['solutionViewerRunModus'] < 2:
            mbs.sys['solutionViewerStep'] += mbs.sys['solutionViewerRowIncrement']
    
            #first variable is scale, which contains step
            dialog.variableList[0][0].set(mbs.sys['solutionViewerStep'])

        if mbs.sys['solutionViewerSaveImages'] == 0:
            #in single-threaded renderer, this causes 2x redraw, so we could save the above SC.renderer.DoIdleTasks(0) then ...!
            SC.renderer.RedrawAndSaveImage() #create images for animation

        if mbs.sys['solutionViewerStep']>mbs.sys['solutionViewerNSteps']-1.:
            #or (mbs.sys['solutionViewerRunModus'] and mbs.sys['solutionViewerStep']==mbs.sys['solutionViewerNSteps']-1.):
            mbs.sys['solutionViewerStep'] = 0
            dialog.variableList[0][0].set(0)

            SetSolutionState(mainSystem, mbs.sys['solutionViewerSolution'], 0, exudyn.ConfigurationType.Visualization)
            CallPreStepUserFunction(0)
            # SC.renderer.SendRedrawSignal()
            # SC.renderer.DoIdleTasks(0) #as there is no simulation, we must do this for graphicsDataUserFunctions
            if mbs.sys['solutionViewerRunModus'] == 1: #one cylce ==> stop
                dialog.StartSimulation() #start/stop simulation

        

    if not SC.renderer.IsActive():
        SC.renderer.Start()
        SC.renderer.RestoreSavedState() #load last model view

    simulationSettings = exudyn.SimulationSettings() #not used, but needed in dialog
     #   self.mbs.sys['solver'].InitializeSolver(self.mbs, self.simulationSettings)
    simulationSettings.solution.file.information = ''

    if not SC.visualizationSettings.general.useMultiThreadedRendering:
        SC.renderer.DoIdleTasks(0) #do an update once

    dialogTitle='Solution Viewer'
    if title != '':
        dialogTitle = title

    #dialog = 
    InteractiveDialog(mbs, simulationSettings=simulationSettings, 
                      simulationFunction=UFviewer, 
                      dialogItems=dialogItems,
                      fontSize=fontSize,title=dialogTitle,
                      doTimeIntegration=False, period=timeout,
                      #no time label: it shows the time of the dialog's own time integration, which
                      #the viewer does not run, so it said t = 1.0 whatever row was shown (#2720);
                      #the time of the row is in the render window
                      showTime=False, runOnStart=runOnStart, windowSize=windowSize,
                      checkRenderEngineStopFlag=checkRenderEngineStopFlag,
                      useSysVariables=True, #use mbs.sys, not to bloat the mbs.variables of the user
                      userSpaceKey=UFspaceKey,
                      )


    #SC.renderer.DoIdleTasks(0) #not needed, Render window closes when dialog is quit
    SC.renderer.Stop() #safely close rendering window!

    SC.visualizationSettings.general.graphicsUpdateInterval = oldUpdateInterval #set values back to original



#%%
def ShowImage(systemContainer, size=[800, 600], modelRotation=None, zoomAll=True, show=True, fileName=''):
    """the current scene as an image, rendered by the raytracer without a window, and shown with matplotlib; made
    for notebooks, where no render window opens, and for documentation images

    Args:
        systemContainer: the SystemContainer whose systems are drawn, with its visualizationSettings
        size: [width, height] of the image in pixels; the render window size of the settings is set back afterwards
        modelRotation: the rotation of the view as 3x3 matrix, e.g. RotationMatrixX(0.4)@RotationMatrixY(-0.5), for this
                       image; None takes openGL.advanced.initialModelRotation of the settings
        zoomAll: if True, the view is fitted to the scene first; set False to keep a view set by
                 SC.renderer.SetModelView(...) or a stored render state
        show: if True, the image is drawn with matplotlib (inline in a notebook); False only returns it
        fileName: if not empty, the image is also written to this file (e.g. 'images/scene.png')

    Returns:
        the image as numpy array of shape (height, width, 3), RGB values 0 to 255

    Example:
        mbs.Assemble()
        exudyn.interactive.ShowImage(SC)   #the scene in the reference configuration
    """
    window = systemContainer.visualizationSettings.view0.window
    advanced = systemContainer.visualizationSettings.openGL.advanced
    sizeBefore = list(window.renderWindowSize)
    rotationBefore = np.array(advanced.initialModelRotation)
    window.renderWindowSize = list(size)
    if modelRotation is not None: #the raytracer without a window takes its view from the settings
        advanced.initialModelRotation = np.array(modelRotation).tolist()
    try:
        if zoomAll:
            systemContainer.renderer.ZoomAll()
        image = systemContainer.renderer.RedrawAndGetImage(useRaytracer=True)
    finally:
        window.renderWindowSize = sizeBefore
        advanced.initialModelRotation = rotationBefore.tolist()

    if show or fileName != '':
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            raise ImportError('ShowImage: matplotlib is needed to show or write the image: pip install matplotlib')
        if fileName != '':
            plt.imsave(fileName, image)
        if show:
            figure = plt.figure(figsize=(image.shape[1]/100, image.shape[0]/100), dpi=100)
            figure.set_label('exudyn.ShowImage') #its pixels are the image: a notebook runner does not resize it
            figure.add_axes([0, 0, 1, 1]).imshow(image)
            figure.axes[0].axis('off')
            if not UIWindowSuppressed('Plots', 'ShowImage'): #in a notebook the figure is shown inline anyway
                plt.show()
    return image


def ConvertImages2Video(workingDir='images', 
                        inputPattern='frame%05d.png', 
                        outputFile='animation.mp4', 
                        inputFrameRate=25, 
                        outputFrameRate=25, 
                        compressionCRF=28,
                        startNumber=0,
                        totalFrames=None,
                        videoCodec=None):
    """function to call ffmpeg in the background and convert images to video; requires the program ffmpeg and the package ffmpeg-python ("conda install ffmpeg", "pip install ffmpeg-python")

    Args:
        workingDir: directory where images are stored and where animation is written to
        inputPattern: pattern of images; 'frame' is the name used in visualizationSettings.exportImages.saveImageFileName; if saveImageFormat=PNG, then the ending is .png
        outputFile: filename and ending (.mp4 recommended) for generated video
        inputFrameRate: framerate for images relative to outputFrameRate: if inputFrameRate=50 and outputFrameRate=25, then only every second frame is used
        outputFrameRate: framerate for resulting video
        compressionCRF: compression rate of ffmpeg, where 0=uncompressed, 25 is medium compression, >30 is very low quality
        startNumber: start index of first frame chosen for animation
        totalFrames: total number of frames (keep field empty to select all frames after startNumber)
        videoCodec: the ffmpeg encoder, e.g. 'libx264'; None: libx264, and if that ffmpeg has no libx264 (as the one of
            conda-forge on macOS), h264_videotoolbox on macOS and mpeg4 on the other platforms; compressionCRF applies to
            libx264 only

    Returns:
        the path of the video written; raises FileNotFoundError if the first image, inputPattern with startNumber
        in workingDir, does not exist, and RuntimeError with the last line of the message of ffmpeg if it fails

    Example:
        #after successful simulation, call:
        mbs.SolutionViewer() #click "Stop", "One Cycle" and "Record frames" => close window
        #if images are in folder 'images', then call this to create animation:
        ConvertImages2Video(workingDir='images', outputFile='test.mp4')
    """
    import os
    if workingDir != '':
        inputPattern = os.path.join(workingDir, inputPattern)
        outputFile = os.path.join(workingDir, outputFile)

    #ffmpeg reports a missing first image only in its error text (#3403)
    try:
        firstImage = inputPattern % startNumber
    except (TypeError, ValueError):
        raise ValueError('ConvertImages2Video: inputPattern "' + inputPattern + '" needs one number field such as %05d')
    if not os.path.isfile(firstImage):
        raise FileNotFoundError('ConvertImages2Video: no image "' + os.path.abspath(firstImage) + '"; check the working '
                                'directory, the input pattern and the start frame')

    try:
        import ffmpeg
    except ImportError:
        raise ImportError('ConvertImages2Video: ffmpeg not found! install using "conda install ffmpeg" and "pip install ffmpeg-python"')
    
    kwargs = {}
    if totalFrames is not None:
        kwargs['vframes'] = totalFrames

    import sys
    if videoCodec is not None:
        codecs = [videoCodec]
    else: #an ffmpeg without libx264 stopped with "Unknown encoder 'libx264'" (#2877)
        codecs = ['libx264', 'h264_videotoolbox' if sys.platform == 'darwin' else 'mpeg4']
    errorText = ''
    for codec in codecs:
        quality = {'crf': compressionCRF} if codec == 'libx264' else {'b:v': '8M'}
        try:
            (
                ffmpeg
                .input(filename=inputPattern, framerate=inputFrameRate, start_number=startNumber)
                .output(filename=outputFile,
                        vcodec=codec,
                        vf='fps='+str(outputFrameRate)+',format=yuv420p',
                        **quality, **kwargs)
                .run(overwrite_output=True, capture_stderr=True)
            )
            if codec != codecs[0]:
                exudyn.Print('ConvertImages2Video: ffmpeg has no encoder ' + codecs[0] + '; used ' + codec)
            return outputFile
        except ffmpeg.Error as error: #ffmpeg ran and failed: try the next encoder
            errorText = error.stderr.decode('utf-8', 'replace') if error.stderr else str(error)
        except Exception as error: #ffmpeg could not be run at all
            errorText = str(error)
            break
    raise RuntimeError('ConvertImages2Video: ffmpeg failed with the encoder(s) ' + ', '.join(codecs) + ': '
                       + (errorText.strip().splitlines()[-1] if errorText.strip() else 'no message')
                       + '; make sure that ffmpeg can be executed from the currently used console by executing "ffmpeg"')


def ExportedImagesLocation(visualizationSettings):
    """the directory and the file pattern of the images the renderer writes with the export settings, as
    ConvertImages2Video takes them

    Args:
        visualizationSettings: SC.visualizationSettings; exportImages.saveImageFileName and saveImageFormat are read

    Returns:
        [workingDir, inputPattern]: the directory, with exudyn.config.outputDirectory as the renderer writes there,
        and the pattern such as 'frame%05d.png'

    Example:
        workingDir, inputPattern = ExportedImagesLocation(SC.visualizationSettings)
        ConvertImages2Video(workingDir=workingDir, inputPattern=inputPattern)
    """
    import os
    from exudyn.basicUtilities import OutputFilePath
    exportImages = visualizationSettings.exportImages
    fileName = OutputFilePath(exportImages.saveImageFileName, 'ExportedImagesLocation')
    ending = '.png' if exportImages.saveImageFormat == 'PNG' else '.tga'
    return [os.path.dirname(fileName), os.path.basename(fileName) + '%05d' + ending]


def InteractiveImages2Video(closeAfterCreation=False, fontSize=11, workingDir='images', inputPattern='frame%05d.png'):
    """interactive dialog to convert generated images to videos using ffmpeg library; see also ConvertImages2Video() for meaning of values; requires ffmpeg-python to be installed

    Args:
        closeAfterCreation: True: the dialog closes after the video is written
        fontSize: the size of the font of the dialog
        workingDir: the directory of the images shown first, as an absolute path; the SolutionViewer gives the
            one of exportImages.saveImageFileName, see ExportedImagesLocation
        inputPattern: the pattern of the images shown first

    Returns:
        None; the dialog writes the video
    """
    if UIWindowSuppressed('Dialogs', 'InteractiveImages2Video'): return

    try:
        import tkinter
        import tkinter.font as tkFont
        from tkinter import filedialog
        from tkinter import messagebox
        #from exudyn.misc.GUI import GetTkRootAndNewWindow
    except ImportError:
        raise ValueError('ERROR: InteractiveDialog: tkinter is not installed; InteractiveDialog or SolutionViewer are therefore not available')

    import os
    
    try:
        import ffmpeg # noqa # pylint: disable=unused-import
    except ImportError:
        raise ImportError('ConvertImages2Video: ffmpeg not found! install using "conda install ffmpeg" and "pip install ffmpeg-python"')

    
    def RunConversion():
        try:
            totalFrames = total_frames.get().strip()
            if totalFrames == '': 
                totalFrames=None
            else:
                totalFrames = int(totalFrames)
            
            videoFile = ConvertImages2Video(
                workingDir=dir_entry.get(),
                outputFile=output_entry.get(),
                inputPattern=input_pattern.get(),
                inputFrameRate=input_frame_rate_slider.get(),
                outputFrameRate=output_frame_rate_slider.get(),
                compressionCRF=crf_slider.get(),
                startNumber=int(start_frame.get()),
                totalFrames=totalFrames,
            )
            messagebox.showinfo("Success", "Video written to\n" + os.path.abspath(videoFile))
            if closeAfterCreation:
                OnQuit()

        except Exception as e:
            messagebox.showerror("Error", f"Something went wrong:\n{e}")
    
    def BrowseDirectory():
        dirname = filedialog.askdirectory()
        if dirname:
            dir_entry.delete(0, tkinter.END)
            dir_entry.insert(0, dirname)

    def OnQuit(event=None):
        tkWindow.quit()
        tkWindow.destroy()

    #[root, tkWindow, tkRuns] = GetTkRootAndNewWindow()
    

    tkWindow = tkinter.Tk()
    tkWindow.title("Image to Video Converter")
    tkWindow.columnconfigure(1, weight=1)
    tkWindow.rowconfigure(6, weight=1)
    tkWindow.bind('<Escape>', OnQuit) #Escape causes immediate quit (no further checks)
    tkWindow.bind('q', OnQuit) #Button 'Q' causes immediate quit (no further checks)

    defaultFont = tkFont.Font(root=tkWindow, family = "TkDefaultFont")#,weight = "bold")
    defaultFont.configure(size=int(fontSize))
    #tkWindow.option_add("*Font", "TkDefaultFont") #all widgets should use TkDefaultFont; does not work

    width = 60
    rowcnt = 0    
    tkinter.Label(tkWindow, text="Working directory", font=defaultFont).grid(row=rowcnt, column=0, sticky="w")
    dir_entry = tkinter.Entry(tkWindow, width=width, font=defaultFont)
    dir_entry.insert(0, os.path.abspath(workingDir))
    dir_entry.grid(row=rowcnt, column=1, sticky="ew")
    tkinter.Button(tkWindow, text="Browse", command=BrowseDirectory, font=defaultFont).grid(row=rowcnt, column=2, padx=10)
    
    rowcnt+=1
    tkinter.Label(tkWindow, text="Output file name", font=defaultFont).grid(row=rowcnt, column=0, sticky="w")
    output_entry = tkinter.Entry(tkWindow, width=width, font=defaultFont)
    output_entry.insert(0, "animation.mp4")
    output_entry.grid(row=rowcnt, column=1, sticky="ew")
    
    rowcnt+=1
    tkinter.Label(tkWindow, text="Input pattern", font=defaultFont).grid(row=rowcnt, column=0, sticky="w")
    input_pattern = tkinter.Entry(tkWindow, width=width, font=defaultFont)
    input_pattern.insert(0, inputPattern)
    input_pattern.grid(row=rowcnt, column=1, sticky="ew")
    
    rowcnt+=1
    tkinter.Label(tkWindow, text="Start frame", font=defaultFont).grid(row=rowcnt, column=0, sticky="w")
    start_frame = tkinter.Entry(tkWindow, width=width, font=defaultFont)
    start_frame.insert(0, "0")
    start_frame.grid(row=rowcnt, column=1, sticky="ew")
    
    rowcnt+=1
    tkinter.Label(tkWindow, text="Total frames", font=defaultFont).grid(row=rowcnt, column=0, sticky="w")
    total_frames = tkinter.Entry(tkWindow, width=width, font=defaultFont)
    total_frames.insert(0, "")
    total_frames.grid(row=rowcnt, column=1, sticky="ew")
    tkinter.Label(tkWindow, text="empty=all").grid(row=rowcnt, column=2, sticky="w")
    
    rowcnt+=1
    tkinter.Label(tkWindow, text="Input frame rate (FPS)", font=defaultFont).grid(row=rowcnt, column=0, sticky="w",pady=10)
    input_frame_rate_slider = tkinter.Scale(tkWindow, from_=1, to=200, orient=tkinter.HORIZONTAL, font=defaultFont)
    input_frame_rate_slider.set(25)
    input_frame_rate_slider.grid(row=rowcnt, column=1, sticky="ew")

    rowcnt+=1
    tkinter.Label(tkWindow, text="Output frame rate (FPS)", font=defaultFont).grid(row=rowcnt, column=0, sticky="w",pady=10)
    output_frame_rate_slider = tkinter.Scale(tkWindow, from_=1, to=100, orient=tkinter.HORIZONTAL, font=defaultFont)
    output_frame_rate_slider.set(25)
    output_frame_rate_slider.grid(row=rowcnt, column=1, sticky="ew")
    
    rowcnt+=1
    tkinter.Label(tkWindow, text="Compression (CRF)", font=defaultFont).grid(row=rowcnt, column=0, sticky="w")
    crf_slider = tkinter.Scale(tkWindow, from_=0, to=51, orient=tkinter.HORIZONTAL, font=defaultFont)
    crf_slider.set(28)
    crf_slider.grid(row=rowcnt, column=1, sticky="ew")
    tkinter.Label(tkWindow, text="<20=high qual.\n>30=low qual.").grid(row=rowcnt, column=2, sticky="s")
    
    rowcnt+=1
    tkinter.Button(tkWindow, text="Convert images to video", command=RunConversion, bg="lightblue", font=defaultFont).grid(row=rowcnt, column=1, columnspan=1, pady=10, sticky="s")
    tkinter.Button(tkWindow, text="Quit", command=OnQuit, bg="lightgrey", font=defaultFont).grid(row=rowcnt, column=2, columnspan=1, pady=10, sticky="s")

    tkWindow.mainloop()
    # tkinter.mainloop()



