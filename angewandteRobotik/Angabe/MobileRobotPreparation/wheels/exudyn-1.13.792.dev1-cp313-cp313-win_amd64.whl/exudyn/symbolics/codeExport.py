#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# This is an EXUDYN python utility library
#
# Details:  Writes symbolic expressions and recorded symbolic user functions as code, from the structure of their flat
#           program (#3087, #3088): exudyn.symbolic.GetFlatProgramData(expressions) or
#           UserFunction.GetFlatProgramData(). Entry k of its 'operations' is node k of the recording, the tK of
#           GetFlatProgram(); an operation refers to its operands by their numbers, which are always smaller than k.
#           The formats:
#             'Python'   the text of GetFlatProgram() and str(), not executable (bare function names);
#             'symbolic' Python with exudyn.symbolic: called with symbolic arguments, it records the same graph;
#             'numpy'    Python with numpy, runs without Exudyn;
#             'sympy'    Python that builds sympy expressions; sympy writes C, C++, Fortran, Julia, Matlab, LaTeX, ...
#           Every format computes what Exudyn computes: mod is C fmod, round rounds halves away from zero, a comparison
#           is the number 0 or 1, IfThenElse is true for a condition other than 0; an exudyn.symbolic.LookupTable is
#           written with its values, by a function of the program in numpy and sympy (#3175).
#           exudyn.symbolic.GetFlatProgram(..., format=...), UserFunction.GetFlatProgram(format=...) and
#           ToString(format=...) of exudyn.symbolic.Real, Vector and Matrix call Write(); the format 'Python' of
#           GetFlatProgram() and ToString() is written by C++, and Write() gives the same text.
#           The scalar form (#3523): Scalarize() writes the vector and matrix operations of a flat program as scalar
#           operations into a ScalarGraph, which computes each operation once and combines numbers; WriteScalarProgram()
#           writes it as C++ (format 'C++' of Write()) or as Python of scalar statements (Write(..., 'numpy',
#           scalar=True)), which Numba compiles.
#
# Author:   Johannes Gerstmayr
# Date:     2026-10-25 (created)
#
# Copyright:This file is part of Exudyn. Exudyn is free software. You can redistribute it and/or modify it under the terms of the Exudyn license. See 'LICENSE.txt' for more details.
#
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

import math

#public API of this module; kept complete by tools/checkAll.py (#2444)
__all__ = ['formats', 'Write', 'ToFunction', 'ToSympy', 'ScalarGraph', 'Scalarize', 'WriteScalarProgram']

#the formats of Write()
formats = ['Python', 'symbolic', 'numpy', 'sympy', 'C++']

#the imports at the top of an executable program
_imports = {'symbolic': 'import exudyn as exu\nesym = exu.symbolic\n',
            'numpy': 'import numpy as np\n',
            'sympy': 'import sympy\n'}

_comparisons = {'==': 'Eq', '!=': 'Ne', '>': 'Gt', '>=': 'Ge', '<=': 'Le', '<': 'Lt'}
_unaryFunctions = ['abs', 'sign', 'round', 'ceil', 'floor', 'sqrt', 'exp', 'log', 'sin', 'cos', 'tan', 'asin', 'acos',
                   'atan', 'sinh', 'cosh', 'tanh', 'asinh', 'acosh', 'atanh', 'isfinite', 'Not']
_binaryFunctions = ['pow', 'atan2', 'mod', 'min', 'max']

#names in numpy and sympy where they differ from exudyn.symbolic; a template where it is not one function
_numpyFunctions = {'asin': 'np.arcsin', 'acos': 'np.arccos', 'atan': 'np.arctan', 'asinh': 'np.arcsinh',
                   'acosh': 'np.arccosh', 'atanh': 'np.arctanh', 'pow': 'np.power', 'atan2': 'np.arctan2',
                   'mod': 'np.fmod', 'min': 'np.minimum', 'max': 'np.maximum',
                   'isfinite': '(1.0*np.isfinite({0}))', 'Not': '(1.0*({0} == 0))',
                   'round': '(np.trunc({0}) + np.sign({0})*(np.abs({0} - np.trunc({0})) >= 0.5))'}
_sympyFunctions = {'abs': 'sympy.Abs', 'ceil': 'sympy.ceiling', 'min': 'sympy.Min', 'max': 'sympy.Max',
                   'pow': '({0}**{1})', 'mod': '({0} - {1}*sympy.sign({0}/{1})*sympy.floor(sympy.Abs({0}/{1})))',
                   'Not': 'sympy.Piecewise((1, sympy.Eq({0}, 0)), (0, True))',
                   'round': '(sympy.sign({0})*sympy.floor(sympy.Abs({0}) + sympy.Rational(1, 2)))'}
_modulePrefix = {'symbolic': 'esym.', 'numpy': 'np.', 'sympy': 'sympy.'}

#the lookup table of exudyn.symbolic (#3175) in the formats numpy and sympy, written into a program that uses one: the
#value at x - with derivative the slope of its interval - of values at start + i*step, linearly interpolated, as
#LookupTableData::Value of the C++ code
_lookupTableHelpers = {'numpy': """def _LookupTable(values, step, start, outside, derivative, x):
    n = len(values)
    u = (x - start)/step
    if outside == 'periodic':
        i = int(np.floor(u))
        fraction = u - i
        i = i % n
        (a, b) = (values[i], values[(i + 1) % n])
        return (b - a)/step if derivative else a + (b - a)*fraction
    if u < 0 or u > n - 1:
        if derivative or outside == 'zero':
            return 0.
        return values[0] if u < 0 else values[n - 1]
    if n == 1:
        return 0. if derivative else values[0]
    i = min(int(np.floor(u)), n - 2)
    (a, b) = (values[i], values[i + 1])
    return (b - a)/step if derivative else a + (b - a)*(u - i)
""", 'sympy': """def _LookupTable(values, step, start, outside, derivative, x):
    n = len(values)
    u = (x - start)/step
    def Segment(i, b):
        return (b - values[i])/step if derivative else values[i] + (b - values[i])*(u - i)
    if outside == 'periodic':
        u = u - n*sympy.floor(u/n)
        pieces = [(Segment(i, values[(i + 1) % n]), u < i + 1) for i in range(n - 1)]
        return sympy.Piecewise(*(pieces + [(Segment(n - 1, values[0]), True)]))
    (low, high) = (0, 0) if (derivative or outside == 'zero') else (values[0], values[n - 1])
    if n == 1:
        return sympy.Piecewise((0 if derivative else values[0], sympy.Eq(u, 0)), (low, u < 0), (high, True))
    pieces = [(low, u < 0)] + [(Segment(i, values[i + 1]), u <= i + 1) for i in range(n - 1)]
    return sympy.Piecewise(*(pieces + [(high, True)]))
"""}
_lookupTableOperations = ['LookupTable', 'LookupTableDerivative']


def _Number(value, format):
    """a number, a vector or a matrix of numbers in an executable format"""
    if isinstance(value, list):
        isMatrix = len(value) != 0 and isinstance(value[0], list)
        rows = value if isMatrix else [value]
        texts = ['[' + ', '.join(_Number(item, format) for item in row) + ']' for row in rows]
        text = '[' + ', '.join(texts) + ']' if isMatrix else texts[0]
        if format == 'Python':
            return text
        constructor = {'symbolic': 'esym.Matrix(' if isMatrix else 'esym.Vector(', 'numpy': 'np.array(',
                       'sympy': 'sympy.Matrix('}[format]
        return constructor + text + ')'
    value = float(value)
    if math.isfinite(value):
        return repr(value)
    if math.isnan(value):
        return {'Python': "float('nan')", 'symbolic': "float('nan')", 'numpy': 'np.nan', 'sympy': 'sympy.nan'}[format]
    sign = '-' if value < 0 else ''
    return sign + {'Python': "float('inf')", 'symbolic': "float('inf')", 'numpy': 'np.inf', 'sympy': 'sympy.oo'}[format]


def _Index(entry, text):
    """the text of an index operand: an integer, if it is a number"""
    if entry['op'] == 'number':
        return str(int(entry['value']))
    return 'int(' + text + ')'


def _Function(function, operands, format):
    """a function of exudyn.symbolic in a format"""
    if format == 'Python':
        return function + '(' + ', '.join(operands) + ')'
    table = {'numpy': _numpyFunctions, 'sympy': _sympyFunctions}.get(format, {})
    if format == 'sympy' and function == 'isfinite':
        raise ValueError('symbolicExport: isfinite has no meaning in the format sympy, where a symbol is finite')
    template = table.get(function, _modulePrefix[format] + function)
    if '{' not in template:
        template += '(' + ', '.join('{' + str(i) + '}' for i in range(len(operands))) + ')'
    return template.format(*operands)


def _Operation(entry, operands, operandEntries, format):
    """the text of one operation, its operands given as text"""
    op = entry['op']
    kind = entry['kind']
    kinds = [operandEntry['kind'] for operandEntry in operandEntries]
    if op in ['+', '-', '*', '/']:
        return '(' + operands[0] + ' ' + op + ' ' + operands[1] + ')'
    if op in _comparisons:
        text = '(' + operands[0] + ' ' + op + ' ' + operands[1] + ')'
        if format in ['Python', 'symbolic']:
            return text
        if kinds[0] == 'Vector': #the comparison of two vectors: 1 if all components are equal
            if format == 'numpy':
                return ('(1.0*np.array_equal(' if op == '==' else '(1.0*(not np.array_equal(') + operands[0] + ', ' \
                    + operands[1] + (')' if op == '==' else ')))')
            pairs = '[sympy.' + _comparisons[op] + '(_a, _b) for _a, _b in zip(' + operands[0] + ', ' + operands[1] + ')]'
            return 'sympy.Piecewise((1, sympy.' + ('And' if op == '==' else 'Or') + '(*' + pairs + ')), (0, True))'
        if format == 'numpy':
            return '(1.0*' + text + ')'
        return 'sympy.Piecewise((1, sympy.' + _comparisons[op] + '(' + operands[0] + ', ' + operands[1] + ')), (0, True))'
    if op == 'pos':
        return operands[0]
    if op == 'neg':
        return '(-' + operands[0] + ')'
    if op in _unaryFunctions or op in _binaryFunctions:
        return _Function(op, operands, format)
    if op == 'IfThenElse':
        return {'Python': 'IfThenElse({0},{1},{2})', 'symbolic': 'esym.IfThenElse({0}, {1}, {2})',
                'numpy': '({1} if {0} else {2})',
                'sympy': 'sympy.Piecewise(({1}, sympy.Ne({0}, 0)), ({2}, True))'}[format].format(*operands)
    if op in _lookupTableOperations:
        if format == 'Python':
            return op + '(' + operands[0] + ')'
        table = entry['table']
        data = (_Number(table['values'], 'Python') + ', ' + _Number(table['step'], format) + ', '
                + _Number(table['start'], format) + ", '" + table['outside'] + "'")
        if format == 'symbolic':
            return ('esym.LookupTable(' + data + ')' + ('.Derivative(' if op == 'LookupTableDerivative' else '(')
                    + operands[0] + ')')
        return '_LookupTable(' + data + ', ' + str(op == 'LookupTableDerivative') + ', ' + operands[0] + ')'
    if op == 'vector':
        text = '[' + ', '.join(operands) + ']'
        return text if format == 'Python' else {'symbolic': 'esym.Vector(', 'numpy': 'np.array(', 'sympy': 'sympy.Matrix('}[format] + text + ')'
    if op == 'matrix':
        columns = entry['columns']
        rows = ['[' + ', '.join(operands[row*columns:(row+1)*columns]) + ']' for row in range(entry['rows'])]
        text = '[' + ', '.join(rows) + ']'
        return text if format == 'Python' else {'symbolic': 'esym.Matrix(', 'numpy': 'np.array(', 'sympy': 'sympy.Matrix('}[format] + text + ')'
    if op == '@':
        if format == 'sympy' and kind == 'Real': #the scalar product of two vectors
            return '(' + operands[0] + '.dot(' + operands[1] + '))'
        return '(' + operands[0] + ' @ ' + operands[1] + ')'
    if op == 'vector@matrix': #the operands are the matrix and the vector
        if format == 'sympy':
            return '(' + operands[0] + '.T @ ' + operands[1] + ')'
        return '(' + operands[1] + ' @ ' + operands[0] + ')'
    if op == 'multiply':
        return {'Python': '{0}.multiply({1})', 'symbolic': '{0}.multiply({1})', 'numpy': 'np.multiply({0}, {1})',
                'sympy': '{0}.multiply_elementwise({1})'}[format].format(*operands)
    if op == 'NormL2':
        return {'Python': 'NormL2({0})', 'symbolic': '{0}.NormL2()', 'numpy': 'np.linalg.norm({0})',
                'sympy': '{0}.norm()'}[format].format(*operands)
    if op == 'T':
        return operands[0] + '.T'
    if op == 'component':
        if format == 'Python':
            return operands[0] + '[' + ','.join(operands[1:]) + ']'
        return operands[0] + '[' + ', '.join(_Index(e, t) for (e, t) in zip(operandEntries[1:], operands[1:])) + ']'
    raise ValueError('symbolicExport: the operation "' + str(op) + '" is not known to the format ' + format)


def _Leaf(entry, format):
    """the text of a number or a named variable"""
    if entry['op'] == 'variable':
        return entry['name']
    if entry['op'] == 'number':
        return entry['text'] if format == 'Python' else _Number(entry['value'], format)
    if format == 'Python':
        return entry['text']
    raise ValueError('symbolicExport: the expression ' + entry['text'] + ' has no operations that the format '
                     + format + ' can write')


def Write(data, format='Python', flatten=True, name='', expressionOnly=False, scalar=False):
    """write the flat program of symbolic expressions or of a recorded user function as code; for exudyn.symbolic.Real,
    Vector and Matrix, ToString(format) calls it, for user functions and expressions GetFlatProgram(format=...)

    Args:
        data: the structure of exudyn.symbolic.GetFlatProgramData(...) or UserFunction.GetFlatProgramData()
        format: 'Python' (the text of GetFlatProgram()), 'symbolic', 'numpy' or 'sympy' (executable Python), or 'C++'
            (the scalar form of WriteScalarProgram(), a function template and a double function for C)
        flatten: True: one line per operation, each node computed once; False: each result as one expression
        name: the name of the function of an executable format; default: the name of the user function, or F
        expressionOnly: True: only the expression of the first result, as ToString() gives it
        scalar: True with format 'numpy': the scalar form of WriteScalarProgram(), which Numba compiles

    Returns:
        the code as str; for an executable format a function with the arguments of the user function, or of the
        named variables of the expressions, and the other named variables it reads - of mbs.symbolicVariables for a
        user function, of exudyn.symbolic.variables else - as keyword arguments (as arguments in C++)
    """
    if format not in formats:
        raise ValueError('symbolicExport.Write: format must be one of ' + str(formats) + ', but received ' + str(format))
    if format == 'C++' or scalar:
        if expressionOnly or format not in ['C++', 'numpy']:
            raise ValueError('symbolicExport.Write: the scalar form is written as a function, by the format C++ or by '
                             'numpy with scalar=True')
        return WriteScalarProgram(data, 'C++' if format == 'C++' else 'Python', name)['code']
    operations = data['operations']
    texts = [''] * len(operations)
    lines = []
    for (k, entry) in enumerate(operations):
        if 'operands' not in entry:
            text = _Leaf(entry, format)
        else:
            operandEntries = [operations[i] for i in entry['operands']]
            text = _Operation(entry, [texts[i] for i in entry['operands']], operandEntries, format)
        if entry['inline'] or not flatten or expressionOnly:
            texts[k] = text
        else:
            texts[k] = 't' + str(k)
            lines.append(texts[k] + ' = ' + text)
    results = [(result['name'], texts[result['node']]) for result in data['results']]
    if expressionOnly:
        return results[0][1]

    numberOfComputations = sum(1 for entry in operations if not entry['inline'])
    isUserFunction = 'variables' in data
    if format == 'Python':
        lines = lines if flatten else []
        header = ''
        if isUserFunction:
            if numberOfComputations == 0: #as C++: a leaf has no flat program
                return '#' + data['name'] + ': no flat program; the result is evaluated as a tree\n'
            header = '#' + data['name'] + ': ' + str(numberOfComputations) + ' operations\n'
        return header + ''.join(line + '\n' for line in lines) + ''.join(n + ' = ' + t + '\n' for (n, t) in results)

    #the named variables that are no arguments - of mbs.symbolicVariables for a user function, which has mbs, else of
    #exudyn.symbolic.variables (#3208): read from there by the format symbolic, which keeps the signature of the user
    #function and records them again; keyword arguments with their present value otherwise
    parameters = [argument['name'] for argument in data['arguments']]
    scope = 'mbs.symbolicVariables' if 'mbs' in parameters else 'esym.variables'
    variableLines = []
    for variable in data.get('variables', []):
        if format == 'symbolic':
            variableLines.append(variable['name'] + ' = ' + scope + ".Get('" + variable['name'] + "')")
        else:
            parameters.append(variable['name'] + '=' + _Number(variable['value'], format))
    functionName = name if name else data.get('name', 'F')
    body = variableLines + (lines if flatten else [])
    returns = ', '.join(t for (n, t) in results)
    helper = ''
    if format in _lookupTableHelpers and any(entry.get('op') in _lookupTableOperations for entry in operations):
        helper = _lookupTableHelpers[format] + '\n'
    return (_imports[format] + helper + 'def ' + functionName + '(' + ', '.join(parameters) + '):\n'
            + ''.join('    ' + line + '\n' for line in body) + '    return ' + returns + '\n')


def ToFunction(data, format='numpy', flatten=True, scalar=False, jit=None):
    """the Python function of an executable format, as Write() gives it as text

    Args:
        data: the structure of exudyn.symbolic.GetFlatProgramData(...) or UserFunction.GetFlatProgramData()
        format: 'symbolic', 'numpy' or 'sympy'
        flatten: as in Write()
        scalar: True with format 'numpy': the scalar form, as in Write()
        jit: with the scalar form, a compiler applied to the function and to its helper functions, numba.njit for
            example; None: the function as Python

    Returns:
        the function, with the arguments of the user function or of the named variables
    """
    if format in ['Python', 'C++']:
        raise ValueError('symbolicExport.ToFunction: the format ' + format + ' is not executable Python; use symbolic, '
                         'numpy or sympy')
    if jit is not None and not (format == 'numpy' and scalar):
        raise ValueError("symbolicExport.ToFunction: jit is possible only for the scalar form (format 'numpy', "
                         "scalar=True)")
    space = {}
    exec(Write(data, format, flatten, name='_F', scalar=scalar), space)
    if jit is None:
        return space['_F']
    for helper in ['_Sign', '_Round', '_LookupTable']: #compiled first: the function calls them by their global names
        if helper in space:
            space[helper] = jit(space[helper])
    return jit(space['_F'])


def ToSympy(data):
    """the results as sympy expressions, with a sympy symbol per argument: x for a number, the components q[0], q[1],
    ... of a vector q as a column sympy.Matrix, M[0][0], ... of a matrix M; sympy must be installed

    Args:
        data: the structure of exudyn.symbolic.GetFlatProgramData(...) or UserFunction.GetFlatProgramData()

    Returns:
        (arguments, results): a dict of the argument names to their symbols (None for the MainSystem) and the list of
        the results; a named variable that is no argument is a symbol as well
    """
    import sympy #optional: needed only here and in the code of the format sympy
    arguments = {}
    for argument in data['arguments'] + data.get('variables', []):
        argumentName, kind = argument['name'], argument['kind']
        if kind == 'MainSystem':
            arguments[argumentName] = None
        elif kind == 'Real':
            arguments[argumentName] = sympy.Symbol(argumentName)
        elif kind == 'Vector':
            if not argument.get('size', 0):
                raise ValueError('symbolicExport.ToSympy: the size of the vector ' + argumentName + ' is not known')
            arguments[argumentName] = sympy.Matrix([sympy.Symbol(argumentName + '[' + str(i) + ']')
                                                    for i in range(argument['size'])])
        else:
            arguments[argumentName] = sympy.Matrix([[sympy.Symbol(argumentName + '[' + str(i) + '][' + str(j) + ']')
                                                     for j in range(argument['columns'])] for i in range(argument['rows'])])
    function = ToFunction(data, 'sympy')
    results = function(**arguments)
    return (arguments, list(results) if len(data['results']) > 1 else [results])


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#the scalar form (#3523): the operations of a flat program on numbers only, written as C++ or as scalar Python

def _Round(x):
    """std::round: halves away from zero"""
    r = math.trunc(x)
    return float(r + math.copysign(1., x)) if abs(x - r) >= 0.5 else float(r)

def _Fold(op, values):
    """an operation on numbers as C computes it; None where Python raises and C would give inf or nan"""
    (a, b) = (values[0], values[1] if len(values) > 1 else None)
    try:
        if op in _scalarBinary:
            return float(_scalarBinary[op](a, b))
        if op in _scalarUnary:
            return float(_scalarUnary[op](a))
        if op == 'select':
            return float(values[1] if a != 0 else values[2])
    except (ValueError, ZeroDivisionError, OverflowError):
        pass
    return None

_scalarBinary = {'+': lambda a, b: a + b, '-': lambda a, b: a - b, '*': lambda a, b: a*b, '/': lambda a, b: a/b,
                 'pow': math.pow, 'atan2': math.atan2, 'mod': math.fmod, 'min': lambda a, b: b if b < a else a,
                 'max': lambda a, b: b if a < b else a, '==': lambda a, b: a == b, '!=': lambda a, b: a != b,
                 '>': lambda a, b: a > b, '>=': lambda a, b: a >= b, '<=': lambda a, b: a <= b, '<': lambda a, b: a < b}
_scalarUnary = {'neg': lambda a: -a, 'abs': abs, 'sign': lambda a: (a > 0) - (a < 0), 'round': _Round,
                'ceil': math.ceil, 'floor': math.floor, 'sqrt': math.sqrt, 'exp': math.exp, 'log': math.log,
                'sin': math.sin, 'cos': math.cos, 'tan': math.tan, 'asin': math.asin, 'acos': math.acos,
                'atan': math.atan, 'sinh': math.sinh, 'cosh': math.cosh, 'tanh': math.tanh, 'asinh': math.asinh,
                'acosh': math.acosh, 'atanh': math.atanh, 'isfinite': math.isfinite, 'Not': lambda a: a == 0}


class ScalarGraph:
    """the scalar operations of programs: node k is a tuple (op, operands, value) - op 'input' (value: the input, for
    example ('q', (2,)) for q[2]), 'number' (value: the number), 'LookupTable' (value: the table) or an operation of
    exudyn.symbolic on numbers ('select' is IfThenElse), operands the numbers of the nodes it reads, always smaller
    than k. A node with the same operation and operands is computed once, an operation on numbers is a number, and
    x*0, x*1, x/1, x+0 and x-0 are simplified (x*0 is 0 also for an x that is not finite); the zeros of a matrix are
    therefore numbers, and its pattern is that of the other entries"""
    def __init__(self):
        self.nodes = []
        self.known = {}

    def Add(self, op, operands=(), value=None):
        """the node of an operation; returns its number"""
        operands = tuple(operands)
        if op == 'select' and self.nodes[operands[0]][0] == 'number': #a known condition selects its branch
            return operands[1] if self.nodes[operands[0]][2] != 0 else operands[2]
        if op not in ['input', 'number', 'LookupTable', 'LookupTableDerivative'] and operands \
                and all(self.nodes[i][0] == 'number' for i in operands):
            folded = _Fold(op, [self.nodes[i][2] for i in operands])
            if folded is not None:
                return self.Add('number', value=folded)
        if op == '*' and any(self.nodes[i] == ('number', (), 0.) for i in operands):
            return self.Add('number', value=0.)
        for (number, neutral) in [(1., {'*': [0, 1], '/': [1]}), (0., {'+': [0, 1], '-': [1]})]:
            for position in neutral.get(op, []):
                if self.nodes[operands[position]] == ('number', (), number):
                    return operands[1 - position]
        key = (op, operands, value)
        if key not in self.known:
            self.known[key] = len(self.nodes)
            self.nodes.append(key)
        return self.known[key]

    def Sum(self, terms):
        """the sum of nodes, from the first to the last, as the C++ loops sum"""
        result = terms[0]
        for term in terms[1:]:
            result = self.Add('+', [result, term])
        return result

    def IsZero(self, node):
        """True if the node is the number 0"""
        return self.nodes[node] == ('number', (), 0.)


def _Map(value, function):
    if isinstance(value, list):
        return [_Map(x, function) for x in value]
    return function(value)

def _Elementwise(graph, op, x, y):
    if isinstance(x, list):
        return [_Elementwise(graph, op, u, v) for (u, v) in zip(x, y)]
    return graph.Add(op, [x, y])

def _Leaves(entry):
    """the leaf nodes of a result: a node, a list or a list of rows"""
    if isinstance(entry, list):
        return [node for item in entry for node in _Leaves(item)]
    return [entry]


def _ScalarInputs(graph, data):
    """the input nodes of the arguments and the named variables of a flat program"""
    inputs = {}
    for argument in data['arguments'] + data.get('variables', []):
        (argumentName, kind) = (argument['name'], argument['kind'])
        if kind == 'MainSystem':
            continue
        if kind == 'Real':
            inputs[argumentName] = graph.Add('input', value=(argumentName, ()))
        elif kind == 'Vector':
            size = argument.get('size', len(argument.get('value', [])))
            if not size:
                raise ValueError('symbolicExport.Scalarize: the size of the vector ' + argumentName + ' is not known')
            inputs[argumentName] = [graph.Add('input', value=(argumentName, (i,))) for i in range(size)]
        else:
            inputs[argumentName] = [[graph.Add('input', value=(argumentName, (i, j))) for j in range(argument['columns'])]
                                    for i in range(argument['rows'])]
    return inputs


def Scalarize(data, graph=None, inputs=None):
    """the results of a flat program as scalar operations: vectors and matrices as lists of their components, each
    an operation on numbers; the sums of products in the order of the C++ code

    Args:
        data: the structure of exudyn.symbolic.GetFlatProgramData(...) or UserFunction.GetFlatProgramData()
        graph: a ScalarGraph to add to, so that several programs share their operations; default: a new one
        inputs: the nodes of the variables by name, a node (number) or a list (vector) or a list of rows (matrix);
            default: an input node per number, component of a vector and entry of a matrix of the arguments and named
            variables of data

    Returns:
        (graph, results): per result of data a node (Real), a list of nodes (Vector) or a list of rows (Matrix)
    """
    graph = ScalarGraph() if graph is None else graph
    inputs = _ScalarInputs(graph, data) if inputs is None else inputs
    operations = data['operations']
    values = []
    for entry in operations:
        (op, kind) = (entry['op'], entry['kind'])
        a = [values[i] for i in entry.get('operands', [])]
        kinds = [operations[i]['kind'] for i in entry.get('operands', [])]
        if op == 'number':
            result = _Map(entry['value'], lambda x: graph.Add('number', value=float(x)))
        elif op == 'variable':
            if entry['name'] not in inputs:
                raise ValueError('symbolicExport.Scalarize: the variable ' + entry['name'] + ' is not an input')
            result = inputs[entry['name']]
        elif op == 'component':
            indexEntries = [operations[i] for i in entry['operands'][1:]]
            if any(e['op'] != 'number' for e in indexEntries):
                raise ValueError('symbolicExport.Scalarize: the index of a component must be a number, not computed')
            indices = [int(e['value']) for e in indexEntries]
            result = a[0][indices[0]] if len(indices) == 1 else a[0][indices[0]][indices[1]]
        elif op in ['+', '-', '*', '/'] and kinds == ['Real', 'Real']:
            result = graph.Add(op, a)
        elif op in ['+', '-']:
            result = _Elementwise(graph, op, a[0], a[1])
        elif op in ['*', '/']: #a vector or matrix with a number
            (number, other, numberFirst) = (a[0], a[1], True) if kinds[0] == 'Real' else (a[1], a[0], False)
            result = _Map(other, lambda x: graph.Add(op, [number, x] if numberFirst else [x, number]))
        elif op == 'pos':
            result = a[0]
        elif op == 'neg':
            result = _Map(a[0], lambda x: graph.Add('neg', [x]))
        elif op in _comparisons:
            if kinds[0] == 'Real':
                result = graph.Add(op, a)
            else: #two vectors: 1 if all components are equal
                equal = graph.Add('number', value=1.)
                for (x, y) in zip(_Leaves(a[0]), _Leaves(a[1])):
                    equal = graph.Add('*', [equal, graph.Add('==', [x, y])])
                result = equal if op == '==' else graph.Add('Not', [equal])
        elif op in _unaryFunctions or op in _binaryFunctions:
            result = graph.Add(op, a)
        elif op == 'IfThenElse':
            result = graph.Add('select', a)
        elif op in _lookupTableOperations:
            table = entry['table']
            result = graph.Add(op, a, (tuple(float(v) for v in table['values']), float(table['step']),
                                       float(table['start']), table['outside']))
        elif op == 'vector':
            result = list(a)
        elif op == 'matrix':
            result = [list(a[row*entry['columns']:(row + 1)*entry['columns']]) for row in range(entry['rows'])]
        elif op == '@':
            if kinds == ['Vector', 'Vector']:
                result = graph.Sum([graph.Add('*', [x, y]) for (x, y) in zip(a[0], a[1])])
            elif kinds == ['Matrix', 'Vector']:
                result = [graph.Sum([graph.Add('*', [x, y]) for (x, y) in zip(row, a[1])]) for row in a[0]]
            else:
                result = [[graph.Sum([graph.Add('*', [row[k], a[1][k][j]]) for k in range(len(row))])
                           for j in range(len(a[1][0]))] for row in a[0]]
        elif op == 'vector@matrix': #v^T A; the operands are A and v
            result = [graph.Sum([graph.Add('*', [a[1][i], a[0][i][j]]) for i in range(len(a[1]))])
                      for j in range(len(a[0][0]))]
        elif op == 'multiply':
            result = _Elementwise(graph, '*', a[0], a[1])
        elif op == 'NormL2':
            result = graph.Add('sqrt', [graph.Sum([graph.Add('*', [x, x]) for x in a[0]])])
        elif op == 'T':
            result = [list(column) for column in zip(*a[0])]
        else:
            raise ValueError('symbolicExport.Scalarize: the operation "' + str(op) + '" of kind ' + kind + ' has no '
                             'scalar form')
        values.append(result)
    return (graph, [values[result['node']] for result in data['results']])


#the operations of the scalar form in C++ and in Python, operands {0}, {1}, {2}
_cppOperations = {'neg': '(-{0})', 'abs': 'abs({0})', 'sign': 'ExportSign({0})', 'Not': 'Real({0} == 0. ? 1. : 0.)',
                  'isfinite': 'Real(isfinite({0}) ? 1. : 0.)', 'mod': 'fmod({0}, {1})',
                  'min': '({1} < {0} ? {1} : {0})', 'max': '({0} < {1} ? {1} : {0})', 'select': '({0} != 0. ? {1} : {2})'}
_pythonOperations = {'neg': '(-{0})', 'abs': 'abs({0})', 'sign': '_Sign({0})', 'Not': '(1.0 if {0} == 0 else 0.0)',
                     'isfinite': '(1.0 if math.isfinite({0}) else 0.0)', 'mod': 'np.fmod({0}, {1})',
                     'min': '({1} if {1} < {0} else {0})', 'max': '({1} if {0} < {1} else {0})',
                     'select': '({1} if {0} != 0 else {2})', 'round': '_Round({0})', 'ceil': 'np.ceil({0})',
                     'floor': 'np.floor({0})', 'pow': 'np.power({0}, {1})', 'atan2': 'math.atan2({0}, {1})'}
#numpy where math raises and C gives inf or nan
_pythonNumpy = ['sqrt', 'exp', 'log', 'asin', 'acos', 'sinh', 'cosh', 'acosh', 'atanh']

#the helper functions of the C++ code, guarded, so that several programs can be in one file
_cppHelpers = {'sign': """#ifndef EXUDYN_EXPORT_SIGN
#define EXUDYN_EXPORT_SIGN
//the sign as exudyn.symbolic computes it: 0 for 0
template<typename Real> inline Real ExportSign(const Real& x) { return Real((0. < x) - (x < 0.)); }
#endif
""", 'LookupTable': """#ifndef EXUDYN_EXPORT_LOOKUPTABLE
#define EXUDYN_EXPORT_LOOKUPTABLE
//the value or the derivative of a lookup table at x (exudyn.symbolic.LookupTable): values at start + i*step,
//linearly interpolated; outside 0: 'zero', 1: 'hold', 2: 'periodic'
template<typename Real> inline Real ExportLookupTable(const double* values, int n, double step, double start,
                                                        int outside, bool derivative, const Real& x)
{
    Real u = (x - start)/step;
    if (outside == 2)
    {
        int i = (int)std::floor((double)u);
        Real fraction = u - (double)i;
        i = ((i % n) + n) % n;
        double a = values[i], b = values[(i + 1) % n];
        return derivative ? Real((b - a)/step) : Real(a + (b - a)*fraction);
    }
    if (u < 0. || u > (double)(n - 1))
    {
        if (derivative || outside == 0) { return Real(0.); }
        return Real(u < 0. ? values[0] : values[n - 1]);
    }
    if (n == 1) { return Real(derivative ? 0. : values[0]); }
    int i = (int)std::floor((double)u);
    if (i > n - 2) { i = n - 2; }
    double a = values[i], b = values[i + 1];
    return derivative ? Real((b - a)/step) : Real(a + (b - a)*(u - (double)i));
}
#endif
"""}
_pythonHelpers = {'sign': """def _Sign(x):
    return 1.0 if x > 0 else (-1.0 if x < 0 else 0.0)
""", 'round': """def _Round(x):
    r = np.trunc(x)
    return r + np.sign(x)*(abs(x - r) >= 0.5)
""", 'LookupTable': _lookupTableHelpers['numpy']}


def _CppNumber(value):
    if math.isfinite(value):
        return repr(float(value))
    if math.isnan(value):
        return 'std::numeric_limits<double>::quiet_NaN()'
    return ('-' if value < 0 else '') + 'std::numeric_limits<double>::infinity()'


def WriteScalarProgram(data, language='C++', name='', sparse=False, graph=None, results=None):
    """the scalar form of a flat program as code: one statement per operation, each computed once, numbers combined;
    C++ as a function template on the type Real (double, or a type of automatic differentiation) and a function of
    double for C and ctypes, of the standard library only; Python of scalar statements on math and numpy, which Numba
    compiles together with its helper functions _Sign, _Round and _LookupTable (ToFunction(..., jit=numba.njit)). The arguments: a number by value, a vector as an array, a matrix as an array of its rows (C++) or a 2D
    array (Python); the named variables that are no arguments follow the arguments (in Python as keyword arguments with
    their present value). The results: in C++ arrays given by the caller after the arguments, a number as an array of
    one; in Python returned, as numpy arrays. A MainSystem argument (of a user function) is kept in Python only.

    Args:
        data: the structure of exudyn.symbolic.GetFlatProgramData(...) or UserFunction.GetFlatProgramData()
        language: 'C++' or 'Python'
        name: the name of the function; default: the name of the user function, or F
        sparse: True: a matrix result as the values of its pattern, the entries that are not the number 0, row by row;
            False: all its entries, row by row
        graph: the graph of Scalarize(data), if it is known already; default: Scalarize(data) is called
        results: the results of Scalarize(data), given with graph

    Returns:
        a dict: 'code' the code as str, 'operations' the number of scalar operations, 'patterns' per result name the
        list of (row, column) of its values for a matrix (all entries if not sparse), None for a number or vector
    """
    if language not in ['C++', 'Python']:
        raise ValueError("symbolicExport.WriteScalarProgram: language must be 'C++' or 'Python', but received "
                         + str(language))
    if graph is None:
        (graph, results) = Scalarize(data)
    functionName = name if name else data.get('name', 'F')
    if not functionName.isidentifier():
        raise ValueError('symbolicExport.WriteScalarProgram: the name ' + functionName + ' is not a valid identifier')
    isCpp = language == 'C++'
    arguments = [a for a in data['arguments'] if not (isCpp and a['kind'] == 'MainSystem')]
    variables = data.get('variables', [])
    argumentNames = [a['name'] for a in arguments + variables]
    resultNames = []
    for (k, result) in enumerate(data['results']):
        resultName = result.get('name', '')
        if not resultName.isidentifier() or resultName in argumentNames + resultNames:
            resultName = 'result' + str(k)
        resultNames.append(resultName)
    prefix = '_t' if any(n.startswith('t') and n[1:].isdigit() for n in argumentNames + resultNames) else 't'

    #the nodes the results need, in their order
    needed = [False]*len(graph.nodes)
    stack = [node for result in results for node in _Leaves(result)]
    while stack:
        node = stack.pop()
        if not needed[node]:
            needed[node] = True
            stack += list(graph.nodes[node][1])

    used = set()
    tables = []
    texts = [''] * len(graph.nodes)
    lines = []
    for (k, (op, operands, value)) in enumerate(graph.nodes):
        if not needed[k]:
            continue
        if op == 'number':
            texts[k] = _CppNumber(value) if isCpp else _Number(value, 'numpy')
            if not math.isfinite(value):
                used.add('limits')
            continue
        if op == 'input':
            (inputName, index) = value
            if len(index) == 2:
                columns = next(a['columns'] for a in arguments + variables if a['name'] == inputName)
                texts[k] = inputName + ('[' + str(index[0]*columns + index[1]) + ']' if isCpp
                                        else '[' + str(index[0]) + ', ' + str(index[1]) + ']')
            else:
                texts[k] = inputName + ''.join('[' + str(i) + ']' for i in index)
            continue
        o = [texts[i] for i in operands]
        if op in ['+', '-', '*', '/']:
            text = '(' + o[0] + ' ' + op + ' ' + o[1] + ')'
        elif op in _comparisons:
            text = ('Real(' + o[0] + ' ' + op + ' ' + o[1] + ' ? 1. : 0.)') if isCpp else \
                   ('(1.0 if ' + o[0] + ' ' + op + ' ' + o[1] + ' else 0.0)')
        elif op in _lookupTableOperations:
            (tableValues, step, start, outside) = value
            if isCpp:
                used.add('LookupTable')
                tables.append('static const double ' + functionName + '_table' + str(len(tables)) + '[] = {'
                              + ', '.join(_CppNumber(v) for v in tableValues) + '};')
                text = ('ExportLookupTable(' + functionName + '_table' + str(len(tables) - 1) + ', '
                        + str(len(tableValues)) + ', ' + _CppNumber(step) + ', ' + _CppNumber(start) + ', '
                        + str(['zero', 'hold', 'periodic'].index(outside)) + ', '
                        + ('true' if op == 'LookupTableDerivative' else 'false') + ', ' + o[0] + ')')
            else:
                used.add('LookupTable')
                text = ('_LookupTable(' + _Number(list(tableValues), 'Python') + ', ' + _Number(step, 'numpy') + ', '
                        + _Number(start, 'numpy') + ", '" + outside + "', " + str(op == 'LookupTableDerivative')
                        + ', ' + o[0] + ')')
        else:
            table = _cppOperations if isCpp else _pythonOperations
            if op in ['sign', 'round']:
                used.add(op)
            if op in table:
                text = table[op].format(*o)
            elif isCpp:
                text = op + '(' + ', '.join(o) + ')'
            elif op in _pythonNumpy:
                text = _numpyFunctions.get(op, 'np.' + op) + '(' + ', '.join(o) + ')'
            else:
                text = 'math.' + op + '(' + ', '.join(o) + ')'
        texts[k] = prefix + str(k)
        lines.append(((('const Real ' if isCpp else '') + texts[k] + ' = ' + text) + (';' if isCpp else '')))

    #the results
    patterns = {}
    resultLines = []
    for (result, resultName) in zip(results, resultNames):
        if not isinstance(result, list): #a number
            patterns[resultName] = None
            resultLines.append(resultName + '[0] = ' + texts[result] + ';' if isCpp else None)
            continue
        if not isinstance(result[0], list): #a vector
            patterns[resultName] = None
            if not isCpp:
                resultLines.append(resultName + ' = np.empty(' + str(len(result)) + ')')
            resultLines += [resultName + '[' + str(i) + '] = ' + texts[node] + (';' if isCpp else '')
                            for (i, node) in enumerate(result)]
            continue
        columns = len(result[0])
        entries = [(i, j) for i in range(len(result)) for j in range(columns)
                   if not (sparse and graph.IsZero(result[i][j]))]
        patterns[resultName] = entries
        if isCpp:
            resultLines += [resultName + '[' + str(m if sparse else i*columns + j) + '] = ' + texts[result[i][j]] + ';'
                            for (m, (i, j)) in enumerate(entries)]
        else:
            resultLines.append(resultName + ' = np.zeros(' + (str(len(entries)) if sparse else
                                                               '(' + str(len(result)) + ', ' + str(columns) + ')') + ')')
            resultLines += [resultName + '[' + (str(m) if sparse else str(i) + ', ' + str(j)) + '] = '
                            + texts[result[i][j]] for (m, (i, j)) in enumerate(entries)
                            if sparse or not graph.IsZero(result[i][j])]
    numberOfOperations = len(lines)

    header = ('written by exudyn.symbolics.codeExport, the scalar form of ' + functionName + ': '
              + str(numberOfOperations) + ' operations')
    if isCpp:
        def Parameter(argument, real):
            if argument['kind'] == 'Real':
                return real + ' ' + argument['name']
            return 'const ' + real + '* ' + argument['name']
        def Signature(real):
            return ', '.join([Parameter(a, real) for a in arguments + variables]
                             + [real + '* ' + n for n in resultNames])
        code = ['//' + header, '//arguments: ' + ', '.join(argumentNames) + '; results: ' + ', '.join(resultNames)
                + ' (a matrix ' + ('as the values of its pattern' if sparse else 'row by row') + ')']
        if variables:
            code.append('//present values of the named variables: ' + ', '.join(
                v['name'] + ' = ' + str(v['value']) for v in variables))
        code += ['#include <cmath>'] + (['#include <limits>'] if 'limits' in used else []) + ['']
        code += [_cppHelpers[h] for h in ['sign', 'LookupTable'] if h in used]
        code += tables + ([''] if tables else [])
        code += ['template<typename Real>', 'void ' + functionName + '(' + Signature('Real') + ')', '{',
                 '    using namespace std;'] + ['    ' + line for line in lines + resultLines] + ['}', '',
                 '//the function of double, for C and ctypes',
                 'extern "C" void ' + functionName + '_double(' + Signature('double') + ')', '{',
                 '    ' + functionName + '<double>(' + ', '.join(argumentNames + resultNames) + ');', '}']
    else:
        resultLines = [line for line in resultLines if line is not None]
        returns = ', '.join(texts[r] if not isinstance(r, list) else n for (r, n) in zip(results, resultNames))
        parameters = [a['name'] for a in arguments] + [v['name'] + '=' + _Number(v['value'], 'numpy') for v in variables]
        code = ['#' + header, 'import math', 'import numpy as np', '']
        code += [_pythonHelpers[h] for h in ['sign', 'round', 'LookupTable'] if h in used]
        code += ['def ' + functionName + '(' + ', '.join(parameters) + '):'] \
                + ['    ' + line for line in lines + resultLines] + ['    return ' + returns]
    return {'code': '\n'.join(code) + '\n', 'operations': numberOfOperations, 'patterns': patterns}
