#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# This is an EXUDYN python utility library
#
# Details:  The solver module provides interfaces to static, dynamic and eigenvalue solvers.
#           Most of the solvers are implemented inside the C++ core.
#
# Author:   Johannes Gerstmayr 
# Date:     2020-12-02
# Notes:    Solver functions are included directly in exudyn and can be used with mbs.SolveStatic(...)
#
# Copyright:This file is part of Exudyn. Exudyn is free software. You can redistribute it and/or modify it under the terms of the Exudyn license. See 'LICENSE.txt' for more details.
#
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#import is necessary, otherwise the solvers cannot be called
from exudyn.misc.docmeta import docmeta
import numpy as np
import exudyn
from exudyn.misc.extensionRegistry import extends

#public API of this module; kept complete by tools/checkAll.py (#2444)
__all__ = [
    'solverCheckMemoryAllocations', 'solverCheckMemoryAllocationsThreshold', 'SolverErrorMessage',
    'SolveStatic', 'SolveDynamic', 'SolverSuccess', 'DeactivateWritingOfSolvers',
    'RestoreSimulationSettings', 'UseSparseLinearSolver', 'ComputeLinearizedSystem',
    'ComputeODE2Eigenvalues', 'ComputeSystemDegreeOfFreedom',
    'CheckSolverInfoStatistics',
    ]

solverCheckMemoryAllocations = True
solverCheckMemoryAllocationsThreshold = 100000 #treshold for warning on too many news during solving

def SolverErrorMessage(solver, mbs, isStatic=False, 
                       showCausingObjects=True, showCausingNodes=True, showHints=True):
    """(internal) helper function for unique error and helper messages
    """
    s = ''
    s += '\n******************************\n'
    if isStatic:
        s += 'STATIC SOLVER FAILED:\n'
    else:        
        s += 'DYNAMIC SOLVER FAILED:\n'

    massMatrixNotInvertible = solver.conv.massMatrixNotInvertible
    linearSolverFailed = solver.conv.linearSolverFailed
    causingRow = solver.conv.linearSolverCausingRow
    newtonFailed = solver.conv.stepReductionFailed or solver.conv.newtonSolutionDiverged

    if showHints:
        s += '  POSSIBLE REASONS for solver abort:\n'
        if linearSolverFailed:
            s += '  * unused node or no equations supplied for node\n'
            s += '  * redundant definition of constraints\n'
        if (solver.conv.stepReductionFailed and (not solver.conv.newtonSolutionDiverged)
            and solver.conv.residual < 1e-3): #indicates that solution is not very wrong
            s += '  * your tolerances (in newton) may be too tight, see solutions below\n'
            
        s += '  * inconsistent or inappropriate initial conditions\n'
        s += '  * system is nearly singular due to high (penalty) stiffness or singularities in your system\n'
        if isStatic:
            s += '  * static problem has unconstrained coordinates (that can move freely)\n'
            if newtonFailed:
                s += '  * the system is very nonlinear and thus requires smaller (load) steps\n'
        else:
            if newtonFailed:
                s += '  * too large step size, which prevents Newton to converge\n'
            if linearSolverFailed:
                s += '  * singular mass matrix (no mass/inertia assigned?)\n'

        s += '  -------------------\n'
        s += '  POSSIBLE SOLUTIONS:\n'
        s += '  * check your Python model!\n'
        s += '  * check the causing nodes, objects, connectors, etc.\n'
        s += '  * check your nodes, objects, connectors, and markers\n'
        s += '  * change solver and solver settings (e.g. change index 3/index 2 solver)\n'
        s += '  * try linearSolver.ignoreSingularJacobian and EigenDense solver type in case of redundant constraints\n'
        s += '  * for small systems (<1000 coordinates), try mbs. ComputeSystemDegreeOfFreedom() to check system\n'
        s += '  * step-by-step remove constraints, until you find the causing item\n'
        s += '  * step-by-step remove objects and nodes, until you find the causing item\n'
        s += '  * check joint axes (using visualization), which may be incompatible\n'
        s += '  * use lower (penalty) stiffness factors\n'
        if newtonFailed:
            if isStatic:
                s += '  * adjust your tolerances: the newton solver may not be able to reach the relative or absolute tolerance, so increase them, e.g., staticSolver.newton.absoluteTolerance; if no loads are applied, usually absolute tolerances should be around 1e-5 to 1e-2\n'
            else:
                s += '  * adjust your tolerances: the newton solver may not be able to reach the relative or absolute tolerance, so increase them, e.g., timeIntegration.newton.absoluteTolerance; if no loads are applied, usually absolute tolerances should be around 1e-5 to 1e-2\n'
            s += '  * use smaller step size or load steps\n'
            s += '  * use adaptiveStep to reduce step size in static or dynamic simulation\n'
            s += '  * adjust the way you initialize your model and how to apply loads, etc.\n'
        s += '  * report error, clearly describing (a minimal description) of your problem, at reply.exudyn@gmail.com\n'
    else:
        s += "  use showHints=True to show helpful information\n"
    s += '******************************\n'
    
    nODE2 = solver.GetODE2size()
    nODE1 = solver.GetODE1size()
    nAE = solver.GetAEsize()
    nSys = nODE2+nODE1+nAE

    causingObjects = []
    if linearSolverFailed and causingRow >=0 and causingRow < nSys:
        s+="The causing system equation "+str(causingRow)+" belongs to a "
        if causingRow < nODE2:
            s+="ODE2 coordinate"
        elif causingRow < nODE2+nODE1:
            s+="ODE1 coordinate"
        else:
            s+="algebraic variable (Lagrange multiplier)"
        s+='\n'

        if showCausingObjects:
            for objectIndex in range(mbs.systemData.NumberOfObjects()):
                ltg = mbs.systemData.GetObjectLTGODE2(objectIndex)
                addObject = False
                if causingRow in ltg:
                    addObject = True
                ltg = mbs.systemData.GetObjectLTGODE1(objectIndex)
                if causingRow - (nODE2) in ltg:
                    addObject = True
                ltg = mbs.systemData.GetObjectLTGAE(objectIndex)
                if causingRow - (nODE2+nODE1) in ltg:
                    addObject = True

                if addObject and (objectIndex not in causingObjects):
                    causingObjects += [objectIndex]
            s+="Potential object number(s) causing linear solver to fail: "+str(causingObjects)+"\n"
            for i in causingObjects:
                oDict = mbs.GetObject(i)
                s += "    object "+str(i)+", name='"+oDict['name']+"', type="+ str(oDict['objectType']) +"\n"

    if massMatrixNotInvertible:
        s+='The mass matrix is not to invertable; check that every node/coordinate has appropriate mass!'

    return s


def _SolverFailed(solver, mbs, functionName, isStatic, showCausingItems, showHints, exception=None):
    """(internal) a failed solve: without an exception, raise SolverError with what the solver reports and the
    reasons and remedies of SolverErrorMessage; with one, add them to it as a note, which the traceback shows, and
    let the caller raise it - so the exception carries the whole message and nothing is printed (#1977);
    a KeyboardInterrupt is CTRL-C, not a failure, and gets no note"""
    if isinstance(exception, KeyboardInterrupt): #(#3628)
        return
    message = SolverErrorMessage(solver, mbs, isStatic=isStatic, showCausingObjects=showCausingItems,
                                 showCausingNodes=showCausingItems, showHints=showHints)
    if exception is None:
        report = solver.GetErrorString().strip()
        raise exudyn.SolverError(functionName + ' terminated' + (': ' + report if report else '') + message)
    if hasattr(exception, 'add_note'): #Python 3.11 and later
        exception.add_note(message)
    else:
        exudyn.Print(message)


@extends(exudyn.MainSystem)
def SolveStatic(mbs, simulationSettings = None, 
                updateInitialValues = False,
                storeSolver = True,
                showHints = False,
                showCausingItems = True,
                autoAssemble = True,
                ) -> bool:
    """solves the static mbs problem using simulationSettings; see MainSolverStatic, [Section](#sec:MainSolverStatic), for further details of the static solver; this function is also available in exudyn (using exudyn.SolveStatic(...))

    Args:
        mbs: the MainSystem containing the assembled system; note that mbs may be changed upon several runs of this function
        simulationSettings: specific simulation settings out of exu.SimulationSettings(), as described in [Section](#sec:SolutionSettings); use options for newton, discontinuous settings, etc., from staticSolver sub-items
        updateInitialValues: if True, the results are written to initial values, such at a consecutive simulation uses the results of this simulation as the initial values of the next simulation
        storeSolver: if True, the staticSolver object is stored in the mbs.sys dictionary as mbs.sys['staticSolver'], and simulationSettings are stored as mbs.sys['simulationSettings']
        showHints: show additional hints, if solver fails
        showCausingItems: if linear solver fails, this option helps to identify objects, etc. which are related to a singularity in the linearized system matrix
        autoAssemble: if True: if mbs.systemIsConsistent=False (system is not assembled), call mbs.Assemble() before solver calls

    Returns:
        :bool: returns True, if successful, False if fails; if storeSolver = True, mbs.sys contains staticSolver, which allows to investigate solver problems (see [Section](#sec:solverSubstructures) and the items described in [Section](#sec:MainSolverStatic))

    Example:
        import exudyn as exu
        from exudyn.itemInterface import *
        SC = exu.SystemContainer()
        mbs = SC.AddSystem()
        #create simple system:
        ground = mbs.AddObject(ObjectGround())
        mbs.AddNode(NodePoint())
        body = mbs.AddObject(MassPoint(mass=1, nodeNumber=0))
        m0 = mbs.AddMarker(MarkerBodyPosition(bodyNumber=ground))
        m1 = mbs.AddMarker(MarkerBodyPosition(bodyNumber=body))
        mbs.AddObject(CartesianSpringDamper(markerNumbers=[m0,m1], stiffness=[100,100,100]))
        mbs.AddLoad(LoadForceVector(markerNumber=m1, loadVector=[10,10,10]))
        mbs.Assemble()
        simulationSettings = exu.SimulationSettings()
        simulationSettings.timeIntegration.endTime = 10
        success = mbs.SolveStatic(simulationSettings, storeSolver = True)
        exu.Print("success =", success)
        exu.Print("iterations = ", mbs.sys['staticSolver'].it)
        exu.Print("pos=", mbs.GetObjectOutputBody(body,localPosition=[0,0,0],
              variableType=exu.OutputVariableType.Position))
    """
    if simulationSettings is None: simulationSettings = exudyn.SimulationSettings()
    if not mbs.systemIsConsistent and autoAssemble:
        exudyn.Print('WARNING: SolveStatic: mbs.systemIsConsistent=False, therefore calling mbs.Assemble() before solving; to avoid this, set autoAssemble=False')
        mbs.Assemble()

    staticSolver = exudyn.MainSolverStatic()
    if storeSolver:
        mbs.sys['staticSolver'] = staticSolver #copy solver structure to sys variable
        mbs.sys['simulationSettings'] = simulationSettings #link to last simulation settings
    success = False
    try:
        success = staticSolver.SolveSystem(mbs, simulationSettings)
    except BaseException as exception:
        #the exception that reaches here EXPLAINS the failure: an ExudynModelError, an
        #ExudynSolverError for a singular matrix, or the user's own error from a user function (#2534)
        _SolverFailed(staticSolver, mbs, 'SolveStatic', True, showCausingItems, showHints, exception)
        raise
    else:
        if not success:
            #the solver stopped without an exception: no Newton convergence, step size below the
            #minimum. Nothing was raised, so this is the one place that has to name a type
            _SolverFailed(staticSolver, mbs, 'SolveStatic', True, showCausingItems, showHints)

        if updateInitialValues:
            currentState = mbs.systemData.GetSystemState() #get current values
            mbs.systemData.SetSystemState(systemStateList=currentState, configuration = exudyn.ConfigurationType.Initial)


    return success

@extends(exudyn.MainSystem)
def SolveDynamic(mbs,
                simulationSettings = None, 
                solverType = None,
                updateInitialValues = False,
                storeSolver = True,
                showHints = False,
                showCausingItems = True,
                autoAssemble = True,
                index2CheckConstraints = True,
                ) -> bool:
    """solves the dynamic mbs problem using simulationSettings and solver type; see MainSolverImplicitSecondOrder, [Section](#sec:MainSolverImplicitSecondOrder), for further details of the dynamic solver; this function is also available in exudyn (using exudyn.SolveDynamic(...))

    Args:
        mbs: the MainSystem containing the assembled system; note that mbs may be changed upon several runs of this function
        simulationSettings: specific simulation settings out of exu.SimulationSettings(), as described in [Section](#sec:SolutionSettings); use options for newton, discontinuous settings, etc., from timeIntegration; therein, implicit second order solvers use settings from generalizedAlpha and explict solvers from explicit; be careful with settings, as the influence accuracy (step size!), convergence and performance (see special [Section](#sec:overview:basics:speedup))
        solverType: an exudyn.DynamicSolverType for this run, which takes the place of simulationSettings.timeIntegration.solverType while the solver runs and is set back afterwards; None (default): the solver given by simulationSettings.timeIntegration.solverType (default GeneralizedAlpha)
        updateInitialValues: if True, the results are written to initial values, such at a consecutive simulation uses the results of this simulation as the initial values of the next simulation
        storeSolver: if True, the dynamicSolver object is stored in the mbs.sys dictionary as mbs.sys['dynamicSolver'], and simulationSettings are stored as mbs.sys['simulationSettings']
        showHints: show additional hints, if solver fails
        showCausingItems: if linear solver fails, this option helps to identify objects, etc. which are related to a singularity in the linearized system matrix
        autoAssemble: if True: if mbs.systemIsConsistent=False (system is not assembled), call mbs.Assemble() before solver calls
        index2CheckConstraints: if True, the solver TrapezoidalIndex2, whose velocity-level (index 2) constraints let the
            positions drift, checks the drift of the position-level constraints during this run, as
            timeIntegration.generalizedAlpha.checkConstraintDrift = True does, and stops above constraintDriftTolerance (#565)

    Returns:
        :bool: returns True, if successful, False if fails; if storeSolver = True, mbs.sys contains dynamicSolver, which allows to investigate solver problems (see [Section](#sec:solverSubstructures) and the items described in [Section](#sec:MainSolverImplicitSecondOrder))

    Example:
        import exudyn as exu
        from exudyn.itemInterface import *
        SC = exu.SystemContainer()
        mbs = SC.AddSystem()
        #create simple system:
        ground = mbs.AddObject(ObjectGround())
        mbs.AddNode(NodePoint())
        body = mbs.AddObject(MassPoint(mass=1, nodeNumber=0))
        m0 = mbs.AddMarker(MarkerBodyPosition(bodyNumber=ground))
        m1 = mbs.AddMarker(MarkerBodyPosition(bodyNumber=body))
        mbs.AddObject(CartesianSpringDamper(markerNumbers=[m0,m1], stiffness=[100,100,100]))
        mbs.AddLoad(LoadForceVector(markerNumber=m1, loadVector=[10,10,10]))
        #
        mbs.Assemble()
        simulationSettings = exu.SimulationSettings()
        simulationSettings.timeIntegration.endTime = 10
        success = mbs.SolveDynamic(simulationSettings, storeSolver = True)
        exu.Print("success =", success)
        exu.Print("iterations = ", mbs.sys['dynamicSolver'].it)
        exu.Print("pos=", mbs.GetObjectOutputBody(body,localPosition=[0,0,0],
              variableType=exu.OutputVariableType.Position))
    """
    if simulationSettings is None: simulationSettings = exudyn.SimulationSettings()
    #the solver is a setting (#2813); a solverType given here takes its place for this run only
    solverTypeStored = simulationSettings.timeIntegration.solverType
    if solverType is None:
        solverType = solverTypeStored
    simulationSettings.timeIntegration.solverType = solverType
    try:
        return _SolveDynamic(mbs, simulationSettings, solverType, updateInitialValues, storeSolver, showHints,
                             showCausingItems, autoAssemble, index2CheckConstraints)
    finally:
        simulationSettings.timeIntegration.solverType = solverTypeStored


def _SolveDynamic(mbs, simulationSettings, solverType, updateInitialValues, storeSolver, showHints, showCausingItems,
                  autoAssemble, index2CheckConstraints):
    """SolveDynamic with the solver type decided and set in the settings"""
    success = False
    if not mbs.systemIsConsistent and autoAssemble:
        exudyn.Print('WARNING: SolveDynamic: mbs.systemIsConsistent=False, therefore calling mbs.Assemble() before solving; to avoid this, set autoAssemble=False')
        mbs.Assemble()

    if solverType in [exudyn.DynamicSolverType.TrapezoidalIndex2, exudyn.DynamicSolverType.GeneralizedAlpha,
                      exudyn.DynamicSolverType.TrapezoidalGGL, exudyn.DynamicSolverType.LobattoIIIA4,
                      exudyn.DynamicSolverType.LobattoIIIC4GGL, exudyn.DynamicSolverType.Radau3,
                      exudyn.DynamicSolverType.Radau5]: #the implicit Runge-Kutta methods in the implicit solver (#3261)
    
        dynamicSolver = exudyn.MainSolverImplicitSecondOrder()
        if storeSolver:
            mbs.sys['dynamicSolver'] = dynamicSolver #copy solver structure to sys variable
            mbs.sys['simulationSettings'] = simulationSettings #link to last simulation settings
        #if (experimentalNewSolver or #solver flag
        #    ('experimentalNewSolver' in exudyn.sys)): #flag set in test suite
        #    dynamicSolver.experimentalUseSolverNew = True #must be set at the very beginning when MainSolverImplicitSecondOrder() is initialized
    
        #store old settings:
        newmarkOld = simulationSettings.timeIntegration.generalizedAlpha.useNewmark
        index2Old = simulationSettings.timeIntegration.generalizedAlpha.useIndex2Constraints
        checkDriftOld = simulationSettings.timeIntegration.generalizedAlpha.checkConstraintDrift

        if solverType == exudyn.DynamicSolverType.TrapezoidalIndex2:
            #manually override settings for integrator
            simulationSettings.timeIntegration.generalizedAlpha.useNewmark = True
            simulationSettings.timeIntegration.generalizedAlpha.useIndex2Constraints = True
            #with velocity-level constraints, the positions drift (#565)
            if index2CheckConstraints:
                simulationSettings.timeIntegration.generalizedAlpha.checkConstraintDrift = True
    
        stat = exudyn.special.InfoStat(False)
        success = False
        try:
            success = dynamicSolver.SolveSystem(mbs, simulationSettings)
        except BaseException as exception:
            _SolverFailed(dynamicSolver, mbs, 'SolveDynamic', False, showCausingItems, showHints, exception)
            raise                       #what actually failed, with its traceback (#2534)
        else:
            if not success:
                _SolverFailed(dynamicSolver, mbs, 'SolveDynamic', False, showCausingItems, showHints)

            CheckSolverInfoStatistics(dynamicSolver.GetSolverName(), stat, dynamicSolver.it.newtonStepsCount) #now check if these statistics are ok
        finally:
            #THE RESTORE BELONGS HERE (#2535). TrapezoidalIndex2 overrides these two settings above,
            #and the raise used to sit in the same block ABOVE the restore - so a failed solve left
            #the user's simulationSettings with useNewmark=True and the NEXT solve in the same
            #script silently used a different integrator
            simulationSettings.timeIntegration.generalizedAlpha.useNewmark = newmarkOld
            simulationSettings.timeIntegration.generalizedAlpha.useIndex2Constraints = index2Old
            simulationSettings.timeIntegration.generalizedAlpha.checkConstraintDrift = checkDriftOld
    elif (solverType == exudyn.DynamicSolverType.ExplicitEuler or 
            solverType == exudyn.DynamicSolverType.ExplicitMidpoint or
            solverType == exudyn.DynamicSolverType.RK33 or
            solverType == exudyn.DynamicSolverType.RK44 or
            solverType == exudyn.DynamicSolverType.RK67 or
            solverType == exudyn.DynamicSolverType.ODE23 or
            solverType == exudyn.DynamicSolverType.DOPRI5 or
            solverType == exudyn.DynamicSolverType.VelocityVerlet
            ):
        dynamicSolver = exudyn.MainSolverExplicit()
        if storeSolver:
            mbs.sys['dynamicSolver'] = dynamicSolver #copy solver structure to sys variable
            mbs.sys['simulationSettings'] = simulationSettings #link to last simulation settings

        stat = exudyn.special.InfoStat(False)
        try:
            success = dynamicSolver.SolveSystem(mbs, simulationSettings)
        except BaseException as exception:
            _SolverFailed(dynamicSolver, mbs, 'SolveDynamic', False, showCausingItems, showHints, exception)
            raise
        #this branch used to return False in silence while the implicit branch raised, so the same
        #call aborted or continued depending on solverType (#2536)
        if not success:
            _SolverFailed(dynamicSolver, mbs, 'SolveDynamic', False, showCausingItems, showHints)

        CheckSolverInfoStatistics(dynamicSolver.GetSolverName(), stat, dynamicSolver.it.currentStepIndex*dynamicSolver.GetNumberOfStages()) #now check if these statistics are ok
    else:
        raise exudyn.NotImplementedFeatureError("SolveDynamic: solver type not implemented: "
                                                + str(solverType))
    
    if updateInitialValues:
        currentState = mbs.systemData.GetSystemState() #get current values
        mbs.systemData.SetSystemState(systemStateList=currentState, 
                                        configuration = exudyn.ConfigurationType.Initial)
        mbs.systemData.SetODE2Coordinates_tt(coordinates = mbs.systemData.GetODE2Coordinates_tt(), 
                                                configuration = exudyn.ConfigurationType.Initial)

    return success

def SolverSuccess(solverStructure):
    """return success (True/False) and error message of solver after SolveSteps(...), SolveSystem(...), SolveDynamic(...) or SolveStatic(...) have been called. May also be set if other higher level functions called e.g. SolveSystem(...)

    Args:
        solverStructure: solver structure, as stored in mbs.sys or as created e.g. by exudyn.MainSolverExplicit()

    Returns:
        :List[bool, str]: returns list [success,errorString], in which success=True or False and in case of no success, information is provided in errorString

    Example:
        #assume MainSystem mbs, exu library and simulationSettings:
        try:
            mbs.SolveDynamic(simulationSettings)
        except exu.ExudynError:
            [success, msg] = exu.SolverSuccess(mbs.sys['dynamicSolver'])
            exu.Print('success=',success)
            exu.Print('error message=',msg)
        #alternative:
        solver=exu.MainSolverImplicitSecondOrder()
        ...
        [success, msg] = exu.SolverSuccess(solver)
    """
    return [solverStructure.output.finishedSuccessfully, solverStructure.GetErrorString()]

#internal function: uniquely turn off all output and file writing - this would potentially erase user's output files ...
def DeactivateWritingOfSolvers(simulationSettings):
    store = {}
    store['verboseModeOld'] = simulationSettings.staticSolver.verboseMode
    simulationSettings.staticSolver.verboseMode = 0
    store['writeSolutionToFileOld'] = simulationSettings.solution.file.write
    simulationSettings.solution.file.write = False
    store['sensorsStoreAndWriteFilesOld'] = simulationSettings.solution.sensors.active
    simulationSettings.solution.sensors.active = False
    return store

#internal function for special solver functions; uniquely restores some settings
def RestoreSimulationSettings(simulationSettings, store):
    simulationSettings.staticSolver.verboseMode = store['verboseModeOld']
    simulationSettings.solution.file.write = store['writeSolutionToFileOld']
    simulationSettings.solution.sensors.active = store['sensorsStoreAndWriteFilesOld']
    

def UseSparseLinearSolver(simulationSettings, sparse):
    """with sparse, set simulationSettings.linearSolver.solverType to EigenSparse, so that the solver computes sparse system
    matrices (#1529); returns the type before, which the caller restores"""
    stored = simulationSettings.linearSolver.solverType
    if sparse and stored not in [exudyn.LinearSolverType.EigenSparse, exudyn.LinearSolverType.EigenSparseSymmetric]:
        simulationSettings.linearSolver.solverType = exudyn.LinearSolverType.EigenSparse
    return stored

@extends(exudyn.MainSystem)
def ComputeLinearizedSystem(mbs, 
                            simulationSettings = None,
                            projectIntoConstraintNullspace = False,
                            singularValuesTolerance = 1e-12,
                            returnConstraintJacobian = False,
                            returnConstraintNullspace = False,
                            autoAssemble = True,
                            useSparseMatrices = False,
                            ) -> list:
    r"""compute linearized system of equations for ODE2 part of mbs, not considering the effects of algebraic constraints; for computation of eigenvalues and advanced computation with constrained systems, see ComputeODE2Eigenvalues; the current implementation is also able to project into the constrained space, however, this currently does not generally work with non-holonomic systems

    Args:
        mbs: the MainSystem containing the assembled system
        simulationSettings: specific simulation settings used for computation of jacobian (e.g., sparse mode in static solver enables sparse computation)
        projectIntoConstraintNullspace: if False, algebraic equations (and constraint jacobian) are not considered for the linearized system; if True, the equations are projected into the nullspace of the constraints in the current configuration, using singular value decomposition; in the latter case, the returned list contains [M, K, D, C, N] where C is the constraint jacobian and N is the nullspace matrix (C and N may be an empty list, depending on the following flags)
        singularValuesTolerance: tolerance used to distinguish between zero and nonzero singular values for algebraic constraints projection
        returnConstraintJacobian: if True, the returned list contains [M, K, D, C, N] where C is the constraint jacobian and N is the nullspace matrix (may be empty)
        returnConstraintNullspace: if True, the returned list contains [M, K, D, C, N] where C is the constraint jacobian (may be empty) and N is the nullspace matrix
        autoAssemble: if True: if mbs.systemIsConsistent=False (system is not assembled), call mbs.Assemble() before solver calls
        useSparseMatrices: if True, the matrices are computed with the sparse solver and returned as scipy.sparse.csr_matrix, without dense matrices on the way - for large systems; needs scipy; not together with projectIntoConstraintNullspace or returnConstraintNullspace, which need a dense singular value decomposition

    Returns:
        :[ArrayLike, ArrayLike, ArrayLike]: [M, K, D]; list containing numpy mass matrix M, stiffness matrix K and damping matrix D (scipy.sparse.csr_matrix with useSparseMatrices=True); for constraints, see options with arguments above, return values may change to [M, K, D, C, N]

    Note:
        consider paper of Agundez, Vallejo, Freire, Mikkola, "The dependent coordinates in the linearization of constrained multibody systems: Handling and elimination", https://www.sciencedirect.com/science/article/pii/S0020740324000791

    Example:
        import exudyn as exu
        from exudyn.utilities import *
        import numpy as np
        SC = exu.SystemContainer()
        mbs = SC.AddSystem()
        #
        b0 = mbs.CreateMassPoint(referencePosition = [2,0,0],
                                 initialVelocity = [2*0,5,0],
                                 mass = 1, gravity = [0,-9.81,0],
                                 drawSize = 0.5, color=graphics.color.blue)
        #
        oGround = mbs.AddObject(ObjectGround())
        #add vertical spring
        oSD = mbs.CreateSpringDamper(itemNumbers=[oGround, b0],
                                     localPosition0=[2,1,0],
                                     localPosition1=[0,0,0],
                                     stiffness=1e4, damping=1e2,
                                     drawSize=0.2)
        #
        mbs.Assemble()
        [M,K,D] = mbs.ComputeLinearizedSystem()
        exu.Print('M=\n',M,'\nK=\n',K,'\nD=\n',D)
    """
    if simulationSettings is None: simulationSettings = exudyn.SimulationSettings()
    if useSparseMatrices and (projectIntoConstraintNullspace or returnConstraintNullspace):
        raise ValueError('ComputeLinearizedSystem: useSparseMatrices=True cannot be combined with projectIntoConstraintNullspace '
                         'or returnConstraintNullspace, which need a dense singular value decomposition')

    #do not overide sensor files or solution files ...
    store = DeactivateWritingOfSolvers(simulationSettings)
    linearSolverTypeStored = UseSparseLinearSolver(simulationSettings, useSparseMatrices)

    if not mbs.systemIsConsistent and autoAssemble:
        exudyn.Print('WARNING: ComputeLinearizedSystem: mbs.systemIsConsistent=False, therefore calling mbs.Assemble() before solving; to avoid this, set autoAssemble=False')
        mbs.Assemble()

    #use static solver, as it does not include factors from time integration (and no velocity derivatives) in the jacobian
    staticSolver = exudyn.MainSolverStatic()

    #initialize solver with initial values
    staticSolver.InitializeSolver(mbs, simulationSettings)

    nODE2 = staticSolver.GetODE2size()
    nODE1 = staticSolver.GetODE1size()
    nAE = staticSolver.GetAEsize()
    if nODE1 != 0:
        exudyn.Print('WARNING: ComputeLinearizedSystem: not implemented for ODE1 coordinates; results may be wrong')

    staticSolver.ComputeMassMatrix(mbs)
    Mode2 = staticSolver.GetSystemMassMatrix(sparse=useSparseMatrices)[0:nODE2,0:nODE2]

    staticSolver.ComputeJacobianODE2RHS(mbs,scalarFactor_ODE2=-1,
                                        scalarFactor_ODE2_t=0, 
                                        scalarFactor_ODE1=0)    #compute ODE2 part of jacobian ==> stored internally in solver

    if nAE != 0 and (projectIntoConstraintNullspace or returnConstraintJacobian or returnConstraintNullspace):
        #compute AE part of jacobian if needed for constraint projection
        staticSolver.ComputeJacobianAE(mbs, scalarFactor_ODE2=1., scalarFactor_ODE2_t=0., 
                                       scalarFactor_ODE1=0., #could be 1 to include ODE1 part
                                       velocityLevel=False)          

    jacobian = staticSolver.GetSystemJacobian(sparse=useSparseMatrices) #read out stored jacobian

    Kode2 = jacobian[0:nODE2,0:nODE2]    #obtain ODE2 part from jacobian == stiffness matrix

    staticSolver.ComputeJacobianODE2RHS(mbs,scalarFactor_ODE2=0,
                                        scalarFactor_ODE2_t=-1, 
                                        scalarFactor_ODE1=0)    #reset jacobian
    jacobian_t = staticSolver.GetSystemJacobian(sparse=useSparseMatrices) #read out stored jacobian
    
    Dode2 = jacobian_t[0:nODE2,0:nODE2] #obtain ODE2_t part from jacobian == damping matrix

    staticSolver.FinalizeSolver(mbs, simulationSettings) #close files, etc.
    RestoreSimulationSettings(simulationSettings, store)
    simulationSettings.linearSolver.solverType = linearSolverTypeStored

    #include constraints:
    listCN = []
    if nAE != 0 and (projectIntoConstraintNullspace or returnConstraintJacobian or returnConstraintNullspace):
        try:
            from scipy.linalg import svd
        except ImportError:
            raise ValueError('ComputeLinearizedSystem: missing scipy package; install with: pip install scipy')
        #use SVD to project equations into nullspace
        #constraint jacobian:
        C = jacobian[0:nODE2,nODE2+nODE1:]
        if returnConstraintJacobian:
            listCN = [C]
        else: listCN.append([])
        
        if projectIntoConstraintNullspace or returnConstraintNullspace:
            #compute SVD; D includes singular values
            [U,D,V] = svd(C)
            
            nnz = (abs(D) > singularValuesTolerance).sum() #size of constraints, often number of cols of C
    
            nullspace = U[:,nnz:].T 

            if returnConstraintNullspace:
                listCN.append(nullspace)
            else: listCN.append([])

    if nAE != 0 and projectIntoConstraintNullspace:
        Knullspace = nullspace @ Kode2 @ nullspace.T
        Mnullspace = nullspace @ Mode2 @ nullspace.T
        Dnullspace = nullspace @ Dode2 @ nullspace.T
            
        return [Mnullspace, Knullspace, Dnullspace] + listCN
    else:
        return [Mode2, Kode2, Dode2] + listCN

@docmeta(author='Johannes Gerstmayr, Michael Pieber')
@extends(exudyn.MainSystem)
def ComputeODE2Eigenvalues(mbs, 
                           simulationSettings = None,
                           useSparseSolver = False, numberOfEigenvalues = 0, constrainedCoordinates=[],
                           convert2Frequencies = False, useAbsoluteValues = True, 
                           computeComplexEigenvalues = False,
                           ignoreAlgebraicEquations=False, singularValuesTolerance=1e-12,
                           autoAssemble = True,
                           ) -> list:
    r"""compute eigenvalues for unconstrained ODE2 part of mbs, which represent the square of the eigenfrequencies (in radiant) of the undamped system; the computation may include constraints in case that ignoreAlgebraicEquations=False (however, this currently does not generally work with non-holonomic systems); for algebraic constraints, however, a dense singular value decomposition of the constraint jacobian is used for the nullspace projection; the computation is done for the initial values of the mbs, independently of previous computations. If you would like to use the current state for the eigenvalue computation, you need to copy the current state to the initial state (using GetSystemState, SetSystemState, see [Section](#sec:mbs:systemData)); with useSparseSolver=True, mass and stiffness matrices are computed and exported as sparse matrices (unless computeComplexEigenvalues or the projection of algebraic equations needs them dense).

    Args:
        mbs: the MainSystem containing the assembled system
        simulationSettings: specific simulation settings used for computation of jacobian (e.g., sparse mode in static solver enables sparse computation)
        useSparseSolver: if False (only for small systems), all eigenvalues are computed in dense mode (slow for large systems!); if True, only the numberOfEigenvalues are computed (numberOfEigenvalues must be set!), and mass and stiffness matrices are computed with the sparse solver and exported as scipy sparse matrices, without dense matrices on the way; NOTE that the sparsesolver accuracy is much less than the dense solver
        numberOfEigenvalues: number of eigenvalues and eivenvectors to be computed; if numberOfEigenvalues==0, all eigenvalues will be computed (may be impossible for larger or sparse problems!)
        constrainedCoordinates: if this list is non-empty (and there are no algebraic equations or ignoreAlgebraicEquations=True), the integer indices represent constrained coordinates of the system, which are fixed during eigenvalue/vector computation; according rows/columns of mass and stiffness matrices are erased; in this case, algebraic equations of the system are ignored
        convert2Frequencies: if True, the square root is computed for eigenvalues, they are converted into frequencies (Hz), and the output is [eigenFrequencies, eigenVectors]
        useAbsoluteValues: if True, abs(eigenvalues) is used, which avoids problems for small (close to zero) eigenvalues; needed, when converting to frequencies
        computeComplexEigenvalues: if True, the system is converted into a system of first order differential equations, including damping terms; returned eigenvalues are complex and contain the 'damping' (=real) part and the eigenfrequency (=complex) part; for this case, set useAbsoluteValues=False (otherwise you will not get the complex values; values are unsorted, however!); also, convert2Frequencies must be False in this case! only implemented for dense solver
        ignoreAlgebraicEquations: if True, algebraic equations (and constraint jacobian) are not considered for eigenvalue computation; otherwise, the solver tries to automatically project the system into the nullspace kernel of the constraint jacobian using a SVD; this gives eigenvalues of the constrained system; eigenvectors are not computed
        singularValuesTolerance: tolerance used to distinguish between zero and nonzero singular values for algebraic constraints projection
        autoAssemble: if True: if mbs.systemIsConsistent=False (system is not assembled), call mbs.Assemble() before solver calls

    Returns:
        :[ArrayLike, ArrayLike]: [eigenValues, eigenVectors]; eigenValues being a numpy array of eigen values ($\omega_i^2$, being the squared eigen frequencies in ($\omega_i$ in rad/s)!), eigenVectors a numpy array containing the eigenvectors in every column

    Example:
         #take any example from the Examples or TestModels folder, e.g., 'cartesianSpringDamper.py' and run it
         #specific example:
        import exudyn as exu
        from exudyn.utilities import *
        import numpy as np
        SC = exu.SystemContainer()
        mbs = SC.AddSystem()
        #
        b0 = mbs.CreateMassPoint(referencePosition = [2,0,0],
                                 mass = 1, gravity = [0,-9.81,0],
                                 drawSize = 0.5, color=graphics.color.blue)
        #
        oGround = mbs.AddObject(ObjectGround())
        #add vertical spring
        oSD = mbs.CreateSpringDamper(itemNumbers=[oGround, b0],
                                     localPosition0=[2,1,0],
                                     localPosition1=[0,0,0],
                                     stiffness=1e4, damping=1e2,
                                     drawSize=0.2)
        #
        mbs.Assemble()
        #
        [eigenvalues, eigenvectors] = mbs.ComputeODE2Eigenvalues()
        #==>eigenvalues contain the eigenvalues of the ODE2 part of the system in the current configuration
        #
        #compute eigenfrequencies in Hz (analytical: 100/2/pi Hz for y-direction):
        [eigenvaluesHz, ev] = mbs.ComputeODE2Eigenvalues(convert2Frequencies=True)
        #
        #compute complex eigenvalues:
        [eigenvaluesComplex, ev] = mbs.ComputeODE2Eigenvalues(computeComplexEigenvalues=True,
                                                              useAbsoluteValues=False)
    """
    if simulationSettings is None: simulationSettings = exudyn.SimulationSettings()

    store = DeactivateWritingOfSolvers(simulationSettings)

    if not mbs.systemIsConsistent and autoAssemble:
        exudyn.Print('WARNING: ComputeODE2Eigenvalues: mbs.systemIsConsistent=False, therefore calling mbs.Assemble() before solving; to avoid this, set autoAssemble=False')
        mbs.Assemble()

    #sparse matrices where the eigenvalues are computed with eigsh (#1529); the projection into the nullspace of the
    #constraints and the complex eigenvalues work on dense matrices
    sparseMatrices = (useSparseSolver and not computeComplexEigenvalues
                      and (constrainedCoordinates != [] or ignoreAlgebraicEquations or mbs.systemData.AEsize() == 0))
    linearSolverTypeStored = UseSparseLinearSolver(simulationSettings, sparseMatrices)

    try:
        from scipy.linalg import eigh, eig, svd  #eigh for symmetric matrices, positive definite; eig for standard eigen value problems
        from scipy.sparse.linalg import eigsh #eigh for symmetric matrices, positive definite
        from scipy.sparse import csr_matrix
    except ImportError:
        raise ValueError('ComputeODE2Eigenvalues: missing scipy package; install with: pip install scipy')

    #use static solver, as it does not include factors from time integration (and no velocity derivatives) in the jacobian
    staticSolver = exudyn.MainSolverStatic()

    #initialize solver with initial values
    staticSolver.InitializeSolver(mbs, simulationSettings)

    nODE2 = staticSolver.GetODE2size()
    nODE1 = staticSolver.GetODE1size()
    nAE = staticSolver.GetAEsize()
    if nODE1 != 0:
        exudyn.Print('WARNING: ComputeODE2Eigenvalues: not implemented for ODE1 coordinates; results may be wrong')

    staticSolver.ComputeMassMatrix(mbs)
    Mode2 = staticSolver.GetSystemMassMatrix(sparse=sparseMatrices)[0:nODE2,0:nODE2]

    #compute ODE2 part of jacobian ==> stored internally in solver
    staticSolver.ComputeJacobianODE2RHS(mbs,scalarFactor_ODE2=-1,
                                        scalarFactor_ODE2_t=0, 
                                        scalarFactor_ODE1=0)    #could be 1 to include ODE1 part
    if nAE != 0:
        #compute AE part of jacobian if needed for constraint projection
        staticSolver.ComputeJacobianAE(mbs, scalarFactor_ODE2=1., scalarFactor_ODE2_t=0., 
                                       scalarFactor_ODE1=0., #could be 1 to include ODE1 part
                                       velocityLevel=False)          
    
    jacobian = staticSolver.GetSystemJacobian(sparse=sparseMatrices) #read out stored jacobian; includes ODE2, ODE1 and nAE part

    #obtain ODE2 part from jacobian == stiffness matrix
    Kode2 = jacobian[0:nODE2,0:nODE2]

    if computeComplexEigenvalues:
        if convert2Frequencies:
            raise ValueError('ComputeODE2Eigenvalues: In case of computeComplexEigenvalues=True, you must set convert2Frequencies=False !')
            
        #compute damping matrix
        staticSolver.ComputeJacobianODE2RHS(mbs,scalarFactor_ODE2=0,
                                                scalarFactor_ODE2_t=-1, 
                                                scalarFactor_ODE1=0)    #could be 1 to include ODE1 part
        jacobianD = staticSolver.GetSystemJacobian() #read out stored jacobian; includes ODE2, ODE1 and nAE part
        Dode2 = jacobianD[0:nODE2,0:nODE2]

    remappingIndices = np.arange(nODE2) #maps new coordinates to original (full) ones
    if constrainedCoordinates != [] and sparseMatrices:
        remappingIndices = np.delete(remappingIndices, constrainedCoordinates)
        Mode2 = Mode2[remappingIndices][:, remappingIndices]
        Kode2 = Kode2[remappingIndices][:, remappingIndices]
    elif constrainedCoordinates != []:
        Mode2 = np.delete(np.delete(Mode2, constrainedCoordinates, 0), constrainedCoordinates, 1)
        Kode2 = np.delete(np.delete(Kode2, constrainedCoordinates, 0), constrainedCoordinates, 1)
        if computeComplexEigenvalues:
            Dode2 = np.delete(np.delete(Dode2, constrainedCoordinates, 0), constrainedCoordinates, 1)
        
        remappingIndices = np.delete(remappingIndices, constrainedCoordinates)

    staticSolver.FinalizeSolver(mbs, simulationSettings) #close files, etc.
    RestoreSimulationSettings(simulationSettings, store)
    simulationSettings.linearSolver.solverType = linearSolverTypeStored

    if nAE != 0 and not ignoreAlgebraicEquations and constrainedCoordinates != []:
        raise ValueError('ComputeODE2Eigenvalues: in case of algebraic equations, either ignoreAlgebraicEquations=True or constrainedCoordinates=[]')


    if constrainedCoordinates != [] or nAE == 0 or ignoreAlgebraicEquations:
        if not useSparseSolver:
            if not computeComplexEigenvalues:
                [eigenValuesUnsorted, eigenVectors] = eigh(Kode2, Mode2) #this gives omega^2 ... squared eigen frequencies (rad/s)
            else:
                #complex eigenvalues
                B = np.block([[                  Kode2, Dode2     ],
                              [np.zeros((nODE2,nODE2)),-Mode2     ]])
            
                A = np.block([[np.zeros((nODE2,nODE2)), Mode2                    ],
                              [                  Mode2, np.zeros((nODE2,nODE2))]])                
                Amod = -np.dot(np.linalg.inv(A),B)
                [eigenValuesUnsorted, eigenVectors] = eig(Amod)
            
            if useAbsoluteValues:
                sortIndices = np.argsort(abs(eigenValuesUnsorted)) #get resorting index
                eigenValues = np.sort(a=abs(eigenValuesUnsorted)) #eigh returns unsorted eigenvalues...
            else:
                sortIndices = np.argsort(eigenValuesUnsorted) #get resorting index
                eigenValues = np.sort(a=eigenValuesUnsorted) #eigh returns unsorted eigenvalues...
            if numberOfEigenvalues > 0:
                eigenValues = eigenValues[0:numberOfEigenvalues]
                sortIndices = sortIndices[0:numberOfEigenvalues]
            eigenVectors = eigenVectors[:,sortIndices] #eigenvectors are given in columns!
        else:
            if computeComplexEigenvalues:
                raise ValueError('ComputeODE2Eigenvalues: computeComplexEigenvalues must be False with sparse solvers')
            if numberOfEigenvalues == 0: #compute all eigenvalues
                numberOfEigenvalues = nODE2
    
            Kcsr = csr_matrix(Kode2)
            Mcsr = csr_matrix(Mode2)
    
            #use "LM" (largest magnitude), but shift-inverted mode with sigma=0, to find the zero-eigenvalues:
            #see https://docs.scipy.org/doc/scipy/reference/tutorial/arpack.html
            [eigenValues, eigenVectors] = eigsh(A=Kcsr, k=numberOfEigenvalues, M=Mcsr, 
                                       which='LM', sigma=0, mode='normal') 
    
            #sort eigenvalues
            if useAbsoluteValues:
                sortIndices = np.argsort(abs(eigenValues)) #get resorting index
                eigenValues = np.sort(a=abs(eigenValues))
            else:
                sortIndices = np.argsort(eigenValues) #get resorting index
                eigenValues = np.sort(a=eigenValues)
            eigenVectors = eigenVectors[:,sortIndices] #eigenvectors are given in columns!

        eigenVectorsNew = np.zeros((nODE2,numberOfEigenvalues))
        if constrainedCoordinates != []:
            for i in range(numberOfEigenvalues):
                eigenVectorsNew[remappingIndices,i] = eigenVectors[:,i]
            eigenVectors = eigenVectorsNew
    else: #this includes general constraints and requires different solvers
                             
        if useSparseSolver:
            raise ValueError('ComputeODE2Eigenvalues: in case of algebraic equations and ignoreAlgebraicEquations=False, useSparseSolver must be False')
        #use SVD to project equations into nullspace
        #constraint jacobian:
        C = jacobian[0:nODE2,nODE2+nODE1:]
        
        #compute SVD; D includes singular values
        [U,D,V] = svd(C)
        
        nnz = (abs(D) > singularValuesTolerance).sum() #size of constraints, often number of cols of C
        
        nullspace = U[:,nnz:].T #U[nnz:]
        Knullspace = nullspace@Kode2@nullspace.T
        Mnullspace = nullspace@Mode2@nullspace.T
        nODE2ns = Knullspace.shape[0]
            
        if computeComplexEigenvalues:
            Dnullspace = nullspace@Dode2@nullspace.T
            #A*q_t + B*q=0 => q=[x,v]
            #[0  M] [x_t]   [K  D] [x]
            #[    ]*[   ] + [    ]*[ ] = 0
            #[I  0] [v_t]   [0 -I] [v]
            #complex eigenvalues
            B = np.block([[                 Knullspace,  Dnullspace                   ],
                          [np.zeros((nODE2ns,nODE2ns)), -Mnullspace                   ]])
        
            A = np.block([[np.zeros((nODE2ns,nODE2ns)), Mnullspace                 ],
                          [                 Mnullspace, np.zeros((nODE2ns,nODE2ns))]])                
            Amod = -np.dot(np.linalg.inv(A),B)
            [eigenValuesUnsorted, eigenVectorsReduced] = eig(Amod)
        else:
            [eigenValuesUnsorted, eigenVectorsReduced] = eigh(Knullspace,Mnullspace)
            
        if useAbsoluteValues:
            sortIndices = np.argsort(abs(eigenValuesUnsorted)) #get resorting index
            eigenValues = np.sort(a=abs(eigenValuesUnsorted)) #eigh returns unsorted eigenvalues...
        else:
            sortIndices = np.argsort(eigenValuesUnsorted) #get resorting index
            eigenValues = np.sort(a=eigenValuesUnsorted) #eigh returns unsorted eigenvalues...

        if numberOfEigenvalues > 0:
            eigenValues = eigenValues[0:numberOfEigenvalues]
            sortIndices = sortIndices[0:numberOfEigenvalues]
        eigenVectorsReduced = eigenVectorsReduced[:,sortIndices] #eigenvectors are given in columns!

        if computeComplexEigenvalues:
            eigenVectors = np.block([nullspace.T, nullspace.T]) @ eigenVectorsReduced
        else:
            eigenVectors = nullspace.T @ eigenVectorsReduced



    if convert2Frequencies: #not possible for computeComplexEigenvalues !
        eigenFrequencies = np.sqrt(eigenValues)/(2*np.pi)
        return [eigenFrequencies, eigenVectors]
    else:
        return [eigenValues, eigenVectors]

    

@extends(exudyn.MainSystem)
def ComputeSystemDegreeOfFreedom(mbs, 
                simulationSettings = None,
                threshold = 1e-12, verbose=False, useSVD=False,
                autoAssemble = True,
                ) -> dict:
    """compute system DOF numerically, considering Grübler-Kutzbach formula as well as redundant constraints; uses numpy matrix rank or singular value decomposition of scipy (useSVD=True)

    Args:
        mbs: MainSystem for which DOF shall be computed
        simulationSettings: used e.g. for settings regarding numerical differentiation; default settings may be used in most cases
        threshold: threshold factor for singular values which estimate the redundant constraints
        useSVD: use singular value decomposition directly, also showing SVD values if verbose=True
        verbose: if True, it will show the singular values and one may decide if the threshold shall be adapted
        autoAssemble: if True: if mbs.systemIsConsistent=False (system is not assembled), call mbs.Assemble() before solver calls

    Returns:
        :dict: returns dictionary with key words 'degreeOfFreedom', 'redundantConstraints', 'nODE2', 'nODE1', 'nAE', 'nPureAE', where: degreeOfFreedom = the system degree of freedom computed numerically, redundantConstraints=the number of redundant constraints, nODE2=number of ODE2 coordinates, nODE1=number of ODE1 coordinates, nAE=total number of constraints, nPureAE=number of constraints on algebraic variables (e.g., lambda=0) that are not coupled to ODE2 coordinates

    Note:
        this approach could possibly fail with special constraints! Currently only works with dense matrices, thus it will be slow for larger systems

    Example:
        import exudyn as exu
        from exudyn.utilities import *
        import numpy as np
        SC = exu.SystemContainer()
        mbs = SC.AddSystem()
        #
        b0 = mbs.CreateRigidBody(inertia = InertiaCuboid(density=5000,
                                                         sideLengths=[1,0.1,0.1]),
                                 referencePosition = [6,0,0],
                                 initialAngularVelocity = [0,8,0],
                                 gravity = [0,-9.81,0],
                                 graphicsDataList = [exu.graphics.Brick(size=[1,0.1,0.1],
                                                                              color=graphics.color.orange)])
        oGround = mbs.AddObject(ObjectGround())
        mbs.CreateGenericJoint(itemNumbers=[oGround, b0], position=[5.5,0,0],
                               constrainedAxes=[1,1,1, 1,0,0],
                               rotationMatrixAxes=RotationMatrixX(0.125*pi), #tilt axes
                               useGlobalFrame=True, axesRadius=0.02, axesLength=0.2)
        #
        mbs.Assemble()
        dof = mbs.ComputeSystemDegreeOfFreedom(verbose=1)['degreeOfFreedom'] #print out details
    """
    if simulationSettings is None: simulationSettings = exudyn.SimulationSettings()

    #use static solver, as it does not include factors from time integration (and no velocity derivatives) in the jacobian
    store = DeactivateWritingOfSolvers(simulationSettings)

    if not mbs.systemIsConsistent and autoAssemble:
        exudyn.Print('WARNING: ComputeSystemDegreeOfFreedom: mbs.systemIsConsistent=False, therefore calling mbs.Assemble() before solving; to avoid this, set autoAssemble=False')
        mbs.Assemble()

    staticSolver = exudyn.MainSolverStatic()
    #initialize solver with initial values
    staticSolver.InitializeSolver(mbs, simulationSettings)

    nODE2 = staticSolver.GetODE2size()
    nODE1 = staticSolver.GetODE1size()
    if nODE1 != 0:
        exudyn.Print('WARNING: ComputeSystemDegreeOfFreedom(...) not suitable in case of ODE1 coordinates; ODE1 coordinates will not count as additional DOF!')
    nODE12 = nODE2+nODE1
    nAE = staticSolver.GetAEsize()

    #reset jacobian    
    staticSolver.ComputeJacobianODE2RHS(mbs,scalarFactor_ODE2=-1,
                                        scalarFactor_ODE2_t=0, 
                                        scalarFactor_ODE1=0)    #compute ODE2 part of jacobian ==> stored internally in solver
    staticSolver.ComputeJacobianAE(mbs, scalarFactor_ODE2=1., scalarFactor_ODE2_t=0., scalarFactor_ODE1=1., velocityLevel=False)
    jacobian = staticSolver.GetSystemJacobian()#.round(20) #read out stored jacobian

    Code2 = jacobian[0:nODE2, nODE12:]    #C_q: constraint jacobian
    Cae = jacobian[nODE12:,nODE12:]       #C_lambda
    Call =  jacobian[:, nODE12:]
    
    staticSolver.FinalizeSolver(mbs, simulationSettings) #close files, etc.
    #restore old settings:
    RestoreSimulationSettings(simulationSettings, store)
    
    if verbose == 2:
        exudyn.Print('Code2=\n', Code2, sep='')
        exudyn.Print('Cae  =\n', Cae, sep='')

    if useSVD:
        try:
            from scipy.linalg import svdvals#, svd
        except ImportError:
            raise ValueError('ComputeSystemDegreeOfFreedom: missing scipy package; install with: pip install scipy')

    
    nRedundant = 0
    nPureAE = 0
    if nAE != 0:

        if useSVD:
            #s = svd(Call, compute_uv=False, full_matrices=False)#, lapack_driver='gesvd')
            s = svdvals(Call)
    
            if verbose:
                exudyn.Print('singular values ODE2+AE='+str(s))
    
            sAE = svdvals(Cae)
            #sAE = svd(Cae, compute_uv=False, full_matrices=False)#, lapack_driver='gesvd')
    
            if verbose:
                exudyn.Print('singular values pure AE='+str(sAE))
            
            nRedundant = (abs(s) <= threshold).sum() #counts True=1, False=0
            #these are constraints on AE coordinates, which do not count as constraints!
            nPureAE = (abs(sAE) > threshold).sum() #counts True=1, False=0
        else:
            nRedundant = nAE - np.linalg.matrix_rank(Call)
            nPureAE = np.linalg.matrix_rank(Cae)

    dof = nODE2-(nAE-nPureAE)+nRedundant
    if verbose:
        exudyn.Print('ODE2 coordinates          = '+str(nODE2))
        exudyn.Print('total constraints         = '+str(nAE))
        exudyn.Print('redundant constraints     = '+str(nRedundant))
        exudyn.Print('pure algebraic constraints= '+str(nPureAE))
        exudyn.Print('degree of freedom         = '+str(dof))

    #return [dof, nRedundant, nODE2, nODE1, nAE, nPureAE] #old mode
    return {'degreeOfFreedom':dof, 
            'redundantConstraints':nRedundant, 
            'nODE2':nODE2, 'nODE1':nODE1, 
            'nAE':nAE, 'nPureAE':nPureAE}


    
def CheckSolverInfoStatistics(solverName, infoStat, numberOfEvaluations):
    """helper function for solvers to check e.g. if high number of memory allocations happened during simulation
    This can happen, if large amount of sensors are attached and output is written in every time step

    Args:
        stat=exudyn.special.InfoStat() from previous step, numberOfEvaluations is a counter which is proportional to number of RHS evaluations in method
    """
    stat = np.array(exudyn.special.InfoStat(False)) - np.array(infoStat)

    newCnt = max(stat[0],stat[2],stat[4]) #array, vector, matrix new counts

    if newCnt > solverCheckMemoryAllocationsThreshold and newCnt >= numberOfEvaluations:
        exudyn.Print("WARNING: "+solverName+" detected large amount ("+str(newCnt)+") of memory allocations, which seem to occur in every time step; this may be due to user functions; solver may be slow")


#%%+++++++++++++++++++
if __name__ == '__main__':
    import exudyn.demos as demos
    if True:
        [mbs, SC] = demos.Demo1(False)
        res = exudyn.ComputeSystemDegreeOfFreedom(mbs, verbose=True)
        exudyn.Print('Demo1 dof=',res['degreeOfFreedom'],'\n') #2 DOF (2D mass point freely moving)

    #takes some seconds to compute:
    if True:
        [mbs, SC] = demos.Demo2(False)
        res = exudyn.ComputeSystemDegreeOfFreedom(mbs)
        exudyn.Print('Demo2=',res,'\n') #12*3=36 (12 bodies with 12 spherical joints)
    
        res = exudyn.ComputeSystemDegreeOfFreedom(mbs, verbose=True, useSVD=True)
        exudyn.Print('Demo2 using SVD=',res) #12*3=36 (12 bodies with 12 spherical joints)


    #3D rigid-body with revolute joint and spring, same as in TestModels/ComputeODE2AEeigenvaluesTest.py
    #compared to analytical solution
    if True:
        from exudyn.utilities import ObjectGround, InertiaCuboid, MarkerBodyRigid,\
            CartesianSpringDamper, VObjectConnectorCartesianSpringDamper
            
        import exudyn.graphics as graphics 
        import numpy as np

        SC = exudyn.SystemContainer()
        mbs = SC.AddSystem()

        beamL=0.1 #in m
        beamW=0.01
        beamH=0.001
        rho=5000 #kg/m**3
        springL=0.02 #in m
        springK=1e1 #in N/m
    
        oGround = mbs.AddObject(ObjectGround())
    
        inertiaCuboid=InertiaCuboid(density=rho,
                                sideLengths=[beamL,beamH,beamW])
    
        bBeam = mbs.CreateRigidBody(inertia = inertiaCuboid,
                                referencePosition = [beamL*0.5,0,0],
                                gravity = [0,-9.81*0,0],
                                graphicsDataList = [exudyn.graphics.Brick(size=[beamL,beamH,beamW],
                                color=graphics.color.orange)])
        mBeamRight = mbs.AddMarker(MarkerBodyRigid(bodyNumber=bBeam, localPosition=[beamL*0.5,0,0]))

        mbs.CreateGenericJoint(itemNumbers= [oGround,bBeam], position= [0.,0.,0.], 
                                      rotationMatrixAxes= np.eye(3), constrainedAxes= [1,1,1,1,1,0], 
                                      axesRadius=0.001, axesLength= 0.01, color= exudyn.graphics.color.default)
    
        markerToConnect = mbs.AddMarker(MarkerBodyRigid(bodyNumber=oGround, localPosition=[beamL,-springL,0])) 
    
        mbs.AddObject(CartesianSpringDamper(markerNumbers=[markerToConnect,mBeamRight],
                                            stiffness=[0,springK,0],
                                            damping=[0,0,0],
                                            offset=[0,springL,0],
                                            visualization=VObjectConnectorCartesianSpringDamper(show=True,drawSize=0.01)
                                            ))    
        mbs.Assemble()
        [ew, ev] = mbs.ComputeODE2Eigenvalues()

        evNumerical = np.sqrt(ew[0]) / (2*np.pi)
        
        thetaZZ=inertiaCuboid.Translated([-beamL/2,0,0]).Inertia()[2,2]
        evAnalytical = np.sqrt( springK*beamL**2/thetaZZ ) / (2*np.pi)

        exudyn.Print('numerical eigenvalues in Hz:',evNumerical)
        exudyn.Print('analytical eigenvalues in Hz:',evAnalytical)
        exudyn.Print('error eigenvalues:', (evAnalytical-evNumerical)/evAnalytical)

