#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# This is an EXUDYN python utility library
#
# Details:  The constructors of curves in 3D for the curve markers: the matrix of the segments that exudyn.cUtilities.Curve
#           and the curve markers take, one row per segment - screw segments (lines, circular arcs, helices), polynomial
#           segments from Hermite data, quintic transitions between two curves, and C2 cubic and C4 quintic splines
#           through points, with a rotation-minimizing director.
#
# Author:   Johannes Gerstmayr
# Date:     2026-11-22
#
# Copyright:This file is part of Exudyn. Exudyn is free software. You can redistribute it and/or modify it under the terms of the Exudyn license. See 'LICENSE.txt' for more details.
#
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

import numpy as np
import exudyn.cMath as cMath #the math functions of the C++ code, the same bits on every platform
from exudyn.cUtilities import Curve, ComputeOrthonormalBasisVectors

#public API of this module; kept complete by tools/checkAll.py
__all__ = [
    'CurveMatrix', 'CurveState', 'PolynomialSegment', 'ScrewSegment', 'LineSegment', 'ArcSegment', 'HelixSegment',
    'HermiteSegment', 'TransitionSegment', 'RotationMinimizingDirectors', 'SplineCurve',
    ]

_screwType = 1


def _Vector(v, name):
    v = np.array(v, dtype=float).flatten()
    if v.size != 3:
        raise ValueError('curves: ' + name + ' must have 3 components, not ' + str(v.size))
    return v


def _Frame(tangent, normal, name):
    """the rotation matrix of the columns t, n, t x n: t the unit tangent, n the unit part of normal normal to t; a
    normal of the tangent if normal is None"""
    t = _Vector(tangent, name + ': tangent')
    if not cMath.norm(t) > 0:
        raise ValueError('curves: ' + name + ': the tangent must not be zero')
    t = t/cMath.norm(t)
    if normal is None:
        n = ComputeOrthonormalBasisVectors(t)[1]
    else:
        n = _Vector(normal, name + ': normal')
        n = n - (n @ t)*t
        if not cMath.norm(n) > 1e-12:
            raise ValueError('curves: ' + name + ': the normal must not be parallel to the tangent')
        n = n/cMath.norm(n)
    return np.array([t, n, np.cross(t, n)]).T


def CurveMatrix(segments):
    """
    the matrix of a curve from its segments, one row per segment as PolynomialSegment, ScrewSegment, ... return them,
    padded with zeros to the longest row; the curve markers and exudyn.cUtilities.Curve take it
    Args:
        segments: a list of rows of segments, or of matrices of several segments (CurveMatrix or SplineCurve)
    Returns:
        the numpy array with one row per segment
    """
    rows = []
    for segment in segments:
        segment = np.array(segment, dtype=float)
        rows += [segment] if segment.ndim == 1 else list(segment)
    width = max(len(row) for row in rows)
    matrix = np.zeros((len(rows), width))
    for (i, row) in enumerate(rows):
        matrix[i, :len(row)] = row
    return matrix


def CurveState(segments, s=None):
    """
    the curve at the curve parameter s (default: its end), evaluated with the segment that contains s, as the dict of
    exudyn.cUtilities.Curve.Evaluate: 'position' (r, r', r'', r''' by s), 'frame', 'frame_s', 'curvature',
    'curvature_s'; for chaining segments and for TransitionSegment
    Args:
        segments: the matrix of the curve (CurveMatrix), or the row of one segment
        s: the curve parameter, None for the end of the curve
    Returns:
        the dict of the curve at s
    """
    curve = Curve(CurveMatrix([segments]))
    if s is None:
        s = curve.Length()
    return curve.Evaluate(curve.FindSegment(s), s)


def PolynomialSegment(controlPoints, directorPoints, length):
    """
    the row of a polynomial segment in Bernstein form, cubic or quintic
    Args:
        controlPoints: the 4 (cubic) or 6 (quintic) control points of the position, as rows of 3 coordinates
        directorPoints: the control points of the director, as many as controlPoints
        length: the range of the curve parameter s of the segment
    Returns:
        the row of the segment, for CurveMatrix
    """
    points = np.array(controlPoints, dtype=float)
    directors = np.array(directorPoints, dtype=float)
    if points.ndim != 2 or points.shape[1] != 3 or points.shape[0] not in [4, 6]:
        raise ValueError('PolynomialSegment: controlPoints must be 4 or 6 rows of 3 coordinates; received shape ' + str(points.shape))
    if directors.shape != points.shape:
        raise ValueError('PolynomialSegment: directorPoints must have the shape of controlPoints, ' + str(points.shape) + '; received ' + str(directors.shape))
    if not length > 0:
        raise ValueError('PolynomialSegment: length must be positive')
    return np.concatenate([[points.shape[0] - 1, length], points.flatten(), directors.flatten()])


def ScrewSegment(position, rotationMatrix, curvature, length):
    """
    the row of a screw segment: the frame R(s) = R0 exp(s omega~) along the unit tangent R(s) e_x, exact in position,
    frame, curvature and torsion
    Args:
        position: the position at the start
        rotationMatrix: R0, the frame at the start; its first column is the tangent
        curvature: omega, the curvature vector in the frame: [torsion, 0, curvature] gives a helix with the normal
            in the second column of the frame, [0, 0, 1/radius] a circular arc, zeros a line
        length: the arc length of the segment
    Returns:
        the row of the segment, for CurveMatrix
    """
    R0 = np.array(rotationMatrix, dtype=float)
    if R0.shape != (3, 3):
        raise ValueError('ScrewSegment: rotationMatrix must be a 3x3 matrix')
    if not length > 0:
        raise ValueError('ScrewSegment: length must be positive')
    return np.concatenate([[_screwType, length], _Vector(position, 'ScrewSegment: position'), R0.flatten(),
                           _Vector(curvature, 'ScrewSegment: curvature')])


def LineSegment(start, end, normal=None):
    """
    the row of a straight segment from start to end, a screw segment without curvature
    Args:
        start: the point at the start
        end: the point at the end
        normal: a vector not parallel to the line, whose part normal to it is the normal of the frame; None for any
    Returns:
        the row of the segment, for CurveMatrix
    """
    start, end = _Vector(start, 'LineSegment: start'), _Vector(end, 'LineSegment: end')
    length = cMath.norm(end - start)
    return ScrewSegment(start, _Frame(end - start, normal, 'LineSegment'), [0, 0, 0], length)


def ArcSegment(start, tangent, normal, radius, angle):
    """
    the row of a circular arc, a screw segment
    Args:
        start: the point at the start
        tangent: the direction at the start
        normal: the direction from the start towards the center (its part normal to tangent)
        radius: the radius
        angle: the angle of the arc in radians
    Returns:
        the row of the segment, for CurveMatrix
    """
    if not (radius > 0 and angle > 0):
        raise ValueError('ArcSegment: radius and angle must be positive')
    return ScrewSegment(start, _Frame(tangent, normal, 'ArcSegment'), [0, 0, 1/radius], radius*angle)


def HelixSegment(start, tangent, normal, curvature, torsion, length):
    """
    the row of a helix, a screw segment with constant curvature and torsion
    Args:
        start: the point at the start
        tangent: the direction at the start
        normal: the principal normal at the start (its part normal to tangent), towards the axis of the helix
        curvature: the curvature, 1/radius of the osculating circle
        torsion: the torsion; a helix of radius a and pitch 2 pi c has curvature a/(a^2+c^2) and torsion c/(a^2+c^2)
        length: the arc length
    Returns:
        the row of the segment, for CurveMatrix
    """
    return ScrewSegment(start, _Frame(tangent, normal, 'HelixSegment'), [torsion, 0, curvature], length)


def _Bernstein(coefficients):
    """the Bernstein control points of a polynomial given by its coefficients in powers of u in [0, 1] (rows)"""
    degree = len(coefficients) - 1
    def binomial(n, k):
        return float(np.prod([(n - k + i)/i for i in range(1, k + 1)]))
    return np.array([sum(binomial(j, k)/binomial(degree, k)*coefficients[k] for k in range(j + 1)) for j in range(degree + 1)])


def HermiteSegment(position0, position1, tangent0, tangent1, length=None, secondDerivative0=None, secondDerivative1=None,
                   director0=None, director1=None):
    """
    the row of a polynomial segment from Hermite data at its ends: cubic from the positions and the first derivatives
    by s, quintic with the second derivatives as well; the director interpolated linearly between director0 and
    director1
    Args:
        position0: the position at the start
        position1: the position at the end
        tangent0: the first derivative by the curve parameter s at the start (a unit vector for s the arc length)
        tangent1: the first derivative by s at the end
        length: the range of s; None for the distance of the ends
        secondDerivative0: the second derivative by s at the start; give both or none
        secondDerivative1: the second derivative by s at the end
        director0: the director at the start; None for a normal of tangent0
        director1: the director at the end; None for director0
    Returns:
        the row of the segment, for CurveMatrix
    """
    p0, p1 = _Vector(position0, 'HermiteSegment: position0'), _Vector(position1, 'HermiteSegment: position1')
    r0, r1 = _Vector(tangent0, 'HermiteSegment: tangent0'), _Vector(tangent1, 'HermiteSegment: tangent1')
    L = cMath.norm(p1 - p0) if length is None else length
    if (secondDerivative0 is None) != (secondDerivative1 is None):
        raise ValueError('HermiteSegment: give both second derivatives or none')
    if secondDerivative0 is None:
        points = [p0, p0 + L/3*r0, p1 - L/3*r1, p1]
    else:
        a0 = _Vector(secondDerivative0, 'HermiteSegment: secondDerivative0')
        a1 = _Vector(secondDerivative1, 'HermiteSegment: secondDerivative1')
        points = [p0, p0 + L/5*r0, p0 + 2*L/5*r0 + L**2/20*a0, p1 - 2*L/5*r1 + L**2/20*a1, p1 - L/5*r1, p1]
    d0 = _Frame(r0, None, 'HermiteSegment')[:, 1] if director0 is None else _Vector(director0, 'HermiteSegment: director0')
    d1 = d0 if director1 is None else _Vector(director1, 'HermiteSegment: director1')
    n = len(points) - 1
    directors = [d0 + j/n*(d1 - d0) for j in range(n + 1)]
    return PolynomialSegment(points, directors, L)


def TransitionSegment(state0, state1, length=None):
    """
    the row of a quintic segment from the end of one curve to the start of another with the same position, tangent
    and curvature at both ends (the role of the clothoid in track design), so that the curve stays C2 from a line
    into an arc; the director from the normals of the frames
    Args:
        state0: the curve at the start, as CurveState returns it, e.g. CurveState(curve0)
        state1: the curve at the end, e.g. CurveState(curve1, 0)
        length: the range of s; None for the distance of the ends
    Returns:
        the row of the segment, for CurveMatrix
    """
    r0, r1 = np.array(state0['position']), np.array(state1['position'])
    return HermiteSegment(r0[0], r1[0], r0[1], r1[1], length, r0[2], r1[2],
                          np.array(state0['frame'])[:, 1], np.array(state1['frame'])[:, 1])


def RotationMinimizingDirectors(positions, tangents, normal0=None, closed=False):
    """
    the rotation-minimizing frame along points of a curve by the double reflection of Wang et al. (2008): the normal
    of each point from the previous one, without rotation about the tangent
    Args:
        positions: the points of the curve, as rows, dense enough to follow it
        tangents: the tangents at the points
        normal0: the normal at the first point (its part normal to the first tangent); None for any
        closed: True for a closed curve: the end twist, the angle between the normal carried around the curve and
            normal0, is distributed linearly over the points, so that the normals close
    Returns:
        the unit normals at the points, as rows, and the end twist in radians (0 for an open curve)
    """
    x = np.array(positions, dtype=float)
    t = np.array([v/cMath.norm(v) for v in np.array(tangents, dtype=float)])
    normals = [_Frame(t[0], normal0, 'RotationMinimizingDirectors')[:, 1]]
    for i in range(len(x) - 1):
        v1 = x[i + 1] - x[i]
        c1 = v1 @ v1
        r = normals[-1]
        if c1 > 0:
            rL = r - (2/c1*(v1 @ r))*v1
            tL = t[i] - (2/c1*(v1 @ t[i]))*v1
        else:
            rL, tL = r, t[i]
        v2 = t[i + 1] - tL
        c2 = v2 @ v2
        r = rL - (2/c2*(v2 @ rL))*v2 if c2 > 0 else rL
        r = r - (r @ t[i + 1])*t[i + 1]
        normals.append(r/cMath.norm(r))
    normals = np.array(normals)
    twist = 0.
    if closed:
        #the angle about the first tangent from the carried normal to the first normal
        n0, nEnd = normals[0], normals[-1]
        twist = cMath.atan2(np.cross(nEnd, n0) @ t[0], nEnd @ n0)
        arc = np.concatenate([[0], np.cumsum([cMath.norm(x[i + 1] - x[i]) for i in range(len(x) - 1)])])
        for i in range(len(x)):
            angle = twist*arc[i]/arc[-1]
            n, b = normals[i], np.cross(t[i], normals[i])
            normals[i] = cMath.cos(angle)*n + cMath.sin(angle)*b
    return normals, twist


def _SplineCoefficients(values, lengths, degree, closed):
    """the coefficients in powers of u in [0, 1] of the C(degree-1) spline through values with the parameter ranges
    lengths: interpolation at both ends of each segment, continuity of the derivatives 1 to degree-1 by s at the joints
    (and at the closing joint of a closed curve), else the derivatives (degree+1)/2 to degree-1 zero at both ends"""
    nSegments = len(lengths)
    p = degree
    nUnknowns = nSegments*(p + 1)
    A = np.zeros((nUnknowns, nUnknowns))
    b = np.zeros((nUnknowns, values.shape[1]))
    row = 0
    def factorial(k):
        return float(np.prod(range(1, k + 1)))
    def Derivative(segment, m, u, factor=1.):
        #the row of the m-th derivative by s of segment at u (0 or 1)
        coefficients = np.zeros(nUnknowns)
        for k in range(m, p + 1):
            coefficients[segment*(p + 1) + k] = factor*factorial(k)/factorial(k - m)*u**(k - m)/lengths[segment]**m
        return coefficients
    for i in range(nSegments):
        A[row] = Derivative(i, 0, 0.)
        b[row] = values[i]
        A[row + 1] = Derivative(i, 0, 1.)
        b[row + 1] = values[(i + 1) % len(values)]
        row += 2
    joints = nSegments if closed else nSegments - 1
    for i in range(joints):
        for m in range(1, p):
            A[row] = Derivative(i, m, 1.) - Derivative((i + 1) % nSegments, m, 0.)
            row += 1
    if not closed:
        for m in range((p + 1)//2, p):
            A[row] = Derivative(0, m, 0.)
            A[row + 1] = Derivative(nSegments - 1, m, 1.)
            row += 2
    solution = np.linalg.solve(A, b)
    return [solution[i*(p + 1):(i + 1)*(p + 1)] for i in range(nSegments)]


def SplineCurve(points, degree=3, closed=False, directors=None, normal0=None):
    """
    the matrix of a spline through points: cubic (degree=3), C2, or quintic (degree=5), C4, with the curve parameter
    s the length of the chords between the points (close to the arc length); an open curve with the natural ends
    (the derivatives from (degree+1)/2 to degree-1 zero at both ends), a closed curve periodic
    Args:
        points: the points, as rows of 3 coordinates, at least 2 (open) or 3 (closed); a closed curve returns to the
            first point
        degree: 3 or 5
        closed: True for a closed curve
        directors: the directors at the points, as rows, interpolated by the same spline; None for the
            rotation-minimizing director (RotationMinimizingDirectors) starting with normal0, with the end twist
            distributed for a closed curve
        normal0: the normal at the first point, if directors is None; None for any
    Returns:
        the matrix of the segments, one per pair of neighbouring points
    """
    x = np.array(points, dtype=float)
    if degree not in [3, 5]:
        raise ValueError('SplineCurve: degree must be 3 or 5')
    if x.ndim != 2 or x.shape[1] != 3 or len(x) < (3 if closed else 2):
        raise ValueError('SplineCurve: points must be at least ' + ('3' if closed else '2') + ' rows of 3 coordinates; received shape ' + str(x.shape))
    nSegments = len(x) if closed else len(x) - 1
    lengths = np.array([cMath.norm(x[(i + 1) % len(x)] - x[i]) for i in range(nSegments)])
    if not min(lengths) > 0:
        raise ValueError('SplineCurve: neighbouring points must not coincide')
    position = _SplineCoefficients(x, lengths, degree, closed)
    if directors is None:
        #the rotation-minimizing director along 8 points per segment, taken at the points
        substeps = 8
        samples, tangents = [], []
        for i in range(nSegments):
            for j in range(substeps + (0 if closed or i < nSegments - 1 else 1)):
                u = j/substeps
                samples.append(sum(position[i][k]*u**k for k in range(degree + 1)))
                tangents.append(sum(k*position[i][k]*u**(k - 1) for k in range(1, degree + 1)))
        if closed:
            samples.append(samples[0])
            tangents.append(tangents[0])
        normals = RotationMinimizingDirectors(samples, tangents, normal0, closed)[0]
        d = normals[::substeps][:len(x)]
    else:
        d = np.array(directors, dtype=float)
        if d.shape != x.shape:
            raise ValueError('SplineCurve: directors must have the shape of points, ' + str(x.shape) + '; received ' + str(d.shape))
    director = _SplineCoefficients(d, lengths, degree, closed)
    return CurveMatrix([PolynomialSegment(_Bernstein(position[i]), _Bernstein(director[i]), lengths[i]) for i in range(nSegments)])
