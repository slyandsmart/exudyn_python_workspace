#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# This is an EXUDYN python utility library
#
# Details:  The machines library includes helper functions and classes for
#           mechanical engineering and machine elements: involute gears, ball bearings, the
#           ISO metric screw threads and roller chain drives
#
# Author:   Johannes Gerstmayr
# Date:     2023-01-06
#
# Copyright:This file is part of Exudyn. Exudyn is free software. You can redistribute it and/or modify it under the terms of the Exudyn license. See 'LICENSE.txt' for more details.
#
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

import exudyn as exu
import numpy as np
from math import radians
from exudyn.cMath import cos, sin, sqrt, tan, atan, atan2, pi
import exudyn.cMath as cMath #the math functions of the C++ code, the same bits on every platform (#2962)

#public API of this module; kept complete by tools/checkAll.py (#2444)
__all__ = [
    'Involute', 'ApproxInvolute', 'InvInvolute', 'InvoluteGear', 'MetricThreadSizes', 'MetricThread',
    'GetBallBearingData', 'CreateBallBearing',
    'rollerChainDimensions', 'RollerChain', 'RollerChainSprocket', 'RollerChainDrive',
    ]

#%%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def Involute(x):
    r"""compute involute (x being in radians): $y=\tan(x)-x$;
    """
    if abs(x) < 0.02:
        return ApproxInvolute(x)
    return tan(x)-x

def ApproxInvolute(x):
    r"""Approximate involute for $|x| < 0.02$, being more accurate than tan: $y=\tan(x)-x \approx (1/3) x^3 + (2/15) x^5$;
    """
    return (1./3.) * x**3 + (2./15.) * x**5 + (17./315.) * x**7

def InvInvolute(y, warn=True):
    r"""compute inverse of involute, see Involute(x); computes $x$ for given $y$ in $y=\tan(x)-x$ using Newton-Raphson method

    Args:
        y provides given value; if warn==True, a warning is displayed if no convergence is achieved

    Note:
        uses Newton-Raphson method (iteratively); usually converges within 4-5 steps
    """
    #compute starting value:
    if abs(y) > 2:
        x0 = atan(y)
    else:
        x0 = cMath.cbrt(3*y) - 2./5.*y  #numpy cubic root also includes negative case!
    
    converged = False
    maxIt = 10
    it = 0
    while not converged and it < maxIt:
        tanX0 = tan(x0)
        if abs(x0) < 0.02:
            d = (y - ApproxInvolute(x0))/tanX0**2
        else:
            d = (y-(tanX0-x0))/tanX0**2
        if abs(d) < 1e-13: #last iteration should do the rest ...
            converged = True
        x0 += d
        it += 1

    if it == maxIt and warn:
        raise ValueError('ERROR: InvInvolute(...) did not converge within 10 steps!')

    return x0




#%%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#GEARS

class InvoluteGear:
    r"""class InvoluteGear is based on github project py_gear_gen, but improved for compatibility with Exudyn; Note the involute profile is generated using the coordinates with parametrization phi (not the polar angle): $x = r_b (\cos(\varphi) + \varphi * \sin(\varphi))$, $y = r_b (\sin(\varphi) - \varphi * \cos(\varphi))$, which avoids numerical computation of the involute function
    """
    def __init__(self, module=1, nTeeth=12, pressureAngleDeg=20, fillet=0, backlash=0,
                 maxSteps=100, arcStepSize=0.1, reductionToleranceDeg=0, 
                 dedendumFactor=1.157, addendumFactor=1.0, isInternalGear=False,
                 tolerance = 1e-6):
        """Initialize class with involute gear parameters, to be then generated with GenerateGear()

        Args:
            module: module of the gear (pitch diameter / number of teeth)
            nTeeth: number of teeth on the gear
            pressureAngleDeg: pressure angle of the gear in degrees
            fillet: radius of the fillet connecting a tooth to the root circle
            backlash: circumferential play between meshed teeth
            maxSteps: maximum steps for generating the involute profile, not all of them used
            arcStepSize: step size for generating arcs for root
            reductionToleranceDeg: angle tolerance for polyline reduction in degrees
            dedendumFactor: factor for dedendum (depth below the pitch circle)
            addendumFactor: factor for addendum (height above the pitch circle)
            isInternalGear: set flag True for internal gear
            tolerance: points closer than this distance are removed; this avoids problems with meshing later on
        """
        self.module = module
        self.nTeeth = nTeeth
        self.pressureAngle = radians(pressureAngleDeg)
        self.reductionTolerance = radians(reductionToleranceDeg)
        self.isInternalGear = isInternalGear
        self.tolerance = tolerance

        # Addendum and dedendum
        self.addendum = addendumFactor * module
        self.dedendum = dedendumFactor * module

        # Adjust for internal gears
        if isInternalGear:
            self.addendum, self.dedendum = self.dedendum, self.addendum

        # Radii
        self.pitchRadius = (module * nTeeth) / 2
        self.baseRadius = cos(self.pressureAngle) * self.pitchRadius
        self.outerRadius = self.pitchRadius + self.addendum
        self.rootRadius = self.pitchRadius - self.dedendum
        self.filletRadius = fillet if not isInternalGear else 0

        # Angular properties
        self.angleToothAndGap = 2 * pi / nTeeth
        angularBacklash = backlash / (2 * self.pitchRadius)
        self.angleTooth = self.angleToothAndGap / 2 - angularBacklash if not isInternalGear else angularBacklash
        self.anglePitchIntersect = None
        self.angleFullTooth = None

        self.maxSteps = maxSteps
        self.arcStepSize = arcStepSize

    def MirrorMatrixV(self):
        """returns a 2x2 numpy array for vertical mirroring
        """
        return np.array([[1, 0], [0, -1]])

    def RotationMatrix2D(self, angleRad):
        """compute 2D rotation matrix; not imported from exudyn.rigidBodyUtilities to avoid cyclic imports

        Args:
            angle around out-of-plane axis in radiant

        Returns:
            2x2 rotation matrix as np.array
        """
        return np.array([ [cMath.cos(angleRad),-cMath.sin(angleRad)],
                          [cMath.sin(angleRad), cMath.cos(angleRad)] ]);
    
    def PolarToCartesian(self, polarCoordinates):
        """convert polarCoordinates as [radius,angle] into Cartesian coordinates [x,y]
        """
        r, ang = polarCoordinates
        return np.array([r * cos(ang), r * sin(ang)])
    
    
    def CartesianToPolar(self, cartesianCoordinates):
        """convert cartesianCoordinates [x,y] into polar coordinates as [radius,angle]
        """
        x, y = cartesianCoordinates
        return np.array([sqrt(x * x + y * y), atan2(y, x)])

    def GenerateHalfTooth(self):
        """generate half of an involute tooth profile; later on mirrored for full tooth

        Returns:
            numpy array of shape (2, n) representing the half-tooth profile
        """
        phiList = np.linspace(0, pi, self.maxSteps)
        points = []
        reachedLimit = False
        self.anglePitchIntersect = None

        for phi in phiList:
            x = self.baseRadius * (cos(phi) + phi * sin(phi))
            y = self.baseRadius * (sin(phi) - phi * cos(phi))
            point = (x, y)
            dist, theta = self.CartesianToPolar(point).tolist()

            if self.anglePitchIntersect is None and dist >= self.pitchRadius:
                self.anglePitchIntersect = theta
                self.angleFullTooth = 2 * self.anglePitchIntersect + self.angleTooth
            elif self.anglePitchIntersect is not None and theta >= self.angleFullTooth / 2:
                reachedLimit = True
                break

            if dist >= self.outerRadius:
                points.append(self.PolarToCartesian((self.outerRadius, theta)).tolist())
            elif dist <= self.rootRadius:
                points.append(self.PolarToCartesian((self.rootRadius, theta)).tolist())
            else:
                points.append((x, y))

        if not reachedLimit:
            raise ValueError("Tooth profile incomplete; check profile parameters!")

        return np.array(points).T

    def GenerateHalfRoot(self):
        """generate half of the root profile between teeth; later on mirrored for full root profile

        Returns:
            numpy array of shape (2, n) representing the half-root profile
        """
        rootArcLength = (self.angleToothAndGap - self.angleFullTooth) * self.rootRadius
        pointsRoot = []

        for theta in np.arange(self.angleFullTooth, self.angleToothAndGap / 2 + self.angleFullTooth / 2,
                               self.arcStepSize / self.rootRadius):
            arcPosition = (theta - self.angleFullTooth) * self.rootRadius
            inFillet = min(rootArcLength - arcPosition, arcPosition) < self.filletRadius

            r = self.rootRadius
            if inFillet:
                circlePos = min(arcPosition, rootArcLength - arcPosition)
                r += self.filletRadius - sqrt(self.filletRadius**2 - (self.filletRadius - circlePos)**2)

            pointsRoot.append(self.PolarToCartesian((r, theta)).tolist())

        return np.array(pointsRoot).T

    def GenerateRoots(self):
        """generate roots on either side of the first tooth

        Returns:
            list of two numpy arrays, each of shape (2, n)
        """
        halfRoot = self.GenerateHalfRoot()
        halfRoot = self.RotationMatrix2D(-self.angleFullTooth / 2) @ halfRoot
        pointsSecondHalf = self.MirrorMatrixV() @ halfRoot
        pointsSecondHalf = np.flip(pointsSecondHalf, axis=1)
        return [pointsSecondHalf, halfRoot]

    def GenerateTooth(self):
        """generate a single involute tooth profile

        Returns:
            numpy array of shape (2, n) representing the tooth profile
        """
        halfTooth = self.GenerateHalfTooth()
        halfTooth = self.RotationMatrix2D(-self.angleFullTooth / 2 ) @ halfTooth
        pointsSecondHalf = self.MirrorMatrixV() @ halfTooth
        pointsSecondHalf = np.flip(pointsSecondHalf, axis=1)
        tooth = np.concatenate((halfTooth, pointsSecondHalf), axis=1)
        return tooth

    def GenerateToothAndGap(self):
        """a single tooth and the adjacent root profile

        Returns:
            numpy array of shape (2, n) representing the tooth and gap profile
        """
        tooth = self.GenerateTooth()
        roots = self.GenerateRoots()
        toothAndGap = np.concatenate((roots[0], tooth, roots[1]), axis=1)
        return toothAndGap

    def GenerateGear(self):
        """generate gear according to dimensions and return Cartesian coordinates of profile

        Returns:
            numpy array of shape (n, 2) representing the gear outline; [x,y] coordinates are in rows of 2D numpy array
        """
        toothAndGap = self.GenerateToothAndGap()
        teeth = [self.RotationMatrix2D(self.angleToothAndGap * n) @ toothAndGap for n in range(self.nTeeth)]
        gear = np.concatenate(teeth, axis=1)
        gear = gear.T
        
        gearFixed = []
        pLast = gear[0,:]
        for p in gear[1:]:
            if cMath.norm(p-pLast) >= self.tolerance:
                gearFixed.append(p)
                pLast = p
        
        return np.array(gearFixed)


#%%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#SCREW THREADS

#ISO metric coarse threads in mm: size -> (pitch, width across flats s, head height k, nut height m);
#nominal values of ISO 261/262 (pitch), ISO 4014 (s, k of the hexagon head) and ISO 4032 (m of the hexagon nut)
_metricCoarseThreads = {
    'M2': (0.4, 4, 1.4, 1.6),       'M2.5': (0.45, 5, 1.7, 2),     'M3': (0.5, 5.5, 2, 2.4),
    'M4': (0.7, 7, 2.8, 3.2),       'M5': (0.8, 8, 3.5, 4.7),      'M6': (1, 10, 4, 5.2),
    'M8': (1.25, 13, 5.3, 6.8),     'M10': (1.5, 16, 6.4, 8.4),    'M12': (1.75, 18, 7.5, 10.8),
    'M14': (2, 21, 8.8, 12.8),      'M16': (2, 24, 10, 14.8),      'M18': (2.5, 27, 11.5, 15.8),
    'M20': (2.5, 30, 12.5, 18),     'M22': (2.5, 34, 14, 19.4),    'M24': (3, 36, 15, 21.5),
    'M27': (3, 41, 17, 23.8),       'M30': (3.5, 46, 18.7, 25.6),  'M33': (3.5, 50, 21, 28.7),
    'M36': (4, 55, 22.5, 31),       'M39': (4, 60, 25, 33.4),      'M42': (4.5, 65, 26, 34),
    'M45': (4.5, 70, 28, 36),       'M48': (5, 75, 30, 38),        'M52': (5, 80, 33, 42),
    'M56': (5.5, 85, 35, 45),       'M60': (5.5, 90, 38, 48),
    }

def MetricThreadSizes():
    """the sizes of the ISO metric coarse threads known to MetricThread, from M2 to M60

    Returns:
        list of strings, e.g. ['M2', 'M2.5', 'M3', ...]
    """
    return list(_metricCoarseThreads.keys())

def MetricThread(size):
    r"""the data of an ISO metric coarse thread and of its hexagon bolt and nut, in metres; nominal values for drawing
    and rough design: the pitch by ISO 261/262, the width across flats and the head height by ISO 4014, the nut height
    by ISO 4032; the depth is that of the basic profile of ISO 68-1, $5/8 H$ with $H = \sqrt{3}/2\,P$

    Args:
        size: the size as string, 'M2' ... 'M60' (see MetricThreadSizes()), or the nominal diameter in mm as a number

    Returns:
        dict with 'size', 'nominalDiameter', 'pitch', 'depth', 'minorDiameter' (the basic minor diameter $d - 2\cdot 5/8 H$),
        'widthAcrossFlats', 'headHeight', 'nutHeight', all lengths in metres

    Example:
        d = machines.MetricThread('M10') #d['pitch'] = 0.0015, d['widthAcrossFlats'] = 0.016
    """
    name = size if isinstance(size, str) else 'M' + ('%g' % size)
    if name not in _metricCoarseThreads:
        raise ValueError("MetricThread: unknown size '" + str(size) + "'; known are " + ', '.join(MetricThreadSizes()))
    (pitch, s, k, m) = _metricCoarseThreads[name]
    d = float(name[1:])
    depth = 5/8*sqrt(3)/2*pitch
    return {'size': name, 'nominalDiameter': 1e-3*d, 'pitch': 1e-3*pitch, 'depth': 1e-3*depth,
            'minorDiameter': 1e-3*(d - 2*depth), 'widthAcrossFlats': 1e-3*s, 'headHeight': 1e-3*k, 'nutHeight': 1e-3*m}


#%%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#ROLLING-ELEMENT BEARINGS


def GetBallBearingData(axis, outsideDiameter, boreDiameter, width, nBalls, 
                       radiusBalls=None, ballsAngleOffset=0,
                       radiusCage=None, innerGrooveRadius=None, outerGrooveRadius=None,
                       innerRingShoulderRadius=None, outerRingShoulderRadius=None, 
                       widthCage=None, heightCage=None,
                       innerEdgeChamfer=None, outerEdgeChamfer=None):
    """based on some nominal data, this function computes the data for a ball bearning, using a couple of common assumptions

    Args:
        outsideDiameter: outer radius of outer ring
        boreDiameter: inner radius of inner ring
        width: width of bearing
        radiusBalls: radius of balls; if not provided it is assumed as 58% of (outsideDiameter-boreDiameter)
        ballsAngleOffset: angle offset for location of balls (in radiant)
        radiusCage: radius of centers of balls; if not provided it is assumed as (outsideDiameter+boreDiameter)/2
        innerGrooveRadius: depends on osculation (usually radiusBalls*1.02 ... radiusBalls*1.04); if not provided assumed as radiusBalls*1.04
        outerGrooveRadius: same as rGrooveInner if not provided
        innerRingShoulderRadius: outer radius of inner ring
        outerRingShoulderRadius: inner radius of outer ring
        heightCage: radial dimension of cage (just for drawing)
        widthCage: width of cage (just for drawing)
        outerEdgeChamfer: chamfer or radius
        innerEdgeChamfer: chamfer or radius

    Returns:
        returns dictionary with all data as used by further bearing functions; note: 'ballPositions' are in the local bearing coordinate system!
    """

    from exudyn.rigidBodyUtilities import ComputeOrthonormalBasisVectors
    outsideRadius = 0.5*outsideDiameter
    boreRadius = 0.5*boreDiameter
    
    #some default parameters (these are rough approximations!)
    if radiusBalls is None:
        radiusBalls = 0.58*(outsideRadius-boreRadius)
    if radiusCage is None:
        radiusCage = 0.5*(outsideRadius+boreRadius)
    if innerGrooveRadius is None:
        innerGrooveRadius = 1.04*radiusBalls
    if outerGrooveRadius is None:
        outerGrooveRadius = 1.04*radiusBalls
    if innerRingShoulderRadius is None:
        innerRingShoulderRadius=radiusCage-0.3*radiusBalls
    if outerRingShoulderRadius is None:
        outerRingShoulderRadius=radiusCage+0.3*radiusBalls
    if widthCage is None:
        widthCage=2.5*radiusBalls #just for drawing
    if heightCage is None:
        heightCage=(outerRingShoulderRadius-innerRingShoulderRadius)*0.7 #just for drawing
    if outerEdgeChamfer is None:
        outerEdgeChamfer=radiusBalls/8
    if innerEdgeChamfer is None:
        innerEdgeChamfer=radiusBalls/8
    
    lenAxis = cMath.norm(axis)
    vAxis0 = np.array(axis)/lenAxis
    innerGrooveTorusRadius = radiusCage+innerGrooveRadius-radiusBalls
    outerGrooveTorusRadius = radiusCage+radiusBalls-outerGrooveRadius

    
    [v,ny,nz] = ComputeOrthonormalBasisVectors(vAxis0)
    ballPositions = []
    for i in range(nBalls):
        phi = i/nBalls*2*pi
        pos = radiusCage*(cos(phi)*ny + sin(phi)*nz)
        ballPositions.append(pos)

    data = {#from input data
            'axis':vAxis0,
            'outsideDiameter':outsideDiameter,
            'boreDiameter':boreDiameter,
            'width':width,
            'nBalls':nBalls,
            'radiusBalls':radiusBalls,
            'radiusCage':radiusCage,
            'innerGrooveRadius':innerGrooveRadius,
            'outerGrooveRadius':outerGrooveRadius,
            'innerRingShoulderRadius':innerRingShoulderRadius,
            'outerRingShoulderRadius':outerRingShoulderRadius,
            'widthCage':widthCage,
            'heightCage':heightCage,
            'innerEdgeChamfer':innerEdgeChamfer,
            'outerEdgeChamfer':outerEdgeChamfer,
            #additional data:
            'innerGrooveTorusRadius':innerGrooveTorusRadius,
            'outerGrooveTorusRadius':outerGrooveTorusRadius,
            'ballPositions':ballPositions
            }
    
    return data

def CreateBallBearing(mbs, bearingData, markerInnerRing, markerOuterRing, densityBalls, densityCage,
                      cageInitialAngularVelocity=[0,0,0], ballsInitialAngularVelocity=[0,0,0],
                      gravity=[0,0,0],
                      springStiffnessCage=0, springDampingCage=0,
                      contactParametersRingBalls={'contactStiffness':2e6,'contactDamping':2e2,'dynamicFriction':0.2,'contactStiffnessExponent':1},
                      nTilesRings=32, nTilesGrooves=12, colorCage=[0.6,0.57,0.4,0.4], 
                      colorInnerRing=[0.5,0.5,0.5,1], colorOuterRing=[0.5,0.5,0.5,1],
                      nTilesBalls=32, colorBalls=[0.6,0.6,0.65,1], addBallsBasis=False, ballsDrawRadiusFactor=1
                      ):
    """create ball bearing in mbs using bearingData from function GetBallBearingData; requires rigid body markers for inner ring and outer ring and creates rigid bodies for cage and balls; also adds contact between balls and inner ring and balls and outer ring

    Args:
        mbs: a MainSystem where bearing objects are added
        bearingData: dictionary as returned from GetBallBearingData; note that axis represents the local axis relative to markers markerInnerRing and markerOuterRing
        markerInnerRing: a rigid body marker where the inner ring is attached to; this represents the bearing center position and orientation; bearing axis is relative to this marker
        markerOuterRing: a rigid body marker where the outer ring is attached to
        densityBalls: the material density for sphere rigid bodies
        densityCage: the material density for cage rigid body, assuming a hollow cylinder with dimensions given in bearingData; density should be adjusted to weight of cage
        cageInitialAngularVelocity: the global initial angular velocity vector of the cage
        ballsInitialAngularVelocity: the global initial angular velocity vector of the balls
        gravity: either [0,0,0] or otherwise the gravity added to balls and cage
        springStiffnessCage: if non-zero, for simplicity spring-dampers are added between balls and cage instead of contact with cage
        springDampingCage: if non-zero, for simplicity springs-dampers are added between balls and cage instead of contact with cage
        contactParametersRingBalls: a dictionary with contact parameters according to ObjectContactSphereTorus, including usually contactStiffness, contactDamping, dynamicFriction, and contactStiffnessExponent
        colorCage: cage RGBA color
        nTilesRings: circumferential tiling of rings
        nTilesGrooves: tiling of grooves
        colorInnerRing: inner ring RGBA color
        colorOuterRing: outer ring RGBA color
        nTilesBalls: tiling of spheres for balls
        colorBalls: balls RGBA color
        addBallsBasis: if True, basis vectors are added to drawing of balls, to see rotation
        ballsDrawRadiusFactor: a factor for drawing balls smaller to avoid drawing artifacts between rings and balls; ideally should be 1

    Returns:
        returns dictionary with newly created items: objectsBalls, objectCage, innerRingBallContacts, outerRingBallContacts, objectsCageBallContact
    """
    
    import exudyn.graphics as graphics
    import exudyn.itemInterface as eii
    from exudyn.rigidBodyUtilities import InertiaSphere, InertiaCylinder, ComputeOrthonormalBasis

    bearingGraphics = graphics.BallBearingRings(**bearingData,colorCage=colorCage,nTilesRings=64)
    
    bearingCenterPos = mbs.GetMarkerOutput(markerInnerRing, exu.OutputVariableType.Position,
                                           configuration=exu.ConfigurationType.Reference)
    bearingRot = mbs.GetMarkerOutput(markerInnerRing, exu.OutputVariableType.RotationMatrix,
                                     configuration=exu.ConfigurationType.Reference).reshape((3,3))
    localBearingAxis = np.array(bearingData['axis'])
    #globalBearingAxis = bearingRot @ localBearingAxis
    radiusBalls = bearingData['radiusBalls']
    widthCage = bearingData['widthCage']
    heightCage = bearingData['heightCage']
    radiusCage = bearingData['radiusCage']
    ballPositions = bearingData['ballPositions']


    #++++++++++++++++++++++++++++++++++++++++++++++++++
    #ball objects
    objectsBalls = []
    for i, pos in enumerate(ballPositions):
        oBall = mbs.CreateRigidBody(referencePosition=bearingCenterPos+bearingRot@pos,
                                    initialVelocity=np.cross(cageInitialAngularVelocity,bearingRot@pos),
                                    initialAngularVelocity=ballsInitialAngularVelocity, # omegaBalls * globalBearingAxis, 
                                    inertia=InertiaSphere(density=densityBalls, radius=radiusBalls),
                                    gravity = gravity,
                                    graphicsDataList=[graphics.Sphere(radius=radiusBalls*ballsDrawRadiusFactor,color=colorBalls, nTiles=nTilesBalls)]+
                                                      addBallsBasis*[graphics.Basis(length=radiusBalls*1.3)],
                                    )
        objectsBalls.append(oBall)

    #++++++++++++++++++++++++++++++++++++++++++++++++++
    #cage object
    bearingLocalRot = ComputeOrthonormalBasis(localBearingAxis)
    inertiaCage = InertiaCylinder(densityCage, widthCage,
                                  outerRadius=radiusCage+0.5*heightCage,
                                  innerRadius=radiusCage-0.5*heightCage,
                                  axis=0) #always axis 0, as axis 0 is used in ComputeOrthonormalBasis

    inertiaCage = inertiaCage.Rotated(bearingLocalRot) #not this is accordint to the local bearing axis!
    
    cageGraphicsList = [bearingGraphics['cageGraphics']] if 'cageGraphics' in bearingGraphics else []
    
    objectCage = mbs.CreateRigidBody(referencePosition=bearingCenterPos,
                                     referenceRotationMatrix=bearingRot,
                                     inertia=inertiaCage,
                                     initialAngularVelocity=cageInitialAngularVelocity,
                                     gravity = gravity,
                                     graphicsDataList=cageGraphicsList)

    #++++++++++++++++++++++++++++++++++++++++++++++++++
    #contact / spring-dampers for cage-balls interaction
    objectsCageBallContact = []
    if springStiffnessCage != 0 or springDampingCage != 0:
        for k, oBall in enumerate(objectsBalls):
            oCSD = mbs.CreateCartesianSpringDamper(itemNumbers=[oBall,objectCage],
                                                   localPosition0=[0,0,0],
                                                   localPosition1=ballPositions[k],
                                                   stiffness=[springStiffnessCage]*3, 
                                                   damping=[springDampingCage]*3, 
                                                   drawSize=radiusBalls*0.2)
            objectsCageBallContact.append(oCSD)


    #++++++++++++++++++++++++++++++++++++++++++++++++++
    #contact balls - rings
    innerRingBallContacts = []
    outerRingBallContacts = []
    for i, oMass in enumerate(objectsBalls):
        mBall = mbs.AddMarker(eii.MarkerBodyRigid(bodyNumber=oMass))
    
        for k, mRing in enumerate([markerInnerRing,markerOuterRing][0:2]):
            torusMinorRadius = bearingData['innerGrooveRadius'] if k==0 else bearingData['outerGrooveRadius']
            torusMajorRadius = bearingData['innerGrooveTorusRadius'] if k==0 else bearingData['outerGrooveTorusRadius']
    
            nData1 = mbs.AddNode(eii.NodeGenericData(initialCoordinates=[0,0,0,0], #contact assumed at beginning
                                                numberOfDataCoordinates=4))
            oSSC = mbs.AddObject(eii.ObjectContactSphereTorus(markerNumbers=[mBall,mRing],
                                                          nodeNumber=nData1,
                                                          sphereRadius=radiusBalls,
                                                          torusMajorRadius = torusMajorRadius, 
                                                          torusMinorRadius = torusMinorRadius, 
                                                          torusAxis = localBearingAxis,
                                                          **contactParametersRingBalls,
                                                          visualization=eii.VObjectContactSphereTorus(show=False),
                                                          ))
            if k==0:
                innerRingBallContacts.append(oSSC)
            else:
                outerRingBallContacts.append(oSSC)


    data = {'objectsBalls':objectsBalls,
            'objectCage':objectCage,
            'objectsCageBallContact':objectsCageBallContact,
            'innerRingBallContacts':innerRingBallContacts,
            'outerRingBallContacts':outerRingBallContacts,
            }
    return data


#%%++++++++++++++++++++++++
#testing of involute and approximated involute
if __name__ == '__main__':
    import exudyn

    if False:
        for i in range(40):
            x = cMath.pow(2, -i/2)
            exudyn.Print('x=', x,'Inv=', Involute(x), ', Approx Inv=', ApproxInvolute(x), ', diff=', ApproxInvolute(x)-Involute(x), 'err term=', (62/2835)*x**9)  
            #==> error term < diff for x<0.02

    #test InvInvolute:
    #iteration number largest for x \approx 1
    for i in range(80): #80 goes up to x=2e-46, invinv=9e-16
        x = 100*2**(-2*i) 
        exudyn.Print('x=', x,'InvInv=', InvInvolute(x), ', Involute(InvInv)-x=', Involute(InvInvolute(x))-x)  
        
    for i in range(80): #80 goes up to x=2e-46, invinv=9e-16
        x = -100*2**(-2*i)
        exudyn.Print('x=', x,'InvInv=', InvInvolute(x), ', Involute(InvInv)-x=', Involute(InvInvolute(x))-x)  


#%%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#ROLLER CHAINS

#simple roller chains of series B, in mm: ISO 606:1994, Table 1 (pitch, roller diameter d1 max, inner width b1 min, pin
#diameter d2 max, inner plate depth h2 max), and the tooth width B1 and the relief F of the chain wheels of DIN 8196
#(Schlecht, Maschinenelemente 2, Tab. 22.29); RollerChain.FromStandard converts them to metres
rollerChainDimensions = {
    '05B': {'pitch': 8.0,    'rollerDiameter': 5.00,  'innerWidth': 3.00,  'pinDiameter': 2.31,  'plateDepth': 7.11,  'toothWidth': 2.8,  'reliefF': 5},
    '06B': {'pitch': 9.525,  'rollerDiameter': 6.35,  'innerWidth': 5.72,  'pinDiameter': 3.28,  'plateDepth': 8.26,  'toothWidth': 5.3,  'reliefF': 6},
    '08B': {'pitch': 12.7,   'rollerDiameter': 8.51,  'innerWidth': 7.75,  'pinDiameter': 4.45,  'plateDepth': 11.81, 'toothWidth': 7.2,  'reliefF': 8},
    '10B': {'pitch': 15.875, 'rollerDiameter': 10.16, 'innerWidth': 9.65,  'pinDiameter': 5.08,  'plateDepth': 14.73, 'toothWidth': 9.1,  'reliefF': 10},
    '12B': {'pitch': 19.05,  'rollerDiameter': 12.07, 'innerWidth': 11.68, 'pinDiameter': 5.72,  'plateDepth': 16.13, 'toothWidth': 11.1, 'reliefF': 11},
    '16B': {'pitch': 25.4,   'rollerDiameter': 15.88, 'innerWidth': 17.02, 'pinDiameter': 8.28,  'plateDepth': 21.08, 'toothWidth': 16.2, 'reliefF': 15},
    '20B': {'pitch': 31.75,  'rollerDiameter': 19.05, 'innerWidth': 19.56, 'pinDiameter': 10.19, 'plateDepth': 26.42, 'toothWidth': 18.5, 'reliefF': 18},
    '32B': {'pitch': 50.8,   'rollerDiameter': 29.21, 'innerWidth': 30.99, 'pinDiameter': 17.81, 'plateDepth': 42.29, 'toothWidth': 29.4, 'reliefF': 29},
    }


class RollerChain:
    """a simple roller chain, given by its dimensions in metres; the roller diameter is what the contact uses, the
    others are for the drawing, the pin diameter also for the joints
    """
    def __init__(self, pitch, rollerDiameter, innerWidth=None, pinDiameter=None, plateDepth=None, toothWidth=None,
                 plateThickness=None, reliefF=None):
        """the chain from its dimensions; a dimension not given gets the ratio to the pitch of chain 08B

        Args:
            pitch: the distance of the pins, p
            rollerDiameter: the outer diameter of the rollers, d1
            innerWidth: the width between the inner plates, b1; default 0.61 p
            pinDiameter: the diameter of the pins, d2; default 0.35 p
            plateDepth: the height of the plates, h2; default 0.93 p
            toothWidth: the width of the teeth of the chain wheels, B1; default 0.93 b1
            plateThickness: the thickness of a plate, as the standards give none; default 0.12 p
            reliefF: the depth F of the relief of the chain wheels below the pitch circle, d_s = d - 2F; default 0.63 p
        """
        self.pitch = pitch
        self.rollerDiameter = rollerDiameter
        self.innerWidth = innerWidth if innerWidth is not None else 0.61*pitch
        self.pinDiameter = pinDiameter if pinDiameter is not None else 0.35*pitch
        self.plateDepth = plateDepth if plateDepth is not None else 0.93*pitch
        self.toothWidth = toothWidth if toothWidth is not None else 0.93*self.innerWidth
        self.plateThickness = plateThickness if plateThickness is not None else 0.12*pitch
        self.reliefF = reliefF if reliefF is not None else 0.63*pitch
        if not (0 < rollerDiameter < pitch):
            raise ValueError('RollerChain: the roller diameter must be positive and smaller than the pitch')

    @staticmethod
    def FromStandard(chainNumber):
        """the chain of a chain number of rollerChainDimensions, e.g. '08B', in metres

        Args:
            chainNumber: a key of rollerChainDimensions

        Returns:
            RollerChain with the dimensions of the table
        """
        if chainNumber not in rollerChainDimensions:
            raise ValueError('RollerChain.FromStandard: unknown chain number ' + repr(chainNumber) + '; known: '
                             + ', '.join(rollerChainDimensions))
        return RollerChain(**{key: 1e-3*value for (key, value) in rollerChainDimensions[chainNumber].items()})


def _ArcSegments(center, radius, angle0, angle1, polynomial, maxAngle):
    """the points of an arc from angle0 to angle1 (radians, either direction) as chord segments, and per segment the
    quintic Hermite data [alpha0, alpha1, beta0, beta1] of ObjectContactCurveCircles for the deflection to the right of
    the chord (the side of the exterior); returns (points without the last one, list of rows)"""
    span = angle1 - angle0
    n = max(1, int(np.ceil(abs(span)/maxAngle - 1e-12)))
    points = []
    rows = []
    h = 0.5*abs(span)/n                   #half the angle of a piece
    bulge = 1. if span > 0 else -1.       #counterclockwise arc: bulges to the right of its chords, clockwise: to the left
    for i in range(n):
        a = angle0 + span*i/n
        points.append([center[0] + radius*cos(a), center[1] + radius*sin(a)])
        if polynomial:
            slope = bulge*tan(h)
            curvature = -bulge/(radius*cos(h)**3)
            rows.append([slope, -slope, curvature, curvature])
    return (points, rows)


class RollerChainSprocket:
    """a chain wheel for a RollerChain with the tooth form of DIN 8196 (Schlecht, Maschinenelemente 2, Fig. 22.35):
    per tooth gap the roller seating arc of radius r1 about the pitch point over the angle chi, at both of its ends a
    convex flank arc of radius r2 up to the tip circle, and the tip arc between the flanks of a tooth; gap 0 is
    centered on the local x-axis, the seats at the angles 2 pi j / z on the pitch circle
    """
    def __init__(self, chain, nTeeth, profile='mean', tipDiameter=None, seatingRadius=None, flankRadius=None,
                 seatingAngle=None):
        """the sprocket for chain with nTeeth teeth; the limits of DIN 8196 leave room for tolerances, profile picks
        the values from them, and each may be given instead

        Args:
            chain: the RollerChain
            nTeeth: the number of teeth z, at least 6
            profile: 'mean' (the mean of each pair of limits), 'minimumGap' (r1 minimum, r2 maximum, chi maximum: the
                tightest seat) or 'maximumGap' (r1 maximum, r2 minimum, chi minimum)
            tipDiameter: d_a; default the mean of its limits
            seatingRadius: r1, instead of the profile
            flankRadius: r2, instead of the profile
            seatingAngle: chi in radians, instead of the profile
        """
        if profile not in ['mean', 'minimumGap', 'maximumGap']:
            raise ValueError("RollerChainSprocket: profile must be 'mean', 'minimumGap' or 'maximumGap'")
        if int(nTeeth) != nTeeth or nTeeth < 6:
            raise ValueError('RollerChainSprocket: nTeeth must be an integer of at least 6')
        self.chain = chain
        self.nTeeth = z = int(nTeeth)
        p = chain.pitch
        d1 = chain.rollerDiameter
        self.pitchDiameter = d = p/sin(pi/z)                           #(22.85)
        self.pitchRadius = 0.5*d
        self.rootDiameter = d - d1                                     #(22.86)
        self.tipDiameterLimits = [d + p*(1 - 1.6/z) - d1, d + 1.25*p - d1]    #(22.87), (22.88)
        self.reliefDiameter = d - 2*chain.reliefF                      #(22.89)
        #the formulas in mm; the term with the cube root of d1 is not homogeneous
        self.seatingRadiusLimits = [0.505*d1, 0.505*d1 + 1e-3*0.069*cMath.cbrt(1e3*d1)]   #(22.90), (22.91)
        self.flankRadiusLimits = [0.12*d1*(z + 2), 0.008*d1*(z**2 + 180)]             #(22.92), (22.93)
        self.seatingAngleLimits = [radians(120 - 90/z), radians(140 - 90/z)]          #(22.94), (22.95)
        pick = {'mean': lambda limits, tight: 0.5*(limits[0] + limits[1]),
                'minimumGap': lambda limits, tight: limits[1] if tight else limits[0],
                'maximumGap': lambda limits, tight: limits[0] if tight else limits[1]}[profile]
        self.seatingRadius = seatingRadius if seatingRadius is not None else pick(self.seatingRadiusLimits, False)
        self.flankRadius = flankRadius if flankRadius is not None else pick(self.flankRadiusLimits, True)
        self.seatingAngle = seatingAngle if seatingAngle is not None else pick(self.seatingAngleLimits, True)
        self.tipDiameter = tipDiameter if tipDiameter is not None else 0.5*sum(self.tipDiameterLimits)
        self.angleTooth = 2*pi/z
        self._ComputeGap()

    def _ComputeGap(self):
        """the arcs of gap 0, in the frame of the sprocket: the seat about the pitch point [R, 0], the flank of the
        upper side (positive angles) up to the tip circle; the lower side is its mirror image"""
        R = self.pitchRadius
        r1 = self.seatingRadius
        r2 = self.flankRadius
        rTip = 0.5*self.tipDiameter
        C = np.array([R, 0.])
        #the end of the seating arc on the upper side, at the angle chi/2 from the direction to the center
        phiEnd = pi - 0.5*self.seatingAngle             #the angle of E - C in the plane
        u = np.array([cos(phiEnd), sin(phiEnd)])        #from C to E
        E = C + r1*u
        F = E + r2*u                                     #the center of the convex flank, on the side of the tooth
        #the flank from E outwards: P(beta) = F - r2 [cos(phiEnd + beta), sin(phiEnd + beta)], tangent to the seat
        def FlankPoint(beta):
            return F - r2*np.array([cos(phiEnd + beta), sin(phiEnd + beta)])
        def Radius(beta): return cMath.norm(FlankPoint(beta))
        def AngleOf(beta):
            q = FlankPoint(beta)
            return atan2(q[1], q[0])
        halfTooth = 0.5*self.angleTooth
        #the end of the flank: the tip circle, or the middle of the tooth if the flank reaches it first
        b0, b1 = 0., 0.5*pi
        def Done(beta): return Radius(beta) >= rTip or AngleOf(beta) >= halfTooth
        if Done(0.):
            raise ValueError('RollerChainSprocket: the seating arc reaches the tip circle; check the dimensions')
        if not Done(b1):
            raise ValueError('RollerChainSprocket: the flank does not reach the tip circle; check the dimensions')
        for i in range(60):
            bm = 0.5*(b0 + b1)
            if Done(bm): b1 = bm
            else: b0 = bm
        self._gap = {'C': C, 'phiSeat': [pi + 0.5*self.seatingAngle, phiEnd], 'F': F,
                     'phiFlank': [phiEnd + pi, phiEnd + pi + b1], 'flankEnd': FlankPoint(b1)}
        self.flankEndAngle = AngleOf(b1)                #the angle of the end of the upper flank
        self.tipRadius = min(rTip, Radius(b1))

    def _GapArcs(self):
        """the arcs of one tooth and gap, counterclockwise from the middle of the tooth below gap 0 to the middle of
        the tooth above it: [center, radius, angle0, angle1] of the lower half tip, the lower flank, the seat, the
        upper flank, the upper half tip"""
        g = self._gap
        C = g['C']
        F = g['F']
        Fm = np.array([F[0], -F[1]])                    #the mirrored flank center
        halfTooth = 0.5*self.angleTooth
        fe = self.flankEndAngle
        arcs = []
        if fe < halfTooth:
            arcs.append([[0, 0], self.tipRadius, -halfTooth, -fe])
        fl = g['phiFlank']
        arcs.append([Fm, self.flankRadius, -fl[1], -fl[0]])        #the lower flank, mirrored and reversed
        ps = g['phiSeat']
        arcs.append([C, self.seatingRadius, ps[0], ps[1]])         #the seat, clockwise about the pitch point
        arcs.append([F, self.flankRadius, fl[0], fl[1]])
        if fe < halfTooth:
            arcs.append([[0, 0], self.tipRadius, fe, halfTooth])
        return arcs

    def SeatAngles(self, phase=0.):
        """the angles of the seats (pitch points) of the teeth gaps, with the sprocket turned by phase

        Args:
            phase: the angle of the sprocket in radians

        Returns:
            numpy array of the z angles phase + 2 pi j / z
        """
        return phase + self.angleTooth*np.arange(self.nTeeth)

    def _Arcs(self):
        """the arcs of the whole outline, counterclockwise, starting in the middle of the tooth below gap 0"""
        arcs = []
        for j in range(self.nTeeth):
            a = j*self.angleTooth
            for (c, r, a0, a1) in self._GapArcs():
                center = [cos(a)*c[0] - sin(a)*c[1], sin(a)*c[0] + cos(a)*c[1]]
                arcs.append([center, r, a0 + a, a1 + a])
        return arcs

    def GenerateProfile(self, pointsPerArc=8):
        """the closed outline as points, counterclockwise, for the drawing

        Args:
            pointsPerArc: the points of each arc of the outline (seat, flanks, tip)

        Returns:
            numpy array of shape (n, 2), the points of the outline without repeating the first one
        """
        points = []
        for (c, r, a0, a1) in self._Arcs():
            for i in range(pointsPerArc):
                a = a0 + (a1 - a0)*i/pointsPerArc
                points.append([c[0] + r*cos(a), c[1] + r*sin(a)])
        return np.array(points)

    def GenerateSegments(self, polynomial=True, maxSegmentAngle=None):
        """the contact segments of the outline for ObjectContactCurveCircles, counterclockwise, so that the exterior is
        on the right of each segment

        Args:
            polynomial: True: each arc as quintic polynomial segments of up to maxSegmentAngle; False: straight segments
            maxSegmentAngle: the largest angle of an arc per segment, in radians; default 30 degrees (polynomial) or
                5 degrees (straight)

        Returns:
            [segmentsData, polynomialData]: numpy arrays with a row [x0, y0, x1, y1] and [alpha0, alpha1, beta0, beta1]
            per segment; polynomialData is None for polynomial=False
        """
        if maxSegmentAngle is None:
            maxSegmentAngle = radians(30) if polynomial else radians(5)
        points = []
        rows = []
        for (c, r, a0, a1) in self._Arcs():
            (p, rw) = _ArcSegments(c, r, a0, a1, polynomial, maxSegmentAngle)
            points += p
            rows += rw
        points = np.array(points)
        segmentsData = np.hstack((points, np.roll(points, -1, axis=0)))
        return [segmentsData, np.array(rows) if polynomial else None]


class RollerChainDrive:
    """sprockets placed in a plane and a RollerChain around them, initialized so that its joints are closed and its
    rollers sit in the seats: the pins on the pitch polygons of the sprockets, tight spans of whole links between them
    - which gives the phases of the sprockets - and the remaining links in a slack span on an arc of equal chords
    """
    def __init__(self, chain, sprockets, nLinks=None, slackSpan=-1, slackSide=None, phase=0.):
        """compute the poses of the links and the phases of the sprockets

        Args:
            chain: the RollerChain
            sprockets: a list of [sprocket, center, side] in the order around the chain: a RollerChainSprocket or its
                number of teeth, the 2D center, and the side 'L' or 'R' as in beams.CreateReevingCurve (seen in the
                direction of the chain: 'L' the chain passes on the left of the sprocket, which turns clockwise)
            nLinks: the number of links; default the taut length divided by the pitch, rounded up to an even number, or
                the next even number that leaves the slack span longer than its chord
            slackSpan: the span with the slack, from sprocket slackSpan to the next; -1: from the last to the first
            slackSide: a 2D direction to which the slack span bulges, e.g. [0,-1] downwards; default away from the
                centers of the sprockets
            phase: the angle of the sprocket after the slack span, which sets the others
        """
        self.chain = chain
        p = chain.pitch
        n = len(sprockets)
        if n < 2:
            raise ValueError('RollerChainDrive: at least two sprockets are needed')
        self.sprockets = []
        self.centers = []
        self.sides = []
        for (s, center, side) in sprockets:
            self.sprockets.append(s if isinstance(s, RollerChainSprocket) else RollerChainSprocket(chain, s))
            self.centers.append(np.array(center[0:2], dtype=float))
            if side not in ['L', 'R']:
                raise ValueError("RollerChainDrive: side must be 'L' or 'R'")
            self.sides.append(-1. if side == 'L' else 1.) #+1: the chain turns counterclockwise about the center
        first = (slackSpan + 1) % n                       #the walk starts after the slack span and ends with it
        order = [(first + i) % n for i in range(n)]

        R = [self.sprockets[k].pitchRadius for k in order]
        c = [self.centers[k] for k in order]
        s = [self.sides[k] for k in order]
        #the taut path on the pitch circles: the tangent from circle i to circle i+1, at the angles out[i] and in[i+1]
        angleOut = [0.]*n
        angleIn = [0.]*n
        tautLength = 0.
        for i in range(n):
            j = (i + 1) % n
            (a0, a1, length) = self._Tangent(c[i], R[i], s[i], c[j], R[j], s[j])
            angleOut[i] = a0
            angleIn[j] = a1
            tautLength += length
        for i in range(n):
            tautLength += R[i]*self._Wrap(angleIn[i], angleOut[i], s[i])
        self.tautLength = tautLength

        #the pins on the sprockets and on the tight spans
        def Seat(i, phi, k): return c[i] + R[i]*np.array([cos(phi + 2*pi*k/self.sprockets[order[i]].nTeeth), sin(phi + 2*pi*k/self.sprockets[order[i]].nTeeth)])
        phases = [0.]*n
        phases[0] = phase
        pins = []
        tooth = [2*pi/self.sprockets[order[i]].nTeeth for i in range(n)]
        #the first seat at or after the arrival on sprocket 0, in its direction of turning
        k = self._FirstSeat(phase, angleIn[0], s[0], tooth[0])
        firstAngle = phase + k*tooth[0]
        angle = firstAngle
        for i in range(n):
            #the seats of sprocket i from angle up to the departure; a seat beyond the departure (a small wrap, as at a
            #tensioner) is the only one
            tangentWrap = self._Wrap(angleIn[i], angleOut[i], s[i])
            seatOffset = self._Wrap(angleIn[i], angle, s[i])
            if seatOffset > 2*pi - 1e-9: #at the arrival, within rounding
                seatOffset = 0.
            wrap = max(tangentWrap - seatOffset, 0.)
            nSeats = int(np.floor(wrap/tooth[i] + 1e-9)) + 1
            for m in range(nSeats):
                a = angle + s[i]*m*tooth[i]
                pins.append(c[i] + R[i]*np.array([cos(a), sin(a)]))
            if i == n - 1:
                break
            #the tight span: whole links to a point of the pitch circle of sprocket i+1 at or after its arrival
            pLast = pins[-1]
            j = i + 1
            arrival = c[j] + R[j]*np.array([cos(angleIn[j]), sin(angleIn[j])])
            m = max(1, int(np.ceil(cMath.norm(arrival - pLast)/p - 1e-9)))
            q = self._CirclePoint(pLast, m*p, c[j], R[j], angleIn[j], s[j])
            if q is None:
                raise ValueError('RollerChainDrive: no tight span of whole links from sprocket ' + str(order[i])
                                 + ' to sprocket ' + str(order[j]) + '; the sprockets may be too close')
            for k2 in range(1, m):
                pins.append(pLast + (k2/m)*(q - pLast))
            angle = atan2(q[1] - c[j][1], q[0] - c[j][0])
            phases[j] = angle                             #a seat at the arrival: the phase of sprocket j
        #the slack span from the last pin back to the first
        pA = pins[-1]
        pB = c[0] + R[0]*np.array([cos(firstAngle), sin(firstAngle)])
        chord = cMath.norm(pB - pA)
        if nLinks is None:
            nLinks = int(np.ceil(tautLength/p - 1e-9))
            nLinks += nLinks % 2
            while (nLinks - len(pins) + 1)*p <= chord:
                nLinks += 2
        nSlack = nLinks - len(pins) + 1                #the links of the slack span, from pA to pB
        if nSlack < 1 or nSlack*p < chord*(1 - 1e-12):
            raise ValueError('RollerChainDrive: nLinks = ' + str(nLinks) + ' is too small; at least '
                             + str(len(pins) - 1 + int(np.ceil(chord/p))) + ' are needed')
        if slackSide is None:
            mid = 0.5*(pA + pB)
            slackSide = mid - np.mean(np.array(self.centers), axis=0)
        slackSide = np.array(slackSide[0:2], dtype=float)
        direction = (pB - pA)/chord if chord > 0 else np.array([1., 0.])
        left = np.array([-direction[1], direction[0]])
        sign = 1. if left @ slackSide >= 0 else -1.   #+1: the arc bulges to the left of pA -> pB
        self.slackChord = chord
        self.slackLinks = nSlack
        gamma = self._SlackAngle(nSlack, p, chord)      #the turning between the links of the slack span
        psi = atan2(direction[1], direction[0]) + sign*0.5*(nSlack - 1)*gamma
        q = pA
        for k2 in range(nSlack - 1):
            q = q + p*np.array([cos(psi), sin(psi)])
            pins.append(q)
            psi -= sign*gamma

        self.nLinks = nLinks
        self.pinPositions = np.array(pins)               #the first pin of each link
        nextPins = np.roll(self.pinPositions, -1, axis=0)
        d = nextPins - self.pinPositions
        self.linkAngles = np.array([atan2(v[1], v[0]) for v in d])
        self.phases = [0.]*n                             #in the order of sprockets
        for i in range(n):
            ph = phases[i] if i > 0 else phase
            self.phases[order[i]] = (ph - 0.) % tooth[i] #the gap 0 at the angle phase (mod one tooth)
        #pins inside a pitch circle off the wraps: the slack span runs into a sprocket
        for (k, sp) in enumerate(self.sprockets):
            dist = min(cMath.norm(q - self.centers[k]) for q in self.pinPositions)
            if dist < sp.pitchRadius*(1 - 1e-9) - 0.5*chain.rollerDiameter:
                exu.Print('WARNING: RollerChainDrive: a pin lies inside sprocket ' + str(k) + '; give slackSide or nLinks')

    @staticmethod
    def CenterDistance(chain, nTeeth0, nTeeth1, nLinks):
        """the distance of two sprockets at which a chain of nLinks links is taut on their pitch circles, both passed on
        the same side: the inverse of the chain length; a RollerChainDrive at this distance has a slack span of nearly
        zero sag

        Args:
            chain: the RollerChain
            nTeeth0: the number of teeth of the first sprocket
            nTeeth1: the number of teeth of the second sprocket
            nLinks: the number of links

        Returns:
            the center distance
        """
        r0 = RollerChainSprocket(chain, nTeeth0).pitchRadius
        r1 = RollerChainSprocket(chain, nTeeth1).pitchRadius
        target = nLinks*chain.pitch
        def Length(a): #the taut length: two tangents and the wraps, of the larger sprocket by 2 beta more than pi
            beta = cMath.asin((r1 - r0)/a)
            return 2*sqrt(a**2 - (r1 - r0)**2) + r0*(pi - 2*beta) + r1*(pi + 2*beta)
        lo = 1.001*abs(r1 - r0) + 1e-12
        hi = target
        if Length(lo) > target:
            raise ValueError('RollerChainDrive.CenterDistance: nLinks is too small for these sprockets')
        for i in range(100):
            a = 0.5*(lo + hi)
            if Length(a) < target: lo = a
            else: hi = a
        return 0.5*(lo + hi)

    @staticmethod
    def _Wrap(angle0, angle1, side):
        """the angle from angle0 to angle1 turning in the direction side (+1 counterclockwise), in [0, 2 pi)"""
        return (side*(angle1 - angle0)) % (2*pi)

    @staticmethod
    def _FirstSeat(phase, angle, side, tooth):
        """the index of the first seat phase + k tooth at or after angle in the direction side"""
        k = (angle - phase)/tooth
        return int(np.ceil(k - 1e-9)) if side > 0 else int(np.floor(k + 1e-9))

    @staticmethod
    def _Tangent(c0, r0, s0, c1, r1, s1):
        """the common tangent of the chain from circle 0 to circle 1 (turning s0 and s1): the angles of its points on
        the circles and its length"""
        d = c1 - c0
        L = cMath.norm(d)
        #the tangent touches circle i at c_i + r_i n_i, n_i = -s_i l with l the left normal of the direction t (the
        #center on the left for s_i = 1); p1 - p0 parallel to t gives d . l = s1 r1 - s0 r0 = L sin(angle(d) - angle(t))
        k = (s1*r1 - s0*r0)/L
        if abs(k) >= 1:
            raise ValueError('RollerChainDrive: the sprockets overlap; no tangent between them')
        base = atan2(d[1], d[0])
        tAngle = base - cMath.asin(k)            #the direction of the tangent
        t = np.array([cos(tAngle), sin(tAngle)])
        n0 = -s0*np.array([-t[1], t[0]])
        n1 = -s1*np.array([-t[1], t[0]])
        p0 = c0 + r0*n0
        p1 = c1 + r1*n1
        return (atan2(n0[1], n0[0]), atan2(n1[1], n1[0]), cMath.norm(p1 - p0))

    @staticmethod
    def _CirclePoint(p, distance, center, radius, angleRef, side):
        """the point of the circle at the distance from p, the first after angleRef in the direction side, or None"""
        d = center - p
        L = cMath.norm(d)
        if L == 0 or distance > L + radius or distance < abs(L - radius):
            return None
        a = (distance**2 - radius**2 + L**2)/(2*L)
        h = sqrt(max(distance**2 - a**2, 0.))
        e = d/L
        f = np.array([-e[1], e[0]])
        candidates = [p + a*e + h*f, p + a*e - h*f]
        best = None
        bestWrap = 1e10
        for q in candidates:
            w = RollerChainDrive._Wrap(angleRef, atan2(q[1] - center[1], q[0] - center[0]), side)
            if w > pi: w -= 2*pi                 #slightly before the arrival counts as before
            if w >= -1e-9 and w < bestWrap:
                best = q
                bestWrap = w
        return best

    @staticmethod
    def _SlackAngle(nLinks, p, chord):
        """the turning gamma between links of a slack span of nLinks links of length p on an arc of equal chords
        between two pins at the distance chord: p sin(n gamma/2)/sin(gamma/2) = chord"""
        if nLinks*p - chord <= 1e-12*p:
            return 0.
        lo, hi = 0., 2*pi/nLinks
        for i in range(100):
            g = 0.5*(lo + hi)
            if p*sin(0.5*nLinks*g)/sin(0.5*g) > chord: lo = g
            else: hi = g
        return 0.5*(lo + hi)

    def CreateItems(self, mbs, sprocketMarkers, contactStiffness, contactDamping=0., dynamicFriction=0.,
                    frictionProportionalZone=1e-3, contactModel=1, linkMass=None, linkInertia=None, gravity=[0,0,0],
                    show=True, showContact=False):
        """create the chain: the links as 2D rigid bodies with their reference point at their first pin, the revolute
        joints between them, and per sprocket an ObjectContactCurveCircles with all rollers as circles; the sprocket
        bodies are the caller's, at the centers and turned by the phases

        Args:
            mbs: the MainSystem
            sprocketMarkers: per sprocket, in the order given, a rigid body marker at its center that turns with it
            contactStiffness: the contactStiffness of ObjectContactCurveCircles: per length of the curve for the
                integral model, contactModel=1, the stiffness of the point for contactModel=2
            contactDamping: the contactDamping of ObjectContactCurveCircles
            dynamicFriction: the friction coefficient between rollers and sprockets
            frictionProportionalZone: the regularization of the friction
            contactModel: 1 (integral) or 2 (point), see ObjectContactCurveCircles
            linkMass: the mass of a link; default steel, 7850 kg/m^3, of two plates of pitch x plateDepth x
                plateThickness and a roller
            linkInertia: the inertia of a link about its center of mass; default that of a plate with linkMass
            gravity: the gravity vector, 2D or 3D
            show: draw the links, alternately inner and outer
            showContact: draw the contact curves and circles

        Returns:
            dict with the lists 'links' (object numbers), 'nodes', 'markers' (MarkerBodyRigid at the first pin of each
            link, the circles of the contacts), 'joints', 'contacts' and 'dataNodes'
        """
        import exudyn.graphics as graphics
        import exudyn.itemInterface as eii
        chain = self.chain
        p = chain.pitch
        if len(sprocketMarkers) != len(self.sprockets):
            raise ValueError('RollerChainDrive.CreateItems: one marker per sprocket is needed')
        if linkMass is None:
            linkMass = 7850*(2*p*chain.plateDepth*chain.plateThickness + 0.25*pi*chain.rollerDiameter**2*chain.innerWidth)
        if linkInertia is None:
            linkInertia = linkMass*(p**2 + chain.plateDepth**2)/12
        inertiaAtPin = linkInertia + linkMass*(0.5*p)**2 #the reference point at the first pin
        graphicsInner = graphics.RollerChainLink(chain, inner=True) if show else []
        graphicsOuter = graphics.RollerChainLink(chain, inner=False) if show else []
        g = list(gravity) + [0]*(3 - len(gravity))
        result = {'links': [], 'nodes': [], 'markers': [], 'joints': [], 'contacts': [], 'dataNodes': []}
        endMarkers = []
        for i in range(self.nLinks):
            pin = self.pinPositions[i]
            node = mbs.AddNode(eii.NodeRigidBody2D(referenceCoordinates=[pin[0], pin[1], self.linkAngles[i]]))
            link = mbs.AddObject(eii.ObjectRigidBody2D(nodeNumber=node, mass=linkMass,
                inertia=inertiaAtPin, centerOfMass=[0.5*p, 0],
                visualization=eii.VObjectRigidBody2D(show=show, graphicsData=graphicsInner if i % 2 == 0 else graphicsOuter)))
            result['nodes'].append(node)
            result['links'].append(link)
            result['markers'].append(mbs.AddMarker(eii.MarkerBodyRigid(bodyNumber=link)))
            endMarkers.append(mbs.AddMarker(eii.MarkerBodyRigid(bodyNumber=link, localPosition=[p, 0, 0])))
            if g != [0, 0, 0]:
                mMass = mbs.AddMarker(eii.MarkerBodyMass(bodyNumber=link))
                mbs.AddLoad(eii.LoadMassProportional(markerNumber=mMass, loadVector=g))
        for i in range(self.nLinks):
            result['joints'].append(mbs.AddObject(eii.RevoluteJoint2D(markerNumbers=[endMarkers[i], result['markers'][(i + 1) % self.nLinks]],
                visualization=eii.VRevoluteJoint2D(show=False))))
        nRegions = 2
        for (k, sprocket) in enumerate(self.sprockets):
            [segmentsData, polynomialData] = sprocket.GenerateSegments()
            nData = 2*nRegions*self.nLinks
            dataNode = mbs.AddNode(eii.NodeGenericData(initialCoordinates=[-1]*nData, numberOfDataCoordinates=nData))
            result['dataNodes'].append(dataNode)
            result['contacts'].append(mbs.AddObject(eii.ObjectContactCurveCircles(markerNumbers=[sprocketMarkers[k]] + result['markers'],
                nodeNumber=dataNode, circlesRadii=[0.5*chain.rollerDiameter]*self.nLinks,
                segmentsData=exu.MatrixContainer(segmentsData), polynomialData=exu.MatrixContainer(polynomialData),
                contactStiffness=contactStiffness, contactDamping=contactDamping, dynamicFriction=dynamicFriction,
                frictionProportionalZone=frictionProportionalZone, contactModel=contactModel, maximumContactRegions=nRegions,
                visualization=eii.VObjectContactCurveCircles(show=showContact))))
        return result
