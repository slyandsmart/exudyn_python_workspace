

from typing import (
    Annotated, 
    Any,
    # ByteString,
    # Callable,
    # Container,
    Callable,
    Dict,
    # Generic,
    # IO,
    # Iterable,
    # Iterator,
    List,
    Literal,
    # Mapping,
    # NoReturn,
    # Optional,
    overload,
    # Sequence,
    # Sized,
    # SupportsComplex,
    # SupportsFloat,
    # SupportsInt,
    # Text,
    Tuple, #for Tuple[int, int]
    # Type,
    TypeVar,
    Union,
)
from numpy.typing import ArrayLike, NDArray
from enum import Enum
import numpy as np



T1 = TypeVar("T1", bound=int)
T2 = TypeVar("T2", bound=int)

Shape = Tuple
Shape1D = Shape[T1]
Shape2D = Shape[T1, T2]



import exudyn
from exudyn import (ObjectIndex, NodeIndex, MarkerIndex, LoadIndex, SensorIndex, MaterialIndex,
                    VSettingsMaterial)




@overload
def Help() -> None: 
    """Show basic help information."""
    ...
@overload
def StartRenderer(verbose=0, deprecationWarning=True) -> bool: 
    """DEPRECATED; Start OpenGL rendering engine (in separate thread) for visualization of rigid or flexible multibody system; use verbose=1 to output information during OpenGL window creation; verbose=2 produces more output and verbose=3 gives a debug level; some of the information will only be seen in windows command (powershell) windows or linux shell, but not inside iPython of e.g., Spyder; removed in 2029."""
    ...
@overload
def StopRenderer(deprecationWarning=True) -> None: 
    """DEPRECATED; Stop OpenGL rendering engine; removed in 2029."""
    ...
@overload
def IsRendererActive(deprecationWarning=True) -> bool: 
    """DEPRECATED; returns True if GLFW renderer is available and running; otherwise False; removed in 2029."""
    ...
@overload
def DoRendererIdleTasks(waitSeconds=0, deprecationWarning=True) -> None: 
    """DEPRECATED; Call this function in order to interact with Renderer window; use waitSeconds in order to run this idle tasks while animating a model (e.g., waitSeconds=0.04), use waitSeconds=0 without waiting, or use waitSeconds=-1 (default) to wait until window is closed; removed in 2029."""
    ...
@overload
def SolveStatic(mbs: MainSystem, simulationSettings: SimulationSettings=exudyn.SimulationSettings(), updateInitialValues=False, storeSolver=True) -> bool: 
    """DEPRECATED; Static solver function, mapped from module `solver`, to solve static equations (without inertia terms) of constrained rigid or flexible multibody system; for details on the Python interface see sec-mainsystemextensions-solvestatic; for background on solvers, see sec-solvers; removed in 2029."""
    ...
@overload
def SolveDynamic(mbs: MainSystem, simulationSettings: SimulationSettings=exudyn.SimulationSettings(), solverType: DynamicSolverType=exudyn.DynamicSolverType.GeneralizedAlpha, updateInitialValues=False, storeSolver=True) -> bool: 
    """DEPRECATED; Dynamic solver function, mapped from module `solver`, to solve equations of motion of constrained rigid or flexible multibody system; for details on the Python interface see sec-mainsystemextensions-solvedynamic; for background on solvers, see sec-solvers; removed in 2029."""
    ...
@overload
def ComputeODE2Eigenvalues(mbs: MainSystem, simulationSettings: SimulationSettings=exudyn.SimulationSettings(), useSparseSolver=False, numberOfEigenvalues=-1, setInitialValues=True, convert2Frequencies=False) -> bool: 
    """DEPRECATED; Simple interface to scipy eigenvalue solver for eigenvalue analysis of the second order differential equations part in mbs, mapped from module `solver`; for details on the Python interface see sec-mainsystemextensions-computeode2eigenvalues; removed in 2029."""
    ...
@overload
def RequireVersion(requiredVersionString: str) -> None: 
    """Checks if the installed version is according to the required version.
    
    Major, micro and minor version must agree the required level. This function is defined in the `__init__.py` file
    
    Examples:
        exu.RequireVersion("1.0.31")
    """
    ...
@overload
def SetWriteToFile(filename: str, flagWriteToFile=True, flagAppend=False, flagFlushAlways=False) -> None: 
    """Set flag to write (True) or not write to console; default value of flagWriteToFile = False; flagAppend appends output to file, if set True; in order to finalize the file, write `exu.SetWriteToFile('', False)` to close the output file; in case of flagFlushAlways=True, file will be finalized immediately in every print command, but may be slower; the filename is relative to exudyn.config.outputDirectory, which is prepended when the file is opened; an absolute filename together with a non-empty outputDirectory raises an error;.
    
    Examples:
        exudyn.config.printToConsole = False #no output to console
        exu.SetWriteToFile(filename='testOutput.log', flagWriteToFile=True, flagAppend=False, flagFlushAlways=False)
        exu.Print('print this to file')
        exu.SetWriteToFile('', False) #terminate writing to file which closes the file
    """
    ...
@overload
def Print() -> None: 
    """This allows printing via exudyn with similar syntax as in Python print(args) except for keyword arguments: exu.Print('test=',42,sep=' ',end='',flush=True); allows to redirect all output to file given by SetWriteToFile(...); does not print to console in case that exudyn.config.printToConsole is set to False."""
    ...
@overload
def SetOutputPrecision(numberOfDigits: int) -> None: 
    """DEPRECATED; use set exudyn.config.precision instead; removed in 2029."""
    ...
@overload
def SetLinalgOutputFormatPython(flagPythonFormat: bool) -> None: 
    """DEPRECATED; True: use Python format for output of vectors and matrices; False: use Matlab format; removed in 2029."""
    ...
@overload
def GetVersionString(addDetails=False) -> str: 
    """DEPRECATED; Get Exudyn built version as string (if addDetails=True, adds more information on compilation Python version, platform, etc.; the Python micro version may differ from that you are working with; AVX2 shows that you are running a AVX2 compiled version); removed in 2029."""
    ...
@overload
def SetPrintDelayMilliSeconds(delayMilliSeconds: int) -> None: 
    """DEPRECATED; add some delay (in milliSeconds) to printing to console, in order to let Spyder process the output; default = 0; removed in 2029."""
    ...
@overload
def SuppressWarnings(flag: bool) -> None: 
    """DEPRECATED; set flag to suppress (=True) or enable (=False) warnings; removed in 2029."""
    ...
@overload
def InfoStat(writeOutput=True) -> List[int]: 
    """DEPRECATED; Retrieve list of global information on memory allocation and other counts as list:[array_new_counts, array_delete_counts, vector_new_counts, vector_delete_counts, matrix_new_counts, matrix_delete_counts, linkedDataVectorCast_counts]; May be extended in future; if writeOutput==True, it additionally prints the statistics; counts for new vectors and matrices should not depend on numberOfSteps, except for some objects such as ObjectGenericODE2 and for (sensor) output to files; Not available if code is compiled with __FAST_EXUDYN_LINALG flag; removed in 2029."""
    ...
@overload
def SetWriteToConsole(flag: bool) -> None: 
    """DEPRECATED; set flag to write (True) or not write to console; default = True; removed in 2029."""
    ...
@overload
def InvalidIndex() -> int: 
    """This function provides the invalid index, which may depend on the kind of 32-bit, 64-bit signed or unsigned integer; e.g., node index or item index in list; currently, the InvalidIndex() gives -1, but it may be changed in future versions, therefore you should use this function."""
    ...
__version__:str
"""contains the current version of the Exudyn package."""
config:Config
"""global config settings, like precision, print behavior, warnings, etc."""
variables:dict
"""this dictionary may be used by the user to store exudyn-wide data in order to avoid global Python variables; usage: exu.variables['myvar'] = 42; can be used in particular to exchange data between different mbs or between packages by importing exudyn.variables wherever needed."""
sys:dict
"""this dictionary is used and reserved by the system, e.g., for testsuite, graphics or system function to store module-wide data in order to avoid global Python variables; the variable exu.sys['renderState'] contains the last render state after SC.renderer.Stop() and can be used for subsequent simulations."""
special:Special
"""special attributes and functions, such as global (solver) flags or helper functions; not intended for regular users; for available features, see the C++ code class PySpecial"""
experimental:Experimental
"""Experimental features, not intended for regular users; for available features, see the C++ code class PyExperimental"""
from exudyn.interactive import SolutionViewer as _SolutionViewer
from exudyn.misc.mainSystemExtensions import MainSystemCreateGround as _MainSystemCreateGround
from exudyn.misc.mainSystemExtensions import MainSystemCreateMassPoint as _MainSystemCreateMassPoint
from exudyn.misc.mainSystemExtensions import MainSystemCreateRigidBody as _MainSystemCreateRigidBody
from exudyn.misc.mainSystemExtensions import MainSystemCreateSpringDamper as _MainSystemCreateSpringDamper
from exudyn.misc.mainSystemExtensions import MainSystemCreateCartesianSpringDamper as _MainSystemCreateCartesianSpringDamper
from exudyn.misc.mainSystemExtensions import MainSystemCreateRigidBodySpringDamper as _MainSystemCreateRigidBodySpringDamper
from exudyn.misc.mainSystemExtensions import MainSystemCreateTorsionalSpringDamper as _MainSystemCreateTorsionalSpringDamper
from exudyn.misc.mainSystemExtensions import MainSystemCreateLinearSpringDamper as _MainSystemCreateLinearSpringDamper
from exudyn.misc.mainSystemExtensions import MainSystemCreateRevoluteJoint as _MainSystemCreateRevoluteJoint
from exudyn.misc.mainSystemExtensions import MainSystemCreateHelicalJoint as _MainSystemCreateHelicalJoint
from exudyn.misc.mainSystemExtensions import MainSystemCreatePrismaticJoint as _MainSystemCreatePrismaticJoint
from exudyn.misc.mainSystemExtensions import MainSystemCreateSphericalJoint as _MainSystemCreateSphericalJoint
from exudyn.misc.mainSystemExtensions import MainSystemCreateGenericJoint as _MainSystemCreateGenericJoint
from exudyn.misc.mainSystemExtensions import MainSystemCreateDistanceConstraint as _MainSystemCreateDistanceConstraint
from exudyn.misc.mainSystemExtensions import MainSystemCreateCoordinateConstraint as _MainSystemCreateCoordinateConstraint
from exudyn.misc.mainSystemExtensions import MainSystemCreateRollingDisc as _MainSystemCreateRollingDisc
from exudyn.misc.mainSystemExtensions import MainSystemCreateRollingDiscPenalty as _MainSystemCreateRollingDiscPenalty
from exudyn.misc.mainSystemExtensions import MainSystemCreateSphereSphereContact as _MainSystemCreateSphereSphereContact
from exudyn.misc.mainSystemExtensions import MainSystemCreateSphereQuadContact as _MainSystemCreateSphereQuadContact
from exudyn.misc.mainSystemExtensions import MainSystemCreateSphereTriangleContact as _MainSystemCreateSphereTriangleContact
from exudyn.misc.mainSystemExtensions import MainSystemCreateSphereCylinderContact as _MainSystemCreateSphereCylinderContact
from exudyn.misc.mainSystemExtensions import MainSystemCreateCylinderCylinderContact as _MainSystemCreateCylinderCylinderContact
from exudyn.misc.mainSystemExtensions import MainSystemCreateCylinderTriangleContact as _MainSystemCreateCylinderTriangleContact
from exudyn.misc.mainSystemExtensions import MainSystemCreateConeConeContact as _MainSystemCreateConeConeContact
from exudyn.misc.mainSystemExtensions import MainSystemCreateConeTriangleContact as _MainSystemCreateConeTriangleContact
from exudyn.misc.mainSystemExtensions import MainSystemCreateConvexConvexContact as _MainSystemCreateConvexConvexContact
from exudyn.misc.mainSystemExtensions import MainSystemCreatePrimitiveConvexContact as _MainSystemCreatePrimitiveConvexContact
from exudyn.misc.mainSystemExtensions import MainSystemCreateKinematicTree as _MainSystemCreateKinematicTree
from exudyn.misc.mainSystemExtensions import MainSystemCreateFFRFReducedOrderObject as _MainSystemCreateFFRFReducedOrderObject
from exudyn.misc.mainSystemExtensions import MainSystemCreateForce as _MainSystemCreateForce
from exudyn.misc.mainSystemExtensions import MainSystemCreateTorque as _MainSystemCreateTorque
from exudyn.misc.mainSystemExtensions import CreateDistanceSensorGeometry as _CreateDistanceSensorGeometry
from exudyn.misc.mainSystemExtensions import CreateDistanceSensor as _CreateDistanceSensor
from exudyn.plot import PlotSensor as _PlotSensor
from exudyn.solver import SolveStatic as _SolveStatic
from exudyn.solver import SolveDynamic as _SolveDynamic
from exudyn.solver import ComputeLinearizedSystem as _ComputeLinearizedSystem
from exudyn.solver import ComputeODE2Eigenvalues as _ComputeODE2Eigenvalues
from exudyn.solver import ComputeSystemDegreeOfFreedom as _ComputeSystemDegreeOfFreedom
from exudyn.systemUtilities import ComputeConstraintResiduals as _ComputeConstraintResiduals
from exudyn.systemUtilities import DrawSystemGraph as _DrawSystemGraph


class ExudynError(Exception): ...

class ModelError(ExudynError, ValueError): ...

class SolverError(ExudynError, RuntimeError): ...

class InternalError(ExudynError, RuntimeError): ...

class NotImplementedFeatureError(ExudynError, NotImplementedError): ...

class ExudynIndexError(ExudynError, IndexError): ...

class ExudynValueError(ExudynError, ValueError): ...

class ExudynTypeError(ExudynError, TypeError): ...

class ExudynArithmeticError(ExudynError, ArithmeticError): ...






class OutputVariableType(Enum):
    """The enumeration type  OutputVariableType is used for selecting output values, e.g., for GetObjectOutput(...) or for selecting variables for contour plot.

    Available output variables and the interpreation of the output variable can be found at the object definitions.

    The OutputVariableType does not provide information about the size of the output variable, which can be either scalar or a list (vector)
    For vector output quantities, the contour plot option offers an additional parameter for selection of the component of the OutputVariableType
    The components are usually out of {0,1,2}, representing {x,y,z} components (e.g., of displacements, velocities, ...), or {0,1,2,3,4,5} representing {xx,yy,zz,yz,xz,xy} components (e.g., of strain or stress)
    In order to compute a norm, chose component=-1, which will result in the quadratic norm for other vectors and to a norm specified for stresses (if no norm is defined for an outputVariable, it does not compute anything) The values are bits; | and & combine them into an int, as in C++.
    """
    def __or__(self, other: OutputVariableType | int) -> int: ...
    def __ror__(self, other: OutputVariableType | int) -> int: ...
    def __and__(self, other: OutputVariableType | int) -> int: ...
    def __rand__(self, other: OutputVariableType | int) -> int: ...
    _None = int
    """no value; used, e.g., to select no output variable in contour plot"""
    Distance = int
    """e.g., measure distance in spring damper connector"""
    Position = int
    """measure 3D position, e.g., of node or body"""
    Displacement = int
    """measure displacement; usually difference between current position and reference position"""
    DisplacementLocal = int
    """measure local displacement, e.g., in local joint coordinates"""
    Velocity = int
    """measure (translational) velocity of node or object"""
    VelocityLocal = int
    """measure local (translational) velocity, e.g., in local body or joint coordinates"""
    Acceleration = int
    """measure (translational) acceleration of node or object"""
    AccelerationLocal = int
    """measure (translational) acceleration of node or object in local coordinates"""
    RotationMatrix = int
    """measure rotation matrix of rigid body node or object"""
    Rotation = int
    """measure, e.g., scalar rotation of 2D body, Euler angles of a 3D object or rotation within a joint"""
    AngularVelocity = int
    """measure angular velocity of node or object"""
    AngularVelocityLocal = int
    """measure local (body-fixed) angular velocity of node or object"""
    AngularAcceleration = int
    """measure angular acceleration of node or object"""
    AngularAccelerationLocal = int
    """measure angular acceleration of node or object in local coordinates"""
    CoordinatesTotal = int
    """measure the total coordinates (including reference configuration) of a node or object; otherwise the same as Coordinates"""
    Coordinates = int
    """measure the coordinates of a node or object; coordinates just contain displacements, but not the reference (position or rotation) values - see also definition of respective nodes or objects"""
    Coordinates_t = int
    """measure the time derivative of coordinates (= velocity coordinates) of a node or object"""
    Coordinates_tt = int
    """measure the second time derivative of coordinates (= acceleration coordinates) of a node or object"""
    SlidingCoordinate = int
    """measure sliding coordinate in sliding joint"""
    Director1 = int
    """measure a director (e.g., of a rigid body frame), or a slope vector in local 1 or x-direction"""
    Director2 = int
    """measure a director (e.g., of a rigid body frame), or a slope vector in local 2 or y-direction"""
    Director3 = int
    """measure a director (e.g., of a rigid body frame), or a slope vector in local 3 or z-direction"""
    Force = int
    """measure global force, e.g., in joint or beam (resultant force), or generalized forces; see description of according object"""
    ForceLocal = int
    """measure local force, e.g., in joint or beam (resultant force)"""
    Torque = int
    """measure torque, e.g., in joint or beam (resultant couple/moment)"""
    TorqueLocal = int
    """measure local torque, e.g., in joint or beam (resultant couple/moment)"""
    Strain = int
    """measure global strain, e.g., the Euler-Almansi strain of a solid finite element in global coordinates"""
    Stress = int
    """measure global stress, e.g., the Cauchy stress of a solid finite element in global coordinates; choosing component==-1 will result in the computation of the Mises stress"""
    StrainLocal = int
    """measure local strain, e.g., axial strain in cross section frame of beam or Green-Lagrange strain"""
    StressLocal = int
    """measure local stress, e.g., axial stress in cross section frame of beam or Second Piola-Kirchoff stress; choosing component==-1 will result in the computation of the Mises stress"""
    StrainPlasticLocal = int
    """measure the plastic part of a local strain, e.g., the plastic Green-Lagrange strain of a solid finite element with plasticity, as StrainLocal; choosing component==-1 will result in the equivalent strain"""
    Temperature = int
    """measure the temperature, e.g., the prescribed temperature of a solid finite element at a local position or a mesh node"""
    CurvatureLocal = int
    """measure local curvature; may be scalar or vectorial: twist and curvature of beam in cross section frame"""
    ConstraintEquation = int
    """evaluates constraint equation (=current deviation or drift of constraint equation)"""
    KineticEnergy = int
    """measure kinetic energy of a body, position independent"""
    PotentialEnergy = int
    """measure potential (=elastic) energy of a body or connector, position independent"""
    HomogeneousTransformation = int
    """measure the homogeneous transformation of a node, body point or marker: its rotation matrix A and position p as the 4x4 matrix [A p; 0 1]; the Get...Output functions return it as exu.HT, a sensor stores its 16 components row by row; every item with Position and RotationMatrix provides it"""
    HomogeneousTransformationLocal = int
    """measure the homogeneous transformation of a frame relative to another, e.g., of joint frame J1 in joint frame J0: the 4x4 matrix [A p; 0 1] with the relative rotation matrix A and the relative position p in the first frame; returned and stored as HomogeneousTransformation"""
    UserType0 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""
    UserType1 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""
    UserType2 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""
    UserType3 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""


class InspectType(Enum):
    """The enumeration type InspectType selects what mbs.Inspect(itemIndex, what) reports about an item; each answer is a list of the enumeration types Exudyn exports, the flags of C++ split into their single members."""
    OutputVariables = int
    """the output variables of an object, node or marker (OutputVariableType), with its current parameters: the energies only where they can be computed"""
    ObjectType = int
    """the type flags of an object (ObjectType): Body, Connector, Constraint, SuperElement, ..."""
    NodeType = int
    """the types a node provides (NodeType): Position, Orientation, RotationEulerParameters, ..."""
    RequestedNodeTypes = int
    """for each node of an object, the node types it requests (NodeType), all of them; for the node of a node marker, a list of requirements, each a list of alternatives of which the node provides one - [[NodeType.Position, NodeType.Position2D]] for MarkerNodePosition"""
    MarkerType = int
    """the types a marker provides (MarkerType)"""
    RequestedMarkerTypes = int
    """for each marker of a connector, constraint or load, the marker types it requests (MarkerType)"""
    AccessFunctions = int
    """the access functions a body offers (AccessFunctionType), which decide the body markers it takes"""


class ComputeItemType(Enum):
    """The enumeration type ComputeItemType selects what mbs.ComputeItem(itemIndex, what, ...) computes for an item at the current state of the system; matrices and vectors refer to the coordinates of the item (its local-to-global ODE2 coordinates, mbs.systemData.GetObjectLTGODE2, or the coordinates of the node)."""
    PositionJacobian = int
    """the position Jacobian, d(velocity)/d(q_t): of a body at localPosition, of a node, of a marker"""
    RotationJacobian = int
    """the rotation Jacobian, d(angular velocity)/d(q_t), global: of a body at localPosition, of a node, of a rigid marker"""
    JacobianTTimesVectorDerivative = int
    """the derivative of the transposed Jacobian times a vector by the coordinates: of a body at localPosition and of a marker, d(J_pos^T f + J_rot^T tau)/dq with vector = [f, tau] (6 values); of a node, d(J_rot^T tau)/dq with vector = tau (3 values); an empty matrix where it is zero"""
    MassWeightedPositionJacobian = int
    """the integral of the density times the position Jacobian over a body, as the mass-proportional load uses it"""
    ODE2LHS = int
    """the left-hand side of the second order equations of an object - a body, or the forces of a connector projected on its markers -, with the sign of ComputeODE2LHS"""
    MassMatrix = int
    """the mass matrix of a body"""
    AlgebraicEquations = int
    """the algebraic equations of a constraint, of a body or of a node with algebraic equations (Euler parameters), at position level"""
    ConstraintJacobian = int
    """the Jacobian of the algebraic equations by the ODE2 coordinates (by the velocities for a constraint at velocity level)"""
    ReactionForces = int
    """the reaction forces C_q^T lambda of a constraint, with the current Lagrange multipliers"""
    Kinematics = int
    """the marker data of a marker, without Jacobians, as a dict: position, velocity, rotationMatrix and angularVelocityLocal where the marker has an orientation, value and value_t for a coordinate marker"""
    CoordinateJacobian = int
    """the Jacobian of a coordinate marker by the coordinates it acts on"""
    JacobianODE2 = int
    """the analytic Jacobian d(ODE2LHS)/dq of a body or connector, where it has one - the one the solver uses; for the others, NumericalJacobian of ODE2LHS"""
    JacobianODE2_t = int
    """the analytic Jacobian d(ODE2LHS)/dq_t of a body or connector, where it has one"""
    AlgebraicEquations_t = int
    """the algebraic equations at velocity level, as with useIndex2Constraints: the time derivative of a position-level constraint, the equations of a velocity-level constraint; of a constraint, a body or a node with algebraic equations (#565)"""
    ConstraintDrift = int
    """the drift of the position-level constraints: AlgebraicEquations, zero for the equations of a velocity-level constraint (rolling disc, velocityLevel=True), as the solver checks it with checkConstraintDrift (#565)"""


class ConfigurationType(Enum):
    """The enumeration type  ConfigurationType is used for selecting a configuration for reading or writing information to the module.

    Specifically, the ConfigurationType.Current configuration is usually used at the end of a solution process, to obtain result values, or the ConfigurationType.Initial is used to set initial values for a solution process.
    """
    _None = int
    """no configuration; usually not valid, but may be used, e.g., if no configurationType is required"""
    Initial = int
    """initial configuration prior to static or dynamic solver; is computed during mbs.Assemble() or AssembleInitializeSystemCoordinates()"""
    Current = int
    """current configuration during and at the end of the computation of a step (static or dynamic)"""
    Reference = int
    """configuration used to define deformable bodies (reference configuration for finite elements) or joints (configuration for which some joints are defined)"""
    StartOfStep = int
    """during computation, this refers to the solution at the start of the step = end of last step, to which the solver falls back if convergence fails"""
    Visualization = int
    """this is a state completely de-coupled from computation, used for visualization"""
    EndOfEnumList = int
    """this marks the end of the list, usually not important to the user"""


class ItemType(Enum):
    """The enumeration type  ItemType is used for defining types of indices, e.g., in render window and will be also used in item dictionaries in future."""
    _None = int
    """item has no type"""
    Node = int
    """item or index is of type Node"""
    Object = int
    """item or index is of type Object"""
    Marker = int
    """item or index is of type Marker"""
    Load = int
    """item or index is of type Load"""
    Sensor = int
    """item or index is of type Sensor"""


class NodeType(Enum):
    """The enumeration type  NodeType is used for defining node types for 3D rigid bodies.

    The values are bits; | and & combine them into an int, as in C++.
    """
    def __or__(self, other: NodeType | int) -> int: ...
    def __ror__(self, other: NodeType | int) -> int: ...
    def __and__(self, other: NodeType | int) -> int: ...
    def __rand__(self, other: NodeType | int) -> int: ...
    _None = int
    """node has no type"""
    Ground = int
    """ground node"""
    Position2D = int
    """2D position node"""
    Orientation2D = int
    """node with 2D rotation"""
    Point2DSlope1 = int
    """2D node with 1 slope vector"""
    Position = int
    """3D position node"""
    Orientation = int
    """3D orientation node"""
    RigidBody = int
    """node that can be used for rigid bodies"""
    RotationEulerParameters = int
    """node with 3D orientations that are modelled with Euler parameters (unit quaternions)"""
    RotationRxyz = int
    """node with 3D orientations that are modelled with Tait-Bryan angles"""
    RotationRotationVector = int
    """node with 3D orientations that are modelled with the rotation vector"""
    LieGroupWithDirectUpdate = int
    """node to be solved with Lie group methods, without data coordinates"""
    GenericODE2 = int
    """node with general ODE2 variables"""
    GenericODE1 = int
    """node with general ODE1 variables"""
    GenericAE = int
    """node with general algebraic variables"""
    GenericData = int
    """node with general data variables"""
    PointSlope1 = int
    """node with 1 slope vector"""
    PointSlope12 = int
    """node with 2 slope vectors in x and y direction"""
    PointSlope23 = int
    """node with 2 slope vectors in y and z direction"""
    UserType0 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""
    UserType1 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""
    UserType2 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""
    UserType3 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""


class MarkerType(Enum):
    """The enumeration type MarkerType lists the properties of a marker as bits; a connector or load requests a combination of them (GetRequestedMarkerType), which the marker type must contain.

    The values are bits; | and & combine them into an int, as in C++.
    """
    def __or__(self, other: MarkerType | int) -> int: ...
    def __ror__(self, other: MarkerType | int) -> int: ...
    def __and__(self, other: MarkerType | int) -> int: ...
    def __rand__(self, other: MarkerType | int) -> int: ...
    _None = int
    """no type is used"""
    Body = int
    """marker is attached to a body (must also be Object)"""
    Node = int
    """marker is attached to a node"""
    Object = int
    """marker is attached to an object"""
    SuperElement = int
    """marker only applicable to super elements; accesses (virtual) nodes of super elements"""
    KinematicTree = int
    """marker only applicable to KinematicTree; accesses (virtual) nodes of KinematicTree"""
    Position = int
    """can measure position, apply distance constraint"""
    Orientation = int
    """can measure rotation, apply general rigid body constraint (if Position is set)"""
    Coordinate = int
    """access any coordinate (always available)"""
    Coordinates = int
    """access all coordinates (always available)"""
    BodyLine = int
    """line load (vector load applied to line)"""
    BodySurface = int
    """surface load / connector (e.g. for revolute joint with FE-mesh)"""
    BodyVolume = int
    """volume load, usually gravity"""
    BodyMass = int
    """mass proportional load, usually gravity"""
    BodySurfaceNormal = int
    """surface pressure (uses scalar load)"""
    MultiNodal = int
    """multinodal marker uses a weighting matrix to transform node values into the marker value"""
    ReducedCoordinates = int
    """marker uses reduced (modal) coordinates of a super element"""
    ODE1 = int
    """marker addresses ODE1 coordinate(s) (standard is ODE2)"""
    JacobianDerivativeNonZero = int
    """the derivative of the marker jacobian is non-zero (e.g. for rotations)"""
    JacobianDerivativeAvailable = int
    """the derivative of the marker jacobian is implemented"""
    HasPostNewton = int
    """the PostNewton function has to be called"""
    Beam2DShape = int
    """access to 2D beam shape"""
    Beam3DShape = int
    """access to 3D beam shape"""
    UserType0 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""
    UserType1 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""
    UserType2 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""
    UserType3 = int
    """a type for a user item, e.g. a strain of a user element; its name is set with exudyn.special.userTypes.SetName, which also adds it as an alias of this value"""


class JointType(Enum):
    """The enumeration type  JointType is used for defining joint types, used in KinematicTree."""
    _None = int
    """node has no type"""
    RevoluteX = int
    """revolute joint type with rotation around local X axis"""
    RevoluteY = int
    """revolute joint type with rotation around local Y axis"""
    RevoluteZ = int
    """revolute joint type with rotation around local Z axis"""
    PrismaticX = int
    """prismatic joint type with translation along local X axis"""
    PrismaticY = int
    """prismatic joint type with translation along local Y axis"""
    PrismaticZ = int
    """prismatic joint type with translation along local Z axis"""


class AccessFunctionType(Enum):
    """The enumeration type AccessFunctionType lists the access functions (jacobians) an object provides for markers, as bits; its values share the bits of MarkerType.

    A marker can be attached to an object only if the object provides the access function the marker needs.
    """
    _None = int
    """no access function"""
    TranslationalVelocity_qt = int
    """for application of forces, position constraints"""
    AngularVelocity_qt = int
    """for application of torques, rotational constraints"""
    Coordinate_q = int
    """for application of generalized forces"""
    DisplacementLineIntegral_q = int
    """for line loads"""
    DisplacementSurfaceIntegral_q = int
    """for surface loads"""
    DisplacementVolumeIntegral_q = int
    """for distributed (body-volume) loads"""
    DisplacementMassIntegral_q = int
    """for distributed (body-mass) loads"""
    DisplacementSurfaceNormalIntegral_q = int
    """for surface loads; pressure acts normal to the surface"""
    SuperElement = int
    """for super elements, using TranslationalVelocity_qt and AngularVelocity_qt"""
    KinematicTree = int
    """for KinematicTree, using TranslationalVelocity_qt and AngularVelocity_qt"""
    OwnMarkersOnly = int
    """the access functions serve only the object's own markers (super element or kinematic tree markers); the general body markers are refused"""
    JacobianTtimesVector_q = int
    """derivative of jacobian^T times vector (provided in markerData.vectorValue)"""


class DynamicSolverType(Enum):
    """The enumeration type  DynamicSolverType is used for selecting dynamic solvers for simulation."""
    GeneralizedAlpha = int
    """an implicit solver for index 3 problems; intended to be used for solving directly the index 3 constraints using the spectralRadius sufficiently small (usually 0.5 .. 1)"""
    TrapezoidalIndex2 = int
    """an implicit solver for index 3 problems with index2 reduction; uses generalized alpha solver with settings for Newmark with index2 reduction"""
    ExplicitEuler = int
    """an explicit 1st order solver (generally not compatible with constraints)"""
    ExplicitMidpoint = int
    """an explicit 2nd order solver (generally not compatible with constraints)"""
    RK33 = int
    """an explicit 3 stage 3rd order Runge-Kutta method, aka 'Heun third order'; (generally not compatible with constraints)"""
    RK44 = int
    """an explicit 4 stage 4th order Runge-Kutta method, aka 'classical Runge Kutta' (generally not compatible with constraints), compatible with Lie group integration and elimination of CoordinateConstraints"""
    RK67 = int
    """an explicit 7 stage 6th order Runge-Kutta method, see 'On Runge-Kutta Processes of High Order', J. C. Butcher, J. Austr Math Soc 4, (1964); can be used for very accurate (reference) solutions, but without step size control!"""
    ODE23 = int
    """an explicit Runge Kutta method with automatic step size selection with 3rd order of accuracy and 2nd order error estimation, see Bogacki and Shampine, 1989; also known as ODE23 in MATLAB"""
    DOPRI5 = int
    """an explicit Runge Kutta method with automatic step size selection with 5th order of accuracy and 4th order error estimation, see  Dormand and Prince, 'A Family of Embedded Runge-Kutta Formulae.', J. Comp. Appl. Math. 6, 1980"""
    DVERK6 = int
    """[NOT IMPLEMENTED YET] an explicit Runge Kutta solver of 6th order with 5th order error estimation; includes adaptive step selection"""
    VelocityVerlet = int
    """a special explicit time integration scheme, the 'velocity Verlet' method (similar to leap frog method), with second order accuracy for conservative second order differential equations and first order if forces depend on velocities (damping, gyroscopic terms), often used for particle dynamics and contact; implementation uses Explicit Euler for ODE1 equations"""
    TrapezoidalGGL = int
    """an implicit solver for index 3 problems: the trapezoidal rule with the constraints and the velocity constraints at the end of the step, the positions moved onto the constraints by a second multiplier (GGL stabilization); order 2, without numerical damping; automatic step size by the error of the embedded trapezoidal solution (#3261)"""
    LobattoIIIA4 = int
    """an implicit Runge-Kutta solver for index 3 problems: Lobatto IIIA with three stages (start, middle, end of the step), the constraints and the velocity constraints at the end of the step; order 4 in positions and velocities, without numerical damping; automatic step size by an error estimate of the order of the method (#3261)"""
    LobattoIIIC4GGL = int
    """an implicit Runge-Kutta solver for index 3 problems: Lobatto IIIC with three implicit stages, the constraints and velocity constraints at each stage with the GGL stabilization; order 4 in positions and velocities, L-stable (damps fast modes); automatic step size as LobattoIIIA4 (#3261)"""
    Radau3 = int
    """an implicit Runge-Kutta solver for index 3 problems: Radau IIA with the stages at 1/3 and the end of the step, the constraints as LobattoIIIA4; order 3, L-stable; automatic step size as LobattoIIIA4 (#3261)"""
    Radau5 = int
    """an implicit Runge-Kutta solver for index 3 problems: Radau IIA with three stages at (4 - sqrt 6)/10, (4 + sqrt 6)/10 and the end of the step, the constraints as LobattoIIIA4; order 5 in positions and velocities, L-stable; automatic step size as LobattoIIIA4 (#3318)"""


class CrossSectionType(Enum):
    """The enumeration type  CrossSectionType is used for defining beam cross section types.

    The values are bits; | and & combine them into an int, as in C++.
    """
    def __or__(self, other: CrossSectionType | int) -> int: ...
    def __ror__(self, other: CrossSectionType | int) -> int: ...
    def __and__(self, other: CrossSectionType | int) -> int: ...
    def __rand__(self, other: CrossSectionType | int) -> int: ...
    Polygon = int
    """cross section profile defined by polygon"""
    Circular = int
    """cross section is circle or elliptic"""


class KeyCode(Enum):
    """The enumeration type  KeyCode is used for special key codes in keyPressUserFunction."""
    SPACE = int
    """space key"""
    ENTER = int
    """enter (return) key"""
    TAB = int
    """"""
    BACKSPACE = int
    """"""
    RIGHT = int
    """cursor right"""
    LEFT = int
    """cursor left"""
    DOWN = int
    """cursor down"""
    UP = int
    """cursor up"""
    F1 = int
    """function key F1"""
    F2 = int
    """function key F2"""
    F3 = int
    """function key F3"""
    F4 = int
    """function key F4"""
    F5 = int
    """function key F5"""
    F6 = int
    """function key F6"""
    F7 = int
    """function key F7"""
    F8 = int
    """function key F8"""
    F9 = int
    """function key F9"""
    F10 = int
    """function key F10"""


class LinearSolverType(Enum):
    """The enumeration type  LinearSolverType is used for selecting linear solver types, which are dense or sparse solvers.

    The values are bits; | and & combine them into an int, as in C++.
    """
    def __or__(self, other: LinearSolverType | int) -> int: ...
    def __ror__(self, other: LinearSolverType | int) -> int: ...
    def __and__(self, other: LinearSolverType | int) -> int: ...
    def __rand__(self, other: LinearSolverType | int) -> int: ...
    _None = int
    """no value; used, e.g., if no solver is selected"""
    EXUdense = int
    """use dense matrices and according solvers for densly populated matrices (usually the CPU time grows cubically with the number of unknowns)"""
    EigenSparse = int
    """use sparse matrices and according solvers; additional overhead for very small multibody systems; specifically, memory allocation is performed during a factorization process"""
    EigenSparseSymmetric = int
    """use sparse matrices and according solvers; NOTE: this is the symmetric mode, which assumes symmetric system matrices; this is EXPERIMENTAL and should only be used of user knows that the system matrices are (nearly) symmetric; does not work with scaled GeneralizedAlpha matrices; does not work with constraints, as it must be symmetric positive definite"""
    EigenDense = int
    """use Eigen's LU factorization with partial pivoting (faster than EXUdense) or full pivot (if linearSolver.ignoreSingularJacobian=True; is much slower, but can resolve overdetermined and underdetermined problems!); NOTE: in the default partial pivoting mode a singular matrix is NOT detected - Eigen provides no invertibility check there - so the solver continues with an undefined result instead of reporting a singular jacobian; use EXUdense or EigenSparse if that must be reported, or full pivot (ignoreSingularJacobian=True), which resolves the singular system by least squares on purpose"""
    PardisoMKL = int
    """use sparse matrices as EigenSparse, factorized and solved by Intel MKL PARDISO, which the user installs into the Python environment (pip install mkl, or conda install mkl; x86-64 only) and which Exudyn loads at run time; faster than EigenSparse for frequent factorizations of large systems (full Newton, contact), slower in the back-substitution; the residual is checked after the first factorization of a pattern and periodically, and a failure falls back to SparseLU with a warning; exudyn.special.solver.PardisoInfo() tells whether MKL is found, and exudyn.special.solver holds the settings; EXPERIMENTAL"""


class TextureInterpretation(Enum):
    """The enumeration type TextureInterpretation says how SC.renderer.AddTexture interprets an image and how the renderers draw it (#3029); the channels of the image are converted to those of the interpretation: a grey image gives equal R, G and B, an image without alpha gets A=1; an image with colors cannot be interpreted as Grey."""
    Grey = int
    """one channel, the brightness; multiplied with the color of the triangle it shades a colored surface"""
    RGB = int
    """three channels, the color; opaque"""
    RGBA = int
    """four channels, the color and A the opacity; transparent where A < 1, multiplied with the alpha of the triangle"""
    RGBAMask = int
    """four channels, the color and A a mask: a pixel with A < 0.5 is not drawn, the others are opaque; for cut-out shapes without the sorting that transparency needs"""


class TextureFlags(Enum):
    """The enumeration type TextureFlags lists the options of a texture, passed to SC.renderer.AddTexture (#3029, #3037); with none, a texture is filtered linearly, repeated outside the texture coordinates 0 to 1, and multiplied with the color of the triangle, as OpenGL does by default.

    The values are bits; | and & combine them into an int, as in C++.
    """
    def __or__(self, other: TextureFlags | int) -> int: ...
    def __ror__(self, other: TextureFlags | int) -> int: ...
    def __and__(self, other: TextureFlags | int) -> int: ...
    def __rand__(self, other: TextureFlags | int) -> int: ...
    Nearest = int
    """the nearest pixel instead of linear interpolation; sharp pixels, e.g. for a checkerboard or a pixel image"""
    Clamp = int
    """texture coordinates outside 0 to 1 take the color of the border instead of repeating the texture"""
    Replace = int
    """the texture replaces the color of the triangle instead of being multiplied with it; the triangle color and the lighting are not applied"""


class ContactTypeIndex(Enum):
    """The enumeration type  ContactTypeIndex is used in GeneralContact to select specific contact items, such as spheres, ANCFCable or triangle items."""
    IndexSpheresMarkerBased = int
    """spheres attached to markers"""
    IndexANCFCable2D = int
    """ANCFCable2D contact items"""
    IndexTrigsRigidBodyBased = int
    """triangles attached to rigid body (or rigid body marker)"""
    IndexEndOfEnumList = int
    """signals end of list"""


class ContactImpactModel(Enum):
    """The enumeration type ContactImpactModel selects the impact model of the penalty contacts (ObjectContactCoordinate, ObjectContactSphereSphere, ObjectContactSphereTriangle, ...), the parameter impactModel; the integers 0, 1 and 2 are accepted for it as well.

    In all models the linear contactDamping is added, if it is not zero (#3327).
    """
    Linear = int
    """the linear model: the contact stiffness and only the linear contactDamping"""
    HuntCrossley = int
    """the model of Hunt and Crossley: a damping proportional to the penetration, from the restitution coefficient and the impact velocity"""
    GonthierCarvalhoMartins = int
    """the mixed model of Gonthier et al. and Carvalho and Martins, much more accurate for the coefficient of restitution in the full range (0, 1]"""


class JournalBearingModel(Enum):
    """The enumeration type JournalBearingModel selects the model of the oil film of ObjectJournalBearing, the parameter bearingModel; the integers 0 and 1 are accepted for it as well (#3335)."""
    Short = int
    """the infinitely short bearing of Ocvirk, for a length/diameter ratio below about 0.5"""
    Long = int
    """the infinitely long bearing of Sommerfeld, with the half-film (Guembel) condition"""


class ContactPrimitiveType(Enum):
    """The enumeration type ContactPrimitiveType selects the shape of marker 0 of ObjectContactPrimitiveConvex, the parameter primitiveType; the integers 0 to 3 are accepted for it as well (#3364)."""
    Sphere = int
    """a sphere of the radius"""
    Capsule = int
    """a capsule: the radius and the length between the centers of its half spheres"""
    Cylinder = int
    """a finite cylinder of the radius and the length"""
    Cone = int
    """a truncated cone with the length, the radius at -length/2 and radius1 at +length/2"""


class DistributedLoadType(Enum):
    """The enumeration type DistributedLoadType selects the field of LoadDistributed, the parameter distributedLoadType; the integers 0 to 2 are accepted for it as well (#3600)."""
    Acceleration = int
    """a constant acceleration, the force density rho a; parameters = [ax, ay, az]"""
    Centrifugal = int
    """the centrifugal field of a rotation about an axis, the force density -rho omega x (omega x (x - xA)); parameters = [xA, omega], the point xA on the axis and the angular velocity vector omega"""
    UserFunction = int
    """the field of loadUserFunction"""


class MatrixContainer:
    """The MatrixContainer is a versatile representation for dense and sparse matrices.

    NOTE: if the MatrixContainer is constructed from a numpy array or a list of lists, both representing a dense matrix, it will go into dense mode; if it is initialized with a scipy sparse csr matrix, it will go into sparse mode
    Examples:
    """
    @overload
    def Initialize(self, numberOfRows: int, numberOfColumns: int, useDenseMatrix: bool=True) -> None: 
        """Initialize MatrixContainer with number of rows and columns and set dense/sparse mode."""
        ...
    @overload
    def SetWithDenseMatrix(self, pyArray: ArrayLike, useDenseMatrix: bool=False, factor: float=1.) -> None: 
        """Set MatrixContainer with dense numpy array of size (n x m); array (=matrix) contains values and matrix size information; if useDenseMatrix=True, matrix will be stored internally as dense matrix, otherwise it will be converted and stored as sparse matrix (which may speed up computations for larger problems); pyArray is multiplied with given factor."""
        ...
    @overload
    def SetWithSparseMatrix(self, sparseMatrix: Any, numberOfRows: int=exudyn.InvalidIndex(), numberOfColumns: int=exudyn.InvalidIndex(), useDenseMatrix: bool=False, factor: float=1.) -> None: 
        """Set with scipy sparse csr_matrix (NOT: csc_matrix!) or with internal sparse triplet format (denoted as CSR): 'sparseMatrix' either contains a scipy matrix create with csr_matrix or a list of lists of sparse triplets (row, col, value) or the list of lists converted into numpy array; numberOfRowsInit and numberOfColumnsInit denote the size of the matrices, which are ignored in case of a scipy sparse matrix; if useDenseMatrix=True, matrix will be converted and stored internally as dense matrix, otherwise it will be stored as sparse matrix triplets; the values of sparseMatrix are multiplied with the given factor before storing."""
        ...
    @overload
    def AddSparseMatrix(self, sparseMatrix: Any, factor: float=1.) -> None: 
        """Add scipy sparse csr_matrix with factor to already initilized MatrixContainer; sparseMatrix must contain according scipy csr format, otherwise the behavior is undefined! This function allows to efficiently add submatrices to the MatrixContainer."""
        ...
    @overload
    def GetPythonObject(self) -> Union[dict,ArrayLike]: 
        """Convert MatrixContainer to numpy array (dense) or dictionary (sparse): containing nr.
        
        of rows, nr. of columns, numpy matrix with sparse triplets
        """
        ...
    @overload
    def Convert2DenseMatrix(self) -> ArrayLike: 
        """Convert MatrixContainer to dense numpy array (SLOW and may fail for too large sparse matrices)."""
        ...
    @overload
    def UseDenseMatrix(self) -> bool: 
        """Returns True if dense matrix is used, otherwise False."""
        ...
    @overload
    def SetAllZero(self) -> None: 
        """Set all values to zero; dense mode: set all matrix entries to zero (slow); sparse mode: set number of triplets to zero (fast)."""
        ...
    @overload
    def SetWithSparseMatrixCSR(self, numberOfRowsInit: int, numberOfColumnsInit: int, pyArrayCSR: Any, useDenseMatrix: bool=False, factor: float=1.) -> None: 
        """DEPRECATED: set with sparse CSR matrix format: numpy array 'pyArrayCSR' contains sparse triplet (row, col, value) per row; numberOfRows and numberOfColumns given extra; if useDenseMatrix=True, matrix will be converted and stored internally as dense matrix, otherwise it will be stored as sparse matrix; the values of pyArrayCSR are multiplied by the given factor; removed in 2029."""
        ...


class HT:
    """The HT is a homogeneous transformation - a rotation matrix A and a translation p, the 4x4 matrix [A p; 0 1] -, the frame of a rigid body, marker or joint, and the place for transformations of rigid bodies: it converts from and to the coordinates of the rigid body nodes (Euler parameters, Tait-Bryan angles Rxyz, rotation vector), composes, inverts and interpolates.

    It is the C++ class of Exudyn, faster than the 4x4 numpy arrays of exudyn.rigidBodyUtilities: it stores the 12 numbers it needs, and a transformation without rotation (identity, a translation only, a unit matrix) skips the rotation in its products
    The Set functions return the HT itself, so that they chain
    Examples:
    """
    rotation:ArrayLike
    """the 3x3 rotation matrix as read-only numpy view of the HT, without a copy: it follows later changes of the HT, np.array(H.rotation) copies it (#3184); setting it keeps the translation."""
    translation:ArrayLike
    """the translation as read-only numpy view of the HT, as rotation; setting it keeps the rotation."""
    @overload
    def Set(self, rotation: ArrayLike=None, translation: ArrayLike=None, eulerParameters: ArrayLike=None, Rxyz: ArrayLike=None, rotationVector: ArrayLike=None) -> HT: 
        """Set the parts given, a part that is None stays: the rotation from at most one of a 3x3 matrix, Euler parameters, Tait-Bryan angles Rxyz and a rotation vector, and the translation; returns the HT (`returns a reference`)."""
        ...
    @overload
    def SetRotationX(self, angle: float) -> HT: 
        """Set a rotation about the x-axis by angle (in radians) and zero translation; returns the HT (`returns a reference`)."""
        ...
    @overload
    def SetRotationY(self, angle: float) -> HT: 
        """Set a rotation about the y-axis by angle (in radians) and zero translation; returns the HT (`returns a reference`)."""
        ...
    @overload
    def SetRotationZ(self, angle: float) -> HT: 
        """Set a rotation about the z-axis by angle (in radians) and zero translation; returns the HT (`returns a reference`)."""
        ...
    @overload
    def SetRotationAxis(self, axis: ArrayLike, angle: float) -> HT: 
        """Set a rotation by angle (in radians) about axis, a 3D vector of any length but zero, and zero translation; returns the HT (`returns a reference`)."""
        ...
    @overload
    def GetEP(self) -> ArrayLike: 
        """The rotation as the 4 Euler parameters [ep0,ep1,ep2,ep3], the rotation parameters of NodeRigidBodyEP, a numpy array."""
        ...
    @overload
    def GetRxyz(self) -> ArrayLike: 
        """The rotation as the 3 Tait-Bryan angles [rotX,rotY,rotZ] (rotation about x, then y, then z), the rotation parameters of NodeRigidBodyRxyz, a numpy array."""
        ...
    @overload
    def GetRotationVector(self) -> ArrayLike: 
        """The rotation as rotation vector (axis times angle), the rotation parameters of NodeRigidBodyRotVecLG, a numpy array."""
        ...
    @overload
    def GetCoordinatesEP(self) -> ArrayLike: 
        """The 7 coordinates of NodeRigidBodyEP: the translation and the Euler parameters, e.g. for referenceCoordinates, a numpy array."""
        ...
    @overload
    def GetCoordinatesRxyz(self) -> ArrayLike: 
        """The 6 coordinates of NodeRigidBodyRxyz: the translation and the Tait-Bryan angles, a numpy array."""
        ...
    @overload
    def GetCoordinatesRotationVector(self) -> ArrayLike: 
        """The 6 coordinates of NodeRigidBodyRotVecLG: the translation and the rotation vector, a numpy array."""
        ...
    @overload
    def SetCoordinatesEP(self, coordinates: ArrayLike) -> HT: 
        """Set from the 7 coordinates of NodeRigidBodyEP, translation and Euler parameters, as given by GetCoordinates...
        
        or by a node; returns the HT (`returns a reference`)
        """
        ...
    @overload
    def SetCoordinatesRxyz(self, coordinates: ArrayLike) -> HT: 
        """Set from the 6 coordinates of NodeRigidBodyRxyz, translation and Tait-Bryan angles, as given by GetCoordinates...
        
        or by a node; returns the HT (`returns a reference`)
        """
        ...
    @overload
    def SetCoordinatesRotationVector(self, coordinates: ArrayLike) -> HT: 
        """Set from the 6 coordinates of NodeRigidBodyRotVecLG, translation and rotation vector, as given by GetCoordinates...
        
        or by a node; returns the HT (`returns a reference`)
        """
        ...
    @overload
    def RotationAngle(self) -> float: 
        """The angle of the rotation in radians, 0 to pi: the length of the rotation vector."""
        ...
    @overload
    def RotationAxis(self, raiseError: bool=True) -> ArrayLike: 
        """The unit axis of the rotation, from the rotation vector; for no rotation an error, or [0,0,0] if raiseError=False."""
        ...
    @overload
    def Relative(self, other: HT) -> HT: 
        """The frame of other seen from this one, H.Inverse()*other, without computing the inverse: what a joint computes between the frames of its two markers."""
        ...
    @overload
    def InterpolateSO3(self, other: HT, factor: float) -> HT: 
        """The transformation between this one (factor=0) and other (factor=1): the translation linear and the rotation on SO(3), about one fixed axis with the angle in proportion."""
        ...
    @overload
    def InterpolateSE3(self, other: HT, factor: float) -> HT: 
        """The transformation between this one (factor=0) and other (factor=1) on SE(3): a screw motion, in which translation and rotation are coupled, as a rigid body moves with constant twist."""
        ...
    @overload
    def LogSE3(self) -> ArrayLike: 
        """The logarithm on SE(3): the motion vector [U, Omega], 6 components as numpy array, from which SetExpSE3 gives this HT back; Omega is the rotation vector, U the translation in the coordinates of the screw motion."""
        ...
    @overload
    def SetExpSE3(self, vector: ArrayLike) -> HT: 
        """Set from the exponential map on SE(3) of the motion vector [U, Omega], 6 components: the screw motion of constant twist; returns the HT (`returns a reference`)."""
        ...
    @overload
    def LogR3xSO3(self) -> ArrayLike: 
        """The logarithm on R3xSO(3): the translation and the rotation vector, each on its own, 6 components as numpy array - the same numbers as GetCoordinatesRotationVector()."""
        ...
    @overload
    def SetExpR3xSO3(self, vector: ArrayLike) -> HT: 
        """Set from the exponential map on R3xSO(3) of [U, Omega], 6 components: the translation U and the rotation of the rotation vector Omega, each on its own; returns the HT (`returns a reference`)."""
        ...
    @overload
    def HT44(self) -> ArrayLike: 
        """The 4x4 matrix [A p; 0 1] as numpy array."""
        ...
    @overload
    def Inverse(self) -> HT: 
        """The inverse transformation [A^T, -A^T p], an HT."""
        ...
    @overload
    def HasNoRotation(self) -> bool: 
        """True if the rotation is the unit matrix - set without rotation (identity, a translation only, a product of such) or given as the exact unit matrix from Python -, which its products then skip; a unit matrix computed in C++ is not checked."""
        ...
    @overload
    def __mul__(self, other: Union[HT, ArrayLike]) -> Union[HT, ArrayLike]: 
        """H1*H2, the composition of two transformations, an HT; H*v, the transformed point A*v+p of a 3D vector, a numpy array."""
        ...
    @overload
    def __eq__(self, other: HT) -> bool: 
        """True if rotation and translation are equal, component by component."""
        ...
    @overload
    def __matmul__(self, other: Union[HT, ArrayLike]) -> Union[HT, ArrayLike]: 
        """H1@H2, the composition of two transformations as H1*H2, an HT; H@x for any other x as numpy computes it with the 4x4 matrix, e.g. H@[x,y,z,1]."""
        ...
    @overload
    def __copy__(self) -> HT: 
        """A copy, for copy.copy(H)."""
        ...
    @overload
    def __deepcopy__(self, memo: Any) -> HT: 
        """A copy, for copy.deepcopy(H) and objects holding an HT."""
        ...
    @overload
    def __getitem__(self, key: Any) -> Any: 
        """H[key]: numpy indexing of the 4x4 matrix [A p; 0 1], e.g. H[0:3,3] for the translation; the result is a copy."""
        ...
    @overload
    def __setitem__(self, key: Any, value: Any) -> None: 
        """H[key] = value: numpy indexing of the 4x4 matrix for writing the rotation and the translation, e.g. H[0:3,3] = p; writing the last row [0,0,0,1] raises."""
        ...
    @overload
    def __array__(self, dtype: Any=None, copy: Any=None) -> ArrayLike: 
        """The 4x4 matrix [A p; 0 1] as numpy array, for np.array(H) and wherever numpy takes the HT."""
        ...
    @overload
    def __repr__(self) -> str: 
        """The string representation of the HT."""
        ...


class Twist:
    """The Twist is the velocity of a frame: the velocity of its origin and its angular velocity, both in global components, the 6D velocity at the origin of the frame.

    With the HT of the frame it gives the velocity of a point fixed in the frame, the twist in the components of the frame and the twist of one frame relative to another: PointVelocity, LocalTwist and RelativeTwist of exudyn.cUtilities and exudyn.symbolics.kinematics
    The forceUserFunction of ObjectConnectorUser gets the HT and the Twist of each marker.
    """
    velocity:ArrayLike
    """the velocity of the origin of the frame, global components, as read-only numpy view of the Twist, without a copy: it follows later changes of the Twist, np.array(twist.velocity) copies it (#3184)."""
    angularVelocity:ArrayLike
    """the angular velocity of the frame, global components, as read-only numpy view of the Twist, as velocity."""
    @overload
    def __eq__(self, other: Twist) -> bool: 
        """True if velocity and angular velocity are equal, component by component."""
        ...
    @overload
    def __add__(self, other: Twist) -> Twist: 
        """Twist0 + twist1, the sum of the velocities and of the angular velocities, a Twist (#3235)."""
        ...
    @overload
    def __sub__(self, other: Twist) -> Twist: 
        """Twist1 - twist0, the difference of the velocities and of the angular velocities, a Twist: LocalTwist(HT0, twist1 - twist0) gives [A0^T (v1 - v0), A0^T (omega1 - omega0)] (#3235)."""
        ...
    @overload
    def __copy__(self) -> Twist: 
        """A copy, for copy.copy(twist)."""
        ...
    @overload
    def __deepcopy__(self, memo: Any) -> Twist: 
        """A copy, for copy.deepcopy(twist)."""
        ...
    @overload
    def __repr__(self) -> str: 
        """The string representation of the Twist."""
        ...


class ConnectorMarker:
    """A ConnectorMarker is one marker of ObjectConnectorUser in its markerAccessUserFunction and postNewtonStepUserFunction, which get one per marker: it reads the marker in the configuration of the call - its position, velocity, rotation and coordinates, and for a body marker positions and velocities anywhere on its body - and applies forces and torques through the Jacobians of the marker.

    A force and a torque act on the marker as a load does, in global coordinates; the functions applied in one call add up
    A function that the marker does not provide raises a ValueError; a ConnectorMarker is valid during the call it was passed to only.
    """
    @overload
    def GetMarkerNumber(self) -> int: 
        """The number of the marker in mbs."""
        ...
    @overload
    def GetObjectNumber(self) -> int: 
        """The number of the object of the marker, -1 for a marker without an object."""
        ...
    @overload
    def GetNodeNumber(self) -> int: 
        """The number of the node of the marker, -1 for a marker without a node."""
        ...
    @overload
    def GetPosition(self) -> ArrayLike: 
        """The global position of a Position marker, as numpy array."""
        ...
    @overload
    def GetVelocity(self) -> ArrayLike: 
        """The global velocity of a Position marker, as numpy array."""
        ...
    @overload
    def GetRotationMatrix(self) -> ArrayLike: 
        """The rotation matrix of an Orientation marker, 3x3 numpy array, from the marker to the global frame."""
        ...
    @overload
    def GetAngularVelocity(self) -> ArrayLike: 
        """The global angular velocity of an Orientation marker, as numpy array."""
        ...
    @overload
    def GetAngularVelocityLocal(self) -> ArrayLike: 
        """The angular velocity of an Orientation marker in the frame of the marker, as numpy array."""
        ...
    @overload
    def GetCoordinates(self) -> ArrayLike: 
        """The coordinates of a Coordinate or Coordinates marker, as numpy array."""
        ...
    @overload
    def GetCoordinates_t(self) -> ArrayLike: 
        """The velocities of the coordinates of a Coordinate or Coordinates marker, as numpy array."""
        ...
    @overload
    def GetBodyPosition(self, localPosition: ArrayLike) -> ArrayLike: 
        """The global position of the point at localPosition of the body of a body marker, as numpy array; localPosition is in the coordinates of the body, not of the marker."""
        ...
    @overload
    def GetBodyVelocity(self, localPosition: ArrayLike) -> ArrayLike: 
        """The global velocity of the point at localPosition of the body of a body marker, as numpy array."""
        ...
    @overload
    def ApplyForce(self, force: ArrayLike) -> None: 
        """Apply the global force (3 components) at a Position marker: the generalized force is the transposed position Jacobian of the marker times the force."""
        ...
    @overload
    def ApplyTorque(self, torque: ArrayLike) -> None: 
        """Apply the global torque (3 components) to an Orientation marker: the generalized force is the transposed rotation Jacobian of the marker times the torque."""
        ...
    @overload
    def ApplyBodyForce(self, force: ArrayLike, localPosition: ArrayLike) -> None: 
        """Apply the global force (3 components) at the point localPosition of the body of a body marker, e.g. at a contact point searched along a flexible body; localPosition is in the coordinates of the body."""
        ...
    @overload
    def ApplyCoordinateForces(self, forces: ArrayLike) -> None: 
        """Apply forces to the coordinates of a Coordinate or Coordinates marker, one per coordinate of the marker."""
        ...


class GraphicsMaterialList:
    """The GraphicsMaterialList contains the list of materials (material properties) for visualization; currently, only the raytracer uses materials.

    Materials can be accessed via the variable materials in renderer of SystemContainer.
    """
    @overload
    def Reset(self) -> None: 
        """Reset materials to 10 default materials."""
        ...
    @overload
    def Append(self, material: Any) -> int: 
        """Add single material as dict or VSettingsMaterial to list; returns index of newly added material."""
        ...
    @overload
    def New(self) -> VSettingsMaterial: 
        """Get new default material, which can be modified or appended to materials list."""
        ...
    @overload
    def Set(self, indexOrName: int, material: Any) -> None: 
        """Set material with index 'materialIndex' as dict or VSettingsMaterial."""
        ...
    @overload
    def Get(self, indexOrName: int) -> None: 
        """Get material with index 'materialIndex' as VSettingsMaterial."""
        ...
    @overload
    def GetDict(self, indexOrName: int) -> None: 
        """Get material with index 'materialIndex' as dict."""
        ...


class Vector3DList:
    """The Vector3DList is used to represent lists of 3D vectors.

    This is used to transfer such lists from Python to C++.
    
    
    
    Usage:
    
    - Create empty ``Vector3DList`` with ``x = Vector3DList()``
    - Create ``Vector3DList`` with list of numpy arrays:``x = Vector3DList([ numpy.array([1.,2.,3.]), numpy.array([4.,5.,6.]) ])``
    - Create ``Vector3DList`` with list of lists ``x = Vector3DList([[1.,2.,3.], [4.,5.,6.]])``
    - Append item: ``x.Append([0.,2.,4.])``
    - Copy: ``y = Vector3DList(x)``; iterate: ``for v in x: ...``
    - Convert into list of numpy arrays: ``x.GetPythonObject()``
    """
    @overload
    def Append(self, pyArray: [float,float,float]) -> None: 
        """Add single array or list to Vector3DList; array or list must have appropriate dimension!."""
        ...
    @overload
    def GetPythonObject(self) -> List[[float,float,float]]: 
        """Convert Vector3DList into (copied) list of numpy arrays."""
        ...


class Vector2DList:
    """The Vector2DList is used to represent lists of 2D vectors.

    This is used to transfer such lists from Python to C++.
    
    
    
    Usage:
    - Create empty ``Vector2DList`` with ``x = Vector2DList()``
    - Create ``Vector2DList`` with list of numpy arrays:
    
      ``x = Vector2DList([ numpy.array([1.,2.]), numpy.array([4.,5.]) ])``
    - Create ``Vector2DList`` with list of lists ``x = Vector2DList([[1.,2.], [4.,5.]])``
    - Append item: ``x.Append([0.,2.])``
    - Convert into list of numpy arrays: ``x.GetPythonObject()``
    - similar to Vector3DList !
    """
    @overload
    def Append(self, pyArray: [float,float]) -> None: 
        """Add single array or list to Vector2DList; array or list must have appropriate dimension!."""
        ...
    @overload
    def GetPythonObject(self) -> List[[float,float]]: 
        """Convert Vector2DList into (copied) list of numpy arrays."""
        ...


class Vector6DList:
    """The Vector6DList is used to represent lists of 6D vectors.

    This is used to transfer such lists from Python to C++.
    
    
    
    Usage:
    - Create empty ``Vector6DList`` with ``x = Vector6DList()``
    - Convert into list of numpy arrays: ``x.GetPythonObject()``
    - similar to Vector3DList !
    """
    @overload
    def Append(self, pyArray: [float,float,float,float,float,float]) -> None: 
        """Add single array or list to Vector6DList; array or list must have appropriate dimension!."""
        ...
    @overload
    def GetPythonObject(self) -> List[[float,float,float,float,float,float]]: 
        """Convert Vector6DList into (copied) list of numpy arrays."""
        ...


class Matrix3DList:
    """The Matrix3DList is used to represent lists of 3D Matrices.

    
    This is used to transfer such lists from Python to C++.
    
    
    
    Usage:
    - Create empty ``Matrix3DList`` with ``x = Matrix3DList()``
    - Create ``Matrix3DList`` with list of numpy arrays:
    
      ``x = Matrix3DList([ numpy.eye(3), numpy.array([[1.,2.,3.],[4.,5.,6.],[7.,8.,9.]]) ])``
    - Create ``Matrix3DList`` with one matrix ``x = Matrix3DList(13.*numpy.eye(3))``
    - Append item: ``x.Append(numpy.eye(3))``
    - Convert into list of numpy arrays: ``x.GetPythonObject()``
    - similar to Vector3DList !
    """
    @overload
    def Append(self, pyArray: NDArray[Shape2D[3,3], float]) -> None: 
        """Add single 3D array or list of lists to Matrix3DList; array or lists must have appropriate dimension!."""
        ...
    @overload
    def GetPythonObject(self) -> List[NDArray[Shape2D[3,3], float]]: 
        """Convert Matrix3DList into (copied) list of 3x3 numpy arrays."""
        ...


class Matrix6DList:
    """The Matrix6DList is used to represent lists of 6D Matrices.

    
    This is used to transfer such lists from Python to C++.
    
    
    
    Usage:
    - Create empty ``Matrix6DList`` with ``x = Matrix6DList()``
    - Create ``Matrix6DList`` with list of numpy arrays:
    
      ``x = Matrix6DList([ numpy.eye(6), 2*numpy.eye(6) ])``
    - Append item: ``x.Append(numpy.eye(6))``
    - Convert into list of numpy arrays: ``x.GetPythonObject()``
    - similar to Matrix3DList !
    """
    @overload
    def Append(self, pyArray: NDArray[Shape2D[6,6], float]) -> None: 
        """Add single 6D array or list of lists to Matrix6DList; array or lists must have appropriate dimension!."""
        ...
    @overload
    def GetPythonObject(self) -> List[NDArray[Shape2D[6,6], float]]: 
        """Convert Matrix6DList into (copied) list of 6x6 numpy arrays."""
        ...


class BeamSection:
    """Data structure for definition of 2D and 3D beam (cross) section mechanical properties. The beam has local coordinates, in which :math:`X` represents the beam centerline (beam axis) coordinate, being the neutral fiber w.r.t. bending; :math:`Y` and :math:`Z` are the local cross section coordinates. Note that most elements do not accept all parameters, which results in an error if those parameters (e.g., stiffness parameters) are non-zero."""
    dampingMatrix: ArrayLike
    r"""[SI:Nsm:math:`^2`, Nsm and Ns (mixed)] sectional linear damping matrix related to :math:`\vp{{}^{c}{\nv}}{{}^{c}{\mv}} = {}^{c}{\Dm} \vp{{}^{c}{\tepsDot}}{{}^{c}{\tkappaDot}}`; note that this damping models is highly simplified and usually, it cannot be derived from material parameters; however, it can be used to adjust model damping to observed damping behavior. Set with list of lists or numpy array."""
    inertia: ArrayLike
    r"""[SI:kg:math:`\,`m:math:`^2`] sectional inertia for shear-deformable beams. Set with list of lists or numpy array."""
    massPerLength: float
    """[SI:kg/m] mass per unit length of the beam."""
    stiffnessMatrix: ArrayLike
    r"""[SI:Nm:math:`^2`, Nm and N (mixed)] sectional stiffness matrix related to :math:`\vp{{}^{c}{\nv}}{{}^{c}{\mv}} = {}^{c}{\Cm} \vp{{}^{c}{\teps}}{{}^{c}{\tkappa}}` with sectional normal force :math:`{}^{c}{\nv}`, torque :math:`{}^{c}{\mv}`, strain :math:`{}^{c}{\teps}` and curvature :math:`{}^{c}{\tkappa}`, all quantities expressed in the cross section frame :math:`c`. Set with list of lists or numpy array."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class BeamSectionGeometry:
    """Data structure for definition of 2D and 3D beam (cross) section geometrical properties. Used for visualization and contact."""
    crossSectionRadiusY: float
    """[SI:m] :math:`Y` radius for circular cross section."""
    crossSectionRadiusZ: float
    """[SI:m] :math:`Z` radius for circular cross section."""
    crossSectionType: CrossSectionType
    """Type of cross section: Polygon, Circular, etc."""
    polygonalPoints: Vector2DList
    """[SI: (m,m) ] list of polygonal (:math:`Y,Z`) points in local beam cross section coordinates, defined in positive rotation direction."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class SolutionFileExportSettings:
    """The quantities written into the coordinates solution file in addition to the coordinates."""
    accelerations: bool
    """add ODE2 accelerations to the solution file."""
    algebraicCoordinates: bool
    """add algebraicCoordinates (=Lagrange multipliers) to the solution file."""
    dataCoordinates: bool
    """add DataCoordinates to the solution file."""
    ODE1Velocities: bool
    """add coordinatesODE1_t to the solution file."""
    velocities: bool
    """add ODE2 velocities to the solution file."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class SolutionFileSettings:
    """The coordinates solution file: all coordinates of the system versus time, read by the SolutionViewer and exudyn.utilities.LoadSolutionFile."""
    export: SolutionFileExportSettings
    """which quantities are written in addition to the coordinates."""
    append: bool
    """flag (true/false); if true, the solution and the solver information are appended to existing files (otherwise created); in BINARY mode, files are always replaced and this parameter is ineffective!"""
    binary: bool
    """if true, the solution file is written in binary format for improved speed and smaller file sizes; setting solution.precision >= 8 uses double (8 bytes), otherwise float (4 bytes) is used; note that append is ineffective and files are always replaced without asking! If not provided, file ending will read .sol in case of binary files and .txt in case of text files."""
    flushAboveCoordinates: int
    """number of coordinates above which the buffers of the solution file are always flushed, irrespectively of solution.flushFilesImmediately; for larger files, writing takes so much time that flushing does not add considerable time."""
    information: str
    """special information added to header of solution file (e.g. parameters and settings, modes, ...); character encoding my be UTF-8, restricted to characters in sec-utf8, but for compatibility, it is recommended to use ASCII characters only (95 characters, see wiki)."""
    name: str
    """filename and (relative) path of the solution file containing all multibody system coordinates versus time; the default is in the directory solution/, like every file a run writes by default, so that nothing is written beside the script; directory will be created if it does not exist; character encoding of string is up to your filesystem, but for compatibility, it is recommended to use letters, numbers and '_' only; filename ending will be added automatically if not provided: .txt in case of text mode and .sol in case of binary solution files (binary=True)."""
    write: bool
    """flag (true/false), which determines if the coordinates are written to the solution file; standard quantities that are written are: solution is written as displacements and coordinatesODE1; for additional quantities, see export."""
    writeFooter: bool
    """flag (true/false); if true, information at end of simulation is written: convergence, total solution time, statistics."""
    writeHeader: bool
    """flag (true/false); if true, file header is written (turn off, e.g. for multiple runs of time integration)."""
    writeInitialValues: bool
    """flag (true/false); if true, initial values are exported for the start time; applies to the solution file and the sensor files; this may not be wanted in the append file mode if the initial values are identical to the final values of a previous computation."""
    writePeriod: float
    """time span (period), determines how often the solution file is written during a simulation; the dynamic solvers write at the multiples of writePeriod and at the end, a time within a step by the state interpolated between its start and its end (#3286): the ODE2 coordinates by the cubic Hermite polynomial of the coordinates and velocities, the velocities by its derivative, the others linear, the data coordinates of the end of the step; 0 writes every step."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class SolutionSensorsSettings:
    """Storing and writing of the sensors."""
    active: bool
    """flag (true/false); if false, no sensor files will be created and no sensor data will be stored; this may be advantageous for benchmarking as well as for special solvers which should not overwrite existing results (e.g. ComputeODE2Eigenvalues); settings this value to False may cause problems if sensors are required to perform operations which are needed e.g. in UserSensors as input of loads, etc."""
    append: bool
    """flag (true/false); if true, sensor output is appended to existing file (otherwise created) or in case of internal storage, it is appended to existing currently stored data; this allows storing sensor values over different simulations."""
    writeFooter: bool
    """flag (true/false); if true, file footer is written for sensor output (turn off, e.g. for multiple runs of time integration)."""
    writeHeader: bool
    """flag (true/false); if true, file header is written for sensor output (turn off, e.g. for multiple runs of time integration)."""
    writePeriod: float
    """time span (period), determines how often the sensor output is written to file or internal storage during a simulation; the dynamic solvers write at the multiples of writePeriod and at the end, a time within a step from the state interpolated as for solution.file.writePeriod (#3286); 0 writes every step."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class SolutionRestartSettings:
    """The restart file of a dynamic simulation: its state - time, coordinates, velocities, accelerations, the algorithmic accelerations of the generalized-alpha method, the step size and the sizes of the output files - written every writePeriod and at the end, from which the same script continues with continueIfAvailable; for a job that is stopped (e.g. by exudyn.special.solver.timeout or on a cluster) and started again unchanged. The model itself, its user functions and their Python state come from the script; the static solver writes no restart file."""
    continueIfAvailable: bool
    """flag (true/false); if true and the restart file exists, a dynamic solver continues from its state instead of starting at startTime: it takes time, state and step size from the file, appends to the solution and sensor files - shortened to what was written up to that state - and writes no initial values; a file that does not fit the system or the solver raises an error; without a file, the simulation starts as usual. Sensors with storeInternal hold only the values after the restart."""
    name: str
    """filename and (relative) path of the restart file."""
    write: bool
    """flag (true/false); if true, the dynamic solvers write the restart file every writePeriod and at the end of the simulation; the file is written to name.tmp and renamed, the previous one kept as name.bck."""
    writePeriod: float
    """time span (period) in which the restart file is updated."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class SolutionSettings:
    """General settings for exporting the solution (results) of a simulation: the solution file, the sensors and the restart file."""
    file: SolutionFileSettings
    """the coordinates solution file."""
    restart: SolutionRestartSettings
    """the restart file."""
    sensors: SolutionSensorsSettings
    """storing and writing of the sensors."""
    flushFilesImmediately: bool
    """flush file buffers after every period written (solution file and sensor files); if set False, the output is written through a buffer, which is highly efficient, but during simulation, files may be always in an incomplete state; if set True, this may add a large amount of CPU time as the process waits until files are really written to hard disc (especially for simulation of small scale systems, writing 10.000s of time steps; at least 5us per step/file, depending on hardware)."""
    precision: int
    """precision for floating point numbers written to the solution and sensor files; the precision of the output to the console is consolePrecision."""
    recordImagesInterval: float
    """record frames of the main view in the renderer (images) during solving: amount of time to wait until next image (frame) is recorded; set recordImages = -1. if no images shall be recorded; set, e.g., recordImages = 0.01 to record an image every 10 milliseconds (requires that the time steps / load steps are sufficiently small!); for file names, etc., see VisualizationSettings.exportImages; note that only the main view (0) can be saved in this way, while for multiple views, you have to aquire data via renderer.RedrawAndGetImage()."""
    solverInformationFileName: str
    """filename and (relative) path of text file showing detailed information during solving; detail level according to yourSolver.verboseModeFile; if file.append is true, the information is appended in every solution step; directory will be created if it does not exist; character encoding of string is up to your filesystem, but for compatibility, it is recommended to use letters, numbers and '_' only."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class SolutionSettingsDeprecated:
    """The settings of the solution as they were named up to Exudyn 1.11: each forwards to its place in simulationSettings.solution, with a DeprecationWarning."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class NumericalDifferentiationSettings:
    """Settings for numerical differentiation of a function (needed for computation of numerical jacobian e.g. in implizit integration)."""
    addReferenceCoordinatesToEpsilon: bool
    """True: for the size estimation of the differentiation parameter, the reference coordinate :math:`q^{Ref}_i` is added to ODE2 coordinates --> see; False: only the current coordinate is used for size estimation of the differentiation parameter."""
    constraintReactionDerivative: bool
    r"""True: the derivative of the reaction forces :math:`\Cm_{\qv}\tp \tlambda` of the constraints, the bodies and the nodes with algebraic equations by the ODE2 coordinates and velocities is added to the Jacobian, by a numerical differentiation of the reaction forces of each item by its own coordinates at the current Lagrange multipliers, serially; False: it is neglected, in the local and in the system-wide Jacobian; it may improve the convergence of stiff constraints with large reaction forces and large rotations, at the cost of evaluating the constraint Jacobians once per coordinate of each constraint (#3201)."""
    doSystemWideDifferentiation: bool
    """True: the whole Jacobian by numerical differentiation - the ODE2, ODE1 and algebraic equations by all coordinates -, for comparison and for dependencies outside the coordinates of the items, such as a user function reading a sensor; slow for larger systems; False: the Jacobian of each object, analytic, by automatic differentiation or numerical by its own coordinates (#3205)."""
    jacobianConnectorDerivative: bool
    """True: for analytic Jacobians of connectors, the Jacobian derivative is computed, causing additional CPU costs and not beeing available for all connectors or markers (thus switching to numerical differentiation); False: Jacobian derivative is neglected in analytic Jacobians (but included in numerical Jacobians), which often has only minor influence on convergence."""
    minimumCoordinateSize: float
    """minimum size of coordinates in relative differentiation parameter."""
    relativeEpsilon: float
    r"""relative differentiation parameter epsilon; the numerical differentiation parameter :math:`\varepsilon` follows from the formula (:math:`\varepsilon = \varepsilon_\mathrm{relative}*max(q_{min}, |q_i + [q^{Ref}_i]|)`, with :math:`\varepsilon_\mathrm{relative}`=relativeEpsilon, :math:`q_{min} = `minimumCoordinateSize, :math:`q_i` is the current coordinate which is differentiated, and :math:`qRef_i` is the reference coordinate of the current coordinate."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class DiscontinuousSettings:
    """Settings for discontinuous iterations, as in contact, friction, plasticity and general switching phenomena."""
    ignoreMaxIterations: bool
    """continue solver if maximum number of discontinuous (post Newton) iterations is reached (ignore tolerance)."""
    iterationTolerance: float
    """absolute tolerance for discontinuous (post Newton) iterations; the errors represent absolute residuals and can be quite high."""
    maxIterations: int
    """maximum number of discontinuous (post Newton) iterations."""
    updateJacobianAfterSwitch: bool
    """if True, the modified Newton method updates the Jacobian for the next discontinuous iteration when an object - a contact, friction, a switching connector - reports that its state switched; False keeps the Jacobian of the previous state, which may need more iterations (#3574)."""
    useRecommendedStepSize: bool
    """some objects (contact-related) provide a recommendedStepSize; if True, this recommendation is used, but may lead to very small step sizes and solver could fail if restrictions are too hard; set to False to ignore this recommendation."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class NewtonSettings:
    """Settings for Newton method used in static or dynamic simulation."""
    numericalDifferentiation: NumericalDifferentiationSettings
    """numerical differentiation parameters for numerical jacobian (e.g. Newton in static solver or implicit time integration)."""
    absoluteTolerance: float
    """absolute tolerance of residual for Newton (needed e.g. if residual is fulfilled right at beginning); condition: sqrt(q*q)/numberOfCoordinates <= absoluteTolerance."""
    active: bool
    """flag (true/false); false = linear computation, true = use Newton solver for nonlinear solution."""
    adaptInitialResidual: bool
    """flag (true/false); false = standard; True: if initialResidual is very small (or zero), it may increase significantely in the first Newton iteration; to achieve relativeTolerance, the initialResidual will by updated by a higher residual within the first Newton iteration."""
    maximumSolutionNorm: float
    """this is the maximum allowed value for solutionU.L2NormSquared() which is the square of the square norm (i.e., value=:math:`u_1^2`+:math:`u_2^2`+...), and solutionV/A...; if the norm of solution vectors is larger, Newton method is stopped; the default value is chosen such that it would still work for single precision numbers (float)."""
    maxIterations: int
    """maximum number of iterations (including modified + restart Newton iterations); after that total number of iterations, the static/dynamic solver refines the step size or stops with an error."""
    maxModifiedNewtonIterations: int
    """maximum number of iterations for modified Newton (without Jacobian update); after that number of iterations, the modified Newton method gets a jacobian update and is further iterated."""
    maxModifiedNewtonRestartIterations: int
    """maximum number of iterations for modified Newton after a Jacobian update; after that number of iterations, the full Newton method is started for this step."""
    modifiedNewtonContractivity: float
    """maximum contractivity (=reduction of error in every Newton iteration) accepted by modified Newton; if contractivity is greater, a Jacobian update is computed."""
    modifiedNewtonJacUpdatePerStep: bool
    """True: compute Jacobian at every time step (or static step), but not in every Newton iteration (except for bad convergence ==> switch to full Newton)."""
    relativeTolerance: float
    """relative tolerance of residual for Newton (general goal of Newton is to decrease the residual by this factor)."""
    residualMode: int
    """0 ... use residual for computation of error (standard); 1 ... use ODE2 and ODE1 newton increment for error (set relTol and absTol to same values!) ==> may be advantageous if residual is zero, e.g., in kinematic analysis; TAKE CARE with this flag."""
    useModifiedNewton: bool
    """True: compute Jacobian only at first call to solver; the Jacobian (and its factorizations) is not computed in each Newton iteration, even not in every (time integration) step; False: Jacobian (and factorization) is computed in every Newton iteration, which may be costly; the default is True for timeIntegration.newton and False for staticSolver.newton."""
    weightTolerancePerCoordinate: bool
    """flag (true/false); false = compute error as L2-Norm of residual; true = compute error as (L2-Norm of residual) / (sqrt(number of coordinates)), which can help to use common tolerance independent of system size."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class GeneralizedAlphaSettings:
    """Settings for generalized-alpha, implicit trapezoidal or Newmark time integration methods."""
    checkConstraintDrift: bool
    """True: every constraintDriftCheckPeriod steps, the solver evaluates the position-level constraints - their drift, which grows with velocity-level (index 2) constraints, useIndex2Constraints and the solver TrapezoidalIndex2; a warning names the item once the drift exceeds 0.001 constraintDriftTolerance, the solver stops with an exception above constraintDriftTolerance, the largest drift is in the output of the solver; SolveDynamic switches it on for the solver TrapezoidalIndex2 (its argument index2CheckConstraints); see sec-solver-constraintdrift (#565)."""
    checkInitialConstraints: bool
    """True: at the start of the time integration, the constraints are evaluated with the initial positions and with the initial velocities; if the largest residual exceeds initialConstraintsTolerance, a warning names the item - inconsistent initial conditions give large constraint forces and oscillations in the first steps; the residuals are in the output of the solver; False: no check and no warning; see sec-solver-initialconstraints (#2234)."""
    computeInitialAccelerations: bool
    """True: compute initial accelerations from system EOM in acceleration form, with the derivatives of the constraints by the time, e.g. of their user functions; False: use zero accelerations."""
    constraintDriftCheckPeriod: int
    """the number of steps between two checks of checkConstraintDrift."""
    constraintDriftTolerance: float
    """the largest drift of the position-level constraints that checkConstraintDrift accepts, in the units of the constraint equations (m for a position, rad for an angle); a warning comes at 0.001 of it."""
    initialConstraintsTolerance: float
    """the tolerance of checkInitialConstraints and projectInitialVelocities, relative to 1 plus the largest initial coordinate (positions) or initial velocity coordinate (velocities)."""
    lieGroupAddTangentOperator: bool
    """True: for Lie group nodes, in case that lieGroupSimplifiedKinematicRelations=True, the integrator adds the tangent operator for stiffness and constraint matrices, for improved Newton convergence; not available for sparse matrix mode (EigenSparse)."""
    lieGroupSimplifiedKinematicRelations: bool
    """True: for Lie group nodes, the integrator uses the original kinematic relations of the Bruls and Cardona 2010 paper; False (recommended): higher accuracy as proposed in paper by Holzinger, Arnold, Gerstmayr, sigma-modified Lie group generalized alpha methods for constrained multibody systems, 2025 (to be sumitted)."""
    newmarkBeta: float
    r"""value beta for Newmark method; default value beta = :math:`\frac 1 4` corresponds to (undamped) trapezoidal rule."""
    newmarkGamma: float
    r"""value gamma for Newmark method; default value gamma = :math:`\frac 1 2` corresponds to (undamped) trapezoidal rule."""
    projectInitialVelocities: bool
    r"""True: initial velocities that do not fulfill the constraints are projected onto them, :math:`\dot \qv_0 \leftarrow \dot \qv_0 + \Delta \dot \qv` with :math:`\Mm \Delta \dot \qv + \Cm_q\tp \tmu = \Null`, :math:`\Cm_q \Delta \dot \qv = -\gv_v`, the change of least kinetic energy that makes the velocity-level constraints :math:`\gv_v` zero; the initial positions are not changed (#2234)."""
    resetAccelerations: bool
    """this flag only affects if computeInitialAccelerations=False: if resetAccelerations=True, accelerations are set zero in the solver function InitializeSolverInitialConditions; this may be unwanted in case of repeatedly called SolveSteps() and in cases where solutions shall be prolonged from previous computations."""
    spectralRadius: float
    """spectral radius for Generalized-alpha solver; set this value to 1 for no damping or to 0 < spectralRadius < 1 for damping of high-frequency dynamics; for position-level constraints (index 3), spectralRadius must be < 1."""
    storeInitialAlgebraicCoordinates: bool
    """True: IF computeInitialAccelerations=True, store initial algebraic coordinates (usually the Lagrange multipliers) in the initial coordinates vector (and thus in the first line of the coordinates solution file); for further details on limitations, see computeInitialAccelerations."""
    useIndex2Constraints: bool
    """set useIndex2Constraints = true in order to use index2 (velocity level constraints) formulation."""
    useNewmark: bool
    """if true, use Newmark method with beta and gamma instead of generalized-Alpha."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class ExplicitIntegrationSettings:
    """Settings for explicit solvers, like Explicit Euler, RK44, ODE23, DOPRI5 and others. The settings may significantely influence performance."""
    computeEndOfStepAccelerations: bool
    """accelerations are computed at stages of the explicit integration scheme; if the user needs accelerations at the end of a step, this flag needs to be activated; if True, this causes a second call to the RHS of the equations, which may DOUBLE COMPUTATIONAL COSTS for one-step-methods; if False, the accelerations are re-used from the last stage, being slightly different."""
    computeMassMatrixInversePerBody: bool
    """If true, the solver assumes the bodies to be independent and computes the inverse of the mass matrix for all bodies independently; this may lead to WRONG RESULTS, if bodies share nodes, e.g., two MassPoint objects put on the same node or a beam with a mass point attached at a shared node; however, it may speed up explicit time integration for large systems significantly (multi-threaded) - together with a sparse solver, linearSolver.solverType = exu.LinearSolverType.EigenSparse: with the dense default the inverse is stored as a dense matrix and every step costs O(n^2) (#2400)."""
    eliminateConstraints: bool
    """True: make explicit solver work for simple CoordinateConstraints, which are eliminated for ground constraints (e.g. fixed nodes in finite element models): the coordinate is set to the value of the constraint equation in every stage and step (#3240). False: incompatible constraints are ignored (BE CAREFUL)!"""
    useLieGroupIntegration: bool
    """True: use Lie group integration for rigid body nodes; must be turned on for Lie group nodes (without data coordinates) to work properly; does not work for nodes with data coordinates!"""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class ExplicitIntegrationSettingsDeprecated:
    """The settings of the explicit solvers as they were named up to Exudyn 1.11: each forwards to its place in simulationSettings.timeIntegration, with a DeprecationWarning."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class RealtimeSettings:
    """Simulation in realtime: the time integration waits until the CPU time has reached the simulation time."""
    active: bool
    """True: simulate in realtime; the solver waits for computation of the next step until the CPU time reached the simulation time; if the simulation is slower than realtime, it simply continues."""
    factor: float
    """if active=True, this factor is used to make the simulation slower than realtime (factor < 1) or faster than realtime (factor > 1)."""
    waitMicroseconds: int
    """if active=True, a loop runs which waits waitMicroseconds until checking again if the realtime is reached; using larger values leads to less CPU usage but less accurate realtime accuracy; smaller values (< 1000) increase CPU usage but improve realtime accuracy."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class TimeIntegrationSettings:
    """General parameters used in time integration; specific parameters are provided in the according solver settings, e.g. for generalizedAlpha."""
    discontinuous: DiscontinuousSettings
    """parameters for treatment of discontinuities."""
    explicit: ExplicitIntegrationSettings
    """special parameters for explicit time integration."""
    generalizedAlpha: GeneralizedAlphaSettings
    """parameters for generalized-alpha, implicit trapezoidal rule or Newmark (options only apply for these methods)."""
    newton: NewtonSettings
    """parameters for Newton method; used for implicit time integration methods only; the modified Newton method is the default here."""
    realtime: RealtimeSettings
    """simulation in realtime."""
    absoluteTolerance: float
    """: if automaticStepSize=True, absolute tolerance for the error control; must fulfill :math:`a_{tol} > 0`; see sec-explicitsolver."""
    adaptiveStep: bool
    """True: the step size may be reduced if step fails; no automatic stepsize control."""
    adaptiveStepDecrease: float
    """Multiplicative factor (MUST BE: 0 < factor < 1) for step size to decrese due to discontinuousIteration or Newton errors."""
    adaptiveStepIncrease: float
    """Multiplicative factor (MUST BE > 1) for step size to increase after previous step reduction due to discontinuousIteration or Newton errors."""
    adaptiveStepRecoveryIterations: int
    """Number of max. (Newton iterations + discontinuous iterations) at which a step increase is considered; in order to immediately increase steps after reduction, chose a high value."""
    adaptiveStepRecoverySteps: int
    """Number of steps needed after which steps will be increased after previous step reduction due to discontinuousIteration or Newton errors."""
    automaticStepSize: bool
    r"""True: for specific integrators with error control (e.g., DOPRI5), compute automatic step size based on error estimation; False: constant step size (step may be reduced if adaptiveStep=True); the maximum stepSize reads :math:`h = h_{max} = \frac{t_{end} - t_{start}}{n_{steps}}`."""
    computeLoadsJacobian: int
    """0:  jacobian of loads not considered (may lead to slow convergence or Newton failure); 1: in case of implicit integrators, compute (numerical) Jacobian of ODE2 and ODE1 coordinates for loads, causing additional computational costs; this is advantageous in cases where loads are related nonlinearly to coordinates; 2: also compute ODE2_t dependencies for jacobian; note that computeLoadsJacobian has no effect in case of doSystemWideDifferentiation, as this anyway includes all load dependencies."""
    endTime: float
    """: end time of time integration."""
    errorEstimate: str
    """the error estimate of the automatic step size of the implicit Runge-Kutta solvers (TrapezoidalGGL, LobattoIIIA4, LobattoIIIC4GGL, Radau3, Radau5): 'oneStep', against the trapezoidal rule of the first and the last stage, of order 3; 'twoSteps', the quadrature of the method against the polynomial through the stage velocities of the previous and this step, of the order of the method; 'default', twoSteps for the Runge-Kutta methods and oneStep for TrapezoidalGGL (#3287); the argument errorEstimate of the solvers of exudyn.symbolics.advancedSolvers."""
    initialStepSize: float
    """: if automaticStepSize=True, initial step size; if initialStepSize==0, max. stepSize, which is (endTime-startTime)/numberOfSteps, is used as initial guess; a good choice of initialStepSize may help the solver to start up faster."""
    minimumStepSize: float
    """: if automaticStepSize=True or adaptiveStep=True: lower limit of time step size, before integrator stops with adaptiveStep; lower limit of automaticStepSize control (continues but raises warning)."""
    numberOfSteps: float
    r""": number of steps in time integration; (maximum) stepSize :math:`h` is computed from :math:`h = \frac{t_{end} - t_{start}}{n_{steps}}`; for automatic stepsize control, this stepSize is the maximum steps size, :math:`h_{max} = h`; numberOfSteps can also be a float type, but must be close to an integer (relative tolerance :math:`100\cdot\varepsilon`) as it is silently rounded to int."""
    relativeTolerance: float
    r""": if automaticStepSize=True, relative tolerance for the error control; must fulfill :math:`r_{tol} \ge 0`; see sec-explicitsolver."""
    reuseConstantMassMatrix: bool
    """True: does not recompute constant mass matrices (e.g. of some finite elements, mass points, etc.); if False, it always recomputes the mass matrix (e.g. needed, if user changes mass parameters via Python)."""
    solverType: DynamicSolverType
    """the solver of mbs.SolveDynamic(...): an implicit one (GeneralizedAlpha, TrapezoidalIndex2, ...) or an explicit one (DOPRI5, ExplicitEuler, RK44, ...), see DynamicSolverType, sec-dynamicsolvertype; the argument solverType of mbs.SolveDynamic, if given, takes its place for that run."""
    startTime: float
    """: start time of time integration (usually set to zero)."""
    stepInformation: int
    """add up the following binary flags: 0 ... show only step time, 1 ... show time to go, 2 ... show newton iterations (Nit) per step or period, 4 ... show Newton jacobians (jac) per step or period, 8 ... show discontinuous iterations (Dit) per step or period, 16 ... show step size (dt), 32 ... show CPU time spent; 64 ... show adaptive step reduction warnings; 128 ... show step increase information; 1024 ... show every time step; time is usually shown in fractions of seconds (s), hours (h), or days."""
    stepSizeMaxIncrease: float
    """: if automaticStepSize=True, maximum increase of step size per step, see sec-explicitsolver; make this factor smaller (but :math:`> 1`) if too many rejected steps."""
    stepSizeSafety: float
    """: if automaticStepSize=True, a safety factor added to estimated optimal step size, in order to prevent from many rejected steps, see sec-explicitsolver. Make this factor smaller if many steps are rejected."""
    verboseMode: int
    """0 ... no output, 1 ... show short step information every 2 seconds (every 30 seconds after 1 hour CPU time), 2 ... show every step information, 3 ... show also solution vector, 4 ... show also mass matrix and jacobian (implicit methods), 5 ... show also Jacobian inverse (implicit methods)."""
    verboseModeFile: int
    """same behaviour as verboseMode, but outputs all solver information to file."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class StaticSolverSettings:
    """Settings for static solver linear or nonlinear (Newton)."""
    discontinuous: DiscontinuousSettings
    """parameters for treatment of discontinuities."""
    newton: NewtonSettings
    """parameters for Newton method (e.g. in static solver or time integration)."""
    adaptiveStep: bool
    """True: use step reduction if step fails; False: fixed step size."""
    adaptiveStepDecrease: float
    """Multiplicative factor (MUST BE: 0 < factor < 1) for step size to decrese due to discontinuousIteration or Newton errors."""
    adaptiveStepIncrease: float
    """Multiplicative factor (MUST BE > 1) for step size to increase after previous step reduction due to discontinuousIteration or Newton errors."""
    adaptiveStepRecoveryIterations: int
    """Number of max. (Newton iterations + discontinuous iterations) at which a step increase is considered; in order to immediately increase steps after reduction, chose a high value."""
    adaptiveStepRecoverySteps: int
    """Number of steps needed after which steps will be increased after previous step reduction due to discontinuousIteration or Newton errors."""
    computeLoadsJacobian: bool
    """True: compute (currently numerical) Jacobian for loads, causing additional computational costs; this is advantageous in cases where loads are related nonlinearly to coordinates; False: jacobian of loads not considered (may lead to slow convergence or Newton failure); note that computeLoadsJacobian has no effect in case of doSystemWideDifferentiation, as this anyway includes all load dependencies."""
    constrainODE1Coordinates: bool
    """True: ODE1coordinates are constrained to initial values; False: undefined behavior, currently not supported."""
    loadStepDuration: float
    """quasi-time for all load steps (added to current time in load steps)."""
    loadStepGeometric: bool
    """if loadStepGeometric=false, the load steps are incremental (arithmetic series, e.g. 0.1,0.2,0.3,...); if true, the load steps are increased in a geometric series, e.g. for :math:`n=8` numberOfLoadSteps and :math:`d = 1000` loadStepGeometricRange, it follows: :math:`1000^{1/8}/1000=0.00237`, :math:`1000^{2/8}/1000=0.00562`, :math:`1000^{3/8}/1000=0.0133`, ..., :math:`1000^{7/8}/1000=0.422`, :math:`1000^{8/8}/1000=1`."""
    loadStepGeometricRange: float
    """if loadStepGeometric=true, the load steps are increased in a geometric series, see loadStepGeometric."""
    loadStepStart: float
    """a quasi time, which can be used for the output (first column) as well as for time-dependent forces; quasi-time is increased in every step i by loadStepDuration/numberOfLoadSteps; loadStepTime = loadStepStart + i*loadStepDuration/numberOfLoadSteps, but loadStepStart untouched ==> increment by user."""
    minimumStepSize: float
    """lower limit of step size, before nonlinear solver stops."""
    numberOfLoadSteps: int
    """number of load steps; if numberOfLoadSteps=1, no load steps are used and full forces are applied at once."""
    stabilizerODE2term: float
    """add mass-proportional stabilizer term in ODE2 part of jacobian for stabilization (scaled ), e.g. of badly conditioned problems; the diagnoal terms are scaled with :math:`stabilizer = (1-loadStepFactor^2)`, and go to zero at the end of all load steps: :math:`loadStepFactor=1` -> :math:`stabilizer = 0`."""
    stepInformation: int
    """add up the following binary flags: 0 ... show only step time, 1 ... show time to go, 2 ... show newton iterations (Nit) per step or period, 4 ... show Newton jacobians (jac) per step or period, 8 ... show discontinuous iterations (Dit) per step or period, 16 ... show step size (dt), 32 ... show CPU time spent; 64 ... show adaptive step reduction warnings; 128 ... show step increase information; 1024 ... show every time step; time is usually shown in fractions of seconds (s), hours (h), or days."""
    useLoadFactor: bool
    r"""True: compute a load factor :math:`\in [0,1]` from static step time; all loads are scaled by the load factor; False: loads are always scaled with 1 -- use this option if time dependent loads use a userFunction."""
    verboseMode: int
    """0 ... no output, 1 ... show errors and load steps, 2 ... show short Newton step information (error), 3 ... show also solution vector, 4 ... show also jacobian, 5 ... show also Jacobian inverse."""
    verboseModeFile: int
    """same behaviour as verboseMode, but outputs all solver information to file."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class LinearSolverSettings:
    """Settings for linear solver, both dense and sparse (Eigen)."""
    dropThreshold: float
    """[ONLY for the sparse solvers] relative threshold for the entries of the Newton Jacobian: an entry whose magnitude is at most dropThreshold times the smaller of the largest magnitudes in its row and in its column is left out before the factorization; such entries are round-off of rotations and of numerical derivatives and cost fill-in; the solution is not changed, as the residual is computed exactly, only the convergence of the Newton iteration can be; 0: only exact zeros are left out."""
    ignoreSingularJacobian: bool
    """[ONLY implemented for dense, Eigen matrix mode] False: standard way, fails if jacobian is singular; True: use Eigen's FullPivLU (thus only works with LinearSolverType.EigenDense) which handles over- and underdetermined systems; can often resolve redundant constraints, but MAY ALSO LEAD TO ERRONEOUS RESULTS!"""
    pivotThreshold: float
    """[ONLY available for EXUdense and EigenDense (FullPivot) solver] threshold for dense linear solver, can be used to detect close to singular solutions, setting this to, e.g., 1e-12; solver then reports on equations that are causing close to singularity."""
    reuseAnalyzedPattern: bool
    """[ONLY available for sparse matrices] True: the Eigen SparseLU solver offers the possibility to reuse an analyzed pattern of a previous factorization; this may reduce total factorization time by a factor of 2 or 3, depending on the matrix type; however, if the matrix patterns heavily change between computations, this may even slow down performance; this flag is set for SparseMatrices in InitializeSolverData(...) and should be handled with care!"""
    showCausingItems: bool
    """False: no output, if solver fails; True: if redundant equations appear, they are resolved such that according solution variables are set to zero; in case of redundant constraints, this may help, but it may lead to erroneous behaviour; for static problems, this may suppress static motion or resolve problems in case of instabilities, but should in general be considered with care!"""
    solverType: LinearSolverType
    """selection of numerical linear solver: exu.LinearSolverType.EXUdense (dense matrix inverse), exu.LinearSolverType.EigenSparse (sparse matrix LU-factorization), ... (enumeration type)."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class LinearSolverSettingsDeprecated:
    """The settings of the linear solver as they were named up to Exudyn 1.11: each forwards to its place in simulationSettings.linearSolver, with a DeprecationWarning."""


class Parallel:
    """Settings for linear solver, both dense and sparse (Eigen)."""
    multithreadedLowerLimitJacobians: int
    """compute jacobians (ODE2, AE, ...) multi-threaded; this is the limit number of according objects from which on parallelization is used; flag is copied into MainSystem internal flag at InitializeSolverData(...)."""
    multithreadedLowerLimitLoads: int
    """compute loads multi-threaded; this is the limit number of loads from which on parallelization is used; flag is copied into MainSystem internal flag at InitializeSolverData(...)."""
    multithreadedLowerLimitMassMatrices: int
    """compute bodies mass matrices multi-threaded; this is the limit number of bodies from which on parallelization is used; flag is copied into MainSystem internal flag at InitializeSolverData(...)."""
    multithreadedLowerLimitResiduals: int
    """compute RHS vectors, AE, and reaction forces multi-threaded; this is the limit number of objects from which on parallelization is used; with fewer items in every list, the solver runs serially; 10 objects such as 5 rigid bodies with 5 connectors already pay on 4 threads (#3494); flag is copied into MainSystem internal flag at InitializeSolverData(...)."""
    numberOfThreads: int
    """number of threads used for parallel computation (1 == scalar processing); do not use more threads than available threads (in most cases it is good to restrict to the number of cores); currently, only one solver can be started with multithreading; if you use several mbs in parallel (co-simulation), you should use serial computing."""
    taskSplitMinItems: int
    """number of items from which on the tasks are split into subtasks (which slightly increases threading performance; this may be critical for smaller number of objects, should be roughly between 50 and 5000; flag is copied into MainSystem internal flag at InitializeSolverData(...)."""
    taskSplitTasksPerThread: int
    """this is the number of subtasks that every thread receives; minimum is 1, the maximum should not be larger than 100; this factor is 1 as long as the taskSplitMinItems is not reached; flag is copied into MainSystem internal flag at InitializeSolverData(...)."""
    useLoadBalancing: bool
    """if True, parallel computation uses load balancing, which may give better performance in case of non-equilibrated loads; (mobile) Intel CPUs may perform better without load balancing; this flag is coupled to exudyn.special.solver.multiThreadingLoadBalancing (overwritten when solver starts with multithreading)."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class ShowSettings:
    """What the solvers show in the console at the end of solving."""
    computationTime: bool
    """display computation time statistics at end of solving."""
    globalTimers: bool
    """display global timer statistics at end of solving (e.g., for contact, but also for internal timings during development)."""
    statistics: bool
    """display general computation information at end of time step (steps, iterations, function calls, step rejections, ..."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class SimulationSettings:
    """General Settings for simulation; according settings for solution and solvers are given in subitems of this structure."""
    linearSolver: LinearSolverSettings
    """linear solver parameters (used for dense and sparse solvers)."""
    parallel: Parallel
    """parameters for vectorized and parallelized (multi-threaded) computations."""
    show: ShowSettings
    """what the solvers show in the console at the end of solving."""
    solution: SolutionSettings
    """settings for solution files."""
    staticSolver: StaticSolverSettings
    """static solver parameters."""
    timeIntegration: TimeIntegrationSettings
    """time integration parameters."""
    cleanUpMemory: bool
    """True: solvers will free memory at exit (recommended for large systems); False: keep allocated memory for repeated computations to increase performance."""
    consolePrecision: int
    """precision for floating point numbers written to the console, e.g. the values written by the solver; the precision of the solution and sensor files is solution.precision."""
    pauseAfterEachStep: bool
    """pause after every time step or static load step(user press SPACE)."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsGeneral:
    """General settings for visualization that influence all windows, default values, autofit, multithreading, etc."""
    autoFitScene: bool
    """automatically fit scene within startup after SC.renderer.Start()."""
    axesTiling: int
    """global number of segments for drawing cylinders for axes and cones for arrows (reduce this number, e.g. to 4, if many axes are drawn)."""
    backgroundColor: Tuple[float,float,float,float]
    """red, green, blue and alpha values for background color of render window (white=[1,1,1,1]; black = [0,0,0,1])."""
    backgroundColorBottom: Tuple[float,float,float,float]
    """red, green, blue and alpha values for bottom background color in case that useGradientBackground = True."""
    boundingBoxZoomAllFactor: float
    """factor on boundingBox for zoom all (without minimum offset)."""
    boundingBoxZoomAllOffset: float
    """minimum offset to bounding box of scene in window - width or height, whatever is smaller, a length; usually boundingBoxZoomAllFactor decides; adjust for very small scenes, see sec-renderer-modelsize; may be negative."""
    circleTiling: int
    """global number of segments for circles; if smaller than 2, 2 segments are used (flat); the circles of the 2D cable contacts (ObjectContactCircleCable2D, ObjectContactFrictionCircleCable2D), large compared to the cable, take 4 times as many."""
    coordinateSystemSize: float
    """size of coordinate system relative to font size."""
    cylinderTiling: int
    """global number of segments for cylinders; if smaller than 2, 2 segments are used (flat); also around the rope of a reeving system and the wire of a spring drawn as a tube; the disc of ObjectJointRollingDisc and ObjectConnectorRollingDiscPenalty, large compared to the joint, takes 4 times as many; space curves use connectors.curveTiling."""
    displayScaleFactor: float
    """factor on the texts of the render window, multiplied with the display scaling of the system (monitor scaling, e.g. 150 percent on Windows, fractional scaling on Linux), which GLFW reads (glfwGetWindowContentScale; on Linux from GLFW 3.3.6 on) and follows when it changes; acts while the renderer runs; the dialogs are scaled with dialogs.fontScaling."""
    graphicsUpdateInterval: float
    """interval of graphics update during simulation in seconds; 0.1 = 10 frames per second; low numbers might slow down computation speed."""
    iconBarAndControlsInImages: bool
    """True: the icon bar, as far as it is shown, and the buttons and sliders of the render window (SC.renderer.AddButton, AddSlider) are in the saved images and in RedrawAndGetImage; False: only on the screen; the scopes have their own switch, window.showScopes (#3400)."""
    iconBarFoldDistance: float
    """distance from the right border of the render window in pixels, at the display scaling, at which the icon bar folds in (#3026)."""
    iconBarScaling: float
    """size of the icons of the icon bar relative to 54 pixels at the display scaling (monitor scaling times displayScaleFactor); the icons are made smaller where the window is not high enough for all of them; see view0.window.showIconBar (#3026)."""
    iconBarStartTime: int
    """time in milliseconds the icon bar is shown when the render window opens, so that it is seen where it is; 0: it folds in only at the mouse; it is not part of saved or raytraced images unless iconBarAndControlsInImages is True (#3396)."""
    iconBarTimeout: int
    """time in milliseconds the icon bar stays after the mouse left it, before it folds out (#3026)."""
    limitWindowToScreenSize: bool
    """True: size for render window of respective view is limited to screen size; False: larger window sizes (e.g. for rendering) allowed according to renderWindowSize."""
    minSceneSize: float
    """minimum scene size for initial scene size and for autoFitScene: a scene of points (drawn in pixels) and texts has no size; reduce it for models smaller than it, see sec-renderer-modelsize; SET GREATER THAN ZERO."""
    pointSize: float
    """global point size (absolute)."""
    reallyQuitTimeLimit: float
    """number of seconds after which user is asked a security question before stopping simulation and closing renderer; set to 0 in order to always get asked; set to 1e10 to (nearly) never get asked."""
    rendererPrecision: int
    """precision of general floating point numbers shown in render window: total number of digits used  (max. 16)."""
    rendererStartupTimeout: int
    """OpenGL render windows startup timeout in ms (change might be necessary if CPU is very slow)."""
    renderWindowString: str
    """string shown in render window (use this, e.g., for debugging, etc.; written below EXUDYN, similar to information in simulationSettings.solution.file)."""
    showHelpOnStartup: int
    """seconds to show help message on startup (0=deactivate)."""
    showSolutionInformation: bool
    """true = show solution information (from simulationSettings.solution)."""
    showSolverInformation: bool
    """true = solver name and further information shown in render window."""
    showSolverTime: bool
    """true = solver current time shown in render window."""
    sphereTiling: int
    """global number of segments of a half circle for the spheres of connectors and joints and for graphics.Sphere and graphics.Spheres with nTiles=-1 (the default); used as power of 2 (rounded down), as the spheres are drawn from display lists; if smaller than 2, 2 segments are used."""
    textAlwaysInFront: bool
    """if true, text for item numbers and other item-related text is drawn in front; this may be unwanted in case that you only with to see numbers of objects in front; currently does not work with perspective."""
    textColor: Tuple[float,float,float,float]
    """general text color (default); used for system texts in render window."""
    textHasBackground: bool
    """if true, text for item numbers and other item-related text have a background (depending on text color), allowing for better visibility if many numbers are shown; the text itself is black; therefore, dark background colors are ignored and shown as white."""
    textOffsetFactor: float
    """This is an additional out of plane offset for item texts (node number, etc.); the factor is relative to the maximum scene size and is only used, if textAlwaysInFront=False; this factor allows to draw text, e.g., in front of nodes."""
    threadSafeGraphicsUpdate: bool
    """true = updating of visualization is threadsafe, but slower for complicated models; deactivate this to speed up computation, but activate for generation of animations; may be improved in future by adding a safe visualizationUpdate state."""
    useBitmapText: bool
    """if true, texts are displayed using pre-defined bitmaps for the text; may increase the complexity of your scene, e.g., if many (>10000) node numbers shown."""
    useGradientBackground: bool
    """true = use vertical gradient for background;."""
    useMultiThreadedRendering: bool
    """true = rendering is done in separate thread; false = no separate thread, which may be more stable but has lagging interaction for large models (do not interact with models during simulation); you MUST set this parameter BEFORE call to SC.renderer.Start(); MAC OS: uses always false, because MAC OS does not support multi threaded GLFW."""
    zoomAllUseBoundingBox: bool
    """if true, use exact scene bounding box (but not including texts) for zoom; does not include perspective effects!"""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsContourAdvanced:
    """Advanced settings for contour plots."""
    colorBarPrecision: int
    """precision of floating point values shown in color bar; total number of digits used (max. 16)."""
    colorBarTiling: int
    """number of tiles (segements) shown in the colorbar for the contour plot."""
    contourColor0: Tuple[float,float,float,float]
    """RGBA color for relative value 0 used for contour plot; alpha is ignored."""
    contourColor1: Tuple[float,float,float,float]
    """RGBA color for relative value 0.25 used for contour plot; alpha is ignored."""
    contourColor2: Tuple[float,float,float,float]
    """RGBA color for relative value 0.5 used for contour plot; alpha is ignored."""
    contourColor3: Tuple[float,float,float,float]
    """RGBA color for relative value 0.75 used for contour plot; alpha is ignored."""
    contourColor4: Tuple[float,float,float,float]
    """RGBA color for relative value 1 used for contour plot; alpha is ignored."""
    contourColorMax: Tuple[float,float,float,float]
    """RGBA color if relative value in contour plot is larger than 1 (if automaticRange=False); alpha is ignored."""
    contourColorMin: Tuple[float,float,float,float]
    """RGBA color if relative value in contour plot is smaller than 0 (if automaticRange=False); alpha is ignored."""
    minimumRelativeRange: float
    """with automaticRange, a range (max-min) smaller than minimumRelativeRange times the larger of |min| and |max| is widened symmetrically to that size, which avoids color artifacts of a nearly constant field; not applied if that magnitude is below minimumRelativeRange squared; 0 switches it off."""
    showColorBar: bool
    """show the colour bar with minimum and maximum values for the contour plot."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsContour:
    """Settings for contour plots; use these options to visualize field data, such as displacements, stresses, strains, etc. for bodies, nodes and finite elements. The value is computed at the vertices of the drawn triangles and lines and normalized to the range; between the vertices the raytracer interpolates the value and takes its color from the color bar (contourColor0 to contourColor4), while OpenGL interpolates the colors of the vertices, which differs from the color bar where the value of a triangle spans more than a quarter of the range (#3539)."""
    advanced: VSettingsContourAdvanced
    """advanced settings for contour."""
    alphaTransparency: float
    """default value for contour alpha transparency (RGB color computed from contour value)."""
    automaticRange: bool
    """if true, the contour plot value range is chosen automatically to the maximum range."""
    maxValue: float
    """maximum value for contour plot; set manually, if automaticRange == False."""
    minValue: float
    """minimum value for contour plot; set manually, if automaticRange == False."""
    nodesColored: bool
    """if true, the contour color is also applied to nodes (except mesh nodes), otherwise node drawing is not influenced by contour settings."""
    outputVariable: OutputVariableType
    """selected contour plot output variable type; select OutputVariableType._None to deactivate contour plotting."""
    outputVariableComponent: int
    """select the component of the chosen output variable; e.g., for displacements, 3 components are available: 0 == x, 1 == y, 2 == z component; for stresses, 6 components are available, see OutputVariableType description; to draw the norm of a outputVariable, set component to -1; if a certain component is not available by certain objects or nodes, no value is drawn (using default color)."""
    reduceRange: bool
    """if true, the contour plot value range is also reduced; better for static computation; in dynamic computation set this option to false, it can reduce visualization artifacts; you should also set minVal to max(float) and maxVal to min(float)."""
    rigidBodiesColored: bool
    """if true, the contour color is also applied to triangular faces of rigid bodies and mass points, otherwise the rigid body drawing are not influenced by contour settings; for general rigid bodies (except for ObjectGround), Position, Displacement, DisplacementLocal(=0), Velocity, VelocityLocal, AngularVelocity, and AngularVelocityLocal are available; may slow down visualization!"""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsNodes:
    """Visualization settings for nodes."""
    basisSize: float
    """size of basis for nodes."""
    defaultColor: Tuple[float,float,float,float]
    """default RGBA color for nodes; 4th value is alpha-transparency."""
    defaultSize: float
    """global node size; if -1.f, node size is relative to openGL.initialMaxSceneSize."""
    drawNodesAsPoint: bool
    """simplified/faster drawing of nodes; uses general->pointSize as drawing size; if drawNodesAsPoint==True, the basis of the node will be drawn with lines."""
    show: bool
    """flag to decide, whether the nodes are shown."""
    showBasis: bool
    """show basis (three axes) of coordinate system in 3D nodes."""
    showNodalSlopes: bool
    """draw nodal slope vectors, e.g. in ANCF beam finite elements."""
    showNumbers: bool
    """flag to decide, whether the node number is shown."""
    tiling: int
    """tiling for node if drawn as sphere; used to lower the amount of triangles to draw each node; if drawn as circle, this value is multiplied with 4."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsBeams:
    """Visualization settings for beam finite elements."""
    axialTiling: int
    """number of segments to discretise the beams axis."""
    crossSectionFilled: bool
    """if implemented for element, cross section is drawn as solid (filled) instead of wire-frame; NOTE: some quantities may not be interpolated correctly over cross section in visualization; equivalent to drawSolid of shells."""
    crossSectionTiling: int
    """number of quads drawn over height of beam, if drawn as flat objects; leads to higher accuracy of components drawn over beam height or with, but also to larger CPU costs for drawing."""
    drawVertical: bool
    """draw contour plot outputVariables 'vertical' along beam height; contour.outputVariable must be set accordingly."""
    drawVerticalColor: Tuple[float,float,float,float]
    """color for outputVariable to be drawn along cross section (vertically)."""
    drawVerticalFactor: float
    """factor for outputVariable to be drawn along cross section (vertically)."""
    drawVerticalLines: bool
    """draw additional vertical lines for better visibility."""
    drawVerticalOffset: float
    """offset for vertical drawn lines; offset is added before multiplication with drawVerticalFactor."""
    drawVerticalValues: bool
    """show values at vertical lines; note that these numbers are interpolated values and may be different from values evaluated directly at this point!"""
    reducedAxialInterploation: bool
    """if True, the interpolation along the beam axis may be lower than the beam element order; this may, however, show more consistent values than a full interpolation, e.g. for strains or forces."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsShells:
    """Visualization settings for plate/shell finite elements."""
    contourZeta: float
    """thickness coordinate in [-1,1] at which the contour is evaluated: the top surface (and the mid surface without drawSolid) at +|contourZeta|, the bottom surface at -|contourZeta|; 0 is the mid surface, 1 the outer fibre."""
    drawNormal: bool
    """if True, the contour value is drawn along the normal of the mid surface, n = r_x x r_y normalized, as lines: an envelope through the points p + drawNormalFactor * value * n, positive values on the side of the normal; contour.outputVariable must be set."""
    drawNormalColor: Tuple[float,float,float,float]
    """color of the lines drawn with drawNormal."""
    drawNormalFactor: float
    """factor of the contour value drawn along the normal with drawNormal."""
    drawNormalLines: bool
    """with drawNormal, also draw the lines from the mid surface to the envelope."""
    drawSolid: bool
    """if true: to draw plates/shells as 3D objects; false: only the element surface is drawn; equivalent to crossSectionFilled in beams."""
    inPlaneTiling: int
    """number of segments along each local direction of an element, which is drawn as inPlaneTiling x inPlaneTiling quads (at least 2), for its shape and for the points at which the contour is evaluated."""
    reducedInterpolation: bool
    """if True, the contour of the strain-type outputs StrainLocal, StressLocal, CurvatureLocal, ForceLocal and TorqueLocal is interpolated bilinearly from the values at the four corners of each element, as beams.reducedAxialInterploation does along a beam; if False, it is evaluated at each point of the drawing."""
    thicknessFactor: float
    """a factor multiplied with the thickness of shells/plates only for visualization (e.g. to make some effects more visible)."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsKinematicTree:
    """Visualization settings for kinematic trees."""
    frameSize: float
    """size of COM and joint frames."""
    showCOMframes: bool
    """if True, a frame is attached to every center of mass."""
    showFramesNumbers: bool
    """if True, numbers are drawn for joint frames (O[i]J[j]) and COM frames (O[i]COM[j]) for object [i] and local joint [j]."""
    showJointFrames: bool
    """if True, a frame is attached to the origin of every joint frame."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsBodies:
    """Visualization settings for bodies."""
    beams: VSettingsBeams
    """visualization settings for beams (e.g. ANCFCable or other beam elements)."""
    kinematicTree: VSettingsKinematicTree
    """visualization settings for kinematic tree."""
    shells: VSettingsShells
    """visualization settings for plates and shells."""
    defaultColor: Tuple[float,float,float,float]
    """default RGBA color for bodies; 4th value is alpha-transparency."""
    defaultSize: Tuple[float,float,float]
    """global body size of xyz-cube."""
    deformationScaleFactor: float
    """global deformation scale factor for the drawing of superelements (FFRF, FFRFreducedOrder, GenericODE2 with a mesh): their mesh nodes and the markers on them are drawn with the local deformation scaled by it (#1813)."""
    show: bool
    """flag to decide, whether the bodies are shown."""
    showNumbers: bool
    """flag to decide, whether the body(=object) number is shown."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsConnectors:
    """Visualization settings for connectors."""
    contactPointsDefaultSize: float
    """DEPRECATED: do not use! global contact points size; if -1.f, connector size is relative to maxSceneSize."""
    curveTiling: int
    """number of segments of a full turn of a space curve drawn by a connector: a winding of a spring, the arc of a rope on a sheave (ObjectConnectorReevingSystemSprings); an arc gets the share of its angle, at least one segment; circles and cylinders take the tilings of general."""
    defaultColor: Tuple[float,float,float,float]
    """default RGBA color for connectors; 4th value is alpha-transparency."""
    defaultSize: float
    """global connector size; if -1.f, connector size is relative to maxSceneSize."""
    drawSimplified: bool
    """draw connectors with lines: the windings of springs, ObjectConnectorDistance; False draws the windings as a tube with a tenth of the spring radius and the distance connector as a rod of its drawSize."""
    jointAxesLength: float
    """global joint axes length."""
    jointAxesRadius: float
    """global joint axes radius."""
    show: bool
    """flag to decide, whether the connectors are shown."""
    showContact: bool
    """flag to decide, whether contact points, lines, etc. are shown for special cable-circle contacts; for spheres, triangles, tori, see visualizationSettings.contact."""
    showJointAxes: bool
    """flag to decide, whether contact joint axes of 3D joints are shown."""
    showNumbers: bool
    """flag to decide, whether the connector(=object) number is shown."""
    springNumberOfWindings: int
    """number of windings for springs drawn as helical spring."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsMarkers:
    """Visualization settings for markers."""
    basisSize: float
    """size of the frame of the markers."""
    defaultColor: Tuple[float,float,float,float]
    """default RGBA color for markers; 4th value is alpha-transparency."""
    defaultSize: float
    """global marker size; if -1.f, marker size is relative to maxSceneSize."""
    drawSimplified: bool
    """draw markers with simplified symbols."""
    show: bool
    """flag to decide, whether the markers are shown."""
    showBasis: bool
    """show the frame (three axes) of the markers with position and orientation; with drawSimplified as three lines in red, green and blue, else as three arrows, whose heads are half as long as those of a node basis."""
    showNumbers: bool
    """flag to decide, whether the marker numbers are shown."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsLoads:
    """Visualization settings for loads."""
    defaultColor: Tuple[float,float,float,float]
    """default RGBA color for loads; 4th value is alpha-transparency."""
    defaultRadius: float
    """global radius of load axis if drawn in 3D."""
    defaultSize: float
    """global load size; if -1.f, load size is relative to maxSceneSize."""
    drawSimplified: bool
    """draw loads with simplified symbols."""
    drawWithUserFunction: bool
    """draw loads with the value of their user function, time dependent; make sure that fixedLoadSize=false, while otherwise only the direction will change; a load with a user function is drawn in the main thread for it, as the render thread cannot call Python (#3003)."""
    fixedLoadSize: bool
    """if true, the load is drawn with a fixed vector length in direction of the load vector, independently of the load size."""
    loadSizeFactor: float
    """if fixedLoadSize=false, then this scaling factor is used to draw the load vector."""
    show: bool
    """flag to decide, whether the loads are shown."""
    showNumbers: bool
    """flag to decide, whether the load numbers are shown."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsTraces:
    """Visualization settings for traces of sensors. Note that a large number of time points (influenced by simulationSettings.solution.sensors.writePeriod) may lead to slow graphics."""
    lineWidth: float
    """line width for traces."""
    listOfPositionSensors: List[int]
    """list of position sensors which can be shown as trace inside render window if sensors have storeInternal=True; if this list is empty and showPositionTrace=True, then all available sensors are shown."""
    listOfTriadSensors: List[int]
    """list of sensors of with OutputVariableType RotationMatrix; this non-empty list needs to coincide in length with the listOfPositionSensors to be shown if showTriads=True; the triad is drawn at the related position."""
    listOfVectorSensors: List[int]
    """list of sensors with 3D vector quantities; this non-empty list needs to coincide in length with the listOfPositionSensors to be shown if showVectors=True; the vector quantity is drawn relative to the related position."""
    positionsShowEvery: int
    """integer value i; out of available sensor data, show every i-th position."""
    sensorsMbsNumber: int
    """number of main system which is used to for sensor lists; if only 1 mbs is in the SystemContainer, use 0; if there are several mbs, it needs to specify the number."""
    showCurrent: bool
    """show current trace position (and especially vector quantity) related to current visualization state; this only works in solution viewer if sensor values are stored at time grid points of the solution file (up to a precision of 1e-10) and may therefore be temporarily unavailable."""
    showFuture: bool
    """show trace future to current visualization state if already computed (e.g. in SolutionViewer)."""
    showPast: bool
    """show trace previous to current visualization state."""
    showPositionTrace: bool
    """show position trace of all position sensors if listOfPositionSensors=[] or of specified sensors; sensors need to activate storeInternal=True."""
    showTriads: bool
    """if True, show basis vectors from rotation matrices provided by sensors."""
    showVectors: bool
    """if True, show vector quantities according to description in showPositionTrace."""
    timeSpan: float
    """maximum trace time span of past or future trace; given in seconds of simulation time; if zero, it is unused."""
    traceColors: List[float]
    """RGBA float values for traces in one array; using 6x4 values gives different colors for 6 traces; in case of triads, the 0/1/2-axes are drawn in red, green, and blue."""
    triadSize: float
    """length of triad axes if shown."""
    triadsShowEvery: int
    """integer value i; out of available sensor data, show every i-th triad."""
    vectorScaling: float
    """scaling of vector quantities; if, e.g., loads, this factor has to be adjusted significantly."""
    vectorsShowEvery: int
    """integer value i; out of available sensor data, show every i-th vector."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsScopes:
    """The look of all scopes of all views, see VSettingsScope (#3237, #3251): their colors, line width and font size."""
    axesColor: Tuple[float,float,float,float]
    """RGBA color of the axes, ticks, grid, labels and legend."""
    backgroundColor: Tuple[float,float,float,float]
    """RGBA color of the area of a scope."""
    fontSizeFactor: float
    """the font size of the scopes relative to ``window.globalFontSize`` of the view, which the display scaling multiplies as all texts."""
    frameColor: Tuple[float,float,float,float]
    """RGBA color of the frame around a scope."""
    lineWidth: float
    """width in pixels of the plotted lines, the axes and the ticks; the sub-ticks and the grid have half of it."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsSensors:
    """Visualization settings for sensors."""
    scopes: VSettingsScopes
    """the look of all scopes: colors, line width and font size; what each scope plots and where is in ``view0.window.scope0``, ... (#3251)."""
    traces: VSettingsTraces
    """settings for showing (position/triad) sensor traces and vector plots in the render window."""
    defaultColor: Tuple[float,float,float,float]
    """default RGBA color for sensors; 4th value is alpha-transparency."""
    defaultSize: float
    """global sensor size; if -1.f, sensor size is relative to maxSceneSize."""
    drawSimplified: bool
    """draw sensors with simplified symbols."""
    show: bool
    """flag to decide, whether the sensors are shown."""
    showNumbers: bool
    """flag to decide, whether the sensor numbers are shown."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsContactShow:
    """Which shapes of the contacts are drawn: of GeneralContact and of the contact items whose visualization has show=True (#3340)."""
    cones: bool
    """show the truncated cones of the contact items (ObjectContactConeCone, ObjectContactConeTriangle) whose visualization has show=True."""
    cylinders: bool
    """show the cylinders of the contact items (ObjectContactSphereCylinder, ObjectContactCylinderCylinder, ObjectJournalBearing, ...) whose visualization has show=True."""
    spheres: bool
    """show contact spheres (SpheresWithMarker, ...) and the spheres of the contact items (ObjectContactSphereSphere, ...) whose visualization has show=True."""
    tori: bool
    """show the torus of each ObjectContactSphereTorus whose visualization has show=True."""
    triangles: bool
    """show contact triangles (TrianglesRigidBodyBased, ...) and the triangles of the contact items (ObjectContactSphereTriangle, ObjectContactConvexConvex, ...) whose visualization has show=True."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsContactColor:
    """The colors of the shapes of the contacts, of GeneralContact and of the contact items, unless an item has its own color; the default alpha value of 0.8 keeps the contact forces drawn inside the shapes visible (#3340)."""
    cones: Tuple[float,float,float,float]
    """RGBA color of the contact cones, see show.cones."""
    cylinders: Tuple[float,float,float,float]
    """RGBA color of the contact cylinders, see show.cylinders."""
    spheres: Tuple[float,float,float,float]
    """RGBA color of the contact spheres, see show.spheres."""
    tori: Tuple[float,float,float,float]
    """RGBA color of the contact tori, see show.tori."""
    triangles: Tuple[float,float,float,float]
    """RGBA color of the contact triangles, see show.triangles."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsContact:
    """Global visualization settings for GeneralContact. This allows to easily switch on/off during visualization; also used for contact objects, such as ObjectContactSphereSphere or ObjectContactSphereTriangle."""
    color: VSettingsContactColor
    """the colors of the shapes of the contacts (#3340)."""
    show: VSettingsContactShow
    """which shapes of the contacts are drawn: triangles, spheres, tori, cylinders, cones (#3340)."""
    colorBoundingBoxes: Tuple[float,float,float,float]
    """RGBA color for boudnding boxes, see showBoundingBoxes."""
    colorSearchTree: Tuple[float,float,float,float]
    """RGBA color for search tree, see showSearchTree."""
    contactForcesFactor: float
    """factor used for scaling of contact forces is showContactForces=True; for the arrows of the contact items: their length per force [SI:m/N]."""
    contactForcesRadius: float
    """radius of the shaft of the arrows of the contact forces [SI:m], see showContactForces; at most a tenth of the length of an arrow (#3339)."""
    contactPointsDefaultSize: float
    """global contact points size; if -1.f, connector size is relative to maxSceneSize; used for some contacts, e.g., in ContactFrictionCircle."""
    showBoundingBoxes: bool
    """show computed bounding boxes of all GeneralContacts; Warning: avoid for large number of contact objects!"""
    showContactForces: bool
    """if True, contact forces are drawn for certain contact models; the contact items between spheres, cylinders, cones, triangles and polytopes and ObjectJournalBearing whose visualization has show=True draw at each contact point the force on marker 0 as a red arrow and the force on marker 1 as a green one, their heads meeting at the contact point, except with a user function of the force (#3339)."""
    showContactForcesValues: bool
    """if True and showContactForces=True, numerical values for  contact forces are shown at certain points."""
    showSearchTree: bool
    """show outer box of search tree for all GeneralContacts."""
    showSearchTreeCells: bool
    """show all cells of search tree; empty cells have colorSearchTree, cells with contact objects have higher red value; Warning: avoid for large number of search tree cells!"""
    tilingCurves: int
    """tiling for nonlinear/polynomial curves; higher values give smoother curves."""
    tilingSpheres: int
    """tiling for spheres; higher values give smoother spheres, but may lead to lower frame rates."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsCamera:
    """Settings for camera like perspective, marker tracking, clipping plane, etc. Note that some options may also be found in openGL settings."""
    cameraPosition: Tuple[float,float,float]
    """if modelCentricView=False: the position of the camera in the model (and, if used, relative to a tracked marker); camera rotation follows modelRotation in renderState; ZoomAll sets it in a perspective view, such that the camera looks at the center of the scene from the distance at which it shows the scene."""
    clippingPlaneDistance: float
    """distance of clipping plane on normal vector; see also clippingPlaneNormal and openGL.advanced.clippingPlaneColor."""
    clippingPlaneNormal: Tuple[float,float,float]
    """normal vector of clipping plane, e.g. [0,0,1] to set a xy-clipping plane; the clipped half-space is in direction of the normal; use [0,0,0] to deactivate clipping plane; Note that clipping is mainly made for triangles in order to visualize hidden objects and currently it only fully clips triangles, but does not exactly cut them; see also clippingPlaneDistance and openGL.advanced.clippingPlaneColor."""
    modelCentricView: bool
    """True: rotations and translations are applied to model, while camera stays far enough away from the model and always captures the whole model (everything is in front of camera plane); False: camera moves and rotates while model stays in physical space; only geometry in front of camera is visible; note that the behavior of trackMarker changes with modelCentricView and some features are not available in case of modelCentricView=False; see sec-renderer-modelcameracentric."""
    nearFarPlaneOffset: Tuple[float,float,float]
    """the three values are [nearPlaneOffset, farPlaneOffset, flag]; if flag=0, the offsets are ignored and computed automatically, using x = 2 * maxSceneSize * zMaxSceneFactor, setting near plane to -x and far plane to +x in case of modelCentricView=True and setting near plane to the minimal offset to the eye point, 0.1 or 0.001 maxSceneSize if smaller, and far plane to +x if modelCentricView=False; with perspective and modelCentricView=True, the near plane is not nearer to the eye than this minimal offset; if flag=1, the near and far plane values are just overwritten; note that positive values for near plane make objects in front of the camera invisible while negative values make objects behind the camera plane visible; in case of camera-centric view, the eyepoint can be shifted backwards using cameraPosition accordingly."""
    perspective: float
    """parameter prescribes amount of perspective (0=no perspective=orthographic projection; positive values increase perspective; feasible values are 0.001 (little perspective) ... 1 (extreme: 5), where larger values are possible but should be used with care; NOTE that the relation to the common field of view (FOV) angle alpha, with alpha=90°, is given by perspective = tan(alpha/2) = 1; mouse coordinates (F3) can not be shown with perspective>0."""
    trackMarker: int
    """if valid marker index is provided and marker provides position (and orientation), the centerpoint of the scene follows the marker (and orientation); depends on trackMarkerPosition and trackMarkerOrientation; by default, only position is tracked."""
    trackMarkerMbsNumber: int
    """number of main system which is used to track marker; if only 1 mbs is in the SystemContainer, use 0; if there are several mbs, it needs to specify the number."""
    trackMarkerOrientation: Tuple[float,float,float]
    """choose which orientation axes (x,y,z) are tracked; currently can only be all zero or all one."""
    trackMarkerPosition: Tuple[float,float,float]
    """choose which coordinates or marker are tracked (x,y,z)."""
    useRaytracer: bool
    """True: use (software) raytracer for this view; False: use standard OpenGL renderer."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsScene:
    """Settings change scene representation (show edges, show faces, global transparency), adding world basis, etc., in particular settings that are individual to each view. Note that some scene settings that are global to all views may be found in general and in openGL settings."""
    drawCoordinateSystem: int
    """0 = no coordinate system shown, 1 = draw lines with text, 2 = draw arrows, 3 = draw arrows with text."""
    drawWorldBasis: bool
    """true = draw world basis coordinate system at (0,0,0)."""
    facesTransparent: bool
    """True: show faces transparent independent of transparency (A)-value in color of objects; allow to show otherwise hidden node/marker/object numbers."""
    hideMbs: List[int]
    """the numbers of the systems (as in SC.GetSystem(i), in the order of SC.AddSystem) whose graphics this view does not show: their faces, edges, lines, texts and shadows, the sensor traces of traces.sensorsMbsNumber, the zoom of this view and the raytracer image of this view leave them out; numbers without a system are ignored; e.g. [1] to show only mbs 0 in a view (#3442)."""
    showFaceEdges: bool
    """True: show edges of triangles; using the options showFaces=false and showFaceEdges=true gives are wire frame representation."""
    showFaces: bool
    """True: show faces of triangles, etc.; using the options showFaces=false and showFaceEdges=true gives are wireframe representation."""
    showLines: bool
    """True: show lines (other lines than face and mesh edges)."""
    showMeshEdges: bool
    """True: show edges of finite elements; independent of showFaceEdges."""
    showMeshFaces: bool
    """True: show faces of finite elements; independent of showFaces."""
    worldBasisSize: float
    """size of world basis coordinate system."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsScope:
    """A scope: stored sensor values plotted over time, or over another sensor, in a region of the render window, drawn by OpenGL and the raytracer and part of saved images; each view has three, shown with ``window.showScopes`` (#3237). The values are those up to the visualization time, as the sensor traces show them, so that the solution viewer plots them in its animations; only sensors with ``storeInternal=True`` have them. Colors, line width and font size are common to all scopes, in ``sensors.scopes`` (#3251)."""
    location: ArrayLike
    """where the scope is in the window, ``[[xmin, ymin], [xmax, ymax]]``, its top left and its bottom right corner relative to the width and the height of the window, measured from its top left corner; e.g. ``[[0.5, 0.], [1., 0.5]]`` is the top right quarter."""
    minMaxX: Tuple[float,float]
    """``[xmin, xmax]`` of the horizontal axis; both 0: fitted to the values, or the last ``timeHistory`` seconds."""
    minMaxY: Tuple[float,float]
    """``[ymin, ymax]`` of the vertical axis; both 0: fitted to the values."""
    sensors: List[List[int]]
    """the lines of the scope, a list of rows of integers, one row per line, all rows of 2 or all of 5 integers: ``[sensorY, componentY]`` plots component ``componentY`` of sensor ``sensorY`` of mbs 0 over time, e.g. ``[[0,1],[2,3]]`` plots component 1 of sensor 0 and component 3 of sensor 2; ``[sensorY, componentY, sensorX, componentX, mbsNumber]`` plots it over component ``componentX`` of sensor ``sensorX``, e.g. ``[[1,1,1,0,0]]`` the y-component of sensor 1 over its x-component, and ``sensorX=-1`` over time; ``componentY=-1`` plots all components of the sensor. The components count from 0, without the time; only sensors with ``storeInternal=True`` can be plotted. If the lists of all three scopes of the view are empty, the scopes show the first three sensors of mbs 0 that store their values, one per scope."""
    showLegend: bool
    """True: the name of the sensor of each line, with ``-`` and the component for a sensor of more than one component, ``m0.Pos-X``, and ``m0.Pos-Y over m0.Pos-X`` for a line over another sensor, in the top right corner of the plot; so the name of a sensor should say what it measures; named lines of ``SC.renderer.scopes`` follow."""
    timeHistory: float
    """-1: all values up to the visualization time; otherwise only those of the last ``timeHistory`` seconds, e.g. 2 shows the last 2 seconds, and a plot over time scrolls."""
    useGrid: int
    """0: no grid; 1: a grid at the ticks; 2: a grid at the ticks and the sub-ticks."""
    xLabel: str
    """label of the horizontal axis."""
    xResolution: float
    """over time: how many values are drawn per pixel of the width of the plot; more values are reduced to the minimum and the maximum of each pixel column, so that peaks stay; 0.25 is a very low resolution. Over another sensor: every stored value, and below 1 every (1/xResolution)-th value, e.g. 0.2 draws every 5th value."""
    yLabel: str
    """label of the vertical axis, written above the plot."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsWindow:
    """Settings for window that are individual to each view; in particular initial size, and behavior. Note that some of the settings are only used during creation of the window."""
    scope0: VSettingsScope
    """the first scope of this view, at the top right corner."""
    scope1: VSettingsScope
    """the second scope of this view, below the first one."""
    scope2: VSettingsScope
    """the third scope of this view, below the second one."""
    alwaysOnTop: bool
    """True: render window of respective view will be always on top of all other windows."""
    globalFontSize: float
    """general text font size (roughly measured in pixels); if useWindowsDisplayScaleFactor=True, the the textSize is multplied with the windows display scaling (monitor scaling; content scaling) factor for larger texts on on high resolution displays; for bitmap fonts, the maximum size of any font (standard/large/huge) is limited to 256 (which is not recommended, especially if you do not have a powerful graphics card)."""
    lockModelView: bool
    """True: all movements (with mouse/keys), rotations, zoom are disabled; the view is either based on initial values (or on the current state) ==> initial zoom, rotation and center point need to be adjusted, approx. 0.4*maxSceneSize is a good value."""
    maximize: bool
    """True: render window of respective view will be maximized at startup."""
    renderWindowPosition: Tuple[int,int]
    """position of the top left corner of the render window of this view, in pixels; a NEGATIVE coordinate - which is the default - means that the window manager places the window, as it did before this setting existed. Set both to place the window, or store them in ``~/.exudyn/config.json`` to have every run start there, see Section sec-usersettings. NOTE: this is the position of the OpenGL area, not of the title bar, so a small value hides part of the title bar and 0 hides it completely - which still leaves the escape key, and is a way to have a view without one. The position is only used while the window is created, and one that lies outside the screens you have now puts the window where you cannot reach it."""
    renderWindowSize: Tuple[int,int]
    """initial size of the render window of this view, in pixels."""
    showComputationInfo: bool
    """true = show (hide) all computation information including Exudyn and version."""
    showIconBar: bool
    """True: the icon bar folds in when the mouse comes near the right border of the render window, without a button pressed; its icons do what keys do; see general.iconBarScaling, general.iconBarFoldDistance and general.iconBarTimeout (#3026)."""
    showMouseCoordinates: bool
    """True: show OpenGL coordinates and distance to last left mouse button pressed position in renderer status message; switched on/off with key 'F3'; only works for axis-aligned ortho-projections."""
    showRenderStateInfo: bool
    """True: show renderer.state infos regarding zoom, offset and rotation in renderer status message; switched on/off with 'CTRL-F3'."""
    showRuler: bool
    """True: show a ruler along the bottom and the left border of the window, with ticks at 1, 2 or 5 times a power of 10 in model units; in an axis-aligned view the labels are the coordinates of the view, as the mouse coordinates show them, else the distance from the left or bottom end; only shown with perspective=0; switched on/off with key 'F5' (#2244)."""
    showScopes: bool
    """True: show the scopes ``scope0``, ``scope1`` and ``scope2`` of this view, see VSettingsScope; switched on/off with the scope icon of the icon bar (#3237)."""
    showWindow: bool
    """True: render window of respective view is shown when created; False: window will be iconified when created (e.g. if you are starting multiple computations automatically)."""
    storeRenderWindowGeometry: bool
    """True: when the render window of this view closes, where it was is written into ``renderWindowSize`` and ``renderWindowPosition`` - so that storing the settings keeps the window where you left it, see Section sec-usersettings. False (default): the settings are only ever what you set, which is why *diff to default* does not report a window position after every run."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsView:
    """Settings for view including camera, scene, window, and advanced options to setup a view or view window."""
    camera: VSettingsCamera
    """settings for camera like perspective, marker tracking or clipping plane."""
    scene: VSettingsScene
    """settings which change scene representation, showing edges, faces or world basis."""
    window: VSettingsWindow
    """visualization settings for window that are individual to each view."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsWindowDeprecated:
    """OpenGL Window and interaction settings for visualization; handle changes with care, as they might lead to unexpected results or crashes."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsDialogs:
    """Settings related to dialogs (e.g., visualization settings dialog)."""
    alphaTransparency: float
    """alpha-transparency of dialogs; recommended range 0.7 (very transparent) - 1 (not transparent at all)."""
    alwaysTopmost: bool
    """True: dialogs are always topmost (otherwise, they are sometimes hidden)."""
    columnWidthName: float
    """width of the name column of a settings dialog, as a fraction of the width of the dialog; the description column takes what the three columns leave."""
    columnWidthType: float
    """width of the type column of a settings dialog, as a fraction of the width of the dialog."""
    columnWidthValue: float
    """width of the value column of a settings dialog, as a fraction of the width of the dialog."""
    fontScaling: float
    """factor on the font of the dialogs, relative to the display scaling of the system (monitor scaling on Windows, fractional scaling on Linux), which the dialogs follow anyway; 0 = 1 (on MacOS a fixed factor for the settings tree); every widget of the dialogs takes it - text, buttons, edit fields and the settings tree."""
    multiThreadedDialogs: bool
    """True: During dialogs, the OpenGL render windows will still get updates of changes in dialogs, etc., which may cause problems on some platforms or for some (complicated) models; False: changes of dialogs will take effect when dialogs are closed."""
    openTreeView: bool
    """True: all sub-trees of the visusalization dialog are opened when opening the dialog; False: only some sub-trees are opened."""
    storeDialogPositions: bool
    """True: a dialog stores its size and position in ``~/.exudyn/config.json`` when it closes, so that the next dialog of the same kind starts with them. A geometry that IS stored - by this flag, by the store button of the settings dialog, or by a script - is used whenever such a dialog opens, whatever this flag says: the size always, the position only if the window would still be reachable on the current screen. See Section sec-usersettings."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsMaterial:
    """A material of the raytracer: the colors of a face, its highlights (Phong), reflection, transparency with refraction and emission; OpenGL does not use materials. A face selects a material by the fourth value of its color, 1000 + the index of the material; how, and what each property does, is described in sec-raytracer-materials. The ten predefined materials are raytracer.material0 to material9, whose values are listed in sec-vsettingsraytracer; ``SC.renderer.materials`` holds them and further ones, see sec-graphicsmateriallist."""
    alpha: float
    """opacity of the material, which replaces the alpha value of the color: 1 opaque, 0 fully transparent; a ray through a transparent face is traced further, up to raytracer.maxTransparencyDepth faces, and a shadow lets light through in proportion to 1 - alpha; costs one more ray per transparent face."""
    baseColor: Tuple[float,float,float]
    """RGB color of the faces of this material whose color has the red value -1, e.g. ``graphics.material.steel``; changing it changes the color of all these faces; OpenGL draws such faces black."""
    emission: Tuple[float,float,float]
    """RGB color that the faces of this material add by themselves, independent of the lights, e.g. for a lamp; it does not light other faces."""
    ior: float
    """index of refraction of a transparent material (alpha < 1): 1 lets the rays pass straight, 1.5 is glass; a ray enters at a face whose normal points against it and leaves at a face whose normal points along it, so a closed body needs outward normals."""
    name: str
    """the name of the material, by which ``SC.renderer.materials.Get(name)`` and ``Set(name, material)`` find it."""
    reflectivity: float
    """share of the reflected color in the color of a face, in [0,1]: 0 no reflection (rubber), 1 a perfect mirror; a reflected ray is traced up to raytracer.maxReflectionDepth times, and a ray that hits nothing takes raytracer.advanced.backgroundColorReflections; costs one more ray per reflecting pixel."""
    roughness: float
    """the blur of the reflections of a reflective material, as the angular radius in radians of the cone over which the reflected rays spread, e.g. 0.02 for polished and 0.1 for brushed metal; 0 gives sharp, mirror-like reflections; for the faces seen directly, the raytracer traces raytracer.reflectionSamples rays per pixel, which multiplies the cost of their reflections."""
    shininess: float
    """exponent of the highlights (Phong), at least 1: below 5 broad and dull, above 50 small and sharp highlights."""
    specular: Tuple[float,float,float]
    """RGB color of the highlights (Phong), multiplied by the specular value of each light."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsRaytracerAdvanced:
    """Advanced settings of the raytracer: the shadow map of soft shadows, savings of shadow rays, the distribution of the work over the threads, and colors for special cases; see sec-raytracer-quality."""
    adaptiveShadowSamples: int
    """if lightRadiusVariations is larger, this number of the samples of a light is traced first for each hit, the innermost and the outermost ones of its disk; if they agree (fully lit or fully in shadow), the other samples take their value without being traced, which saves most of the cost of soft shadows away from their edges; 0 traces all samples; details of a shadow smaller than the spacing of these samples may be missed; range=0..256."""
    backFaceColor: Tuple[float,float,float,float]
    """if the alpha (fourth) value is > 0: faces seen from their back - whose normals point away from the camera, e.g. the inward normals of a closed body - are drawn in this RGB color, without light, to check the orientation of the normals of imported meshes, as the one-sided lighting of OpenGL (openGL.advanced.lightModelTwoSide = False) shows them dark (#3275); 0: drawn as the front."""
    backgroundColorReflections: Tuple[float,float,float,float]
    """RGBA color of the background seen in reflections and through the last transparent face, also when maxReflectionDepth is reached; the background of the image (general.backgroundColor) is often black or white, which would make reflective objects black or very light, as the scenes are usually not inside a closed room."""
    minimumShadowWeight: float
    """a hit of a reflected or refracted ray casts its shadow rays only if the weight of the ray, its share in the color of the pixel (the product of the reflectivities, 1 - alpha of the transparent faces, divided by the number of rays of a blurred reflection), is at least this value; otherwise it is lit; e.g. 0.2 saves the shadow rays of weak reflections, such as of a floor of reflectivity 0.12, at the cost of their missing shadows; 0 casts all shadow rays; the visible surfaces always cast theirs."""
    searchTreeFactor: int
    """multiplies the number of the cells of the search tree, the grid over the scene by which a ray finds the faces it may hit; a larger factor can be faster for scenes with many small faces in a part of a large scene; range=1..128."""
    shadowScalingFactor: int
    """if a light casts soft shadows (lightRadius > 0, raytracer.lightRadiusVariations > 1), its shadows are computed on a shadow map of the resolution of the window divided by this factor, smoothed (shadowSmoothingSteps) and interpolated to the pixels; the map is used only if shadowScalingFactor x raytracer.multiSampling > 1: with 0, or with 1 and multiSampling = 1, every pixel takes its own samples, without smoothing, which gives grainy soft shadows at about twice the time of the default 3; 2 gives sharper edges of shadows than 3 at about 20 % more time; larger values blur small shadows; range=0..16."""
    shadowSmoothingSteps: int
    """number of smoothing passes over the shadow map of soft shadows (see shadowScalingFactor): each averages the neighbours of similar depth, so that a shadow does not spread across the silhouette of an object, and the pixels interpolate the values of similar depth; 2 to 3 remove the grain of 13 samples (lightRadiusVariations), more passes gain nothing; no effect without a shadow map; range=0..32."""
    showText: bool
    """True: the raytracer draws the texts of the scene (status text, node and object numbers, ..., as the other settings ask for them); False: no text at all in raytraced images."""
    tilesPerThread: int
    """the image is split into numberOfThreads x tilesPerThread tiles, which the threads take one after the other, so that the expensive parts of an image are shared by all threads."""
    zBiasLines: float
    """lines and edges are drawn by this distance in front of the faces, relative to the size of the scene, so that they are not hidden by the faces they lie on."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsRaytracer:
    """Settings of the raytracer, the renderer on the CPU that draws a view with shadows, soft shadows, sharp and blurred reflections, transparency with refraction, emission and fog, through the materials of the faces. It is switched on per view by view0.camera.useRaytracer, and ``SC.renderer.RedrawAndGetImage(useRaytracer=True)`` gives an image without any window. The lights and their shadows, the ambient light, the background, the line width and the clipping plane are taken from the OpenGL, general and view settings. An image takes from a fraction of a second to seconds: start with a small window. See sec-overview-basics-raytracing, and sec-raytracer-quality for the cost of each setting."""
    advanced: VSettingsRaytracerAdvanced
    """advanced settings of the raytracer: the shadow map, savings of shadow rays, threads, and colors for special cases."""
    material0: VSettingsMaterial
    """material 0, selected by the color ``graphics.material.default`` or the index ``graphics.material.indexDefault``."""
    material1: VSettingsMaterial
    """material 1, selected by the color ``graphics.material.matt`` or the index ``graphics.material.indexMatt``."""
    material2: VSettingsMaterial
    """material 2, selected by the color ``graphics.material.steel`` or the index ``graphics.material.indexSteel``."""
    material3: VSettingsMaterial
    """material 3, selected by the color ``graphics.material.plastic`` or the index ``graphics.material.indexPlastic``."""
    material4: VSettingsMaterial
    """material 4, selected by the color ``graphics.material.chrome`` or the index ``graphics.material.indexChrome``."""
    material5: VSettingsMaterial
    """material 5, selected by the color ``graphics.material.shiny`` or the index ``graphics.material.indexShiny``."""
    material6: VSettingsMaterial
    """material 6, selected by the color ``graphics.material.transparent`` or the index ``graphics.material.indexTransparent``."""
    material7: VSettingsMaterial
    """material 7, selected by the color ``graphics.material.glass`` or the index ``graphics.material.indexGlass``."""
    material8: VSettingsMaterial
    """material 8, selected by the color ``graphics.material.mirror`` or the index ``graphics.material.indexMirror``."""
    material9: VSettingsMaterial
    """material 9, selected by the color ``graphics.material.emission`` or the index ``graphics.material.indexEmission``."""
    globalFogColor: Tuple[float,float,float,float]
    """RGBA color of the fog, see globalFogDensity."""
    globalFogDensity: float
    """density of an exponential fog, relative to the size of the scene: a face at the distance d is mixed with globalFogColor by the factor exp(-globalFogDensity d / D), D the diameter of the scene; 0 switches the fog off; it becomes visible from about 1."""
    imageSizeFactor: int
    """renders the image smaller by this factor in each direction, which is faster (2: 4 times fewer rays), e.g. while adjusting a scene; ``SC.renderer.RedrawAndGetImage`` then returns the smaller image; range=1..16."""
    keepWindowActive: bool
    """special flag, handle with care; True: the raytracer lets the render window process its events during long images (> 2 seconds), as otherwise the window may time out before the image is finished."""
    lightRadiusVariations: int
    """the number of samples of each light with a lightRadius > 0 (openGL.light0.lightRadius, ...), which gives soft shadows on the faces seen directly; 1 gives hard shadows; the samples lie on a spiral over the disk of the light, rotated from hit to hit, so few samples give grain, which the shadow map smooths (advanced.shadowScalingFactor, advanced.shadowSmoothingSteps); e.g. 13 with the default smoothing, 31 for a little more detail at about 10 % more time; the samples are traced at the edges of shadows only (advanced.adaptiveShadowSamples); range=1..256."""
    maxReflectionDepth: int
    """maximum number of reflections traced for one ray, range=0..32; each transparent face passed counts as well; 2 to 4 suffice usually, more cost time where mirrors face each other."""
    maxTransparencyDepth: int
    """maximum number of transparent faces a ray passes, range=0..32; a ray through a closed body passes two faces, so 2 shows the background through one body; each reflection counts as well; beyond it, the face is drawn opaque."""
    multiSampling: int
    """anti-aliasing: each pixel is the mean of multiSampling x multiSampling rays, which smooths edges, lines and text, and the grain of soft shadows and blurred reflections; the cost grows with its square (3: 9 times); range=1..4; this is the setting of the raytracer, not openGL.multiSampling."""
    numberOfThreads: int
    """Number of CPU-threads (max: 256) used by the raytracer; 0: the number of logical processors of the computer, which is the fastest choice in general (#3445); the threads belong to the raytracer alone, so it renders in parallel also while a solver runs and from the renderer thread (#3438)."""
    reflectionSamples: int
    """the number of reflected rays per pixel on a surface whose material has a roughness > 0, spread over its cone for blurred reflections (only for the faces seen directly; a reflection in a reflection is sharp); 1 turns the blur off and gives sharp reflections at the cost of one ray; fewer rays are faster in proportion but grainy: 2 to 3 suffice for a roughness up to about 0.02, or with multiSampling = 2; range=1..256."""
    verbose: int
    """1: print the times and counters of each image; 2 and higher: further debug information."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsOpenGLAdvanced:
    """Advanced settings for openGL."""
    clippingPlaneColor: Tuple[float,float,float,float]
    """RGBA color for clipping plane; if alpha-channel is 0, the cutting plane is not drawn; if alpha-channel is 1, the clippingPlaneColor is used; if alpha-channel is 2, the color of the object interior is used as clipping plane color (which may look strange in case of object-in-object); see also view.camera for clipping plane options."""
    curvedTriangleContourMinTiling: int
    """minimum number of subdivisions per edge of a 6-node (curved) triangle or quadratic line with a contour color, at most curvedTriangleMaxTiling, so that the value of a flat quadratic element is not drawn as one flat triangle; 1 subdivides them by their curvature only, as the others; see curvedTriangleTilingAngle."""
    curvedTriangleMaxTiling: int
    """maximum number of subdivisions per edge of a 6-node (curved) triangle or quadratic line; see curvedTriangleTilingAngle."""
    curvedTriangleTilingAngle: float
    """6-node (curved) triangles of a TriangleList (key triangles6) are drawn as flat triangles, split when they are drawn: each edge is subdivided until the angle between its end tangents, and between the given normals of its nodes, falls below this angle (in degrees), at most curvedTriangleMaxTiling times, and the inside follows its three edges - 15 degrees give 24 segments around a full cylinder, and a surface curved in one direction is not subdivided along the other; 0 draws each as 1 flat triangle; used by the raytracer as well."""
    depthSorting: bool
    """True (slower): sort triangles by Z-depth to remove transparency artifacts: only works if triangles do not intersect or come close (you may like to refine triangle meshes); False: no depth-sort (faster)."""
    enableLighting: bool
    """generally enable lighting (otherwise, colors of objects are used); OpenGL: glEnable(GL_LIGHTING)."""
    faceNormalsColor: Tuple[float,float,float,float]
    """global RGBA color for face normals."""
    initialCenterPoint: Tuple[float,float,float]
    """centerpoint of scene (3D) at renderer startup; overwritten if autoFitScene = True; only used in case that modelCentricView=True."""
    initialMaxSceneSize: float
    """initial maximum scene size (auto: diagonal of cube with maximum scene coordinates); used for 'zoom all' functionality and for visibility of objects; overwritten if autoFitScene = True."""
    initialModelRotation: ArrayLike
    """initial model rotation matrix for OpenGl; in python use e.g.: initialModelRotation=[[1,0,0],[0,1,0],[0,0,1]]; only used in case that modelCentricView=True."""
    initialZoom: float
    """initial zoom of scene; overwritten/ignored if autoFitScene = True."""
    lightModelLocalViewer: bool
    """True: the camera origin is used to compute shininess effects (more realistic); maps to OpenGL glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER,...)."""
    lightModelTwoSide: bool
    """enlighten also backside of object; may cause problems on some graphics cards and lead to slower performance; maps to OpenGL glLightModeli(GL_LIGHT_MODEL_TWO_SIDE,...)."""
    lineSmooth: bool
    """draw lines smooth."""
    polygonOffset: float
    """general polygon offset for polygons, except for shadows; use this parameter to draw polygons behind lines to reduce artifacts for very large or small models."""
    shadeModelSmooth: bool
    """True: turn on smoothing for shaders, which uses vertex normals to smooth surfaces."""
    shadowPolygonOffset: float
    """some special drawing parameter for shadows which should be handled with care; defines some offset needed by openGL to avoid aritfacts for shadows and depends on maxSceneSize; this value may need to be reduced for larger models in order to achieve more accurate shadows, it may be needed to be increased for thin bodies."""
    showBoundingBox: bool
    """show scene bounding box (red), as available in renderState.boundingBox; NOTE that the bounding box is only updated with ZoomAll or at startup; this is a debug flag and it may show reasongs for strange ZoomAll behavior, as ZoomAll should zoom to the bounding box; does only work for perspective=0."""
    textLineSmooth: bool
    """draw lines for representation of text smooth."""
    textLineWidth: float
    """width of lines used for representation of text."""
    vertexNormalsColor: Tuple[float,float,float,float]
    """global RGBA color for vertex normals."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsLight:
    """Settings for lights."""
    constantAttenuation: float
    """constant attenuation coefficient of this light, this is a constant factor that attenuates the light source; attenuation factor = 1/(kc +kl*d + kq*d*d); (kc,kl,kq)=(1,0,0) means no attenuation; only used for lights, where last component of light position is 1."""
    diffuse: float
    """diffuse value of this light."""
    enable: bool
    """turn this light on or off; the four lights light0 to light3 of visualizationSettings.openGL are OpenGL GL_LIGHT0 to GL_LIGHT3, and each of them can cast a shadow - see shadow below."""
    lightRadius: float
    """only used by raytracers: radius of light used to compute smooth shadows (approximated by raytracer.lightRadiusVariations); if lightRadiusVariations>1, this value defines the radius of the light, converting point lights into distributed lights (slower); for a directional light (4th component of position 0), it is the angular radius in radians, e.g. 0.0047 for the sun."""
    linearAttenuation: float
    """linear attenuation coefficient of this light, this is a linear factor for attenuation of the light source with distance."""
    position: Tuple[float,float,float,float]
    """4D position vector of this light; the 4th value should be 0 for directional lights that are (almost) infinitely far away, like the sun, but 1 for position-based lights (and for the attenuation factor to be computed); if this light casts a shadow, its position decides where the shadow falls, so it has to be at a reasonable place for the scene; see opengl manuals."""
    quadraticAttenuation: float
    """quadratic attenuation coefficient of this light, this is a quadratic factor for attenuation of the light source with distance."""
    shadow: float
    r"""in OpenGL renderer, the shadow parameter :math:`\in [0 ... 1]` prescribes the amount of shadow of this light that is added to the scene, using its position (or only its direction); every light can cast a shadow and the effects accumulate; if this parameter is different from 0, rendering of triangles becomes approx. 5 times more expensive, so take care in case of complex scenes; for complex object, such as spheres with fine resolution or for particle systems, the present approach has limitations and leads to artifacts and unrealistic shadows; for raytracer, shadow is included by a physics-based model for each light if shadow>0, accumulating effects of each light source; the openGL renderer computes shadows with shadow volumes and approximates a directional light by enlarging its direction to a multiple of maxSceneSize, while the raytracer uses the direction itself."""
    specular: float
    """specular value of this light."""
    useCameraFrame: bool
    """set False to set light positions and directions relative to model frame; True: lights are in camera frame, not following the visual transformations; this was True up to Exudyn 1.9.174."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsOpenGL:
    """OpenGL settings for 2D and 3D rendering - with many settings also used for raytracer. For further details and backgrounds also see OpenGL 1.3 functionality on the web."""
    advanced: VSettingsOpenGLAdvanced
    """advanced settings for openGL."""
    light0: VSettingsLight
    """settings for light0 and shadow."""
    light1: VSettingsLight
    """settings for light1 and shadow."""
    light2: VSettingsLight
    """settings for light2 and shadow."""
    light3: VSettingsLight
    """settings for light3 and shadow."""
    drawFaceNormals: bool
    """draws triangle normals, e.g. at center of triangles; used for debugging of faces."""
    drawNormalsLength: float
    """length of normals; used for debugging."""
    drawVertexNormals: bool
    """draws vertex normals; used for debugging."""
    faceEdgesColor: Tuple[float,float,float,float]
    """global RGBA color for face edges."""
    faceTransparencyGlobal: float
    """in case that facesTransparent=True this represents the max alpha-transparency."""
    lightModelAmbient: Tuple[float,float,float,float]
    """global ambient light (needed for faces that are close to orthogonal to light or faces in shadow region); maps to OpenGL glLightModeli(GL_LIGHT_MODEL_AMBIENT,[r,g,b,a]); also used by raytracer."""
    lineWidth: float
    """width of lines used for representation of lines, circles, points, etc."""
    materialShininess: float
    """shininess of material."""
    materialSpecular: Tuple[float,float,float,float]
    """RGBA specular color of material."""
    multiSampling: int
    """NOTE: this parameter must be set before starting renderer; later changes are not affecting visualization; multi sampling turned off (<=1) or turned on to given values (2, 3, 4, 8 or 16); increases the graphics buffers and might crash due to graphics card memory limitations; only works if supported by hardware; if it does not work, try to change 3D graphics hardware settings!"""
    showTextures: bool
    """True: the triangles of a TriangleList with a texture are drawn with it, by OpenGL and by the raytracer; False: with the colors of their points (#3032)."""
    zMaxSceneFactor: float
    """factor multiplied with maxSceneSize to avoid clipping of modelview; larger values reduce clipping of near or far objects, but may lead to artifacts (so-called Z-fighting)."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsExportImages:
    """Functionality to export images of view0 to files (PNG or TGA format) which can be used to create animations; in order to activate image recording during the solution process, set SolutionSettings.recordImagesInterval accordingly."""
    heightAlignment: int
    """alignment of exported image height; using a value of 2 helps to reduce problems with video conversion (additional horizontal lines are lost)."""
    saveImageFileCounter: int
    """current value of the counter which is used to consecutively save frames (images) with consecutive numbers."""
    saveImageFileName: str
    """filename (without extension!) and (relative) path for image file(s) with consecutive numbering (e.g., frame0000.png, frame0001.png,...); ; directory will be created if it does not exist."""
    saveImageFormat: str
    """format of an exported image, ``PNG`` or ``TGA``; ``TGA`` has the highest compatibility with all platforms. The drawing elements of a scene as data - lines, triangles, texts, each with the item that drew it - are ``SC.renderer.GetGraphicsData()``."""
    saveImageSingleFile: bool
    """True: only save single files with given filename, not adding numbering; False: add numbering to files, see saveImageFileName."""
    saveImageTimeOut: int
    """timeout in milliseconds for saving a frame as image to disk; this is the amount of time waited for redrawing; increase for very complex scenes."""
    widthAlignment: int
    """alignment of exported image width; using a value of 4 helps to reduce problems with video conversion (additional vertical lines are lost)."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsInteractiveAdvanced:
    """Advanced settings for interactive."""
    highlightColor: Tuple[float,float,float,float]
    """RGBA color for highlighted item; 4th value is alpha-transparency."""
    highlightOtherColor: Tuple[float,float,float,float]
    """RGBA color for other items (which are not highlighted); 4th value is alpha-transparency."""
    joystickScaleRotation: float
    """rotation scaling factor for joystick input."""
    joystickScaleTranslation: float
    """translation scaling factor for joystick input."""
    keypressRotationStep: float
    """rotation increment per keypress in degree (full rotation = 360 degree)."""
    keypressTranslationStep: float
    """translation increment per keypress relative to window size."""
    mouseMoveRotationFactor: float
    """rotation increment per 1 pixel mouse movement in degree."""
    pauseWithSpacebar: bool
    """True: during simulation, space bar can be pressed to pause simulation."""
    selectionHighlights: bool
    """True: enable mouse click to highlights item (default: red)."""
    selectionLeftMouse: bool
    """True: enable left mouse click on items to show basic information."""
    selectionLeftMouseItemTypes: int
    """binary flags (1,2,4,8,16) for (Node,Object,Marker,Load,Sensor) that are identified with left mouse click selection."""
    selectionRightMouse: bool
    """True: enable right mouse click on items to show dictionary (read only!)."""
    selectionRightMouseGraphicsData: bool
    """True: right mouse click on items also shows GraphicsData information for inspectation (may sometimes be very large and may not fit into dialog for large graphics objects!)."""
    zoomStepFactor: float
    """change of zoom per keypress (keypad +/-) or mouse wheel increment."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VSettingsInteractive:
    """Functionality to interact with render window; includes special rotation and zoom factors, item-highlighting, marker tracking, item selection and keyPressUserFunction."""
    advanced: VSettingsInteractiveAdvanced
    """advanced interactive visualization settings."""
    autoRotateModelView: bool
    """True: rotate model view with autorotation."""
    autoRotationVelocity: Tuple[float,float,float]
    """Angular velocity vector for auto-rotation of scene (only visualization view is rotated, not the model itself!)."""
    highlightItemIndex: int
    """index of item that shall be highlighted (e.g., to find item which cauess problems); if set -1, no item is highlighted."""
    highlightItemType: ItemType
    """item type (Node, Object, ...) that shall be highlighted (e.g., to find item which cauess problems)."""
    highlightMbsNumber: int
    """index of main system (mbs) for which the item shall be highlighted; number is related to the ID in SystemContainer (first mbs = 0, second = 1, ...)."""
    ignoreKeys: bool
    """True: ignore keyboard input except escape and 'F2' keys; used for interactive mode, e.g., to perform kinematic analysis; This flag can be switched with key 'F2'; if ignoreKeys=True, then keyPressUserFunction can be used!"""
    keyPressUserFunction: Any
    """add a Python function f(key, action, mods) here, which is called every time a key is pressed; set this parameter to 0 (int) in order to deactivate it; the user function is only called if interactive.ignoreKeys=True; function shall return true, if key has been processed; Example: ``def f(key, action, mods): print('key=',key)``; use chr(key) to convert key codes [32 ...96] to ascii; special key codes (>256) are provided in the exudyn.KeyCode enumeration type; key action needs to be checked (0=released, 1=pressed, 2=repeated); mods provide information (binary) for SHIFT (1), CTRL (2), ALT (4), Super keys (8), CAPSLOCK (16)."""
    logMouseCoordinates: bool
    """True: if showMouseCoordinates=True, also log mouse coordinates (transformed to model coordinates); only works for axis-aligned ortho-projections and shows the coordinates of the current plane."""
    useJoystickInput: bool
    """True: read joystick input (use 6-axis joystick with lowest ID found when starting renderer window) and interpret as (x,y,z) position and (rotx, roty, rotz) rotation: as available from 3Dconnexion space mouse and maybe others as well; set to False, if external joystick makes problems ..."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class VisualizationSettings:
    """Top structure for all visualization settings in Exudyn."""
    bodies: VSettingsBodies
    """body visualization settings."""
    connectors: VSettingsConnectors
    """connector visualization settings."""
    contact: VSettingsContact
    """contact visualization settings."""
    contour: VSettingsContour
    """contour plot visualization settings."""
    dialogs: VSettingsDialogs
    """dialogs settings."""
    exportImages: VSettingsExportImages
    """settings for exporting (saving) images to files in order to create animations."""
    general: VSettingsGeneral
    """general visualization settings."""
    interactive: VSettingsInteractive
    """Settings for interaction with renderer."""
    loads: VSettingsLoads
    """load visualization settings."""
    markers: VSettingsMarkers
    """marker visualization settings."""
    nodes: VSettingsNodes
    """node visualization settings."""
    openGL: VSettingsOpenGL
    """OpenGL rendering settings."""
    raytracer: VSettingsRaytracer
    """Raytracer settings (builds on OpenGL rendering settings)."""
    sensors: VSettingsSensors
    """sensor visualization settings."""
    view0: VSettingsView
    """Settings for main view 0."""
    view1: VSettingsView
    """Settings for sub-view 1."""
    view2: VSettingsView
    """Settings for sub-view 2."""
    view3: VSettingsView
    """Settings for sub-view 3."""
    def GetDictionary(self) -> dict: ...
    def SetDictionary(self, d: dict) -> None: ...


class CSolverTimer:
    """Structure for timing in solver. Each Real variable is used to measure the CPU time which certain parts of the solver need. This structure is only active if the code is not compiled with the __FAST_EXUDYN_LINALG option and if displayComputationTime is set True. Timings will only be filled, if useTimer is True."""
    AERHS: float
    """time for residual evaluation of algebraic equations right-hand-side."""
    errorEstimator: float
    """for explicit solvers, additional evaluation."""
    factorization: float
    """solve or inverse."""
    integrationFormula: float
    """time spent for evaluation of integration formulas."""
    jacobianAE: float
    """jacobian of algebraic equations (not counted in sum)."""
    jacobianODE1: float
    """jacobian w.r.t. coordinates of ODE1 equations (not counted in sum)."""
    jacobianODE2: float
    """jacobian w.r.t. coordinates of ODE2 equations (not counted in sum)."""
    jacobianODE2_t: float
    """jacobian w.r.t. coordinates_t of ODE2 equations (not counted in sum)."""
    massMatrix: float
    """mass matrix computation."""
    newtonIncrement: float
    """Jac:math:`^{-1}` * RHS; backsubstitution."""
    ODE1RHS: float
    """time for residual evaluation of ODE1 right-hand-side."""
    ODE2RHS: float
    """time for residual evaluation of ODE2 right-hand-side."""
    overhead: float
    """overhead, such as initialization, copying and some matrix-vector multiplication."""
    postNewton: float
    """discontinuous iteration / PostNewtonStep."""
    python: float
    """time spent for Python functions."""
    reactionForces: float
    """CqT * lambda."""
    realtimeIdleCPU: float
    """time waited for next frame to compute and draw if timeIntegration.realtime.active is True."""
    @overload
    def Reset(useSolverTimer) -> None: ...
    @overload
    def StartTimer(value) -> None: ...
    @overload
    def StopTimer(value) -> None: ...
    @overload
    def Sum() -> float: ...
    @overload
    def ToString() -> str: ...
    total: float
    """total time measured between start and end of computation (static/dynamics)."""
    totalJacobian: float
    """time for all jacobian computations."""
    userFunctions: float
    """time spent in user functions of items and of the system (e.g. preStep), called in the computation thread; within the other timers (not counted in sum)."""
    useTimer: bool
    """flag to decide, whether the timer is used (true) or not."""
    visualization: float
    """time spent for visualization in computation thread."""
    writeSolution: float
    """time for writing solution."""


class SolverIterationData:
    """Solver internal structure for counters, steps, step size, time, etc.; solution vectors, residuals, etc. are SolverLocalData. The given default values are overwritten by the simulationSettings when initializing the solver."""
    adaptiveStep: bool
    """True: the step size may be reduced if step fails; no automatic stepsize control."""
    automaticStepSize: bool
    """True: if timeIntegration.automaticStepSize == True AND chosen integrators supports automatic step size control (e.g., DOPRI5); False: constant step size used (step may be reduced if adaptiveStep=True)."""
    automaticStepSizeError: float
    r"""estimated error (relative to atol + rtol*solution) of last step; must be :math:`\le 1`  for a step to be accepted."""
    currentStepIndex: int
    """current step index; :math:`i`."""
    currentStepSize: float
    """stepSize of current step."""
    currentTime: float
    """holds the current simulation time, copy of state.current.time; interval is [startTime,tEnd]; in static solver, duration is loadStepDuration."""
    discontinuousIteration: int
    """number of current discontinuous iteration."""
    discontinuousIterationsCount: int
    """count total number of discontinuous iterations (min. 1 per step)."""
    endTime: float
    """end time of static/dynamic solver."""
    initialStepSize: float
    """initial stepSize for dynamic solver; only used, if automaticStepSize is activated."""
    lastStepSize: float
    """stepSize suggested from last step or by initial step size; only used, if automaticStepSize is activated."""
    maxStepSize: float
    """constant or maximum stepSize."""
    minStepSize: float
    """minimum stepSize for static/dynamic solver; only used, if automaticStepSize is activated."""
    newtonJacobiCount: int
    """count total Newton jacobian computations."""
    newtonSteps: int
    """number of current newton steps."""
    newtonStepsCount: int
    """count total Newton steps."""
    numberOfSteps: int
    """number of time steps (if fixed size); :math:`n`."""
    recommendedStepSize: float
    """recommended step size :math:`h_{recom}` after PostNewton(...): :math:`h_{recom} < 0`: no recommendation, :math:`h_{recom}==0`: use minimum step size, :math:`h_{recom}>0`: use specific step size, if no smaller size requested by other reason."""
    rejectedAutomaticStepSizeSteps: int
    """count the number of rejected steps in case of automatic step size control (rejected steps are repeated with smaller step size)."""
    rejectedModifiedNewtonSteps: int
    """count the number of rejected modified Newton steps (switch to full Newton)."""
    startTime: float
    """time at beginning of time integration."""
    @overload
    def ToString() -> str: ...


class SolverConvergenceData:
    """Solver internal structure for convergence information: residua, iteration loop errors and error flags. For detailed behavior of these flags, visit the source code!"""
    contractivity: float
    """Newton contractivity = geometric decay of error in every step."""
    discontinuousIterationError: float
    """error of discontinuous iterations (contact, friction, ...) outside of Newton iteration."""
    discontinuousIterationSuccessful: bool
    """true, if last discontinuous iteration had success (failure may be recovered by adaptive step)."""
    errorCoordinateFactor: float
    """factor may include the number of system coordinates to reduce the residual."""
    @overload
    def InitializeData() -> None: ...
    jacobianUpdateRequested: bool
    """true, if a jacobian update is requested in modified Newton (determined in previous step)."""
    lastResidual: float
    """last Newton residual to determine contractivity."""
    linearSolverCausingRow: int
    """-1 if successful, 0 ... n-1, the system equation (=coordinate) index which may have caused the problem, at which the linear solver failed."""
    linearSolverFailed: bool
    """true, if linear solver failed to factorize."""
    massMatrixNotInvertible: bool
    """true, if mass matrix is not invertable during initialization or solution (explicit solver)."""
    newtonConverged: bool
    """true, if Newton has (finally) converged."""
    newtonSolutionDiverged: bool
    """true, if Newton diverged (may be recovered)."""
    residual: float
    """current Newton residual."""
    stepReductionFailed: bool
    """true, if iterations over time/static steps failed (finally, cannot be recovered)."""
    stopNewton: bool
    """set true by Newton, if Newton was stopped, e.g., because of exceeding iterations or linear solver failed."""


class SolverOutputData:
    """Solver internal structure for output modes, output timers and counters."""
    constraintDriftItem: str
    """the item of constraintDriftMaximum, as object 5 or node 3."""
    constraintDriftMaximum: float
    """the largest drift of the position-level constraints found by timeIntegration.generalizedAlpha.checkConstraintDrift in this run; -1 if not checked (#565)."""
    constraintDriftTime: float
    """the time of constraintDriftMaximum."""
    cpuLastTimePrinted: float
    """CPU time when output has been printed last time."""
    cpuSolverStartTime: float
    """CPU start time of main solver (not including initial conditions); cpuSolverStartTime-cpuStartTime gives time for initialization."""
    cpuStartTime: float
    """CPU start time of computation (starts counting at computation of initial conditions)."""
    finishedSuccessfully: bool
    """flag is false until solver functions SolveSteps)...) or SolveSystem(...) finished successfully (can be used as external trigger)."""
    initialConstraintsResidualPosition: float
    """the largest absolute residual of the constraints with the initial positions, computed at the start of the time integration if timeIntegration.generalizedAlpha.checkInitialConstraints is True; -1 if not computed (#2234)."""
    initialConstraintsResidualVelocity: float
    """the largest absolute residual of the velocity-level constraints with the initial velocities, after their projection if timeIntegration.generalizedAlpha.projectInitialVelocities is True; -1 if not computed (#2234)."""
    initializationSuccessful: bool
    """flag is set during call to InitializeSolver(...); reasons for failure are multiple, either inconsistent solver settings are used, files cannot be written (file locked), or initial conditions could not be computed."""
    @overload
    def InitializeData() -> None: ...
    initialVelocitiesProjected: bool
    """True if the initial velocities have been projected onto the constraints (timeIntegration.generalizedAlpha.projectInitialVelocities) (#2234)."""
    lastDiscontinuousIterationsCount: int
    """discontinuous iterations count when written to console (or file) last time."""
    lastImageRecorded: float
    """simulation time when last image has been recorded."""
    lastNewtonJacobiCount: int
    """jacobian update count when written to console (or file) last time."""
    lastNewtonStepsCount: int
    """newton steps count when written to console (or file) last time."""
    lastRestartWritten: float
    """simulation time when the restart file has been written last."""
    lastSensorsWritten: float
    """simulation time when last sensors have been written."""
    lastSolutionWritten: float
    """simulation time when last solution has been written."""
    lastVerboseStepIndex: int
    """step index when last time written to console (or file)."""
    multiThreadingMode: int
    """multithreading mode that has been used: 0=None (serial), 1=multithreading, 2=multithreading with load balancing; (modes new since 2025-06, V1.9.198)."""
    numberOfThreadsUsed: int
    """number of threads that have been used in simulation."""
    restartTime: float
    """simulation time from which the solver continued with the restart file (solution.restart.continueIfAvailable); -1 if it started at the start time."""
    simulationStoppedByUser: bool
    """flag (initialized false) is set true when user stops the simulation (press Q, Escape, etc.)."""
    simulationStoppedByUserFunction: bool
    """flag (initialized false) is set true when a user function (PreStep, PostNewton, etc.) sends termination signal."""
    simulationTimeout: bool
    """flag (initialized false) is set true when exudyn.special.solver.timeout is reached (and timeout is >= 0)."""
    stepInformation: int
    """this is a copy of the solvers stepInformation used for console output."""
    verboseMode: int
    """this is a copy of the solvers verboseMode used for console output."""
    verboseModeFile: int
    """this is a copy of the solvers verboseModeFile used for file."""
    writeToSolutionFile: bool
    """if false, no solution file is generated and no file is written."""
    writeToSolverFile: bool
    """if false, no solver output file is generated and no file is written."""


class MainSolverStatic:
    """PyBind interface (trampoline) class for static solver. With this interface, the static solver and its substructures can be accessed via Python. NOTE that except from SolveSystem(...), these functions are only intended for experienced users and they need to be handled with care, as unexpected crashes may happen if used inappropriate. Furthermore, the functions have a lot of overhead (performance much lower than internal solver) due to Python interfaces, and should thus be used for small systems. To access the solver in Python, write:; ; ; ``solver = MainSolverStatic()``; ; ; and hereafter you can access all data and functions via 'solver'."""
    conv: SolverConvergenceData
    """all information about tolerances, errors and residua."""
    it: SolverIterationData
    """all information about iterations (steps, discontinuous iteration, newton,...)."""
    newton: NewtonSettings
    """copy of newton settings from timeint or staticSolver."""
    output: SolverOutputData
    """output modes and timers for exporting solver information and solution."""
    timer: CSolverTimer
    """timer which measures the CPU time of solver sub functions."""
    @overload
    def CheckInitialized(mainSystem) -> bool: ...
    @overload
    def ComputeAlgebraicEquations(mainSystem, velocityLevel=False) -> None: ...
    @overload
    def ComputeJacobianAE(mainSystem, scalarFactor_ODE2=1., scalarFactor_ODE2_t=0., scalarFactor_ODE1=1., velocityLevel=False) -> None: ...
    @overload
    def ComputeJacobianODE1RHS(mainSystem, scalarFactor_ODE2=1., scalarFactor_ODE2_t=0., scalarFactor_ODE1=1., computeLoadsJacobian=0) -> None: ...
    @overload
    def ComputeJacobianODE2RHS(mainSystem, scalarFactor_ODE2=1., scalarFactor_ODE2_t=0., scalarFactor_ODE1=1., computeLoadsJacobian=0) -> None: ...
    @overload
    def ComputeLoadFactor(simulationSettings) -> float: ...
    @overload
    def ComputeMassMatrix(mainSystem, scalarFactor=1.) -> None: ...
    @overload
    def ComputeNewtonJacobian(mainSystem, simulationSettings) -> None: ...
    @overload
    def ComputeNewtonResidual(mainSystem, simulationSettings) -> float: ...
    @overload
    def ComputeNewtonUpdate(mainSystem, simulationSettings, initial=True) -> None: ...
    @overload
    def ComputeODE2RHS(mainSystem) -> None: ...
    @overload
    def DiscontinuousIteration(mainSystem, simulationSettings) -> bool: ...
    @overload
    def FinalizeSolver(mainSystem, simulationSettings) -> None: ...
    @overload
    def FinishStep(mainSystem, simulationSettings) -> None: ...
    @overload
    def GetAEsize() -> int: ...
    @overload
    def GetDataSize() -> int: ...
    @overload
    def GetErrorString() -> str: ...
    @overload
    def GetLinearSolverInfo() -> Any: ...
    @overload
    def GetNewtonSolution() -> ArrayLike: ...
    @overload
    def GetODE1size() -> int: ...
    @overload
    def GetODE2size() -> int: ...
    @overload
    def GetSimulationEndTime(simulationSettings) -> float: ...
    @overload
    def GetSolverName() -> str: ...
    @overload
    def GetSystemJacobian(sparse=False) -> Any: ...
    @overload
    def GetSystemMassMatrix(sparse=False) -> Any: ...
    @overload
    def GetSystemResidual() -> ArrayLike: ...
    @overload
    def HasAutomaticStepSizeControl(mainSystem, simulationSettings) -> bool: ...
    @overload
    def IncreaseStepSize(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolver(mainSystem, simulationSettings) -> bool: ...
    @overload
    def InitializeSolverData(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolverInitialConditions(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolverOutput(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolverPreChecks(mainSystem, simulationSettings) -> bool: ...
    @overload
    def InitializeStep(mainSystem, simulationSettings) -> None: ...
    @overload
    def IsStaticSolver() -> bool: ...
    @overload
    def IsVerboseCheck(level) -> bool: ...
    loadStepGeometricFactor: float
    """multiplicative load step factor; this factor is computed from loadStepGeometric parameters in SolveSystem(...)."""
    @overload
    def Newton(mainSystem, simulationSettings) -> bool: ...
    @overload
    def PostInitializeSolverSpecific(mainSystem, simulationSettings) -> None: ...
    @overload
    def PreInitializeSolverSpecific(mainSystem, simulationSettings) -> None: ...
    @overload
    def ReduceStepSize(mainSystem, simulationSettings, severity) -> bool: ...
    @overload
    def SetSystemJacobian(systemJacobian) -> None: ...
    @overload
    def SetSystemMassMatrix(systemMassMatrix) -> None: ...
    @overload
    def SetSystemResidual(systemResidual) -> None: ...
    @overload
    def SolveSteps(mainSystem, simulationSettings) -> bool: ...
    @overload
    def SolveSystem(mainSystem, simulationSettings) -> bool: ...
    @overload
    def UpdateCurrentTime(mainSystem, simulationSettings) -> None: ...
    @overload
    def VerboseWrite(level, str) -> None: ...
    @overload
    def WriteCoordinatesToFile(mainSystem, simulationSettings) -> None: ...
    @overload
    def WriteSensorsToFile(mainSystem, simulationSettings) -> None: ...
    @overload
    def WriteSolutionFileHeader(mainSystem, simulationSettings) -> None: ...


class MainSolverImplicitSecondOrder:
    """PyBind interface (trampoline) class for dynamic implicit solver. Note that this solver includes the classical Newmark method (set useNewmark True; with option of index 2 reduction) as well as the generalized-alpha method. With the interface, the dynamic implicit solver and its substructures can be accessed via Python. NOTE that except from SolveSystem(...), these functions are only intended for experienced users and they need to be handled with care, as unexpected crashes may happen if used inappropriate. Furthermore, the functions have a lot of overhead (still fast, but performance much lower than internal solver) due to Python interfaces, and should thus be used for small systems. To access the solver in Python, write:; ; ; ``solver = MainSolverImplicitSecondOrder()``; ; ; and hereafter you can access all data and functions via 'solver'.; In this solver, user functions are possible to extend the solver at certain parts, while keeping the overal C++ performance. User functions, which are added with SetUserFunction...(...), have the arguments (MainSolver, MainSystem, simulationSettings), except for ComputeNewtonUpdate which adds the initial flag as an additional argument and ComputeNewtonResidual, which returns the scalar residual."""
    conv: SolverConvergenceData
    """all information about tolerances, errors and residua."""
    it: SolverIterationData
    """all information about iterations (steps, discontinuous iteration, newton,...)."""
    newton: NewtonSettings
    """copy of newton settings from timeint or staticSolver."""
    output: SolverOutputData
    """output modes and timers for exporting solver information and solution."""
    timer: CSolverTimer
    """timer which measures the CPU time of solver sub functions; note that solver structures can only be written indirectly, e.g.,  timer=dynamicSolver.timer; timer.useTimer = False; dynamicSolver.timer=timer; however, dynamicSolver.timer.useTimer cannot be written."""
    alphaF: float
    """copy of parameter in timeIntegration.generalizedAlpha."""
    alphaM: float
    """copy of parameter in timeIntegration.generalizedAlpha."""
    @overload
    def CheckInitialized(mainSystem) -> bool: ...
    @overload
    def ComputeAlgebraicEquations(mainSystem, velocityLevel=False) -> None: ...
    @overload
    def ComputeJacobianAE(mainSystem, scalarFactor_ODE2=1., scalarFactor_ODE2_t=0., scalarFactor_ODE1=1., velocityLevel=False) -> None: ...
    @overload
    def ComputeJacobianODE1RHS(mainSystem, scalarFactor_ODE2=1., scalarFactor_ODE2_t=0., scalarFactor_ODE1=1., computeLoadsJacobian=0) -> None: ...
    @overload
    def ComputeJacobianODE2RHS(mainSystem, scalarFactor_ODE2=1., scalarFactor_ODE2_t=0., scalarFactor_ODE1=1., computeLoadsJacobian=0) -> None: ...
    @overload
    def ComputeLoadFactor(simulationSettings) -> float: ...
    @overload
    def ComputeMassMatrix(mainSystem, scalarFactor=1.) -> None: ...
    @overload
    def ComputeNewtonJacobian(mainSystem, simulationSettings) -> None: ...
    @overload
    def ComputeNewtonResidual(mainSystem, simulationSettings) -> float: ...
    @overload
    def ComputeNewtonUpdate(mainSystem, simulationSettings, initial=True) -> None: ...
    @overload
    def ComputeODE1RHS(mainSystem) -> None: ...
    @overload
    def ComputeODE2RHS(mainSystem) -> None: ...
    @overload
    def DiscontinuousIteration(mainSystem, simulationSettings) -> bool: ...
    factJacAlgorithmic: float
    """locally computed parameter from generalizedAlpha parameters."""
    @overload
    def FinalizeSolver(mainSystem, simulationSettings) -> None: ...
    @overload
    def FinishStep(mainSystem, simulationSettings) -> None: ...
    @overload
    def GetAAlgorithmic() -> ArrayLike: ...
    @overload
    def GetAEsize() -> int: ...
    @overload
    def GetDataSize() -> int: ...
    @overload
    def GetErrorString() -> str: ...
    @overload
    def GetLinearSolverInfo() -> Any: ...
    @overload
    def GetNewtonSolution() -> ArrayLike: ...
    @overload
    def GetODE1size() -> int: ...
    @overload
    def GetODE2size() -> int: ...
    @overload
    def GetSimulationEndTime(simulationSettings) -> float: ...
    @overload
    def GetSolverName() -> str: ...
    @overload
    def GetStartOfStepStateAAlgorithmic() -> ArrayLike: ...
    @overload
    def GetSystemJacobian(sparse=False) -> Any: ...
    @overload
    def GetSystemMassMatrix(sparse=False) -> Any: ...
    @overload
    def GetSystemResidual() -> ArrayLike: ...
    @overload
    def HasAutomaticStepSizeControl(mainSystem, simulationSettings) -> bool: ...
    @overload
    def IncreaseStepSize(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolver(mainSystem, simulationSettings) -> bool: ...
    @overload
    def InitializeSolverData(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolverInitialConditions(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolverOutput(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolverPreChecks(mainSystem, simulationSettings) -> bool: ...
    @overload
    def InitializeStep(mainSystem, simulationSettings) -> None: ...
    @overload
    def IsStaticSolver() -> bool: ...
    @overload
    def IsVerboseCheck(level) -> bool: ...
    newmarkBeta: float
    """copy of parameter in timeIntegration.generalizedAlpha."""
    newmarkGamma: float
    """copy of parameter in timeIntegration.generalizedAlpha."""
    @overload
    def Newton(mainSystem, simulationSettings) -> bool: ...
    @overload
    def PostInitializeSolverSpecific(mainSystem, simulationSettings) -> None: ...
    @overload
    def PostNewton(mainSystem, simulationSettings) -> float: ...
    @overload
    def PreInitializeSolverSpecific(mainSystem, simulationSettings) -> None: ...
    @overload
    def ReduceStepSize(mainSystem, simulationSettings, severity) -> bool: ...
    @overload
    def SetSystemJacobian(systemJacobian) -> None: ...
    @overload
    def SetSystemMassMatrix(systemMassMatrix) -> None: ...
    @overload
    def SetSystemResidual(systemResidual) -> None: ...
    @overload
    def SetUserFunctionComputeNewtonJacobian(mainSystem, userFunction) -> None: ...
    @overload
    def SetUserFunctionComputeNewtonResidual(mainSystem, userFunction) -> None: ...
    @overload
    def SetUserFunctionComputeNewtonUpdate(mainSystem, userFunction) -> None: ...
    @overload
    def SetUserFunctionDiscontinuousIteration(mainSystem, userFunction) -> None: ...
    @overload
    def SetUserFunctionFinishStep(mainSystem, userFunction) -> None: ...
    @overload
    def SetUserFunctionInitializeStep(mainSystem, userFunction) -> None: ...
    @overload
    def SetUserFunctionNewton(mainSystem, userFunction) -> None: ...
    @overload
    def SetUserFunctionPostNewton(mainSystem, userFunction) -> None: ...
    @overload
    def SetUserFunctionUpdateCurrentTime(mainSystem, userFunction) -> None: ...
    @overload
    def SolveSteps(mainSystem, simulationSettings) -> bool: ...
    @overload
    def SolveSystem(mainSystem, simulationSettings) -> bool: ...
    spectralRadius: float
    """copy of parameter in timeIntegration.generalizedAlpha."""
    @overload
    def UpdateCurrentTime(mainSystem, simulationSettings) -> None: ...
    @overload
    def VerboseWrite(level, str) -> None: ...
    @overload
    def WriteCoordinatesToFile(mainSystem, simulationSettings) -> None: ...
    @overload
    def WriteSensorsToFile(mainSystem, simulationSettings) -> None: ...
    @overload
    def WriteSolutionFileHeader(mainSystem, simulationSettings) -> None: ...


class MainSolverExplicit:
    """PyBind interface (trampoline) class for dynamic explicit solver. Note that this solver includes the 1st order explicit Euler scheme and the 4th order Runge-Kutta scheme with 5th order error estimation (DOPRI5). With the interface, the solver and its substructures can be accessed via Python. NOTE that except from SolveSystem(...), these functions are only intended for experienced users and they need to be handled with care, as unexpected crashes may happen if used inappropriate. Furthermore, the functions have a lot of overhead (still fast, but performance much lower than internal solver) due to Python interfaces, and should thus be used for small systems. To access the solver in Python, write; ; ; ``solver = MainSolverExplicit()``; ; ; and hereafter you can access all data and functions via 'solver'.; In this solver, no user functions are possible, but you can use SolverImplicitSecondOrder instead (turning off Newton gives explicit scheme ...)."""
    conv: SolverConvergenceData
    """all information about tolerances, errors and residua."""
    it: SolverIterationData
    """all information about iterations (steps, discontinuous iteration, newton,...)."""
    output: SolverOutputData
    """output modes and timers for exporting solver information and solution."""
    timer: CSolverTimer
    """timer which measures the CPU time of solver sub functions."""
    @overload
    def ComputeLoadFactor(simulationSettings) -> float: ...
    @overload
    def ComputeMassMatrix(mainSystem, scalarFactor=1.) -> None: ...
    @overload
    def ComputeNewtonJacobian(mainSystem, simulationSettings) -> None: ...
    @overload
    def ComputeNewtonResidual(mainSystem, simulationSettings) -> float: ...
    @overload
    def ComputeNewtonUpdate(mainSystem, simulationSettings, initial=True) -> None: ...
    @overload
    def ComputeODE1RHS(mainSystem) -> None: ...
    @overload
    def ComputeODE2RHS(mainSystem) -> None: ...
    @overload
    def DiscontinuousIteration(mainSystem, simulationSettings) -> bool: ...
    @overload
    def FinalizeSolver(mainSystem, simulationSettings) -> None: ...
    @overload
    def FinishStep(mainSystem, simulationSettings) -> None: ...
    @overload
    def GetAEsize() -> int: ...
    @overload
    def GetDataSize() -> int: ...
    @overload
    def GetErrorString() -> str: ...
    @overload
    def GetLinearSolverInfo() -> Any: ...
    @overload
    def GetMethodOrder() -> int: ...
    @overload
    def GetNumberOfStages() -> int: ...
    @overload
    def GetODE1size() -> int: ...
    @overload
    def GetODE2size() -> int: ...
    @overload
    def GetSimulationEndTime(simulationSettings) -> float: ...
    @overload
    def GetSolverName() -> str: ...
    @overload
    def GetSystemMassMatrix(sparse=False) -> Any: ...
    @overload
    def GetSystemResidual() -> ArrayLike: ...
    @overload
    def HasAutomaticStepSizeControl(mainSystem, simulationSettings) -> bool: ...
    @overload
    def IncreaseStepSize(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolver(mainSystem, simulationSettings) -> bool: ...
    @overload
    def InitializeSolverData(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolverInitialConditions(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolverOutput(mainSystem, simulationSettings) -> None: ...
    @overload
    def InitializeSolverPreChecks(mainSystem, simulationSettings) -> bool: ...
    @overload
    def InitializeStep(mainSystem, simulationSettings) -> None: ...
    @overload
    def IsStaticSolver() -> bool: ...
    @overload
    def IsVerboseCheck(level) -> bool: ...
    @overload
    def Newton(mainSystem, simulationSettings) -> bool: ...
    @overload
    def PostInitializeSolverSpecific(mainSystem, simulationSettings) -> None: ...
    @overload
    def PreInitializeSolverSpecific(mainSystem, simulationSettings) -> None: ...
    @overload
    def ReduceStepSize(mainSystem, simulationSettings, severity) -> bool: ...
    @overload
    def SetSystemMassMatrix(systemMassMatrix) -> None: ...
    @overload
    def SetSystemResidual(systemResidual) -> None: ...
    @overload
    def SolveSteps(mainSystem, simulationSettings) -> bool: ...
    @overload
    def SolveSystem(mainSystem, simulationSettings) -> bool: ...
    @overload
    def UpdateCurrentTime(mainSystem, simulationSettings) -> None: ...
    @overload
    def VerboseWrite(level, str) -> None: ...
    @overload
    def WriteCoordinatesToFile(mainSystem, simulationSettings) -> None: ...
    @overload
    def WriteSensorsToFile(mainSystem, simulationSettings) -> None: ...
    @overload
    def WriteSolutionFileHeader(mainSystem, simulationSettings) -> None: ...


class VisuGeneralContact:
    """This structure may contains some visualization parameters in future.

    Currently, all visualization settings are controlled via SC.visualizationSettings
    """
    @overload
    def Reset(self) -> None: 
        """Reset visualization parameters to default values."""
        ...


class GeneralContact:
    """Structure to define general and highly efficient contact functionality in multibody systems, allowing millions of particles, using search trees and parallelized contact computations, mainly intended for explicit solvers."""
    @overload
    def GetPythonObject(self) -> dict: 
        """Convert member variables of GeneralContact into dictionary; use this for debug only!."""
        ...
    @overload
    def Reset(self, freeMemory=True) -> None: 
        """Remove all contact objects and reset contact parameters."""
        ...
    isActive:bool
    """default = True (compute contact); if isActive=False, no contact computation is performed for this contact set."""
    verboseMode:int
    """default = 0; verboseMode = 1 or higher outputs useful information on the contact creation and computation."""
    visualization:VisuGeneralContact
    """access visualization data structure  (``returns a reference``)."""
    resetSearchTreeInterval:int
    """(default=10000) number of search tree updates (contact computation steps) after which the search tree cells are re-created; this costs some time, will free memory in cells that are not needed any more."""
    sphereSphereContact:bool
    """activate/deactivate contact between spheres."""
    sphereSphereFrictionRecycle:bool
    """False: compute static friction force based on tangential velocity; True: recycle friction from previous PostNewton step, which greatly improves convergence, but may lead to unphysical artifacts; will be solved in future by step reduction."""
    keepContactWhilePenetrating:bool
    """True: a sphere-sphere or sphere-triangle contact acts while the bodies penetrate (their gap is negative), and the damping may pull at the end of a contact - as ObjectContactSphereSphere and ObjectContactSphereTriangle do, and as the restitution models assume; False: it acts only while its contact force presses (stiffness times gap plus damping times normal velocity is negative), so the damping never pulls - except a sphere-triangle contact with an explicit solver, which acts while the bodies penetrate in both cases."""
    minRelDistanceSpheresTriangles:float
    """(default=1e-10) tolerance (relative to sphere radiues) below which the contact between triangles and spheres is ignored; used for spheres directly attached to triangles."""
    frictionProportionalZone:float
    r"""(default=0.001) velocity :math:`v_{\mu,reg}` upon which the dry friction coefficient is interpolated linearly (regularized friction model); must be greater 0; very small values cause oscillations in friction force."""
    excludeOverlappingTrigSphereContacts:bool
    """(default=True) for consistent, closed meshes, we can exclude overlapping contact triangles (which would cause holes if mesh is overlapping and not consistent!!!)."""
    excludeDuplicatedTrigSphereContactPoints:bool
    """(default=False) run additional checks for double contacts at edges or vertices, being more accurate but can cause additional costs if many contacts."""
    computeExactStaticTriangleBins:bool
    """(default=True) if True, search tree bins are computed exactly for static triangles while if False, it uses the overall (=very inaccurate) AABB of each triangle in the search tree."""
    computeContactForces:bool
    """(default=False) if True, additional system vector is computed which contains all contact force and torque contributions. In order to recover forces on a single rigid body, the respective LTG-vector has to be used and forces need to be extracted from this system vector; may slow down computations."""
    ancfCableUseExactMethod:bool
    """(default=True) if True, uses exact computation of intersection of 3rd order polynomials and contacting circles."""
    ancfCableNumberOfContactSegments:int
    """(default=1) number of segments to be used in case that ancfCableUseExactMethod=False; maximum number of segments=3."""
    ancfCableMeasuringSegments:int
    """(default=20) number of segments used to approximate geometry for ANCFCable2D elements for measuring with ShortestDistanceAlongLine; with 20 segments the relative error due to approximation as compared to 10 segments usually stays below 1e-8."""
    parallelTaskSplit:int
    """(default=12) general number of tasks per thread (min)."""
    parallelTaskSplitBoundingBoxes:int
    """(default=48) number of tasks per thread for bounding box computations."""
    parallelTaskSplitThreshold:int
    """(default=12) general threshold below which only one task per thread is used."""
    parallelTaskSplitBoundingBoxesThreshold:int
    """(default=400) threshold below which only one task per thread is used, for bounding box computations."""
    @overload
    def SetFrictionPairings(self, frictionPairings: ArrayLike) -> None: 
        """Set Coulomb friction coefficients for pairings of materials (e.g., use material 0,1, then the entries (0,1) and (1,0) define the friction coefficients for this pairing); matrix should be symmetric!.
        
        Examples:
            #set 3 surface friction types, all being 0.1:
            gContact.SetFrictionPairings(0.1*np.ones((3,3)));
        """
        ...
    @overload
    def SetFrictionProportionalZone(self, frictionProportionalZone: float) -> None: 
        """Regularization for friction (m/s); used for all contacts."""
        ...
    @overload
    def SetSearchTreeCellSize(self, numberOfCells: [int,int,int]) -> None: 
        """Set number of cells of search tree (boxed search) in x, y and z direction.
        
        Examples:
            gContact.SetSearchTreeInitSize([10,10,10])
        """
        ...
    @overload
    def SetSearchTreeBox(self, pMin: [float,float,float], pMax: [float,float,float]) -> None: 
        """Set geometric dimensions of searchTreeBox (point with minimum coordinates and point with maximum coordinates); if this box becomes smaller than the effective contact objects, contact computations may slow down significantly.
        
        Examples:
            gContact.SetSearchTreeBox(pMin=[-1,-1,-1],
                pMax=[1,1,1])
        """
        ...
    @overload
    def AddSphereWithMarker(self, markerIndex: MarkerIndex, radius: float, contactStiffness: float, contactDamping: float, frictionMaterialIndex: int) -> int: 
        """Add contact object using a marker (Position or Rigid), radius and contact/friction parameters and return localIndex of the contact item in GeneralContact; frictionMaterialIndex refers to frictionPairings in GeneralContact; contact is possible between spheres (circles in 2D) (if intraSphereContact = True), spheres and triangles and between sphere (=circle) and ANCFCable2D; contactStiffness is computed as serial spring between contacting objects, while damping is computed as a parallel damper."""
        ...
    @overload
    def AddANCFCable(self, objectIndex: ObjectIndex, halfHeight: float, contactStiffness: float, contactDamping: float, frictionMaterialIndex: int) -> int: 
        """Add contact object for an ANCF cable element, using the objectIndex of the cable element and the cable's half height as an additional distance to contacting objects (currently not causing additional torque in case of friction), and return localIndex of the contact item in GeneralContact; currently only contact with spheres (circles in 2D) possible; contact computed using exact geometry of elements, finding max 3 intersecting contact regions."""
        ...
    @overload
    def AddTrianglesRigidBodyBased(self, rigidBodyMarkerIndex: MarkerIndex, contactStiffness: float, contactDamping: float, frictionMaterialIndex: int, pointList: List[[float,float,float]], triangleList: List[[int,int,int]], staticTriangles: bool=False) -> int: 
        """Add contact object using a rigidBodyMarker (of a body), contact/friction parameters, a list of points (as 3D numpy arrays or lists; coordinates relative to rigidBodyMarker) and a list of triangles (3 indices as numpy array or list) according to a mesh attached to the rigidBodyMarker; the flag staticTriangles=True can be used to inform the contact solver that these triangles are static (fixed in space); note that static triangles have to be added before dynamic triangles; function returns starting local index of trigsRigidBodyBased at which the triangles are stored; mesh can be produced with GraphicsData2TrigsAndPoints(...); contact is possible between sphere (circle) and Triangle but yet not between triangle and triangle; frictionMaterialIndex refers to frictionPairings in GeneralContact; contactStiffness is computed as serial spring between contacting objects, while damping is computed as a parallel damper (otherwise the smaller damper would always dominate); the triangle normal must point outwards, with the normal of a triangle given with local points (p0,p1,p2) defined as n=(p1-p0) x (p2-p0), see function ComputeTriangleNormal(...)."""
        ...
    @overload
    def GetItemsInBox(self, pMin: [float,float,float], pMax: [float,float,float]) -> Union[dict,bool]: 
        """Get all items in box defined by minimum coordinates given in pMin and maximum coordinates given by pMax, accepting 3D lists or numpy arrays; in case that no objects are found, False is returned; otherwise, a dictionary is returned, containing numpy arrays with indices of obtained MarkerBasedSpheres, TrigsRigidBodyBased, ANCFCable2D, ...; the indices refer to the local index in GeneralContact which can be evaluated e.g., by GetMarkerBasedSphere(localIndex).
        
        Examples:
            gContact.GetItemsInBox(pMin=[0,1,1],
                pMax=[2,3,2])
        """
        ...
    @overload
    def GetSphereMarkerBased(self, localIndex: int, addData: bool=False) -> dict: 
        """Get dictionary with current position, orientation, velocity, angular velocity as computed in last contact iteration; if addData=True, adds stored data of contact element, such as radius, markerIndex and contact parameters; localIndex is the internal index of contact element, as returned e.g., from GetItemsInBox."""
        ...
    @overload
    def SetSphereMarkerBased(self, localIndex: int, contactStiffness: float=-1., contactDamping: float=-1., radius: float=-1., frictionMaterialIndex: int=-1) -> None: 
        """Set data of marker based sphere with localIndex (as internally stored) with given arguments; arguments that are < 0 (default) imply that current values are not overwritten."""
        ...
    @overload
    def GetTriangleRigidBodyBased(self, localIndex: int) -> dict: 
        """Get dictionary with rigid body index, local position of triangle vertices (nodes) and triangle normal; NOTE: the mesh added to contact is different from this structure, as it contains nodes and connectivity lists; the triangle index corresponds to the order as triangles are added to GeneralContact."""
        ...
    @overload
    def SetTriangleRigidBodyBased(self, localIndex: int, points: NDArray[Shape2D[3,3], float], contactRigidBodyIndex: int=-1) -> None: 
        """Set data of marker based sphere with localIndex (triangle index); points are provided as 3x3 numpy array, with point coordinates in rows; contactRigidBodyIndex<0 indicates no change of the current index (and changing this index should be handled with care)."""
        ...
    @overload
    def ShortestDistanceAlongLine(self, pStart: [float,float,float]=[0,0,0], direction: [float,float,float]=[1,0,0], minDistance: float=-1e-7, maxDistance: float=1e7, asDictionary: bool=False, cylinderRadius: float=0, typeIndex: ContactTypeIndex=ContactTypeIndex.IndexEndOfEnumList) -> Union[dict,float]: 
        """Find shortest distance to contact objects in GeneralContact along line with pStart (given as 3D list or numpy array) and direction (as 3D list or numpy array with no need to be normalized); the function returns the distance which is >= minDistance and < maxDistance; in case of beam elements, it measures the distance to the beam centerline; the distance is measured from pStart along given direction and can also be negative; if no item is found along line, the maxDistance is returned; if asDictionary=False, the result is a float, while otherwise details are returned as dictionary (including distance, velocityAlongLine (which is the object velocity in given direction and may be different from the time derivative of the distance; works similar to a laser Doppler vibrometer - LDV), itemIndex and itemType in GeneralContact); the cylinderRadius, if not equal to 0, will be used for spheres to find closest sphere along cylinder with given point and direction; the typeIndex can be set to a specific contact type, e.g., which are searched for (otherwise all objects are considered)."""
        ...
    @overload
    def UpdateContacts(self, mainSystem: "MainSystem") -> None: 
        """Update contact sets, e.g., if no contact is simulated (isActive=False) but user functions need up-to-date contact states for GetItemsInBox(...) or for GetActiveContacts(...).
        
        Examples:
            gContact.UpdateContacts(mbs)
        """
        ...
    @overload
    def GetActiveContacts(self, typeIndex: ContactTypeIndex, itemIndex: int) -> List[int]: 
        """Get list of global item numbers which are in contact with itemIndex of type typeIndex in case that the global itemIndex is smaller than the abs value of the contact pair index; a negative sign indicates that the contacting (spheres) is in Coloumb friction, a positive sign indicates a regularized friction region; in case of itemIndex==-1, it will return the list of numbers of active contacts per item for the contact type; for interpretation of global contact indices, see gContact.GetPythonObject() and documentation; requires either implicit contact computation or UpdateContacts(...) needs to be called prior to this function.
        
        Examples:
            #if explicit solver is used, we first need to update contacts:
            gContact.UpdateContacts(mbs)
            #obtain active contacts of marker based sphere 42:
            gList = gContact.GetActiveContacts(exu.ContactTypeIndex.IndexSpheresMarkerBased, 42)
        """
        ...
    @overload
    def GetSystemODE2RhsContactForces(self, copy: bool=False) -> List[float]: 
        """Get numpy array of system vector containing contribution of contact forces to system ODE2 Rhs vector; if copy=False, it will give direct (reference) access to the internal vector (note: modifications to this vector do not influence simulation!), however, which may cause problems if the system size changes or simulation is restarted; if copy=True, the vector is copied (time consuming); contributions to single objects may be extracted by checking the according LTG-array of according objects (such as rigid bodies); the contact forces vector is computed in each contact iteration;."""
        ...


class SystemData:
    """A data structure of a MainSystem which mainly allows access to states and details of items (objects, nodes, loads, etc.).

    In particular access is given to system coordinates in all configurations, object and node coordinates, as well as to local-to-global (LTG) coordinate indices
    Here, ODE2 represents second order differential equations (and coordinates), ODE1 for first order ODEs, AE represents algebraic equations, and Data is used for data (=history) variables that represent contact states or plastic deformation which is no classical state
    The SystemData structure allows advanced access to this data, which HAS TO BE USED WITH CARE, as unexpected results and system crash might happen.
    """
    @overload
    def NumberOfLoads(self) -> int: 
        """Return number of loads in system.
        
        Examples:
            print(mbs.systemData.NumberOfLoads())
        """
        ...
    @overload
    def NumberOfMarkers(self) -> int: 
        """Return number of markers in system.
        
        Examples:
            print(mbs.systemData.NumberOfMarkers())
        """
        ...
    @overload
    def NumberOfNodes(self) -> int: 
        """Return number of nodes in system.
        
        Examples:
            print(mbs.systemData.NumberOfNodes())
        """
        ...
    @overload
    def NumberOfObjects(self) -> int: 
        """Return number of objects in system.
        
        Examples:
            print(mbs.systemData.NumberOfObjects())
        """
        ...
    @overload
    def NumberOfMaterials(self) -> int: 
        """Return number of materials in system (#3522).
        
        Examples:
            print(mbs.systemData.NumberOfMaterials())
        """
        ...
    @overload
    def NumberOfSensors(self) -> int: 
        """Return number of sensors in system.
        
        Examples:
            print(mbs.systemData.NumberOfSensors())
        """
        ...
    @overload
    def ODE2Size(self, configurationType: ConfigurationType=ConfigurationType.Current) -> int: 
        """Get size of ODE2 coordinate vector for given configuration (only works correctly after mbs.Assemble() ).
        
        Examples:
            print('ODE2 size=',mbs.systemData.ODE2Size())
        """
        ...
    @overload
    def ODE1Size(self, configurationType: ConfigurationType=ConfigurationType.Current) -> int: 
        """Get size of ODE1 coordinate vector for given configuration (only works correctly after mbs.Assemble() ).
        
        Examples:
            print('ODE1 size=',mbs.systemData.ODE1Size())
        """
        ...
    @overload
    def AEsize(self, configurationType: ConfigurationType=ConfigurationType.Current) -> int: 
        """Get size of AE coordinate vector for given configuration (only works correctly after mbs.Assemble() ).
        
        Examples:
            print('AE size=',mbs.systemData.AEsize())
        """
        ...
    @overload
    def DataSize(self, configurationType: ConfigurationType=ConfigurationType.Current) -> int: 
        """Get size of Data coordinate vector for given configuration (only works correctly after mbs.Assemble() ).
        
        Examples:
            print('Data size=',mbs.systemData.DataSize())
        """
        ...
    @overload
    def SystemSize(self, configurationType: ConfigurationType=ConfigurationType.Current) -> int: 
        """Get size of System coordinate vector for given configuration (only works correctly after mbs.Assemble() ).
        
        Examples:
            print('System size=',mbs.systemData.SystemSize())
        """
        ...
    @overload
    def GetTime(self, configurationType: ConfigurationType=ConfigurationType.Current) -> float: 
        """Get configuration dependent time.
        
        Examples:
            mbs.systemData.GetTime(exu.ConfigurationType.Initial)
        """
        ...
    @overload
    def SetTime(self, newTime: float, configurationType: ConfigurationType=ConfigurationType.Current) -> None: 
        """Set configuration dependent time; use this access with care, e.g., in user-defined solvers.
        
        Examples:
            mbs.systemData.SetTime(10., exu.ConfigurationType.Initial)
        """
        ...
    @overload
    def AddODE2LoadDependencies(self, loadNumber: float, globalODE2coordinates: List[int]) -> None: 
        """Advanced function for adding special dependencies of loads onto ODE2 coordinates, taking a list / numpy array of global ODE2 coordinates; this function needs to be called after Assemble() and needs to contain global ODE2 coordinate indices; this list only affects implicit or static solvers if timeIntegration.computeLoadsJacobian or staticSolver.computeLoadsJacobian is set to 1 (ODE2) or 2 (ODE2 and ODE2_t dependencies); if set, it may greatly improve convergence if loads with user functions depend on some system states, such as in a load with feedback control loop; the additional dependencies are not required, if doSystemWideDifferentiation=True, however the latter option being much less efficient.
        
        For more details, consider the file doublePendulum2DControl.py in the examples directory.
        
        Examples:
            mbs.systemData.AddODE2LoadDependencies(0,[0,1,2])
            #add dependency of load 5 onto node 2 coordinates:
            nodeLTG2 = mbs.systemData.GetNodeLTGODE2(2)
            mbs.systemData.AddODE2LoadDependencies(5,nodeLTG2)
        """
        ...
    @overload
    def AddODE1LoadDependencies(self, loadNumber: float, globalODE1coordinates: List[int]) -> None: 
        """Advanced function for adding special dependencies of loads onto ODE1 coordinates, taking a list / numpy array of global ODE1 coordinates, as AddODE2LoadDependencies does for ODE2 coordinates; it needs to be called after Assemble(); only affects implicit or static solvers if timeIntegration.computeLoadsJacobian or staticSolver.computeLoadsJacobian is set to 1 or 2; the Jacobian of a load on ODE1 coordinates includes the ODE1 coordinates of its node without it (#1548).
        
        Examples:
            nodeLTG1 = mbs.systemData.GetNodeLTGODE1(2)
            mbs.systemData.AddODE1LoadDependencies(5,nodeLTG1)
        """
        ...
    @overload
    def Info(self) -> None: 
        """Print detailed information on every item; for short information use print(mbs).
        
        Examples:
            mbs.systemData.Info()
        """
        ...
    @overload
    def InfoLTG(self) -> None: 
        """Print LTG information of objects and load dependencies.
        
        Examples:
            mbs.systemData.InfoLTG()
        """
        ...
    @overload
    def GetODE2CoordinatesTotal(self, configuration: ConfigurationType=ConfigurationType.Current) -> List[float]: 
        """Get ODE2 system coordinates (displacements/rotation) including reference values for given configuration (default: exu.Configuration.Current); in case of exu.ConfigurationType.Reference, it only includes reference values once and is identical to GetODE2Coordinates; note that faster access to coordinates is possibly with GetODE2Coordinates(copy=False), which is not possible with GetODE2CoordinatesTotal !.
        
        Examples:
            uTotal = mbs.systemData.GetODE2CoordinatesTotal()
            #this is equivalent to:
            uTotal=mbs.systemData.GetODE2Coordinates()+mbs.systemData.GetODE2Coordinates(exu.ConfigurationType.Reference)
        """
        ...
    @overload
    def GetODE2Coordinates(self, configuration: ConfigurationType=ConfigurationType.Current, copy: bool=True) -> List[float]: 
        """Get ODE2 system coordinates (displacements/rotations) for given configuration (default: exu.Configuration.Current).
        
        Examples:
            uCurrent = mbs.systemData.GetODE2Coordinates()
        """
        ...
    @overload
    def SetODE2Coordinates(self, coordinates: List[float], configuration: ConfigurationType=ConfigurationType.Current) -> None: 
        """Set ODE2 system coordinates (displacements/rotations) for given configuration (default: exu.Configuration.Current); invalid vector size may lead to system crash!.
        
        Examples:
            mbs.systemData.SetODE2Coordinates(uCurrent)
        """
        ...
    @overload
    def GetODE2Coordinates_t(self, configuration: ConfigurationType=ConfigurationType.Current, copy: bool=True) -> List[float]: 
        """Get ODE2 system coordinates (velocities) for given configuration (default: exu.Configuration.Current).
        
        Examples:
            vCurrent = mbs.systemData.GetODE2Coordinates_t()
        """
        ...
    @overload
    def SetODE2Coordinates_t(self, coordinates: List[float], configuration: ConfigurationType=ConfigurationType.Current) -> None: 
        """Set ODE2 system coordinates (velocities) for given configuration (default: exu.Configuration.Current); invalid vector size may lead to system crash!.
        
        Examples:
            mbs.systemData.SetODE2Coordinates_t(vCurrent)
        """
        ...
    @overload
    def GetODE2Coordinates_tt(self, configuration: ConfigurationType=ConfigurationType.Current, copy: bool=True) -> List[float]: 
        """Get ODE2 system coordinates (accelerations) for given configuration (default: exu.Configuration.Current).
        
        Examples:
            vCurrent = mbs.systemData.GetODE2Coordinates_tt()
        """
        ...
    @overload
    def SetODE2Coordinates_tt(self, coordinates: List[float], configuration: ConfigurationType=ConfigurationType.Current) -> None: 
        """Set ODE2 system coordinates (accelerations) for given configuration (default: exu.Configuration.Current); invalid vector size may lead to system crash!.
        
        Examples:
            mbs.systemData.SetODE2Coordinates_tt(aCurrent)
        """
        ...
    @overload
    def GetODE1Coordinates(self, configuration: ConfigurationType=ConfigurationType.Current, copy: bool=True) -> List[float]: 
        """Get ODE1 system coordinates (displacements) for given configuration (default: exu.Configuration.Current).
        
        Examples:
            qCurrent = mbs.systemData.GetODE1Coordinates()
        """
        ...
    @overload
    def SetODE1Coordinates(self, coordinates: List[float], configuration: ConfigurationType=ConfigurationType.Current) -> None: 
        """Set ODE1 system coordinates (velocities) for given configuration (default: exu.Configuration.Current); invalid vector size may lead to system crash!.
        
        Examples:
            mbs.systemData.SetODE1Coordinates_t(qCurrent)
        """
        ...
    @overload
    def GetODE1Coordinates_t(self, configuration: ConfigurationType=ConfigurationType.Current, copy: bool=True) -> List[float]: 
        """Get ODE1 system coordinates (velocities) for given configuration (default: exu.Configuration.Current).
        
        Examples:
            qCurrent = mbs.systemData.GetODE1Coordinates_t()
        """
        ...
    @overload
    def SetODE1Coordinates_t(self, coordinates: List[float], configuration: ConfigurationType=ConfigurationType.Current) -> None: 
        """Set ODE1 system coordinates (displacements) for given configuration (default: exu.Configuration.Current); invalid vector size may lead to system crash!.
        
        Examples:
            mbs.systemData.SetODE1Coordinates(qCurrent)
        """
        ...
    @overload
    def GetAECoordinates(self, configuration: ConfigurationType=ConfigurationType.Current, copy: bool=True) -> List[float]: 
        """Get algebraic equations (AE) system coordinates for given configuration (default: exu.Configuration.Current).
        
        Examples:
            lambdaCurrent = mbs.systemData.GetAECoordinates()
        """
        ...
    @overload
    def SetAECoordinates(self, coordinates: List[float], configuration: ConfigurationType=ConfigurationType.Current) -> None: 
        """Set algebraic equations (AE) system coordinates for given configuration (default: exu.Configuration.Current); invalid vector size may lead to system crash!.
        
        Examples:
            mbs.systemData.SetAECoordinates(lambdaCurrent)
        """
        ...
    @overload
    def GetDataCoordinates(self, configuration: ConfigurationType=ConfigurationType.Current, copy: bool=True) -> List[float]: 
        """Get system data coordinates for given configuration (default: exu.Configuration.Current).
        
        Examples:
            dataCurrent = mbs.systemData.GetDataCoordinates()
        """
        ...
    @overload
    def SetDataCoordinates(self, coordinates: List[float], configuration: ConfigurationType=ConfigurationType.Current) -> None: 
        """Set system data coordinates for given configuration (default: exu.Configuration.Current); invalid vector size may lead to system crash!.
        
        Examples:
            mbs.systemData.SetDataCoordinates(dataCurrent)
        """
        ...
    @overload
    def GetSystemState(self, configuration: ConfigurationType=ConfigurationType.Current) -> List[List[float]]: 
        """Get system state for given configuration (default: exu.Configuration.Current); state vectors do not include the non-state derivatives ODE1_t and ODE2_tt and the time; function is copying data - not highly efficient; format of pyList: [ODE2Coords, ODE2Coords_t, ODE1Coords, AEcoords, dataCoords].
        
        Examples:
            sysStateList = mbs.systemData.GetSystemState()
        """
        ...
    @overload
    def SetSystemState(self, systemStateList: List[List[float]], configuration: ConfigurationType=ConfigurationType.Current) -> None: 
        """Set system data coordinates for given configuration (default: exu.Configuration.Current); invalid list of vectors / vector size may lead to system crash; write access to state vectors (but not the non-state derivatives ODE1_t and ODE2_tt and the time); function is copying data - not highly efficient; format of pyList: [ODE2Coords, ODE2Coords_t, ODE1Coords, AEcoords, dataCoords].
        
        Examples:
            mbs.systemData.SetSystemState(sysStateList, configuration = exu.ConfigurationType.Initial)
        """
        ...
    @overload
    def GetSystemStateDict(self, configuration: ConfigurationType=ConfigurationType.Current, reference: bool=False) -> Dict[List[float]]: 
        """Get dictionary with copies of (or references to) system states for given configuration (default: exu.Configuration.Current), with at least the following quantities: ODE1Coords, ODE1Coords_t, ODE2Coords, ODE2Coords_t, ODE2Coords_tt, AECoords, dataCoords; we can obtain copies OR references to vectors without copying, meaning that these vectors then have read-write properties and have to be treated carefully! The dictionary's contents are subject to changes in the future; if reference=False, data is copied.
        
        Examples:
            d = mbs.systemData.GetSystemStateDict()
        """
        ...
    @overload
    def GetObjectLTGODE2(self, objectNumber: int) -> List[int]: 
        """Get object local-to-global coordinate mapping (list of global coordinate indices) for ODE2 coordinates; only available after Assemble().
        
        Examples:
            ltgObject4 = mbs.systemData.GetObjectLTGODE2(4)
        """
        ...
    @overload
    def GetObjectLTGODE1(self, objectNumber: int) -> List[int]: 
        """Get object local-to-global coordinate mapping (list of global coordinate indices) for ODE1 coordinates; only available after Assemble().
        
        Examples:
            ltgObject4 = mbs.systemData.GetObjectLTGODE1(4)
        """
        ...
    @overload
    def GetObjectLTGAE(self, objectNumber: int) -> List[int]: 
        """Get object local-to-global coordinate mapping (list of global coordinate indices) for algebraic equations (AE) coordinates; only available after Assemble().
        
        Examples:
            ltgObject4 = mbs.systemData.GetObjectLTGAE(4)
        """
        ...
    @overload
    def GetObjectLTGData(self, objectNumber: int) -> List[int]: 
        """Get object local-to-global coordinate mapping (list of global coordinate indices) for data coordinates; only available after Assemble().
        
        Examples:
            ltgObject4 = mbs.systemData.GetObjectLTGData(4)
        """
        ...
    @overload
    def GetNodeLTGODE2(self, nodeNumber: int) -> List[int]: 
        """Get node local-to-global coordinate mapping (list of global coordinate indices) for ODE2 coordinates; only available after Assemble().
        
        Examples:
            ltgNode4 = mbs.systemData.GetNodeLTGODE2(4)
        """
        ...
    @overload
    def GetNodeLTGODE1(self, nodeNumber: int) -> List[int]: 
        """Get node local-to-global coordinate mapping (list of global coordinate indices) for ODE1 coordinates; only available after Assemble().
        
        Examples:
            ltgNode4 = mbs.systemData.GetNodeLTGODE1(4)
        """
        ...
    @overload
    def GetNodeLTGAE(self, nodeNumber: int) -> List[int]: 
        """Get node local-to-global coordinate mapping (list of global coordinate indices) for AE coordinates; only available after Assemble().
        
        Examples:
            ltgNode4 = mbs.systemData.GetNodeLTGAE(4)
        """
        ...
    @overload
    def GetNodeLTGData(self, nodeNumber: int) -> List[int]: 
        """Get node local-to-global coordinate mapping (list of global coordinate indices) for Data coordinates; only available after Assemble().
        
        Examples:
            ltgNode4 = mbs.systemData.GetNodeLTGData(4)
        """
        ...


class MainSystem:
    """MainSystem is the class which defines a (multibody) system and it's instance if usually called ``mbs``.

    Interactions with the system are done via MainSystem, either through, e.g., ``mbs.AddObject(...)`` or with create functions, such as ``mbs.CreateRigidBody(...)``; States are accessible via ``mbs.systemData``
    The MainSystem shall only be created from a SystemContainer ``SC`` using ``SC.AddSystem()``; do not use ``exu.MainSystem()``, as the latter one would not be linked to a SystemContainer
    Having already a valid ``mbs``, you may use ``SC.AppendSystem(mbs)``.
    """
    @overload
    def Assemble(self) -> None: 
        """Assemble items (nodes, bodies, markers, loads, ...) of multibody system; Calls CheckSystemIntegrity(...), AssembleCoordinates(), AssembleLTGLists(), AssembleInitializeSystemCoordinates(), and AssembleSystemInitialize()."""
        ...
    @overload
    def AssembleCoordinates(self) -> None: 
        """Assemble coordinates: assign computational coordinates to nodes and constraints (algebraic variables)."""
        ...
    @overload
    def AssembleLTGLists(self) -> None: 
        """Build LTG coordinate lists for objects (used to build global ODE2RHS, MassMatrix, etc.
        
        vectors and matrices) and store special object lists (body, connector, constraint, ...)
        """
        ...
    @overload
    def AssembleInitializeSystemCoordinates(self) -> None: 
        """Initialize all system-wide coordinates based on initial values given in nodes."""
        ...
    @overload
    def AssembleSystemInitialize(self) -> None: 
        """Initialize some system data, e.g., generalContact objects (searchTree, etc.)."""
        ...
    @overload
    def Reset(self) -> None: 
        """Reset all lists of items (nodes, bodies, markers, loads, ...) and temporary vectors; deallocate memory."""
        ...
    @overload
    def GetSystemContainer(self) -> "SystemContainer": 
        """Return the systemContainer where the mainSystem (mbs) was created."""
        ...
    @overload
    def WaitForUserToContinue(self, printMessage=True, deprecationWarning=True) -> None: 
        """Interrupt further computation until user input --> 'pause' function; this command runs a loop in the background to have active response of the render window, e.g., to open the visualization dialog or use the right-mouse-button; behaves similar as SC.WaitForRenderEngineStopFlag(); removed in 2029."""
        ...
    @overload
    def SendRedrawSignal(self) -> None: 
        """This function is used to send a signal to the renderer that the scene shall be redrawn because the visualization state has been updated."""
        ...
    @overload
    def GetRenderEngineStopFlag(self) -> bool: 
        """Get the current stop simulation flag; True=user wants to stop simulation."""
        ...
    @overload
    def SetRenderEngineStopFlag(self, stopFlag: bool) -> None: 
        """Set the current stop simulation flag; set to False, in order to continue a previously user-interrupted simulation."""
        ...
    @overload
    def ActivateRendering(self, flag: bool=True) -> None: 
        """Activate (flag=True) or deactivate (flag=False) rendering for this system."""
        ...
    @overload
    def SetPreStepUserFunction(self, value: Callable[["MainSystem", float],bool]) -> None: 
        """Sets a user function PreStepUserFunction(mbs, t) executed at beginning of every computation step; in normal case return True; return False to stop simulation after current step; set to 0 (integer) in order to erase user function.
        
        Note that the time t in the args is already the end of the step, which allows to compute forces consistently with trapezoidal integrators. A value set here is constant during the step: the multi-stage solvers (Runge-Kutta, explicit and implicit) evaluate the system at stage times and lose their order, and a constraint offset set here may not converge; prescribe values that change with time by time user functions of the items or set them in the PreStageUserFunction, see the section Prescribed values and the stage times of the solver chapter (#3535). The PreStepUserFunction is recommended e.g., for prescribing forces or set values of actuators with generalized-alpha and the trapezoidal solvers
        
        Examples:
            def PreStepUserFunction(mbs, t):
                print(mbs.systemData.NumberOfNodes())
                if(t>1):
                    return False
                return True
            mbs.SetPreStepUserFunction(PreStepUserFunction)
        """
        ...
    @overload
    def GetPreStepUserFunction(self, asDict: bool=False) -> Callable[["MainSystem", float],bool]: 
        """Returns the preStepUserFunction."""
        ...
    @overload
    def SetPostStepUserFunction(self, value: Callable[["MainSystem", float],bool]) -> None: 
        """Sets a user function PostStepUserFunction(mbs, t) executed at end of every computation step; in normal case return True; return False to stop simulation after current step; set to 0 (integer) in order to erase user function.
        
        The difference to PreStepUserFunction, the PostStepUserFunction is called after the step has been computed, AFTER the discontinuous iterations, just BEFORE writing solution file, sensors and visualization. This allows to change or evaluate results before they are stored (e.g., do some projection).
        
        Examples:
            def PostStepUserFunction(mbs, t):
                print(mbs.systemData.NumberOfNodes())
                if(t>1):
                    return False
                return True
            mbs.SetPostStepUserFunction(PostStepUserFunction)
        """
        ...
    @overload
    def GetPostStepUserFunction(self, asDict: bool=False) -> Callable[["MainSystem", float],bool]: 
        """Returns the postStepUserFunction."""
        ...
    @overload
    def SetPostNewtonUserFunction(self, value: Callable[["MainSystem", float],[float,float]]) -> None: 
        """Sets a user function PostNewtonUserFunction(mbs, t) executed after successful Newton iteration in implicit or static solvers and after step update of explicit solvers, but BEFORE PostNewton functions are called by the solver; function returns list [discontinuousError, recommendedStepSize], containing a error of the PostNewtonStep, which is compared to [solver].discontinuous.iterationTolerance.
        
        The recommendedStepSize shall be negative, if no recommendation is given, 0 in order to enforce minimum step size or a specific value to which the current step size will be reduced and the step will be repeated; use this function, e.g., to reduce step size after impact or change of data variables; set to 0 (integer) in order to erase user function. Similar described by Flores and Ambrosio, https://doi.org/10.1007/s11044-010-9209-8
        
        Examples:
            def PostNewtonUserFunction(mbs, t):
                if(t>1):
                    return [0, 1e-6]
                return [0,0]
            mbs.SetPostNewtonUserFunction(PostNewtonUserFunction)
        """
        ...
    @overload
    def GetPostNewtonUserFunction(self, asDict: bool=False) -> Callable[["MainSystem", float],bool]: 
        """Returns the postNewtonUserFunction."""
        ...
    @overload
    def SetPreNewtonResidualUserFunction(self, value: Callable[["MainSystem", float, int, int],None]) -> None: 
        """Sets a user function PreNewtonResidualUserFunction(mbs, t, newtonIt, discontinuousIt) executed prior to computation of the Newton residual in implicit or static solvers; in the implicit Runge-Kutta solvers once per residual of all stages, with the time of the end of the step (#3535).
        
        This function returns nothing. The arguments newtonIt and discontinuousIt may be used to distinguish if the call is done at the beginning of a discontinuous iteration (newtonIt=0) or during Newton iterations (newtonIt>0). The typical use case would be to modify objects or loads in every iteration. Note that this user function is not called during Jacobian computation. If needed, the jacobian can be modified with the user function set by SetSystemJacobianUserFunction.
        
        Examples:
            def PreNewtonResidualUserFunction(mbs, t, newtonIt, discontinuousIt):
                print("t=",t,", newtonIt=",newtonIt,", discIt=",discontinuousIt)
            mbs.SetPreNewtonResidualUserFunction(PreNewtonResidualUserFunction)
        """
        ...
    @overload
    def GetPreNewtonResidualUserFunction(self, asDict: bool=False) -> Callable[["MainSystem", float, int, int],None]: 
        """Returns the preNewtonResidualUserFunction."""
        ...
    @overload
    def SetPreStageUserFunction(self, value: Callable[["MainSystem", float],None]) -> None: 
        """Sets a user function PreStageUserFunction(mbs, t) executed at the time t of each stage, before the system is evaluated there: at each stage of the explicit and implicit Runge-Kutta solvers, before each residual of generalized-alpha, the trapezoidal and the static solvers, and at the end of each step; it returns nothing; set to 0 (integer) in order to erase the user function.
        
        Values set here (loads, parameters of objects, control targets) follow the stage times, so the multi-stage solvers keep their order; it is called several times per step and per Newton iteration, so it shall be cheap and depend only on t and the system state. A constraint whose offset is set here sees no velocity of the offset; use offsetUserFunction with offsetUserFunction_t for prescribed constraints. See the section Prescribed values and the stage times of the solver chapter (#3535).
        
        Examples:
            def PreStageUserFunction(mbs, t):
                mbs.SetLoadParameter(load, 'loadVector', [10*np.sin(2*t),0,0])
            mbs.SetPreStageUserFunction(PreStageUserFunction)
        """
        ...
    @overload
    def GetPreStageUserFunction(self, asDict: bool=False) -> Callable[["MainSystem", float],None]: 
        """Returns the preStageUserFunction."""
        ...
    @overload
    def SetSystemJacobianUserFunction(self, value: Callable[["MainSystem", float, float, float, float],Any]) -> None: 
        """Sets a user function SystemJacobianUserFunction(mbs, t, factorODE2, factorODE2_t, factorODE1) executed after computation of the Newton jacobian of a static solver or an implicit timeintegrator; The function shall return additional terms for the jacobian at RHS, e.g., related to dependencies that are added by the user in the PreNewtonResidualUserFunction; RHS means that for a spring with stiffness K, the jacobian would be -K as it is computed for the RHS, see the RHS-LHS convention.
        
        If you like to completely replace the jacobian, consider using the solver's user function SetUserFunctionComputeNewtonJacobian which can be used to replace the jacobian computation; the factors factorODE2, factorODE2_t, factorODE1 must be multiplied with quantities related to ODE2 coordinates (like stiffness terms), ODE2_t velocity coordinates (like damping terms) and ODE1 quantities. The functions returns a MatrixContainer, for which the sparse format is recommended for efficiency reasons.
        
        Examples:
            def SystemJacobianUserFunction(mbs, t, factorODE2, factorODE2_t, factorODE1):
                return MatrixContainer([[factorODE2*10,0],[0,0]])
            mbs.SetSystemJacobianUserFunction(SystemJacobianUserFunction)
        """
        ...
    @overload
    def GetSystemJacobianUserFunction(self, asDict: bool=False) -> Callable[["MainSystem", float, float, float, float],Any]: 
        """Returns the systemJacobianUserFunction."""
        ...
    @overload
    def AddGeneralContact(self) -> GeneralContact: 
        """Add a new general contact, used to enable efficient contact computation between objects (nodes or markers) (`returns a reference`)."""
        ...
    @overload
    def GetGeneralContact(self, generalContactNumber: int) -> GeneralContact: 
        """Get read/write access to GeneralContact with index generalContactNumber stored in mbs; Examples shows how to access the GeneralContact object added with last AddGeneralContact() command: (`returns a reference`).
        
        Examples:
            gc=mbs.GetGeneralContact(mbs.NumberOfGeneralContacts()-1)
        """
        ...
    @overload
    def DeleteGeneralContact(self, generalContactNumber: int) -> None: 
        """Delete GeneralContact with index generalContactNumber in mbs; other general contacts are resorted (index changes!)."""
        ...
    @overload
    def NumberOfGeneralContacts(self) -> int: 
        """Return number of GeneralContact objects in mbs."""
        ...
    @overload
    def GetAvailableFactoryItems(self) -> dict: 
        """Get all available items to be added (nodes, objects, etc.); this is useful in particular in case of additional user elements to check if they are available; the available items are returned as dictionary, containing lists of strings for Node, Object, etc."""
        ...
    @overload
    def GetDictionary(self) -> dict: 
        """[UNDER DEVELOPMENT]: return the dictionary of the system data (todo: and state), e.g., to copy the system or for pickling."""
        ...
    @overload
    def SetDictionary(self, systemDict: dict) -> None: 
        """[UNDER DEVELOPMENT]: set system data (todo: and state) from given dictionary; used for pickling."""
        ...
    systemIsConsistent:bool
    """this flag is used by solvers to decide, whether the system is in a solvable state; this flag is set to False as long as Assemble() has not been called; any modification to the system, such as Add...(), Modify...(), etc. will set the flag to False again; this flag can be modified (set to True), if a change of e.g.~an object (change of stiffness) or load (change of force) keeps the system consistent, but would normally lead to systemIsConsistent=False."""
    interactiveMode:bool
    """set this flag to True in order to invoke a Assemble() command in every system modification, e.g., AddNode, AddObject, ModifyNode, ...; this helps that the system can be visualized in interactive mode."""
    variables:dict
    """this dictionary may be used by the user to store model-specific data, in order to avoid global Python variables in complex models; mbs.variables['myvar'] = 42  (``returns a reference``)."""
    @property
    def symbolicVariables(self) -> exudyn.symbolic.VariableSet:
        """the scope of the named symbolic variables of the model, an exudyn.symbolic.VariableSet: esym.Real(name, value, scope=mbs) creates one there, or takes the one of that name and sets its value; the symbolic user functions of the model read only these named variables and their arguments, and SymbolicSystem takes its parameters from them; mbs.Reset() empties it, and it is part of the dictionary and the pickle of the system (#3208)."""
        ...
    sys:dict
    """this dictionary is used by exudyn Python libraries, e.g., solvers, to avoid global Python variables  (``returns a reference``)."""
    solverSignalJacobianUpdate:bool
    """this flag is used by solvers to decide, whether the jacobian should be updated; at beginning of simulation and after jacobian computation, this flag is set automatically to False; use this flag to indicate system changes, e.g., during time integration."""
    systemData:SystemData
    """Access to SystemData structure; enables access to number of nodes, objects, ... and to (current, initial, reference, ...) state variables (ODE2, AE, Data,...) (``returns a reference``)."""
    @overload
    def AddNode(self, pyObject: Any) -> NodeIndex: 
        """Add a node with nodeDefinition from Python node class; returns (global) node index (type NodeIndex) of newly added node; use int(nodeIndex) to convert to int, if needed (but not recommended in order not to mix up index types of nodes, objects, markers, ...).
        
        Examples:
            item = Rigid2D( referenceCoordinates= [1,0.5,0], initialVelocities= [10,0,0])
            mbs.AddNode(item)
            nodeDict = {'nodeType': 'Point',
            'referenceCoordinates': [1.0, 0.0, 0.0],
            'initialCoordinates': [0.0, 2.0, 0.0],
            'name': 'example node'}
            mbs.AddNode(nodeDict)
        """
        ...
    @overload
    def DeleteNode(self, nodeNumber: NodeIndex, suppressWarnings: bool=False) -> None: 
        """Delete the node with nodeNumber in MainSystem; consistently renames nodes according to their new node numbers; adapts node numbers in sensors and in markers; items using deleted nodeNumber obtain invalid nodeNumber.
        
        Examples:
            mbs.DeleteNode(nodeNumber=42)
        """
        ...
    @overload
    def GetNodeNumber(self, nodeName: str) -> NodeIndex: 
        """Get node's number by name (string).
        
        Examples:
            n = mbs.GetNodeNumber('example node')
        """
        ...
    @overload
    def GetNode(self, nodeNumber: NodeIndex) -> dict: 
        """Get node's dictionary by node number (type NodeIndex).
        
        Examples:
            nodeDict = mbs.GetNode(0)
        """
        ...
    @overload
    def ModifyNode(self, nodeNumber: NodeIndex, nodeDict: dict) -> None: 
        """Modify node's dictionary by node number (type NodeIndex).
        
        Examples:
            mbs.ModifyNode(nodeNumber, nodeDict)
        """
        ...
    @overload
    def GetNodeDefaults(self, typeName: str) -> dict: 
        """Get node's default values for a certain nodeType as (dictionary).
        
        Examples:
            nodeType = 'Point'
            nodeDict = mbs.GetNodeDefaults(nodeType)
        """
        ...
    @overload
    def GetNodeOutput(self, nodeNumber: NodeIndex, variableType: OutputVariableType, configuration: ConfigurationType=ConfigurationType.Current) -> List[float]: 
        """Get the ouput of the node specified with the OutputVariableType; output may be scalar or array (e.g., displacement vector).
        
        Examples:
            mbs.GetNodeOutput(nodeNumber=0, variableType=exu.OutputVariableType.Displacement)
        """
        ...
    @overload
    def GetNodeODE2Index(self, nodeNumber: NodeIndex) -> int: 
        """Get index in the global ODE2 coordinate vector for the first node coordinate of the specified node.
        
        Examples:
            mbs.GetNodeODE2Index(nodeNumber=0)
        """
        ...
    @overload
    def GetNodeODE1Index(self, nodeNumber: NodeIndex) -> int: 
        """Get index in the global ODE1 coordinate vector for the first node coordinate of the specified node.
        
        Examples:
            mbs.GetNodeODE1Index(nodeNumber=0)
        """
        ...
    @overload
    def GetNodeAEIndex(self, nodeNumber: NodeIndex) -> int: 
        """Get index in the global AE coordinate vector for the first node coordinate of the specified node.
        
        Examples:
            mbs.GetNodeAEIndex(nodeNumber=0)
        """
        ...
    @overload
    def GetNodeParameter(self, nodeNumber: NodeIndex, parameterName: str) -> Any: 
        """Get nodes's parameter from node number (type NodeIndex) and parameterName; parameter names can be found for the specific items in the reference manual; for visualization parameters, use a 'V' as a prefix.
        
        Examples:
            mbs.GetNodeParameter(0, 'referenceCoordinates')
        """
        ...
    @overload
    def SetNodeParameter(self, nodeNumber: NodeIndex, parameterName: str, value: Any) -> None: 
        """Set parameter 'parameterName' of node with node number (type NodeIndex) to value; parameter names can be found for the specific items in the reference manual; for visualization parameters, use a 'V' as a prefix.
        
        Examples:
            mbs.SetNodeParameter(0, 'Vshow', True)
        """
        ...
    @overload
    def AddObject(self, pyObject: Any) -> ObjectIndex: 
        """Add an object with objectDefinition from Python object class; returns (global) object number (type ObjectIndex) of newly added object.
        
        Examples:
            item = MassPoint(name='heavy object', nodeNumber=0, mass=100)
            mbs.AddObject(item)
            objectDict = {'objectType': 'MassPoint',
            'mass': 10,
            'nodeNumber': 0,
            'name': 'example object'}
            mbs.AddObject(objectDict)
        """
        ...
    @overload
    def DeleteObject(self, objectNumber: ObjectIndex, deleteDependentItems: bool=True, suppressWarnings: bool=False) -> None: 
        """Delete the object with objectNumber in MainSystem; consistently renames objects according to their new object numbers; adapts object numbers in sensors and in markers; items using deleted objectNumber obtain invalid objectNumber; with the option deleteDependentItems (default=True) the function also delete nodes and markers which are used by the object.
        
        Examples:
            mbs.DeleteObject(objectNumber=42)
        """
        ...
    @overload
    def GetObjectNumber(self, objectName: str) -> ObjectIndex: 
        """Get object's number by name (string).
        
        Examples:
            n = mbs.GetObjectNumber('heavy object')
        """
        ...
    @overload
    def GetObject(self, objectNumber: ObjectIndex, addGraphicsData: bool=False) -> dict: 
        """Get object's dictionary by object number (type ObjectIndex); NOTE: visualization parameters have a prefix 'V'; in order to also get graphicsData written, use addGraphicsData=True (which is by default False, as it would spoil the information).
        
        Examples:
            objectDict = mbs.GetObject(0)
        """
        ...
    @overload
    def ModifyObject(self, objectNumber: ObjectIndex, objectDict: dict) -> None: 
        """Modify object's dictionary by object number (type ObjectIndex); NOTE: visualization parameters have a prefix 'V'.
        
        Examples:
            mbs.ModifyObject(objectNumber, objectDict)
        """
        ...
    @overload
    def GetObjectDefaults(self, typeName: str) -> dict: 
        """Get object's default values for a certain objectType as (dictionary).
        
        Examples:
            objectType = 'MassPoint'
            objectDict = mbs.GetObjectDefaults(objectType)
        """
        ...
    @overload
    def GetObjectOutput(self, objectNumber: ObjectIndex, variableType: OutputVariableType, configuration: ConfigurationType=ConfigurationType.Current) -> List[float]: 
        """Get object's current output variable from object number (type ObjectIndex) and OutputVariableType; for connectors, it can only be computed for exu.ConfigurationType.Current configuration!."""
        ...
    @overload
    def Inspect(self, itemIndex: Any, what: InspectType=None) -> Any: 
        """What an item provides and requests (#2203): for the typed index of an object, node, marker, load or sensor and a what of type exu.InspectType, a list of exported enumeration members - the output variables (OutputVariableType; energies only where they can be computed with the current parameters), the object, node or marker type flags (ObjectType, NodeType, MarkerType), the requested node types per node (for a node marker: requirements, each a list of alternatives) or marker types per marker, the access functions of a body (AccessFunctionType); with what=None a dict of all that apply to the item; a what that does not apply raises with the list of those that do.
        
        Examples:
            mbs.Inspect(oMassPoint, exu.InspectType.OutputVariables)
            mbs.Inspect(oSpringDamper) #all that apply
        """
        ...
    @overload
    def ComputeItem(self, itemIndex: Any, what: ComputeItemType=None, localPosition: Vector3D=[0.,0.,0.], vector: Any=None) -> Any: 
        """Compute a function of an item at the current state of the system (#2779) - for tests and the debugging of items: for the typed index of an object, node or marker and a what of type exu.ComputeItemType, a numpy array (a dict for the kinematics of a marker), in the coordinates of the item; localPosition is the position in a body, vector the force and torque of a Jacobian derivative; with what=None the list of what applies to the item; a what that does not apply raises with that list; the system must be assembled; exudyn.systemUtilities.NumericalJacobian gives the numerical derivative to compare with.
        
        Examples:
            mbs.ComputeItem(oBody, exu.ComputeItemType.PositionJacobian, localPosition=[0.1,0,0])
            mbs.ComputeItem(oBody) #what applies
        """
        ...
    @overload
    def GetObjectOutputBody(self, objectNumber: ObjectIndex, variableType: OutputVariableType, localPosition: [float,float,float]=[0,0,0], configuration: ConfigurationType=ConfigurationType.Current) -> List[float]: 
        """Get body's output variable from object number (type ObjectIndex) and OutputVariableType, using the localPosition as defined in the body, and as used in MarkerBody and SensorBody.
        
        Examples:
            u = mbs.GetObjectOutputBody(objectNumber = 1, variableType = exu.OutputVariableType.Position, localPosition=[1,0,0], configuration = exu.ConfigurationType.Initial)
        """
        ...
    @overload
    def GetObjectOutputSuperElement(self, objectNumber: ObjectIndex, variableType: OutputVariableType, meshNodeNumber: int, configuration: ConfigurationType=ConfigurationType.Current) -> List[float]: 
        """Get output variable from mesh node number of object with type SuperElement (GenericODE2, FFRF, FFRFreduced - CMS) with specific OutputVariableType; the meshNodeNumber is the object's local node number, not the global node number!.
        
        Examples:
            u = mbs.GetObjectOutputSuperElement(objectNumber = 1, variableType = exu.OutputVariableType.Position, meshNodeNumber = 12, configuration = exu.ConfigurationType.Initial)
        """
        ...
    @overload
    def GetObjectOutputIntegrationPoints(self, objectNumber: ObjectIndex, variableType: OutputVariableType, configuration: ConfigurationType=ConfigurationType.Current) -> List[float]: 
        """Get the output variable at the integration points of a body, as a numpy array of one row per point; for ObjectSolidFEM the points of its elements in their order, the order of its initialStress; available for ObjectSolidTetrahedron and ObjectSolidFEM: Position, Displacement (3 columns), StrainLocal, StressLocal, Strain, Stress, StrainPlasticLocal (6 columns, Voigt), call after mbs.Assemble() (#3597).
        
        Examples:
            S = mbs.GetObjectOutputIntegrationPoints(objectNumber = 1, variableType = exu.OutputVariableType.StressLocal)
        """
        ...
    @overload
    def GetObjectParameter(self, objectNumber: ObjectIndex, parameterName: str) -> Any: 
        """Get objects's parameter from object number (type ObjectIndex) and parameterName; parameter names can be found for the specific items in the reference manual; for visualization parameters, use a 'V' as a prefix; NOTE that BodyGraphicsData cannot be get or set, use dictionary access instead.
        
        Examples:
            mbs.GetObjectParameter(objectNumber = 0, parameterName = 'nodeNumber')
        """
        ...
    @overload
    def SetObjectParameter(self, objectNumber: ObjectIndex, parameterName: str, value: Any) -> None: 
        """Set parameter 'parameterName' of object with object number (type ObjectIndex) to value;; parameter names can be found for the specific items in the reference manual; for visualization parameters, use a 'V' as a prefix; NOTE that BodyGraphicsData cannot be get or set, use dictionary access instead.
        
        Examples:
            mbs.SetObjectParameter(objectNumber = 0, parameterName = 'Vshow', value=True)
        """
        ...
    @overload
    def AddMarker(self, pyObject: Any) -> MarkerIndex: 
        """Add a marker with markerDefinition from Python marker class; returns (global) marker number (type MarkerIndex) of newly added marker.
        
        Examples:
            item = MarkerNodePosition(name='my marker',nodeNumber=1)
            mbs.AddMarker(item)
            markerDict = {'markerType': 'NodePosition',
              'nodeNumber': 0,
              'name': 'position0'}
            mbs.AddMarker(markerDict)
        """
        ...
    @overload
    def DeleteMarker(self, markerNumber: MarkerIndex, suppressWarnings: bool=False) -> None: 
        """Delete the marker with markerNumber in MainSystem; consistently renames markers according to their new marker numbers; adapts marker numbers in objects, loads and sensors; items using deleted markerNumber obtain invalid markerNumber.
        
        Examples:
            mbs.DeleteMarker(markerNumber=42)
        """
        ...
    @overload
    def GetMarkerNumber(self, markerName: str) -> MarkerIndex: 
        """Get marker's number by name (string).
        
        Examples:
            n = mbs.GetMarkerNumber('my marker')
        """
        ...
    @overload
    def GetMarker(self, markerNumber: MarkerIndex) -> dict: 
        """Get marker's dictionary by index.
        
        Examples:
            markerDict = mbs.GetMarker(0)
        """
        ...
    @overload
    def ModifyMarker(self, markerNumber: MarkerIndex, markerDict: dict) -> None: 
        """Modify marker's dictionary by index.
        
        Examples:
            mbs.ModifyMarker(markerNumber, markerDict)
        """
        ...
    @overload
    def GetMarkerDefaults(self, typeName: str) -> dict: 
        """Get marker's default values for a certain markerType as (dictionary).
        
        Examples:
            markerType = 'NodePosition'
            markerDict = mbs.GetMarkerDefaults(markerType)
        """
        ...
    @overload
    def GetMarkerParameter(self, markerNumber: MarkerIndex, parameterName: str) -> Any: 
        """Get markers's parameter from markerNumber and parameterName; parameter names can be found for the specific items in the reference manual."""
        ...
    @overload
    def SetMarkerParameter(self, markerNumber: MarkerIndex, parameterName: str, value: Any) -> None: 
        """Set parameter 'parameterName' of marker with markerNumber to value; parameter names can be found for the specific items in the reference manual."""
        ...
    @overload
    def GetMarkerOutput(self, markerNumber: MarkerIndex, variableType: OutputVariableType, configuration: ConfigurationType=ConfigurationType.Current) -> List[float]: 
        """Get the ouput of the marker specified with the OutputVariableType; currently only provides Displacement, Position and Velocity for position based markers, and RotationMatrix, Rotation and AngularVelocity(Local) for markers providing orientation; Coordinates and Coordinates_t available for coordinate markers.
        
        Examples:
            mbs.GetMarkerOutput(markerNumber=0, variableType=exu.OutputVariableType.Position)
        """
        ...
    @overload
    def AddLoad(self, pyObject: Any) -> LoadIndex: 
        """Add a load with loadDefinition from Python load class; returns (global) load number (type LoadIndex) of newly added load.
        
        Examples:
            item = mbs.AddLoad(LoadForceVector(loadVector=[1,0,0], markerNumber=0, name='heavy load'))
            mbs.AddLoad(item)
            loadDict = {'loadType': 'ForceVector',
              'markerNumber': 0,
              'loadVector': [1.0, 0.0, 0.0],
              'name': 'heavy load'}
            mbs.AddLoad(loadDict)
        """
        ...
    @overload
    def DeleteLoad(self, loadNumber: LoadIndex, deleteDependentMarkers: bool=True, suppressWarnings: bool=False) -> None: 
        """Delete the load with loadNumber in MainSystem; consistently renames loads according to their new load numbers; deleteDependentMarkers (default=True) also deletes the corresponding marker.
        
        Examples:
            mbs.DeleteLoad(loadNumber=42)
        """
        ...
    @overload
    def GetLoadNumber(self, loadName: str) -> LoadIndex: 
        """Get load's number by name (string).
        
        Examples:
            n = mbs.GetLoadNumber('heavy load')
        """
        ...
    @overload
    def GetLoad(self, loadNumber: LoadIndex) -> dict: 
        """Get load's dictionary by index.
        
        Examples:
            loadDict = mbs.GetLoad(0)
        """
        ...
    @overload
    def ModifyLoad(self, loadNumber: LoadIndex, loadDict: dict) -> None: 
        """Modify load's dictionary by index.
        
        Examples:
            mbs.ModifyLoad(loadNumber, loadDict)
        """
        ...
    @overload
    def GetLoadDefaults(self, typeName: str) -> dict: 
        """Get load's default values for a certain loadType as (dictionary).
        
        Examples:
            loadType = 'ForceVector'
            loadDict = mbs.GetLoadDefaults(loadType)
        """
        ...
    @overload
    def GetLoadValues(self, loadNumber: LoadIndex) -> List[float]: 
        """Get current load values, specifically if user-defined loads are used; can be scalar or vector-valued return value."""
        ...
    @overload
    def GetLoadParameter(self, loadNumber: LoadIndex, parameterName: str) -> Any: 
        """Get loads's parameter from loadNumber and parameterName; parameter names can be found for the specific items in the reference manual."""
        ...
    @overload
    def SetLoadParameter(self, loadNumber: LoadIndex, parameterName: str, value: Any) -> None: 
        """Set parameter 'parameterName' of load with loadNumber to value; parameter names can be found for the specific items in the reference manual."""
        ...
    @overload
    def AddSensor(self, pyObject: Any) -> SensorIndex: 
        """Add a sensor with sensor definition from Python sensor class; returns (global) sensor number (type SensorIndex) of newly added sensor.
        
        Examples:
            item = mbs.AddSensor(SensorNode(sensorType= exu.SensorType.Node, nodeNumber=0, name='test sensor'))
            mbs.AddSensor(item)
            sensorDict = {'sensorType': 'Node',
              'nodeNumber': 0,
              'fileName': 'sensor.txt',
              'name': 'test sensor'}
            mbs.AddSensor(sensorDict)
        """
        ...
    @overload
    def DeleteSensor(self, sensorNumber: SensorIndex, suppressWarnings: bool=False) -> None: 
        """Delete the marker with sensorNumber in MainSystem; consistently renames sensors according to their new sensor numbers; adapts sensor numbers in sensors; items using deleted sensorNumber obtain invalid sensorNumber.
        
        Examples:
            mbs.DeleteSensor(sensorNumber=42)
        """
        ...
    @overload
    def GetSensorNumber(self, sensorName: str) -> SensorIndex: 
        """Get sensor's number by name (string).
        
        Examples:
            n = mbs.GetSensorNumber('test sensor')
        """
        ...
    @overload
    def GetSensor(self, sensorNumber: SensorIndex) -> dict: 
        """Get sensor's dictionary by index.
        
        Examples:
            sensorDict = mbs.GetSensor(0)
        """
        ...
    @overload
    def ModifySensor(self, sensorNumber: SensorIndex, sensorDict: dict) -> None: 
        """Modify sensor's dictionary by index.
        
        Examples:
            mbs.ModifySensor(sensorNumber, sensorDict)
        """
        ...
    @overload
    def GetSensorDefaults(self, typeName: str) -> dict: 
        """Get sensor's default values for a certain sensorType as (dictionary).
        
        Examples:
            sensorType = 'Node'
            sensorDict = mbs.GetSensorDefaults(sensorType)
        """
        ...
    @overload
    def GetSensorValues(self, sensorNumber: SensorIndex, configuration: ConfigurationType=ConfigurationType.Current) -> List[float]: 
        """Get sensors's values for configuration; can be a scalar or vector-valued return value!."""
        ...
    @overload
    def GetSensorStoredData(self, sensorNumber: SensorIndex) -> ArrayLike: 
        """Get sensors's internally stored data as matrix (all time points stored); rows are containing time and sensor values as obtained by sensor (e.g., time, and x, y, and z value of position)."""
        ...
    @overload
    def GetSensorParameter(self, sensorNumber: SensorIndex, parameterName: str) -> Any: 
        """Get sensors's parameter from sensorNumber and parameterName; parameter names can be found for the specific items in the reference manual."""
        ...
    @overload
    def SetSensorParameter(self, sensorNumber: SensorIndex, parameterName: str, value: Any) -> None: 
        """Set parameter 'parameterName' of sensor with sensorNumber to value; parameter names can be found for the specific items in the reference manual."""
        ...
    @overload
    def AddMaterial(self, pyObject: Any) -> MaterialIndex: 
        """Add a material from its dictionary (or a material class of exudyn.itemInterface); returns the material number (type MaterialIndex); the name must be unique, an empty name gives 'material<n>'.
        
        Examples:
            steel = mbs.AddMaterial({'materialType': 'SolidBasic', 'name': 'steel', 'density': 7850,
              'youngsModulus': 2.1e11, 'poissonsRatio': 0.3,
              'damping': {'lawType': 'DampingRayleigh', 'alpha': 0, 'beta': 1e-4}})
        """
        ...
    @overload
    def DeleteMaterial(self, materialNumber: MaterialIndex) -> None: 
        """Delete the material with materialNumber; the materials after it get the numbers one smaller, and their default names follow.
        
        Examples:
            mbs.DeleteMaterial(materialNumber=0)
        """
        ...
    @overload
    def GetMaterialNumber(self, materialName: str) -> MaterialIndex: 
        """Get the material's number by its name (string); an invalid index if there is none.
        
        Examples:
            n = mbs.GetMaterialNumber('steel')
        """
        ...
    @overload
    def GetMaterial(self, materialNumber: MaterialIndex) -> dict: 
        """Get the material's dictionary by its number, a copy.
        
        Examples:
            materialDict = mbs.GetMaterial(0)
        """
        ...
    @overload
    def ModifyMaterial(self, materialNumber: MaterialIndex, materialDict: dict) -> None: 
        """Modify the material with the keys of a dictionary; keys not given keep their values; the materialType cannot change.
        
        Examples:
            mbs.ModifyMaterial(materialNumber, {'youngsModulus': 7e10})
        """
        ...
    @overload
    def GetMaterialDefaults(self, typeName: str) -> dict: 
        """Get the default dictionary of a material type: SolidBasic, SolidNeoHooke or SolidMooneyRivlin; every parameter zero.
        
        Examples:
            materialDict = mbs.GetMaterialDefaults('SolidBasic')
        """
        ...
    @overload
    def GetMaterialParameter(self, materialNumber: MaterialIndex, parameterName: str) -> Any: 
        """Get a parameter of a material by its name, 'youngsModulus', or its path in a group, 'damping.beta'.
        
        Examples:
            E = mbs.GetMaterialParameter(0, 'youngsModulus')
        """
        ...
    @overload
    def SetMaterialParameter(self, materialNumber: MaterialIndex, parameterName: str, value: Any) -> None: 
        """Set a parameter of a material by its name, 'youngsModulus', or its path in a group, 'damping.beta'; it acts in the next evaluation, also during a simulation.
        
        Examples:
            mbs.SetMaterialParameter(0, 'damping.beta', 2e-4)
        """
        ...

    SolutionViewer = _SolutionViewer
    CreateGround = _MainSystemCreateGround
    CreateMassPoint = _MainSystemCreateMassPoint
    CreateRigidBody = _MainSystemCreateRigidBody
    CreateSpringDamper = _MainSystemCreateSpringDamper
    CreateCartesianSpringDamper = _MainSystemCreateCartesianSpringDamper
    CreateRigidBodySpringDamper = _MainSystemCreateRigidBodySpringDamper
    CreateTorsionalSpringDamper = _MainSystemCreateTorsionalSpringDamper
    CreateLinearSpringDamper = _MainSystemCreateLinearSpringDamper
    CreateRevoluteJoint = _MainSystemCreateRevoluteJoint
    CreateHelicalJoint = _MainSystemCreateHelicalJoint
    CreatePrismaticJoint = _MainSystemCreatePrismaticJoint
    CreateSphericalJoint = _MainSystemCreateSphericalJoint
    CreateGenericJoint = _MainSystemCreateGenericJoint
    CreateDistanceConstraint = _MainSystemCreateDistanceConstraint
    CreateCoordinateConstraint = _MainSystemCreateCoordinateConstraint
    CreateRollingDisc = _MainSystemCreateRollingDisc
    CreateRollingDiscPenalty = _MainSystemCreateRollingDiscPenalty
    CreateSphereSphereContact = _MainSystemCreateSphereSphereContact
    CreateSphereQuadContact = _MainSystemCreateSphereQuadContact
    CreateSphereTriangleContact = _MainSystemCreateSphereTriangleContact
    CreateSphereCylinderContact = _MainSystemCreateSphereCylinderContact
    CreateCylinderCylinderContact = _MainSystemCreateCylinderCylinderContact
    CreateCylinderTriangleContact = _MainSystemCreateCylinderTriangleContact
    CreateConeConeContact = _MainSystemCreateConeConeContact
    CreateConeTriangleContact = _MainSystemCreateConeTriangleContact
    CreateConvexConvexContact = _MainSystemCreateConvexConvexContact
    CreatePrimitiveConvexContact = _MainSystemCreatePrimitiveConvexContact
    CreateKinematicTree = _MainSystemCreateKinematicTree
    CreateFFRFReducedOrderObject = _MainSystemCreateFFRFReducedOrderObject
    CreateForce = _MainSystemCreateForce
    CreateTorque = _MainSystemCreateTorque
    CreateDistanceSensorGeometry = _CreateDistanceSensorGeometry
    CreateDistanceSensor = _CreateDistanceSensor
    PlotSensor = _PlotSensor
    SolveStatic = _SolveStatic
    SolveDynamic = _SolveDynamic
    ComputeLinearizedSystem = _ComputeLinearizedSystem
    ComputeODE2Eigenvalues = _ComputeODE2Eigenvalues
    ComputeSystemDegreeOfFreedom = _ComputeSystemDegreeOfFreedom
    ComputeConstraintResiduals = _ComputeConstraintResiduals
    DrawSystemGraph = _DrawSystemGraph

class Renderer:
    """The Renderer is the substructure of SystemContainer that collects rendering and visualization interaction, in particular starting and stopping the renderer, image retrieval and materials.

    Rendering is done for a single SystemContainer, which may include several MainSystems
    Note that visualizationSettings are directly accessible from the SystemContainer.
    """
    @overload
    def Start(self, verbose=0) -> bool: 
        """Start OpenGL rendering engine (in separate thread) for visualization of rigid or flexible multibody system; use verbose=1 to output information during OpenGL window creation; verbose=2 produces more output and verbose=3 gives a debug level; some of the information will only be seen in windows command (powershell) windows or linux shell, but not inside iPython of e.g., Spyder."""
        ...
    @overload
    def Stop(self) -> None: 
        """Stop OpenGL rendering engine; uses timeout in multithreading."""
        ...
    @overload
    def IsActive(self) -> bool: 
        """Returns True if GLFW renderer is available and running; otherwise False."""
        ...
    @overload
    def Attach(self) -> bool: 
        """Links the SystemContainer to the render engine, such that the changes in the graphics structure drawn upon updates, etc.; done automatically on creation of SystemContainer; return False, if no renderer exists (e.g., compiled without GLFW) or cannot be linked (if other SystemContainer already linked)."""
        ...
    @overload
    def Detach(self) -> bool: 
        """DEPRECATED; Releases the SystemContainer from the render engine; return True if successfully released, False if no GLFW available or detaching failed; removed in 2029."""
        ...
    @overload
    def StopSimulation(self, forceQuit: bool=True) -> None: 
        """Stop the simulation as closing the render window does: a running simulation ends after its current step, quietly and without an error, as if the user had stopped it; with forceQuit=True (default) a simulation that starts later ends before its first step as well, until mbs.SetRenderEngineStopFlag(False) resets it - which is what pressing Escape or closing the window does.
        
        Works without an open renderer, e.g. from a user function, another thread or a test
        
        Examples:
            SC.renderer.StopSimulation()
        """
        ...
    @overload
    def DoIdleTasks(self, waitSeconds: float=-1., printPauseMessage: bool=True, pollEvents: bool=True) -> bool: 
        """Interrupt further computation until user input (Space, 'Q', Escape-key), representing a PAUSE function; this command runs a loop in the background to have active response of the render window, e.g., to open the visualization dialog or use the right-mouse-button; replaces former SC.WaitForRenderEngineStopFlag() and mbs.WaitForUserToContinue(); call this function in order to interact with Renderer window; use waitSeconds in order to run this idle tasks while animating a model (e.g., waitSeconds=0.04), use waitSeconds=0 without waiting, or use waitSeconds=-1 (default) to wait until window is closed; pollEvents=False: the renderer draws and runs queued commands, but leaves the window events to the event loop that called it - a tkinter dialog calling this from its after-callback on macOS, where both share one event loop; NOTE: may also first initialize renderState from visualizationSettings (if renderer is inactive).
        
        Examples:
            SC.renderer.DoIdleTasks()
        """
        ...
    @overload
    def EnableView(self, viewID: int, createWindow: bool=True) -> None: 
        """Enables a specified view (1,2 or 3) additionally to the main view (0); a window is created if createWindow=True, otherwise, the view is only enabled to use it with the raytracer; NOTE: additional views cause slightly more workload for the renderer which is why they are disabled by default; failure to create the view usually results in an exception; to check whether the view exists, check the according RenderState regarding viewEnabled and windowOpen."""
        ...
    @overload
    def DisableView(self, viewID: int) -> None: 
        """Disables a specified view (1,2 or 3) and (if created) closes the according window; NOTE: in case of renderer.Stop(), all views are closed; NOTE: if you still aim to use the view without the window, you have to enable the view again EnableView(..., createWindow=False)."""
        ...
    @overload
    def ZoomAll(self, computeMaxScene: bool=True, viewID: int=0) -> None: 
        """Send zoom all signal, which will perform zoom all at next redraw request; if renderer is inactive (renderer.IsActive()=0), it will perform computations for renderState, thus at the next RedrawAndGetImage() having the full view as with the OpenGL renderer; NOTE: in case of OpenGL, call ZoomAll() after renderer.Start(); NOTE: may also first initialize renderState from visualizationSettings (if renderer is inactive)."""
        ...
    @overload
    def ZoomToItem(self, itemIndex: NodeIndex | ObjectIndex | MarkerIndex | LoadIndex | SensorIndex, mbsNumber: int=0, viewID: int=0) -> bool: 
        """Center the view on the graphics of one item and zoom such that it fills the window, as ZoomAll does for the scene (#3027); itemIndex is the NodeIndex, ObjectIndex, MarkerIndex, LoadIndex or SensorIndex the Add functions return, mbsNumber the number of its system in the SystemContainer; with an active renderer this happens at its next update and the function returns True, else now, and it returns False if the item draws nothing; in the render window, CTRL+A zooms to the item selected with the left mouse button.
        
        Examples:
            SC.renderer.ZoomToItem(oBody)
        """
        ...
    @overload
    def SetModelView(self, zoom: float=0, rotationVector: [float,float,float]=[0,0,0], centerPoint: [float,float,float]=[0,0,0], viewID: int=0) -> None: 
        """Function to adjusts the current view in renderState; rotationVector and centerPoint transform the modelView while zoom equals the visible scene height; rotationVector is the axis of rotation times the angle in radiant; if zoom=0 then zoom will be computed automatically like in autoFitScene with openGL; use this function in particular for raytracing before RedrawAndGetImage() or with regular OpenGL after renderer.Start(); you can also store the renderState and write the full renderState alternatively; NOTE: may also first initialize renderState from visualizationSettings (if renderer is inactive).
        
        Examples:
            SC.renderer.SetModelView(10,[0,0,pi],[2.5,0,0])
            image=SC.renderer.RedrawAndGetImage()
        """
        ...
    @overload
    def RedrawAndSaveImage(self, viewID: int=0) -> None: 
        """Redraw openGL scene and save image (command waits until process is finished); uses the current rendering engine (OpenGL or raytracer)."""
        ...
    @overload
    def RedrawAndGetImage(self, useRaytracer: bool=False, viewID: int=0) -> NDArray[np.uint8]: 
        """Redraw scene and return image in numpy-format, containing a 3-dimensional array with 3 matrices of RGB channels; the shape is according to (height,width,3) where height and width represent the window pixels defined in visualizationSettings.window.renderWindowSize (Note: in case that raytracer.imageSizeFactor>1 the retrieved image size is smaller by the imageSizeFactor!); command waits until process is finished; if useRaytracer=False, the openGL render is used and the render window needs to be opened before; if useRaytracer=True, the software raytracer is used which runs completely without GLFW and OpenGL (e.g., on a supercomputer); NOTE: in case of useRaytracer=True the displayScaling factor is only available if the OpenGL renderer has been opened once; otherwise e.g., SC.renderer.SetState({'displayScaling':1.5}) has to be used to adjust it; NOTE: may also first initialize renderState from visualizationSettings (if renderer is inactive).
        
        Examples:
            import matplotlib.pyplot as plt
            image=SC.renderer.RedrawAndGetImage()
            plt.imshow(image)
            plt.axis('off')
            plt.show()
        """
        ...
    @overload
    def GetGraphicsData(self, flatShapes=False) -> dict: 
        """The drawing elements of the scene as a dictionary of numpy arrays: what the renderer would draw, as data.
        
        It is built without a window, the way `RedrawAndGetImage(True)` builds it, so it works with `EXUDYN_SUPPRESS_UI_WINDOW_OPEN` set and needs no OpenGL; zoom, model view and window size are not part of it. The keys `lines`, `spheres`, `circles`, `texts` and `triangles` each hold a dictionary whose `items` is an int array of shape (n,3) - the system number, the `exudyn.ItemType` value and the index of the item that drew the element, or `[-1, 0, code]` for a static element of the scene; then `points` and `colors` (RGBA, per vertex for lines and triangles), and per kind `radius` and `resolution` (spheres), `radius` and `numberOfSegments` (circles), `fontSize`, `offset` and the list `text` (texts), `normals` (triangles). The curved shapes are kept as they are under `triangles6` (6-node triangles: `points`, `normals` and `colors` of shape (n,6,3) / (n,6,4), nodes as in the key `triangles6` of a TriangleList; the normals given, else those of the geometry) and `lines3` (quadratic lines: `points` (n,3,3) and `colors` (n,3,4), the end points and then the mid node); `texturedTriangles` holds the triangles with a texture as `triangles` does, and `textureCoordinates` (n,3,2) and the list `texture` of the names of their textures (#3030); with`flatShapes=True` these two are empty and their shapes are among `triangles` and `lines` instead, refined once - 4 triangles on the 6 nodes, 2 lines on the 3 nodes - independently of the tiling settings, which only the renderers apply. `formatVersion` is 1. It is the oracle of the graphics tests: the number of elements per item is exact, coordinates are floats and are compared with a tolerance
        
        Examples:
            data = SC.renderer.GetGraphicsData()
            print(len(data['triangles']['items']), 'triangles')
        """
        ...
    @overload
    def GetState(self, viewID: int=0) -> dict: 
        """Get dictionary with current render state (openGL zoom, modelview, etc.).
        
        Examples:
            SC = exu.SystemContainer()
            renderState = SC.renderer.GetState()
            print(renderState['zoom'])
        """
        ...
    @overload
    def GetDictionary(self) -> dict: 
        """What the renderer holds besides visualizationSettings, as a dictionary (#2075): 'materials', the list of the materials as GraphicsMaterialList.GetDict gives them, 'scopeGraphics', the static graphics of the scopes as scopes.GetGraphics gives them, 'controls', the buttons and sliders as GetControls gives them (#3400), 'states', the render states of the enabled views by their number, as GetState gives them, and 'textures', the list of the textures as GetTexture gives them (#3268).
        
        Examples:
            rendererData = SC.renderer.GetDictionary()
            SC.renderer.SetDictionary(rendererData)
        """
        ...
    @overload
    def SetDictionary(self, values: dict) -> None: 
        """Set the materials, the static graphics of the scopes, the buttons and sliders (with their IDs; the user function stays), the render states of the views and the textures from a dictionary as GetDictionary gives it; a key left out stays as it is, an unknown key raises; materials beyond the existing ones are appended, a state is set as SetState(state, waitForRendererFullStartup=False, viewID) sets it, which needs the view enabled, and a texture is added as AddTexture adds it, replacing the image of its name."""
        ...
    @overload
    def SetState(self, renderState: dict, waitForRendererFullStartup: bool=True, viewID: int=0) -> None: 
        """Set current render state (openGL zoom, modelview, etc.) with given dictionary; usually, this dictionary has been obtained with GetRenderState; waitForRendererFullStartup is used to wait at startup for the first frame to be drawn (and zoom all to be set), but be be set False in case of performance issues; NOTE: before setting available state values, this function may also first initialize renderState from visualizationSettings (if renderer is inactive).
        
        Examples:
            SC = exu.SystemContainer()
            SC.renderer.SetState(renderState)
        """
        ...
    @overload
    def RestoreSavedState(self, viewID: int=0) -> bool: 
        """Restore the render state that exu.sys holds: renderer.Stop() saves the state of every open view there, so this brings back the view of the previous run; returns False if nothing has been saved yet, which is not an error but the ordinary case on the first run of a script; it replaces the two lines that tested for renderState in exu.sys and called SetState with it.
        
        Examples:
            SC = exu.SystemContainer()
            SC.renderer.Start()
            SC.renderer.RestoreSavedState()
        """
        ...
    @overload
    def GetMouseCoordinates(self, useOpenGLcoordinates: bool=False, viewID: int=0) -> [float,float]: 
        """Get current mouse coordinates as list [x, y]; x and y being floats, as returned by GLFW, measured from top left corner of window; use GetCurrentMouseCoordinates(useOpenGLcoordinates=True) to obtain OpenGLcoordinates of projected plane."""
        ...
    @overload
    def GetItemSelection(self, resetSelection: bool=True, viewID: int=0) -> [int,int,int,float]: 
        """Get selected item in render state; option to reset selected item afterwards; item is selected in render window by clicking left mouse button; returns [mbs number, ItemType, ItemIndex, depth] where depth is the Z-depth in the current view; note that only items of the categories activated in visualizationSettings.interactive.selectionLeftMouseItemTypes are returned; NOTE: if itemType == 0, no item has been selected."""
        ...
    @overload
    def ResetState(self) -> None: 
        """Reset renderState in all views to default values using current visualizationSettings; usually this does not have to be called!."""
        ...
    @overload
    def SendRedrawSignal(self) -> None: 
        """This function is used to send a signal to the renderer that all MainSystems (mbs) shall be redrawn."""
        ...
    @overload
    def GetRenderCount(self) -> bool: 
        """Returns the number of rendered OpenGL images; can be used to determine if image has been drawn by comparing to previous counter; also shows that first image has been drawn (needed for zoom all)."""
        ...
    @overload
    def AddTexture(self, name: str, image: ArrayLike, interpretation: TextureInterpretation=TextureInterpretation.RGBA, flags: TextureFlags | int=0) -> None: 
        """Add a texture by its name, or replace the image of a name, for the triangle lists that refer to it with the key 'texture' (#3029); the textures are shared by all SystemContainers and are added before the graphics data that uses them; image is a numpy array of shape (height, width) or (height, width, channels) with 1, 3 or 4 channels, of uint8 or of floats in [0, 1]; its first row is the top of the image, at the texture coordinate v=1; interpretation is a TextureInterpretation, which says how the channels are drawn; flags are TextureFlags combined with |, e.g. exu.TextureFlags.Nearest | exu.TextureFlags.Clamp, or 0 for none; names starting with 'exudyn.' are reserved.
        
        Examples:
            import numpy as np
            image = np.zeros((64,64,3), dtype=np.uint8)
            image[:32,:,0] = 255 #upper half red
            SC.renderer.AddTexture('redTop', image, interpretation=exu.TextureInterpretation.RGB, flags=exu.TextureFlags.Nearest)
        """
        ...
    @overload
    def RemoveTexture(self, name: str) -> bool: 
        """Remove a texture by its name; triangles that refer to it are drawn without texture; returns False if no texture has this name."""
        ...
    @overload
    def GetTexture(self, name: str) -> dict: 
        """A texture as a dict (#3268): 'name', 'image', the pixels as AddTexture takes them - a numpy array of uint8 of shape (height, width) for TextureInterpretation.Grey and (height, width, channels) otherwise, its first row the top of the image -, 'interpretation', the name of the TextureInterpretation, e.g. 'RGB', and 'flags', the TextureFlags as int; GetDictionary and SC.GetDictionary give all textures this way, so that they can be saved, e.g.
        
        with SaveDictToHDF5; raises for an unknown name
        
        Examples:
            texture = SC.renderer.GetTexture('redTop')
            print(texture['image'].shape, texture['interpretation'])
        """
        ...
    @overload
    def GetTextureNames(self) -> list[str]: 
        """The names of the textures added with AddTexture, in the order they were added."""
        ...
    @overload
    def AddButton(self, text: str, location: list[list[float]] | None=None, toggle: bool=False, state: float=0., fontSize: float=12., color: list[float] | None=None, backgroundColor: list[float] | None=None, view: int=0) -> int: 
        """Add a button to the render window; a push button (toggle=False) has the state 0 and sends 1 to the user function when it is released over the button, a toggle button switches its state between 0 and 1 when released and sends the new state; location is [[x0, y0], [x1, y1]], the corners relative to the window from its top left corner, values in [0, 1], so that it scales with the window (None: [[0, 0], [0.1, 0.05]]); the text is centered; fontSize is in points as window.globalFontSize, scaled with the display scaling; color is the color of the text, backgroundColor the color of the element, whose alpha value is its transparency (None: [0, 0, 0, 1] and [0.85, 0.87, 0.9, 0.8]); view is the view it is drawn in; returns the ID of the element, which the user function receives; elements added later are drawn over earlier ones and take the mouse first, after the icon bar; they are not in saved images unless visualizationSettings.general.iconBarAndControlsInImages is True (#3400).
        
        Examples:
            bStart = SC.renderer.AddButton('start', location=[[0.02, 0.02], [0.15, 0.08]])
            bLight = SC.renderer.AddButton('light', location=[[0.02, 0.1], [0.15, 0.16]], toggle=True)
        """
        ...
    @overload
    def AddSlider(self, text: str, location: list[list[float]] | None=None, minMax: list[float] | None=None, value: float | None=None, format: str="{:.3g}", fontSize: float=12., color: list[float] | None=None, backgroundColor: list[float] | None=None, view: int=0) -> int: 
        """Add a slider to the render window, whose value in minMax = [min, max] (None: [0, 1]) is set by dragging it with the left mouse button or by the mouse wheel over it (1/100 of the range per step, with CTRL 1/1000); it sends each new value to the user function; value is its initial value (None: min); format is the value in its label after the text, a Python format with {} or {:.Nf}, {:.Ne}, {:.Ng}, e.g. 'q1 = {:.2f}', or empty for no value; location is [[x0, y0], [x1, y1]], the corners relative to the window from its top left corner, values in [0, 1], so that it scales with the window (None: [[0, 0], [0.1, 0.05]]); the text is centered; fontSize is in points as window.globalFontSize, scaled with the display scaling; color is the color of the text, backgroundColor the color of the element, whose alpha value is its transparency (None: [0, 0, 0, 1] and [0.85, 0.87, 0.9, 0.8]); view is the view it is drawn in; returns the ID of the element, which the user function receives; elements added later are drawn over earlier ones and take the mouse first, after the icon bar; they are not in saved images unless visualizationSettings.general.iconBarAndControlsInImages is True (#3400).
        
        Examples:
            sQ1 = SC.renderer.AddSlider('q1', location=[[0.7, 0.9], [0.98, 0.97]], minMax=[-3.14, 3.14], value=0., format='= {:.2f} rad')
        """
        ...
    @overload
    def SetControlUserFunction(self, function: Callable[[int, list[float]], None] | None) -> None: 
        """Set the one user function of the buttons and sliders, f(controlID, data), with the ID of the element and data = [state, 0, 0]: 0 or 1 for a button, the value of a slider; the renderer queues the events, and the function is called in the main (Python) thread while a simulation runs or in SC.renderer.DoIdleTasks, as the key press function; a slider that is dragged sends only its last value; None removes it (#3400).
        
        Examples:
            def UFcontrols(controlID, data):
                print('element', controlID, 'state', data[0])
            SC.renderer.SetControlUserFunction(UFcontrols)
        """
        ...
    @overload
    def SetControlState(self, controlID: int, data: float | list[float], callUserFunction: bool=False) -> None: 
        """Set the state of a button (0 or 1) or the value of a slider (in its minMax), given as a number or as a list [state, ...] as the user function receives it; the user function is called only with callUserFunction=True, as a click would call it (#3400).
        
        Examples:
            SC.renderer.SetControlState(sQ1, 0.5)
        """
        ...
    @overload
    def GetControlState(self, controlID: int) -> list[float]: 
        """The state of a button or slider as [state, 0, 0], as the user function receives it (#3400).
        
        Examples:
            q1 = SC.renderer.GetControlState(sQ1)[0]
        """
        ...
    @overload
    def GetControls(self) -> list[dict]: 
        """The buttons and sliders as a list of dicts with all their keys: 'id', 'type' ('Button' or 'Slider'), 'view', 'location', 'text', 'fontSize', 'color', 'backgroundColor', 'state', and 'toggle' of a button, 'minMax' and 'format' of a slider (#3400)."""
        ...
    @overload
    def DeleteControl(self, controlID: int) -> None: 
        """Remove a button or slider by its ID (#3400)."""
        ...
    @overload
    def ClearControls(self) -> None: 
        """Remove all buttons and sliders; the user function stays (#3400)."""
        ...
    materials:GraphicsMaterialList
    """GraphicsMaterialList used for raytracer (possibly for OpenGL in future); list can be accessed with [] operator, reset and extended. Note that after Reset() there are at least 10 materials available, which are copied from visualizationSettings.raytracer.materials which are synced continuously (``returns a reference``)."""
    scopes:RendererScopes
    """RendererScopes: lines, texts and points drawn in the scopes of the views, in the coordinates of their graphs (#3237) (``returns a reference``)."""


class RendererScopes:
    """The static graphics of the scopes, ``SC.renderer.scopes`` (#3237): lines, texts and points in the coordinates of the graph of a scope - time or the values of the x-sensor, and the y-values -, such as a threshold, an analytic reference or a marked value.

    They are one list of dicts, each with the view and the scope it is drawn in; they are clipped to the plot area, do not change the automatic range of the axes, and are drawn by OpenGL and the raytracer and in saved images, also by the solution viewer
    They are not settings: they are neither stored in ``config.json`` nor in the settings dialog, and stay until cleared or ``SC.Reset()``
    Each dict has the key ``type``, ``'Line'``, ``'Text'`` or ``'Point'``, and the keys of its type; a key not listed is refused
    All types: ``view`` (0), ``scope`` (0), ``color`` (RGBA, [0,0,0,1]), ``front`` (True: drawn over the sensor lines; False for lines and points, True for texts)
    Line: ``points`` (a list of at least two [x, y], a polyline), ``width`` (in pixels, -1: the ``lineWidth`` of the scope), ``name`` (with a name, the line has an entry in the legend, after the sensor lines)
    Text: ``position`` ([x, y], the bottom left corner of the first character), ``text``, ``size`` (relative to the tick labels, 1)
    Point: ``position`` ([x, y], the center), ``radius`` (in pixels, 4), ``width`` (the line width of the circle, -1).
    """
    @overload
    def SetGraphics(self, items: list[dict]) -> None: 
        """Replace the static graphics of all scopes by a list of dicts; all are checked before anything is replaced.
        
        Examples:
            SC.renderer.scopes.SetGraphics([{'type':'Line', 'points':[[0, 0.5], [10, 0.5]], 'color':[1, 0, 0, 1], 'name':'limit'},
                {'type':'Text', 'position':[1, 0.55], 'text':'limit', 'scope':0}])
        """
        ...
    @overload
    def AddGraphics(self, items: dict | list[dict]) -> None: 
        """Append a dict or a list of dicts to the static graphics.
        
        Examples:
            SC.renderer.scopes.AddGraphics({'type':'Point', 'position':[2.5, 0.8], 'radius':5, 'color':[0, 0, 1, 1], 'view':0, 'scope':1})
        """
        ...
    @overload
    def GetGraphics(self) -> list[dict]: 
        """The static graphics as a list of dicts, with all the keys of their types."""
        ...
    @overload
    def ClearGraphics(self, view: int=-1, scope: int=-1) -> None: 
        """Remove the static graphics of a view and a scope; -1 for all views or all scopes, the default: all."""
        ...


class SystemContainer:
    """The SystemContainer is the top level of structures in Exudyn.

    The container holds all (multibody) systems of type ``MainSystem`` and the link to OpenGL renderers and raytracers (every SystemContainer has an independent rendering, while all MainSystems are rendered together).Via the MainSystems it thus contains all computational data
    A SystemContainer is created by ``SC = exu.SystemContainer()``, understanding ``exu.SystemContainer`` as a state machine where MainSystems are added and renderer state machines are processed, similar to the behavior of other Python packages
    Usually, only one container shall be used, while multiple containers are possible -- e.g., for reasons of significantly different behavior (drawing, etc.)
    The SystemContainer contains ``visualizationSettings`` to adjust all kinds of visualization appearance, windows and interactions.
    """
    @overload
    def __init__(self, attachToRenderer: bool=True) -> None: 
        """Create a SystemContainer; with attachToRenderer=False it is not attached to the renderer and leaves the render window with the container it is attached to - for a container used only to compute, such as the one of InverseKinematics; SC.renderer.Attach() attaches it later (#2259).
        
        Examples:
            SCcompute = exu.SystemContainer(attachToRenderer=False)
        """
        ...
    @overload
    def Reset(self) -> None: 
        """Delete all multibody systems and reset SystemContainer (including graphics); this also releases SystemContainer from the renderer, which requires SC.renderer.Attach() to be called in order to reconnect to rendering; a safer way is to delete the current SystemContainer and create a new one (SC=SystemContainer() )."""
        ...
    @overload
    def AddSystem(self) -> MainSystem: 
        """Add a new computational system; the returned MainSystem keeps the system container alive (`returns a reference`)."""
        ...
    @overload
    def AppendSystem(self, mainSystem: MainSystem) -> int: 
        """Append an existing MainSystem - a copy, or the system of another container - to the system container; returns its index in the container.
        
        The container keeps the system alive but does not own it: SC.Reset() and the end of the container leave it to its owner, and the system of another container gets that container back (#2842) (`returns a reference`)
        """
        ...
    @overload
    def NumberOfSystems(self) -> int: 
        """Obtain number of multibody systems available in system container."""
        ...
    @overload
    def GetSystem(self, systemNumber: int) -> MainSystem: 
        """Obtain multibody systems with index from system container; the returned MainSystem keeps the system container alive (#2851)."""
        ...
    visualizationSettings:VisualizationSettings
    """this structure is read/writeable and contains visualization settings, which are immediately applied to the rendering window. EXAMPLE: ``SC = exu.SystemContainer(); SC.visualizationSettings.autoFitScene=False``."""
    @overload
    def GetDictionary(self) -> dict: 
        """[UNDER DEVELOPMENT]: return the dictionary of the system container data, e.g., to copy the system or for pickling."""
        ...
    @overload
    def SetDictionary(self, systemDict: dict) -> None: 
        """[UNDER DEVELOPMENT]: set system container data from given dictionary; used for pickling."""
        ...
    @overload
    def GetRenderState(self) -> dict: 
        """DEPRECATED; Get dictionary with current render state (openGL zoom, modelview, etc.); will have no effect if GLFW_GRAPHICS is deactivated; removed in 2029."""
        ...
    @overload
    def SetRenderState(self, renderState: dict, waitForRendererFullStartup: bool=True) -> None: 
        """DEPRECATED; Set current render state (openGL zoom, modelview, etc.) with given dictionary; usually, this dictionary has been obtained with GetRenderState; waitForRendererFullStartup is used to wait at startup for the first frame to be drawn (and zoom all to be set), but be be set False in case of performance issues; will have no effect if GLFW_GRAPHICS is deactivated; removed in 2029."""
        ...
    @overload
    def RedrawAndSaveImage(self) -> None: 
        """DEPRECATED; Redraw openGL scene and save image (command waits until process is finished); removed in 2029."""
        ...
    @overload
    def WaitForRenderEngineStopFlag(self) -> bool: 
        """DEPRECTED; Wait for user to stop render engine (Press 'Q' or Escape-key); this command is used to have active response of the render window, e.g., to open the visualization dialog or use the right-mouse-button; behaves similar as mbs.WaitForUserToContinue(); removed in 2029."""
        ...
    @overload
    def RenderEngineZoomAll(self) -> None: 
        """DEPRECATED; Send zoom all signal, which will perform zoom all at next redraw request; removed in 2029."""
        ...
    @overload
    def AttachToRenderEngine(self) -> bool: 
        """DEPRECATED; Links the SystemContainer to the render engine, such that the changes in the graphics structure drawn upon updates, etc.; done automatically on creation of SystemContainer; return False, if no renderer exists (e.g., compiled without GLFW) or cannot be linked (if other SystemContainer already linked); removed in 2029."""
        ...
    @overload
    def DetachFromRenderEngine(self) -> bool: 
        """DEPRECATED; Releases the SystemContainer from the render engine; return True if successfully released, False if no GLFW available or detaching failed; removed in 2029."""
        ...
    @overload
    def SendRedrawSignal(self) -> None: 
        """DEPRECATED; This function is used to send a signal to the renderer that all MainSystems (mbs) shall be redrawn; removed in 2029."""
        ...
    @overload
    def GetCurrentMouseCoordinates(self, useOpenGLcoordinates: bool=False) -> [float,float]: 
        """DEPRECATED; Get current mouse coordinates as list [x, y]; x and y being floats, as returned by GLFW, measured from top left corner of window; use GetCurrentMouseCoordinates(useOpenGLcoordinates=True) to obtain OpenGLcoordinates of projected plane; removed in 2029."""
        ...
    renderer:Renderer
    """The substructure in SystemContainer responsible for rendering (except visualizationSettings)."""
    visualizationSettings:VisualizationSettings
    """Structure representing the settings for renderer; for details of visualizationSettings see Section Structures and Settings."""


class Config:
    """global config settings, like precision, print behavior, warnings, etc."""
    suppressWarnings:int
    """flag to suppress all warnings (default=False)."""
    outputDirectory:str
    """directory which is prepended to all files written by the solver: the coordinates solution file, the solver information file, sensor files and exported images; default='' (files are written exactly as given). An absolute file name together with a non-empty outputDirectory raises an error when the file is opened. NOTE: this setting is global and stays active as long as the exudyn module is loaded, so running two models one after the other in the same process will put both outputs into the same directory; normally you should specify the output folder directly in the file names and use this setting only for a test runner or a batch script. The rule is: everything WRITTEN as output of a run follows the setting, while a file is READ from there only if its name comes from Exudyn itself. Writing: the coordinates solution file, the solver information file, sensor files, exported images, the exudyn.Print log (SetWriteToFile), the figure saved by PlotSensor and the results file of ParameterVariation/GeneticOptimization. Reading: SolutionViewer (name taken from the simulation settings) and PlotSensor for a sensor given by its number (name taken from the sensor). NOT affected: a file name you pass yourself, e.g. to LoadSolutionFile, LoadBinarySolutionFile, RecoverSolutionFile or PlotSensor as a string, and all model data such as mesh import, FEMinterface/ObjectFFRFreducedOrderInterface SaveToFile/LoadFromFile and SaveDictToHDF5/LoadDictFromHDF5; use exudyn.basicUtilities.OutputFilePath(fileName, callerInfo) in your script if you want those in the output directory as well."""
    outputPrecision:int
    """change precision (number of digits) in C++ and Python output."""
    linalgOutputFormatPython:int
    """True (default): use Python format for output of vectors and matrices; False: use Matlab format."""
    printDelayMilliSeconds:int
    """add some delay (in milliSeconds) to printing to console (exudyn.Print), in order to let console (e.g., Spyder) process the output; default = 0."""
    printFlushAlways:bool
    """flush always buffers when using exudyn.Print(...) to write to file or console; this is needed if you are streaming text or showing counters in parameter variation; default=False."""
    printToConsole:bool
    """enables or disables writing to console with exudyn.Print(...); default=True."""
    @property
    def printToFile(self) -> bool:
        """flag that shows if writing to file with exudyn.Print(...) is enabled; flag is readonly."""
        ...
    @property
    def printFileName(self) -> str:
        """file name for writing to file with exudyn.Print(...), as resolved when the file was opened: it is relative to config.outputDirectory, which is prepended by SetWriteToFile(...); flag is readonly."""
        ...
    @property
    def printToFileAppend(self) -> bool:
        """flag that shows if append mode is used for writing to file with exudyn.Print(...); flag is readonly."""
        ...
    @overload
    def Version(self, addDetails=False) -> str: 
        """Get Exudyn built version as string (if addDetails=True, adds more information on compilation Python version, platform, etc.; the Python micro version may differ from that you are working with; AVX2 shows that you are running a AVX2 compiled version)."""
        ...
    @overload
    def GetDictionary(self) -> dict: 
        """All settings of `exudyn.config` as a dictionary, the way a settings structure gives them; `printToFile`, `printFileName` and `printToFileAppend` are in it but only report what the output is doing."""
        ...
    @overload
    def SetDictionary(self, values) -> None: 
        """Set the settings named in the dictionary and leave the others; a name that `exudyn.config` does not have, and one of the three that only report, is ignored."""
        ...
    @overload
    def GetDefaults(self) -> dict: 
        """The defaults of `exudyn.config`: what Exudyn started with, taken while the module was imported and before a script, an override setting or an environment variable could change one.
        
        This is what tells a setting somebody chose from one nobody touched, which is how `overrideSettings.Store(config=...)` knows what to store. They cannot be constructed - `exudyn.config` reads global state, so a second one reports the current values - so they are taken once
        """
        ...

class SpecialSolver:
    """special solver attributes and functions; not intended for regular users; for available features, see the C++ code class PySpecialSolver"""
    timeout:float
    """if >= 0, the solver stops after reaching accoring CPU time specified with timeout; makes sense for parameter variation, automatic testing or for long-running simulations; default=-1 (no timeout)."""
    throwErrorWithCtrlC:bool
    """if True, pressing CTRL-C during a simulation raises an error in Python; if False (default), the solver stops and returns; the error works in a console, the default also in Spyder."""
    initialConstraintsViolations:int
    """the number of time integrations, since the import of exudyn, whose initial positions or velocities did not fulfill the constraints (timeIntegration.generalizedAlpha.checkInitialConstraints); it can be set to 0; the test suite reports it per test model (#2234)."""
    multiThreadingLoadBalancing:bool
    """if True (=default), multithreaded code parts (in particular solver and raytracing) use load balancing, which may give better performance in case of non-equilibrated loads; (mobile) Intel CPUs may perform significantly better without load balancing."""
    suspendWorkersDuringFactorization:bool
    """if True, the worker threads of a multithreaded simulation (parallel.numberOfThreads > 1) sleep on a condition variable while a sparse matrix of at least suspendWorkersMinimumSize unknowns is factorized, instead of spinning; this frees the cores for the threads of MKL PARDISO and for other processes, and the first parallel task after the factorization pays the wake-up of the threads; default=False (#3428)."""
    suspendWorkersMinimumSize:int
    """the number of unknowns from which suspendWorkersDuringFactorization lets the workers sleep; default=1000 (#3428)."""
    pinThreadsToCores:bool
    """if True (=default), the threads of a multithreaded simulation (parallel.numberOfThreads > 1) run each on a physical core of their own while it computes, the cores sharing the L3 cache of the main thread first; the main thread keeps its core and gets its previous affinity back at the end; a thread on the second logical processor of the main thread's core would slow the main thread by up to half; only on Windows (processor group 0) and Linux, and only if there are at least as many cores as threads; set False if several processes compute with threads at the same time (#3494)."""
    workersIdleSpinTime:float
    """the time in seconds that a worker thread waits for its next task by spinning, then it sleeps until the next task wakes it; this keeps waiting threads from slowing the main thread and other processes during long serial parts, e.g. a factorization or Python user functions; < 0: the workers never sleep; default=1e-3 (#3494)."""
    pardisoNumberOfThreads:int
    """the threads of MKL PARDISO (LinearSolverType.PardisoMKL); 0 (=default): parallel.numberOfThreads of the simulation (#3431)."""
    pardisoCheckPeriod:int
    """the residual of a solve with PARDISO is checked after the first factorization of a pattern and after every pardisoCheckPeriod-th factorization; 0: never; default=1, every factorization (#3431)."""
    pardisoResidualTolerance:float
    """the relative residual |A x - b| / |b| of a checked solve with PARDISO above which it is refined (pardisoRefinementSteps) and then the matrix falls back to SparseLU (pardisoMaximumFallbacks); default=1e-6 (#3431)."""
    pardisoRefinementSteps:int
    """the steps of iterative refinement on the factorization of PARDISO (a solve with the residual each) when a checked solve is above pardisoResidualTolerance, before the matrix falls back to SparseLU; they stop when the residual is below the tolerance; a factorization with perturbed pivots typically gains a factor 50 per step; 0: none; default=3 (#3538)."""
    pardisoMaximumFallbacks:int
    """the number of matrices that may fall back to SparseLU in a simulation: a matrix whose check fails is factorized and solved with SparseLU, the next one with PARDISO again; after this number the simulation continues with SparseLU; 0: the first fallback is for the rest of the simulation; default=10 (#3538)."""
    pardisoFallback:bool
    """if True (=default), a failed factorization or check of PARDISO falls back to SparseLU, for this matrix or, after pardisoMaximumFallbacks, for the rest of the simulation, with a warning; if False, it raises an error (#3431)."""
    pardisoParameters:dict
    """a dict {index: value} of entries of the parameter array iparm of PARDISO, written after pardisoinit and the defaults of Exudyn (iparm[1] = 0, the minimum degree ordering, and iparm[23] = 0, the one-level factorization, which were reliable on all Jacobians studied); for experts; assign a whole dict, as a change of a returned dict is lost; default={} (#3431)."""
    pardisoFallbacks:int
    """the number of fallbacks from PARDISO to SparseLU since the import of exudyn, one per matrix; it can be set to 0 (#3431)."""
    parallelSubstitution:bool
    """experimental: if True, EigenSparse factorizes with a nested-dissection ordering (on the coordinates of the objects and the pattern of the Jacobian) and a diagonal pivot threshold of parallelSubstitutionPivotThreshold, and the forward and backward substitution run by the subtrees of the ordering on the threads of parallel.numberOfThreads; the substitution is 2-4 times faster than that of SparseLU, the factorization slower on several threads, so it pays with modified Newton and many solves per factorization; default=False (#3432)."""
    parallelSubstitutionPivotThreshold:float
    """the diagonal pivot threshold of the factorization with parallelSubstitution: a diagonal entry is taken as pivot if its magnitude is at least this fraction of the largest in its column, which keeps the subtrees independent; default=1e-3 (#3432)."""
    parallelSubstitutionSerial:int
    """the number of factorizations with parallelSubstitution whose substitution ran serially, as a pivot coupled two subtrees, or that fell back to SparseLU, as the factorization failed; it can be set to 0 (#3432)."""
    sparseSolveByRows:bool
    """if True (=default), EigenSparse copies the factors of SparseLU into rows after each factorization and solves forward and backward with them, which is about twice as fast as the supernodal solve of Eigen for the small supernodes of multibody systems; False: the solve of Eigen (#3441)."""
    @overload
    def PardisoInfo(self) -> dict: 
        """Whether Intel MKL PARDISO, LinearSolverType.PardisoMKL, is available: the MKL runtime library is searched in the environment variable EXUDYN_MKL_LIBRARY (a full path), in the environment of Python (sys.prefix, sys.base_prefix) and in the system search path, and loaded once; returns a dict with available (bool), library (the path or name loaded), version (of MKL) and message (why it is not available) (#3431)."""
        ...
    @overload
    def StartPersistentThreads(self, numberOfThreads: int) -> None: 
        """Start numberOfThreads (at least 2, the main thread included) worker threads that stay until StopPersistentThreads or the end of Python; while no computation uses them they sleep on a condition variable; a solver whose parallel.numberOfThreads agrees uses them instead of starting and stopping threads of its own, which pays for many runs of small systems; a solver with another parallel.numberOfThreads (also 1) uses its own number for that run, with a warning, and the persistent threads start again after it; the raytracer does not use them, it has threads of its own (#3438); not possible while a computation uses threads (#3437).
        
        Examples:
            exu.special.solver.StartPersistentThreads(8)
            simulationSettings.parallel.numberOfThreads = 8
        """
        ...
    @overload
    def StopPersistentThreads(self) -> None: 
        """Stop the threads of StartPersistentThreads; not possible while a computation uses threads (#3437)."""
        ...
    @overload
    def PersistentThreads(self) -> int: 
        """The number of threads of StartPersistentThreads, the main thread included; 0: none (#3437)."""
        ...

class SpecialExceptions:
    """special flags for exceptions and checks; not intended for regular users; for available features, see the C++ code class PySpecialExceptions"""
    dictionaryVersionMismatch:bool
    """if True (=default), SetDictionary(...) of a settings structure warns if the dictionary comes from another version of Exudyn."""
    dictionaryNonCopyable:bool
    """if True (=default), GetDictionary(...) raises an error if a value cannot be copied into the dictionary."""
    writeErrorsToLogFile:bool
    """if True (=default), the message of a user or system error is also written into the log file of exudyn.SetWriteToFile(...), as a record of an unattended run; set False for a run that provokes and catches many errors, whose exceptions carry the same message."""
    parameterRangeChecks:bool
    """if True (=default), writing an item or settings parameter outside its range (e.g. a negative mass or a non-positive number of steps) raises an error, on every write path (item classes, dictionaries, SetObjectParameter, ...); set False to accept any value, e.g. if a range limit turns out to be wrong."""

class SpecialBeams:
    """switches of the beam elements, for tests and comparisons; a model keeps the defaults; for available features, see the C++ code class PySpecialBeams"""
    geometricallyExactLumpedMass:bool
    """if True, ObjectBeamGeometricallyExact uses the lumped mass matrix of its nodes and their quadratic velocity vector instead of the element-consistent ones (default False); for comparisons and tests."""

class SpecialUserInterface:
    """flags that stop Exudyn from opening windows; meant for automated runs (test runners, CI, AI-assisted development), where a window that waits for a human stops everything; not intended for regular users; for available features, see the C++ code class PySpecialUserInterface"""
    suppressRenderer:bool
    """if True, SC.renderer.Start() returns immediately without opening a window, IsActive() is False - so that a 'while SC.renderer.IsActive()' loop ends at once - and DoIdleTasks() does nothing; default=False."""
    suppressSolutionViewer:bool
    """if True, mbs.SolutionViewer(...) and AnimateModes(...) return immediately instead of opening the viewer; default=False."""
    suppressPlots:bool
    """if True, PlotSensor and the other plotting helpers do not show a plot window; figures are still drawn and a figure given a file name is still saved; setting the environment variable EXUDYN_SUPPRESS_UI_WINDOW_OPEN additionally switches matplotlib to the non-interactive Agg backend, which also silences a plt.show() written in a script; default=False."""
    suppressDialogs:bool
    """if True, InteractiveDialog and the other tkinter dialogs return their defaults instead of opening a window; default=False."""
    @overload
    def SuppressAll(self, flag: bool=True) -> None: 
        """Set all four suppress flags at once; a run either wants windows or does not."""
        ...

class SpecialDeprecations:
    """how a deprecated name - a setting, an item parameter, a function - is reported: a DeprecationWarning once per session and name, or on every use, and a count of every use in the dictionary exudyn.sys[deprecationUse], by source (simulationSettings, visualizationSettings, items, functions) and name; see the C++ code class PySpecialDeprecations"""
    warnOnce:bool
    """if True (=default), each deprecated name warns once per session; if False, every use warns, e.g. to find all places in a script that use it."""
    recordUse:bool
    """if True (=default), every use of a deprecated name is counted in exudyn.sys[deprecationUse], by source and name, also when no warning is shown; a test reads it instead of catching warnings."""
    userFunctionListArguments:bool
    """if True, Python user functions get their vector arguments (q, q_t, ...) as lists, as before version 1.13.104, instead of read-only numpy arrays; False (=default); for the transition of scripts that change their arguments or add lists to them; deprecated, removed in 2031 (#3008)."""
    symbolicStarProduct:bool
    """if True, * of two exudyn.symbolic vectors is their scalar product and * with a symbolic matrix the matrix product, as before version 1.13.115; False (=default): it raises a TypeError, because numpy multiplies the components - dot() or @ give the products and multiply() the product of the components, alike for numpy arrays and symbolic vectors; deprecated, removed when * becomes the product of the components, as in numpy (#3015, #3016)."""
    @overload
    def Reset(self) -> None: 
        """Forget which names were warned about in this session, so that each one warns once more."""
        ...
    @overload
    def Warn(self, source: str, name: str, message: str, stackLevel: int=2) -> None: 
        """Report the use of a deprecated name from Python, as the C++ side does: a DeprecationWarning, once per session unless warnOnce is False, and a count in exudyn.sys[deprecationUse]; stackLevel=2 attributes the warning to the caller of the function that calls Warn."""
        ...

class SpecialUserTypes:
    """the names of the user types: OutputVariableType, NodeType and MarkerType have the values UserType0 to UserType3 for user items, e.g. a strain of a user element; a name set here is written wherever Exudyn writes the type - the header of a sensor file and so the labels of PlotSensor, messages, str() - and becomes an alias of the value, e.g. exudyn.OutputVariableType.BendingStrain; the name property of the value stays UserType0; see the C++ code class PySpecialUserTypes"""
    @overload
    def SetName(self, userType: OutputVariableType | NodeType | MarkerType, name: str) -> None: 
        """Give userType, UserType0 to UserType3 of OutputVariableType, NodeType or MarkerType, a name, which must be a Python name and not yet a name of the enumeration; a new name replaces the previous one and its alias.
        
        Examples:
            exu.special.userTypes.SetName(exu.OutputVariableType.UserType0, 'BendingStrain')
            exu.OutputVariableType.BendingStrain #the same value as UserType0
        """
        ...
    @overload
    def GetName(self, userType: OutputVariableType | NodeType | MarkerType) -> str: 
        """The name of userType: the name that was set, or UserType0, ..."""
        ...
    @overload
    def Reset(self) -> None: 
        """Remove all names of the user types and their aliases."""
        ...

class Special:
    """special attributes and functions, such as global (solver) flags or helper functions; not intended for regular users; for available features, see the C++ code class PySpecial"""
    @overload
    def InfoStat(self, writeOutput=True) -> List[int]: 
        """Retrieve list of global information on memory allocation and other counts as list:[array_new_counts, array_delete_counts, vector_new_counts, vector_delete_counts, matrix_new_counts, matrix_delete_counts, linkedDataVectorCast_counts]; May be extended in future; if writeOutput==True, it additionally prints the statistics; counts for new vectors and matrices should not depend on numberOfSteps, except for some objects such as ObjectGenericODE2 and for (sensor) output to files; Not available if code is compiled with __FAST_EXUDYN_LINALG flag."""
        ...
    @overload
    def RunLinalgBenchmark(self, minimumTime=0.05, numberOfThreads=1) -> List[dict]: 
        """The linear algebra micro-benchmark of this build (#3410): the time per call in ns of the operations of the computation functions of objects, markers and connectors and of the assembly, with Eigen as the reference: vector add, scale and MultAdd over sizes 3 to 500 and across the threading limit (group vector), Matrix3D, 6 x 6 and transformations (small), J^T f and J^T K J of a 3 x n Jacobian (jacobian), matrix times vector and the dense factorization and solve (dense), local Jacobians into the sparse triplets (assembly), AutoDiff<12> (autodiff), and a matrix of compile-time size as prototype; returns a list of dictionaries with group, library, operation, size, threads, nsPerCall and checkSum; each operation runs for at least minimumTime seconds; numberOfThreads > 1 adds the multithreaded vectors above the threading limit; tools/benchmarks/avx2Benchmark.py is the counterpart on the level of the solvers."""
        ...
    @property
    def currentRendererSystemContainer(self) -> Any:
        """the ``SystemContainer`` the renderer is attached to, or ``None``; the render engine can hold one at a time, which is why this is module-wide. It is set when a container attaches to the render engine and cleared when it detaches or is destroyed, and it is what the dialogs of ``exudyn.misc.GUI`` ask for; not intended for regular users."""
        ...
    @property
    def overrideSettings(self) -> dict:
        """the settings that persist between runs, read once by ``import exudyn`` from ``~/.exudyn/config.json``: a dictionary with one key per section, ``config``, ``visualizationSettings``, ``dialogs`` and ``resultsMonitor``; it is empty unless something was stored, and both Python and the C++ side read it. See Section sec-usersettings."""
        ...
    solver:SpecialSolver
    """special solver attributes and functions; not intended for regular users; for available features, see the C++ code class PySpecialSolver."""
    exceptions:SpecialExceptions
    """special flags for exceptions and checks; not intended for regular users; for available features, see the C++ code class PySpecialExceptions."""
    beams:SpecialBeams
    """switches of the beam elements, for tests and comparisons; a model keeps the defaults; for available features, see the C++ code class PySpecialBeams."""
    userInterface:SpecialUserInterface
    """flags that stop Exudyn from opening windows; meant for automated runs (test runners, CI, AI-assisted development), where a window that waits for a human stops everything; not intended for regular users; for available features, see the C++ code class PySpecialUserInterface."""
    deprecations:SpecialDeprecations
    """how a deprecated name - a setting, an item parameter, a function - is reported: a DeprecationWarning once per session and name, or on every use, and a count of every use in the dictionary exudyn.sys[deprecationUse], by source (simulationSettings, visualizationSettings, items, functions) and name; see the C++ code class PySpecialDeprecations."""
    userTypes:SpecialUserTypes
    """the names of the user types: OutputVariableType, NodeType and MarkerType have the values UserType0 to UserType3 for user items, e.g. a strain of a user element; a name set here is written wherever Exudyn writes the type - the header of a sensor file and so the labels of PlotSensor, messages, str() - and becomes an alias of the value, e.g. exudyn.OutputVariableType.BendingStrain; the name property of the value stays UserType0; see the C++ code class PySpecialUserTypes."""

class Experimental:
    """Experimental features, not intended for regular users; for available features, see the C++ code class PyExperimental"""
    eigenFullPivotLUsolverDebugLevel:int
    """debug output of the EigenDense solver with full pivoting: 0 (default) = none, 1 = rank and information, 2 = also the matrices."""
    markerSuperElementRigidTexpSO3:int
    """if nonzero (default), MarkerSuperElementRigid uses the additional tangent operator TexpSO3 of the rotation parameters."""
    @overload
    def EvaluateMathFunction(self, name: str, x: ArrayLike, y: ArrayLike=[], implementation: str='std', repetitions: int=1) -> Tuple[ArrayLike, float]: 
        """Evaluate a function of the math library the way the C++ code of Exudyn calls it, to compare the platforms (#2947): name is one of sin, cos, tan, asin, acos, atan, atan2, exp, log, pow, sinh, cosh, tanh, cbrt, fmod, sqrt; y is the second argument of atan2, pow and fmod, of the size of x; implementation is std (the C++ library, one call per value), stdLoop (in a loop the compiler may vectorize), portable (the functions of musl libc compiled into Exudyn, the same bits on every platform, #2948), exudyn (EM::Sin, ..., what the C++ code of Exudyn calls: the library, or portable with the switch EXUDYN_PORTABLE_MATH) or, on Windows x64, stdNoFMA3 (the UCRT without its FMA3 code path); the evaluation is repeated repetitions times for a timing.
        
        Returns the values as numpy array and the time per evaluation in seconds. python/testing/mathFunctionsPlatform.py compares the platforms with it
        """
        ...
