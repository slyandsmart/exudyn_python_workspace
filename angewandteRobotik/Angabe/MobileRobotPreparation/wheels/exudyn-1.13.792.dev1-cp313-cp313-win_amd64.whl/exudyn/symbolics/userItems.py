#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# This is an EXUDYN python utility library
#
# Details:  User items with the interfaces of the built-in items (#3111, #3125):
#           UserItemCreator(mbs) has the Create functions of mbs with the same
#           arguments, and creates ObjectUserBody and ObjectConnectorUser instead of the built-in objects, with the same
#           nodes, markers and loads. The user functions are Python functions, so that the system runs in Exudyn as
#           built; Record() replaces them by one symbolic recording per kind of item, which SymbolicSystem and the
#           export take. A script that builds a system with creator = mbs builds the same system of user items with
#           creator = UserItemCreator(mbs).
#           The items: CreateGround, CreateMassPoint, CreateRigidBody (on NodeRigidBodyEP or NodeRigidBodyRxyz, #3238), CreateSpringDamper,
#           CreateTorsionalSpringDamper, CreateSphereSphereContact (#3187, with a data node #3197), CreateCartesianSpringDamper,
#           CreateRigidBodySpringDamper (#3193), CreateRevoluteJoint, CreatePrismaticJoint, CreateSphericalJoint,
#           CreateDistanceConstraint (ObjectJointUser, #3140), CreateCoordinateConstraint (ObjectGenericDAE, #3193),
#           CreateForce, CreateTorque, CreateKinematicTree (#3508, floating base #3511) and
#           AddKinematicTreeMarker for its links (#3513). An argument a user item
#           does not support raises, naming it. A parameter of a mass point or a connector may be an expression of
#           named variables of the model, esym.Real(name, value, scope=mbs) (mass=m1, stiffness=k/2): the item gets its
#           value, the creator keeps the expression in parameterBindings, a ParameterBindings, for
#           SymbolicSystem(mbs, parameters=creator.parameterBindings) (#3152, #3159).
#
# Author:   Johannes Gerstmayr
# Date:     2026-10-27 (created)
#
# Copyright:This file is part of Exudyn. Exudyn is free software. You can redistribute it and/or modify it under the terms of the Exudyn license. See 'LICENSE.txt' for more details.
#
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

import numpy as np
import exudyn
import exudyn.itemInterface as eii
import exudyn.cMath as cMath
import exudyn.graphics as graphics
from exudyn.advancedUtilities import CreateSymbolicUserFunction
from exudyn.symbolics.codeExport import ToFunction
import exudyn.symbolics.kinematics as su
from exudyn.symbolics.utilities import IfThenElse
from exudyn.rigidBodyUtilities import (RotationMatrix2RotXYZ, AngularVelocity2RotXYZ_t, ComputeOrthonormalBasis,
                                       RotationMatrix2EulerParameters, AngularVelocity2EulerParameters_t)
from exudyn.misc.mainSystemExtensions import GetMarkersPosRot, JointPreCheckCalcBodyMarkers, _FrameFromHT, _KinematicTreeData

#public API of this module; kept complete by tools/checkAll.py (#2444)
__all__ = ['JointJacobianUserFunction', 'ParameterBindings', 'UserItemCreator']


#the mass point, ObjectUserBody on a NodePoint, parameters [mass]: as ObjectMassPoint, M = m I, the position of a local
#point is the node position plus the local position; it does not rotate
def _UFmassPointMass(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
    return parameters[0]*np.eye(3)

def _UFmassPointMassIntegral(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
    return parameters[0]*np.eye(3)

def _UFmassPointPosition(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    return qTotal + localPosition

def _UFmassPointPositionJacobian(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    return np.eye(3)

def _UFmassPointRotationMatrix(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    return np.eye(3)

def _UFmassPointRotationJacobian(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    return np.zeros((3, 3))

#the functions of exudyn.symbolics.kinematics for an argument: exudyn.symbolic while a function is recorded, else cMath,
#so that the rigid body computes numbers in Exudyn and is recorded by Record
def _Functions(argument):
    return exudyn.symbolic if isinstance(argument, (exudyn.symbolic.Vector, exudyn.symbolic.Matrix)) else cMath

def _Matrix(rows, functions):
    return exudyn.symbolic.Matrix(rows) if functions is exudyn.symbolic else np.array(rows, dtype=float)

def _Vector(components, functions):
    return exudyn.symbolic.Vector(components) if functions is exudyn.symbolic else np.array(components, dtype=float)

def _Blocks3x6(left, right, functions):
    #the 3 x 6 matrix [left, right] of two 3 x 3 matrices; None is a zero block
    return _Matrix([[left[i, j] if left is not None else 0 for j in range(3)]
                    + [right[i, j] if right is not None else 0 for j in range(3)] for i in range(3)], functions)

#the rigid body, ObjectUserBody on a NodeRigidBodyRxyz, qTotal = [position, Tait-Bryan angles], parameters [mass,
#inertia (6 components, about the node, as ObjectRigidBody), centerOfMass]: the mass matrix and the forces of
#src/ImplObjects/CObjectRigidBody.cpp with the local G matrix, the position of a local point p + A pLocal
def _UFrigidBodyMass(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
    F = _Functions(qTotal)
    (m, A, G) = (parameters[0], su.RotXYZ2RotationMatrix(qTotal[3:6], F), su.RotXYZ2GLocal(qTotal[3:6], F))
    Mrot = G.T @ su.Inertia6D2InertiaTensor(parameters[1:7], F) @ G
    Mtr = (-m)*(A @ su.Skew(parameters[7:10], F) @ G) #the coupling of a center of mass off the node
    return _Matrix([[m if i == j else 0 for j in range(3)] + [Mtr[i, j] for j in range(3)] for i in range(3)]
                   + [[Mtr[j, i] for j in range(3)] + [Mrot[i, j] for j in range(3)] for i in range(3)], F)

def _UFrigidBodyForce(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
    #the right-hand side of the quadratic velocity terms: -G^T (omega x J omega + J G_t rot_t) on the rotations, and
    #-A (omega x (U x omega) + U x G_t rot_t) on the translations, U = -m centerOfMass, omega local
    F = _Functions(qTotal)
    (rot, rot_t) = (qTotal[3:6], q_t[3:6])
    J = su.Inertia6D2InertiaTensor(parameters[1:7], F)
    G = su.RotXYZ2GLocal(rot, F)
    omega = G @ rot_t
    G_tRot_t = su.RotXYZ2GLocal_t(rot, rot_t, F) @ rot_t
    torques = G.T @ (su.Cross(omega, J @ omega, F) + J @ G_tRot_t)
    U = (-parameters[0])*parameters[7:10]
    forces = su.RotXYZ2RotationMatrix(rot, F) @ (su.Cross(omega, su.Cross(U, omega, F), F) + su.Cross(U, G_tRot_t, F))
    return _Vector([-forces[i] for i in range(3)] + [-torques[i] for i in range(3)], F)

def _UFrigidBodyMassIntegral(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
    #m J_pos at the center of mass
    F = _Functions(qTotal)
    m = parameters[0]
    rot = qTotal[3:6]
    return _Blocks3x6(_Matrix([[m if i == j else 0 for j in range(3)] for i in range(3)], F),
                      (-m)*(su.RotXYZ2RotationMatrix(rot, F) @ su.Skew(parameters[7:10], F) @ su.RotXYZ2GLocal(rot, F)), F)

def _UFrigidBodyPosition(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    return qTotal[0:3] + su.RotXYZ2RotationMatrix(qTotal[3:6], _Functions(qTotal)) @ localPosition

def _UFrigidBodyPositionJacobian(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    F = _Functions(qTotal)
    rot = qTotal[3:6]
    return _Blocks3x6(_Matrix(np.eye(3), F), -(su.RotXYZ2RotationMatrix(rot, F) @ su.Skew(localPosition, F) @ su.RotXYZ2GLocal(rot, F)), F)

def _UFrigidBodyRotationMatrix(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    return su.RotXYZ2RotationMatrix(qTotal[3:6], _Functions(qTotal))

def _UFrigidBodyRotationJacobian(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    F = _Functions(qTotal)
    rot = qTotal[3:6]
    return _Blocks3x6(None, su.RotXYZ2RotationMatrix(rot, F) @ su.RotXYZ2GLocal(rot, F), F)

#the rigid body on a NodeRigidBodyEP (#3238), qTotal = [position, Euler parameters p], the parameters as above: the mass
#matrix and the forces of CObjectRigidBody with GLocal(p), omega = GLocal p_t, GLocal(p_t) p_t = 0; the algebraic
#equation p^T p - 1 = 0 is the one of the node
def _BlocksEP(left, right, functions):
    #the 3 x 7 matrix [left, right] of a 3 x 3 and a 3 x 4 matrix; None is a zero block
    return _Matrix([[left[i, j] if left is not None else 0 for j in range(3)]
                    + [right[i, j] if right is not None else 0 for j in range(4)] for i in range(3)], functions)

def _UFrigidBodyEPMass(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
    F = _Functions(qTotal)
    (m, A, G) = (parameters[0], su.EulerParameters2RotationMatrix(qTotal[3:7], F), su.EulerParameters2GLocal(qTotal[3:7], F))
    Mrot = G.T @ su.Inertia6D2InertiaTensor(parameters[1:7], F) @ G
    Mtr = (-m)*(A @ su.Skew(parameters[7:10], F) @ G)
    return _Matrix([[m if i == j else 0 for j in range(3)] + [Mtr[i, j] for j in range(4)] for i in range(3)]
                   + [[Mtr[j, i] for j in range(3)] + [Mrot[i, j] for j in range(4)] for i in range(4)], F)

def _UFrigidBodyEPForce(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
    #-G^T (omega x J omega) on the Euler parameters, -A (omega x (U x omega)) on the translations, U = -m centerOfMass
    F = _Functions(qTotal)
    p = qTotal[3:7]
    J = su.Inertia6D2InertiaTensor(parameters[1:7], F)
    G = su.EulerParameters2GLocal(p, F)
    omega = G @ q_t[3:7]
    torques = G.T @ su.Cross(omega, J @ omega, F)
    U = (-parameters[0])*parameters[7:10]
    forces = su.EulerParameters2RotationMatrix(p, F) @ su.Cross(omega, su.Cross(U, omega, F), F)
    return _Vector([-forces[i] for i in range(3)] + [-torques[i] for i in range(4)], F)

def _UFrigidBodyEPMassIntegral(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
    F = _Functions(qTotal)
    (m, p) = (parameters[0], qTotal[3:7])
    return _BlocksEP(_Matrix([[m if i == j else 0 for j in range(3)] for i in range(3)], F),
                     (-m)*(su.EulerParameters2RotationMatrix(p, F) @ su.Skew(parameters[7:10], F) @ su.EulerParameters2GLocal(p, F)), F)

def _UFrigidBodyEPPosition(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    return qTotal[0:3] + su.EulerParameters2RotationMatrix(qTotal[3:7], _Functions(qTotal)) @ localPosition

def _UFrigidBodyEPPositionJacobian(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    F = _Functions(qTotal)
    p = qTotal[3:7]
    return _BlocksEP(_Matrix(np.eye(3), F), -(su.EulerParameters2RotationMatrix(p, F) @ su.Skew(localPosition, F)
                                             @ su.EulerParameters2GLocal(p, F)), F)

def _UFrigidBodyEPRotationMatrix(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    return su.EulerParameters2RotationMatrix(qTotal[3:7], _Functions(qTotal))

def _UFrigidBodyEPRotationJacobian(mbs, t, itemNumber, localPosition, qRef, qTotal, q_t, parameters):
    F = _Functions(qTotal)
    p = qTotal[3:7]
    return _BlocksEP(None, su.EulerParameters2RotationMatrix(p, F) @ su.EulerParameters2GLocal(p, F), F)

#the kinematic tree, ObjectUserBody on the NodeGenericODE2 of its joints, with a fixed base (#3508): the recursions of
#src/ImplObjects/CObjectKinematicTree.cpp (namespace KinematicTreeHT) on the placement (R, p) of each link in its parent,
#x_parent = R x_link + p, with motions (omega, v) and forces (n, f) in link coordinates at the link origin; written on
#Python lists of scalars - numbers, or exudyn.symbolic.Real while recorded -, so that a known zero is no operation. The
#topology (joint types, parents, whether link forces are given, whether the base floats) is a Python constant of the
#functions, one variant per topology; the link data, the gravity, the joint forces and gains, the link forces and the
#base offset of a floating base are the parameters, in the layout of _TreeParameters
_treeLinkSize = 22 #per link: joint transformation (9, row by row), joint offset (3), mass, center of mass (3), inertia at the center of mass (Inertia6D)
_treeJointSize = 5 #per joint: force, P gain, D gain, position offset, velocity offset
_treeLoadSize = 6 #per link, if link forces are given: force (3), torque (3), in global coordinates

def _TreeParameters(jointHTs, linkMasses, linkCOMs, linkInertiasCOM, gravity, jointForces, P, D, positionOffsets,
                    velocityOffsets, linkForces=None, linkTorques=None, baseOffset=None):
    """the parameters of a user kinematic tree: the gravity, then per link the joint transformation, joint offset, mass,
    center of mass and inertia (Inertia6D at the center of mass), then per joint the force, the P and D gains and the
    position and velocity offsets, then - only if linkForces or linkTorques is given - per link the force and the torque
    in global coordinates, then - only with a floating base - the base offset"""
    parameters = list(gravity)
    for (HT, mass, com, inertia) in zip(jointHTs, linkMasses, linkCOMs, linkInertiasCOM):
        (A, p) = (np.array(HT.rotation), np.array(HT.translation))
        J = np.array(inertia)
        parameters += list(A.flatten()) + list(p) + [mass] + list(com) + [J[0, 0], J[1, 1], J[2, 2], J[1, 2], J[0, 2], J[0, 1]]
    for k in range(len(linkMasses)):
        parameters += [jointForces[k], P[k], D[k], positionOffsets[k], velocityOffsets[k]]
    if linkForces is not None or linkTorques is not None:
        for k in range(len(linkMasses)):
            parameters += ([float(x) for x in linkForces[k]] if linkForces is not None else [0.]*3) + (
                [float(x) for x in linkTorques[k]] if linkTorques is not None else [0.]*3)
    if baseOffset is not None:
        parameters += [float(x) for x in baseOffset]
    return parameters

def _IsZero(x):
    return isinstance(x, (int, float)) and x == 0

def _Mul(a, b):
    return 0 if _IsZero(a) or _IsZero(b) else a*b

def _Add(a, b):
    return b if _IsZero(a) else (a if _IsZero(b) else a + b)

def _Sum(terms):
    result = 0
    for term in terms:
        result = _Add(result, term)
    return result

def _MV(R, x): #R x
    return [_Sum(_Mul(R[i][k], x[k]) for k in range(3)) for i in range(3)]

def _MTV(R, x): #R^T x
    return [_Sum(_Mul(R[k][i], x[k]) for k in range(3)) for i in range(3)]

def _MM(A, B): #A B
    return [[_Sum(_Mul(A[i][k], B[k][j]) for k in range(3)) for j in range(3)] for i in range(3)]

def _MMT(A, B): #A B^T
    return [[_Sum(_Mul(A[i][k], B[j][k]) for k in range(3)) for j in range(3)] for i in range(3)]

def _V(a, b, sign=1): #a + sign b
    return [_Add(a[i], _Mul(sign, b[i])) for i in range(3)]

def _SV(s, a): #s a
    return [_Mul(s, a[i]) for i in range(3)]

def _X(a, b): #a x b
    return [_Add(_Mul(a[1], b[2]), _Mul(-1, _Mul(a[2], b[1]))),
            _Add(_Mul(a[2], b[0]), _Mul(-1, _Mul(a[0], b[2]))),
            _Add(_Mul(a[0], b[1]), _Mul(-1, _Mul(a[1], b[0])))]

def _SkewSkew(a, b): #Skew(a) Skew(b) = b a^T - (a^T b) I
    ab = _Sum(_Mul(a[k], b[k]) for k in range(3))
    return [[_Add(_Mul(b[i], a[j]), _Mul(-1, ab) if i == j else 0) for j in range(3)] for i in range(3)]

def _Unit(k, value): #value e_k
    return [value if i == k else 0 for i in range(3)]

class _TreeInertia:
    """the spatial inertia of a link at its origin: mass m, mass times center of mass mc, inertia tensor J at the origin"""
    def __init__(self, m, com, Jcom):
        self.m = m
        self.mc = _SV(m, com)
        Scc = _SkewSkew(com, com)
        self.J = [[_Add(Jcom[i][j], _Mul(-1, _Mul(m, Scc[i][j]))) for j in range(3)] for i in range(3)]

    def Mult(self, w, v): #I (omega, v) = (J omega + mc x v, m v - mc x omega)
        return (_V(_MV(self.J, w), _X(self.mc, v)), _V(_SV(self.m, v), _X(self.mc, w), -1))

    def AddChild(self, R, p, child):
        """the inertia of a child at its origin added, its origin placed by (R, p) in this one: J += R J_c R^T
        - Skew(p) Skew(R mc_c) - Skew(R mc_c) Skew(p) - m_c Skew(p) Skew(p), without a division by the mass"""
        Rmc = _MV(R, child.mc)
        RJR = _MMT(_MM(R, child.J), R)
        (S0, S1, S2) = (_SkewSkew(p, Rmc), _SkewSkew(Rmc, p), _SkewSkew(p, p))
        self.J = [[_Sum([self.J[i][j], RJR[i][j], _Mul(-1, S0[i][j]), _Mul(-1, S1[i][j]), _Mul(-1, _Mul(child.m, S2[i][j]))])
                   for j in range(3)] for i in range(3)]
        self.mc = _V(self.mc, _V(Rmc, _SV(child.m, p)))
        self.m = _Add(self.m, child.m)

def _TreeJoint(jointType):
    """(revolute, axis) of an exu.JointType of the kinematic tree"""
    value = int(jointType)
    if value < 1 or value > 6:
        raise ValueError('UserItemCreator.CreateKinematicTree: the joint type ' + str(jointType) + ' is not one of '
                         'RevoluteX, RevoluteY, RevoluteZ, PrismaticX, PrismaticY, PrismaticZ')
    return (value <= 3, (value - 1) % 3)

def _TreeBase(qTotal, q_t, n, parameters, F, offsetIndex):
    """the floating base on a NodeRigidBodyEP, coordinates n to n+6 of the body (#3511): its rotation A and local G
    matrix as lists, its position, its motion (omega, v) in its frame, its bias acceleration - the gravity as an
    acceleration of the base; GLocal(theta_t) theta_t = 0 for Euler parameters - and the base offset of the root links"""
    theta = qTotal[n + 3:n + 7]
    (Am, Gm) = (su.EulerParameters2RotationMatrix(theta, F), su.EulerParameters2GLocal(theta, F))
    A = [[Am[i, j] for j in range(3)] for i in range(3)]
    G = [[Gm[i, k] for k in range(4)] for i in range(3)]
    w = [_Sum(_Mul(G[i][k], q_t[n + 3 + k]) for k in range(4)) for i in range(3)]
    v = _MTV(A, [q_t[n + k] for k in range(3)])
    gravity = [parameters[0], parameters[1], parameters[2]]
    return {'A': A, 'G': G, 'p': [qTotal[n + k] for k in range(3)], 'w': w, 'v': v, 'aw': [0, 0, 0],
            'av': _V(_MTV(A, _SV(-1, gravity)), _X(w, v), -1),
            'offset': [parameters[offsetIndex + k] for k in range(3)]}

def _TreeBaseForce(k, base, n, f):
    """the force (n, f) of the base frame on base coordinate k, by the transposed motion subspace: the translations
    (A f)_k, the Euler parameters (G^T n)_(k-3)"""
    if k < 3:
        return _Sum(_Mul(base['A'][k][r], f[r]) for r in range(3))
    return _Sum(_Mul(base['G'][r][k - 3], n[r]) for r in range(3))

def _TreeBaseMotion(k, base):
    """column k of the motion subspace of the base as (omega, v) in its frame: (0, A^T e_k), (G e_(k-3), 0)"""
    if k < 3:
        return ([0, 0, 0], [base['A'][k][r] for r in range(3)])
    return ([base['G'][r][k - 3] for r in range(3)], [0, 0, 0])

def _TreeLinks(joints, parents, qTotal, q_t, parameters, F, dynamics, base=None):
    """the placements (R, p) of the links in their parents - the root links in the frame of a floating base, shifted by
    its offset; with dynamics also the velocities, the bias accelerations - the gravity as an acceleration of the
    base - and the inertias"""
    n = len(joints)
    links = []
    gravity = [parameters[0], parameters[1], parameters[2]]
    for i in range(n):
        o = 3 + _treeLinkSize*i
        A = [[parameters[o + 3*r + c] for c in range(3)] for r in range(3)]
        p = [parameters[o + 9 + k] for k in range(3)]
        (revolute, axis) = joints[i]
        q = qTotal[i]
        if revolute:
            (c, s) = (F.cos(q), F.sin(q))
            rotation = {0: [[1, 0, 0], [0, c, -s], [0, s, c]], 1: [[c, 0, s], [0, 1, 0], [-s, 0, c]],
                        2: [[c, -s, 0], [s, c, 0], [0, 0, 1]]}[axis]
            R = _MM(A, rotation)
        else:
            R = A
            p = _V(p, _SV(q, [A[k][axis] for k in range(3)]))
        parent = parents[i]
        if parent < 0 and base is not None:
            p = _V(p, base['offset'])
        link = {'R': R, 'p': p}
        if dynamics:
            qt = q_t[i]
            (wJ, vJ) = (_Unit(axis, qt), [0, 0, 0]) if revolute else ([0, 0, 0], _Unit(axis, qt))
            if parent < 0 and base is None:
                (w, v, aw, av) = (wJ, vJ, [0, 0, 0], _MTV(R, _SV(-1, gravity)))
            else:
                P = links[parent] if parent >= 0 else base
                w = _V(_MTV(R, P['w']), wJ)
                v = _V(_MTV(R, _V(P['v'], _X(P['w'], p))), vJ)
                aw = _V(_MTV(R, P['aw']), _X(w, wJ))
                av = _V(_MTV(R, _V(P['av'], _X(P['aw'], p))), _V(_X(v, wJ), _X(w, vJ)))
            Jcom = [parameters[o + 16], parameters[o + 17], parameters[o + 18], parameters[o + 19], parameters[o + 20], parameters[o + 21]]
            Jcom = [[Jcom[0], Jcom[5], Jcom[4]], [Jcom[5], Jcom[1], Jcom[3]], [Jcom[4], Jcom[3], Jcom[2]]]
            link.update({'w': w, 'v': v, 'aw': aw, 'av': av,
                         'inertia': _TreeInertia(parameters[o + 12], [parameters[o + 13], parameters[o + 14], parameters[o + 15]], Jcom)})
        links.append(link)
    return links

def _TreeJointForce(joint, n, f):
    """the component of a force (n, f) along the motion subspace of the joint"""
    return n[joint[1]] if joint[0] else f[joint[1]]

def _TreeToParent(R, p, n, f):
    """a force (n, f) of the link in parent coordinates: (R n + p x R f, R f)"""
    Rf = _MV(R, f)
    return (_V(_MV(R, n), _X(p, Rf)), Rf)

def _TreeOffsetIndex(n, linkLoads):
    """the index of the base offset in the parameters of a tree with a floating base"""
    return 3 + (_treeLinkSize + _treeJointSize + (_treeLoadSize if linkLoads else 0))*n

def _TreeFunctions(jointTypes, linkParents, linkLoads=False, floating=False):
    """the user functions of a kinematic tree of a topology: the mass matrix by composite rigid bodies and the forces by
    recursive Newton-Euler, as CObjectKinematicTree computes them; with linkLoads, the forces and torques per link of
    the parameters; with floating, the base on a NodeRigidBodyEP, its 7 coordinates after the joints"""
    joints = [_TreeJoint(jointType) for jointType in jointTypes]
    parents = [int(parent) for parent in linkParents]
    n = len(joints)
    nBase = 7 if floating else 0

    def Base(qTotal, q_t, parameters, F):
        return _TreeBase(qTotal, q_t, n, parameters, F, _TreeOffsetIndex(n, linkLoads)) if floating else None

    def UFmass(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
        F = _Functions(qTotal)
        base = Base(qTotal, q_t, parameters, F)
        links = _TreeLinks(joints, parents, qTotal, q_t, parameters, F, True, base)
        inertiaBase = _TreeInertia(0, [0, 0, 0], [[0]*3 for k in range(3)])
        for i in range(n - 1, -1, -1): #the composite inertias, from the leaves to the base
            if parents[i] >= 0:
                links[parents[i]]['inertia'].AddChild(links[i]['R'], links[i]['p'], links[i]['inertia'])
            elif floating:
                inertiaBase.AddChild(links[i]['R'], links[i]['p'], links[i]['inertia'])
        M = [[0]*(n + nBase) for i in range(n + nBase)]
        for k in range(nBase): #the block of the base: S^T I S
            (nk, fk) = inertiaBase.Mult(*_TreeBaseMotion(k, base))
            for m in range(nBase):
                M[n + m][n + k] = _TreeBaseForce(m, base, nk, fk)
        for i in range(n):
            (revolute, axis) = joints[i]
            (w, v) = (_Unit(axis, 1), [0, 0, 0]) if revolute else ([0, 0, 0], _Unit(axis, 1))
            (nh, fh) = links[i]['inertia'].Mult(w, v)
            M[i][i] = _TreeJointForce(joints[i], nh, fh)
            j = i
            while parents[j] >= 0:
                (nh, fh) = _TreeToParent(links[j]['R'], links[j]['p'], nh, fh)
                j = parents[j]
                M[i][j] = _TreeJointForce(joints[j], nh, fh)
                M[j][i] = M[i][j]
            if floating: #the coupling of joint i and the base, the force of its composite inertia carried into the base
                (nb, fb) = _TreeToParent(links[j]['R'], links[j]['p'], nh, fh)
                for k in range(nBase):
                    M[n + k][i] = _TreeBaseForce(k, base, nb, fb)
                    M[i][n + k] = M[n + k][i]
        return _Matrix(M, F)

    def UFforce(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
        #-(I a + v x* I v) of recursive Newton-Euler with the bias accelerations, plus the joint forces and the P and D
        #control, as AddJointForces; with a floating base, the forces of the root links on the base coordinates
        F = _Functions(qTotal)
        base = Base(qTotal, q_t, parameters, F)
        links = _TreeLinks(joints, parents, qTotal, q_t, parameters, F, True, base)
        for link in links: #F = I a + v x* (I v), the force product (w, v) x* (n, f) = (w x n + v x f, w x f)
            inertia = link['inertia']
            (nA, fA) = inertia.Mult(link['aw'], link['av'])
            (nI, fI) = inertia.Mult(link['w'], link['v'])
            link['n'] = _V(nA, _V(_X(link['w'], nI), _X(link['v'], fI)))
            link['f'] = _V(fA, _X(link['w'], fI))
        if linkLoads: #the forces and torques per link in global coordinates, the force at the origin of the link (#3510)
            o = 3 + (_treeLinkSize + _treeJointSize)*n
            rotations = []
            for i in range(n):
                if parents[i] >= 0:
                    R = _MM(rotations[parents[i]], links[i]['R'])
                else:
                    R = _MM(base['A'], links[i]['R']) if floating else links[i]['R']
                rotations.append(R)
                load = [parameters[o + _treeLoadSize*i + k] for k in range(_treeLoadSize)]
                links[i]['f'] = _V(links[i]['f'], _MTV(R, load[0:3]), -1)
                links[i]['n'] = _V(links[i]['n'], _MTV(R, load[3:6]), -1)
        f = [0]*n
        (nB, fB) = ([0, 0, 0], [0, 0, 0])
        for i in range(n - 1, -1, -1):
            f[i] = _TreeJointForce(joints[i], links[i]['n'], links[i]['f'])
            if parents[i] >= 0 or floating:
                (nP, fP) = _TreeToParent(links[i]['R'], links[i]['p'], links[i]['n'], links[i]['f'])
                if parents[i] >= 0:
                    parent = links[parents[i]]
                    (parent['n'], parent['f']) = (_V(parent['n'], nP), _V(parent['f'], fP))
                else:
                    (nB, fB) = (_V(nB, nP), _V(fB, fP))
        o = 3 + _treeLinkSize*n
        forces = []
        for i in range(n):
            (force, P, D, positionOffset, velocityOffset) = [parameters[o + _treeJointSize*i + k] for k in range(_treeJointSize)]
            forces.append(_Sum([_Mul(-1, f[i]), force, _Mul(P, _Add(positionOffset, _Mul(-1, qTotal[i]))),
                                _Mul(D, _Add(velocityOffset, _Mul(-1, q_t[i])))]))
        forces += [_Mul(-1, _TreeBaseForce(k, base, nB, fB)) for k in range(nBase)]
        return _Vector(forces, F)

    return [('massMatrixUserFunction', UFmass), ('forceUserFunction', UFforce)]

def _TreeGraphicsFunction(jointTypes, linkParents, baseOffset, graphicsDataList, linkLoads=False, floating=False):
    """the graphicsDataUserFunction of a user kinematic tree: the graphics of each link, given in its frame as for
    ObjectKinematicTree, moved into the global frame of the link; the root links placed by the base offset, in the
    frame of a floating base"""
    joints = [_TreeJoint(jointType) for jointType in jointTypes]
    parents = [int(parent) for parent in linkParents]
    n = len(joints)
    def UFgraphics(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
        base = _TreeBase(qTotal, q_t, n, parameters, cMath, _TreeOffsetIndex(n, linkLoads)) if floating else None
        links = _TreeLinks(joints, parents, qTotal, q_t, parameters, cMath, False, base)
        (frames, result) = ([], [])
        for i in range(n):
            (R, p) = (np.array(links[i]['R'], dtype=float), np.array(links[i]['p'], dtype=float))
            if parents[i] >= 0:
                (Rp, pp) = frames[parents[i]]
                (R, p) = (Rp @ R, pp + Rp @ p)
            elif floating:
                (AB, pB) = (np.array(base['A'], dtype=float), np.array(base['p'], dtype=float))
                (R, p) = (AB @ R, pB + AB @ p)
            else:
                p = p + np.array(baseOffset, dtype=float)
            frames.append((R, p))
            result += [graphics.Move(g, p, R) for g in graphicsDataList[i]]
        return result
    return UFgraphics

def _TreeParametersSize(n, linkLoads, floating):
    """the number of parameters of a user kinematic tree"""
    return 3 + (_treeLinkSize + _treeJointSize + (_treeLoadSize if linkLoads else 0))*n + (3 if floating else 0)

def _TreeMarkerFunctions(jointTypes, linkParents, linkNumber, linkLoads=False, floating=False):
    """the user functions of a MarkerBodyUser on link linkNumber of a user kinematic tree (#3513), as
    MarkerKinematicTreeRigid: the frame of the link at the local position and its geometric Jacobians, by the joints
    from the root to the link - a revolute joint the axis and its moment about the point, a prismatic joint the axis -
    and with a floating base its translations and the rotations A GLocal e_k; the parameters are those of the tree,
    then the base offset of a fixed base, the local position and the local rotation (row by row, #3517), which turns
    the frame of the marker against the link"""
    joints = [_TreeJoint(jointType) for jointType in jointTypes]
    parents = [int(parent) for parent in linkParents]
    n = len(joints)
    nBase = 7 if floating else 0
    o = _TreeParametersSize(n, linkLoads, floating)
    chain = [linkNumber]
    while parents[chain[0]] >= 0:
        chain.insert(0, parents[chain[0]])

    def Frames(qTotal, q_t, parameters):
        #the global frames (R, p) of the links of the chain, the base, the point and the functions
        F = _Functions(qTotal)
        base = _TreeBase(qTotal, q_t, n, parameters, F, _TreeOffsetIndex(n, linkLoads)) if floating else None
        links = _TreeLinks(joints, parents, qTotal, q_t, parameters, F, False, base)
        frames = {}
        for i in chain:
            (R, p) = (links[i]['R'], links[i]['p'])
            if parents[i] >= 0:
                (Rp, pp) = frames[parents[i]]
                frames[i] = (_MM(Rp, R), _V(pp, _MV(Rp, p)))
            elif floating:
                frames[i] = (_MM(base['A'], R), _V(base['p'], _MV(base['A'], p)))
            else:
                frames[i] = (R, _V([parameters[o + k] for k in range(3)], p))
        (R, p) = frames[linkNumber]
        point = _V(p, _MV(R, [parameters[o + 3 + k] for k in range(3)]))
        return (frames, base, point, F)

    def Jacobians(qTotal, q_t, parameters):
        (frames, base, point, F) = Frames(qTotal, q_t, parameters)
        (Jpos, Jrot) = ([[0]*(n + nBase) for k in range(3)], [[0]*(n + nBase) for k in range(3)])
        for j in chain:
            (revolute, axis) = joints[j]
            (R, p) = frames[j]
            e = [R[k][axis] for k in range(3)]
            column = _X(e, _V(point, p, -1)) if revolute else e
            for k in range(3):
                Jpos[k][j] = column[k]
                if revolute:
                    Jrot[k][j] = e[k]
        if floating: #as CObjectKinematicTree::ComputeJacobian
            r = _V(point, base['p'], -1)
            for m in range(3):
                Jpos[m][n + m] = 1
            for m in range(4):
                e = _MV(base['A'], [base['G'][k][m] for k in range(3)])
                column = _X(e, r)
                for k in range(3):
                    (Jrot[k][n + 3 + m], Jpos[k][n + 3 + m]) = (e[k], column[k])
        return (Jpos, Jrot, F)

    def UFposition(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
        (frames, base, point, F) = Frames(qTotal, q_t, parameters)
        return _Vector(point, F)

    def UFrotation(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
        (frames, base, point, F) = Frames(qTotal, q_t, parameters)
        localRotation = [[parameters[o + 6 + 3*r + c] for c in range(3)] for r in range(3)]
        return _Matrix(_MM(frames[linkNumber][0], localRotation), F)

    def UFpositionJacobian(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
        (Jpos, Jrot, F) = Jacobians(qTotal, q_t, parameters)
        return _Matrix(Jpos, F)

    def UFrotationJacobian(mbs, t, itemNumber, qRef, qTotal, q_t, parameters):
        (Jpos, Jrot, F) = Jacobians(qTotal, q_t, parameters)
        return _Matrix(Jrot, F)

    return [('positionUserFunction', UFposition), ('positionJacobianUserFunction', UFpositionJacobian),
            ('rotationMatrixUserFunction', UFrotation), ('rotationJacobianUserFunction', UFrotationJacobian)]

#the connectors and joints get the frame of each marker, an exudyn.HT, and the connectors also its twist, an
#exudyn.Twist; while recorded, a kinematics.HT and a kinematics.Twist of symbolic parts with the same methods (#3183)

#the spring-damper, ObjectConnectorUser on two position markers, parameters [stiffness, damping, referenceLength, force,
#velocityOffset]: as ObjectConnectorSpringDamper, the force k (L - L0) + d (dL/dt - v0) + f along the axis, pulling
#marker 0 towards marker 1 if positive; with cMath, it computes numbers and is recorded
def _UFspringDamperForce(mbs, t, itemNumber, HT0, twist0, HT1, twist1, dataCoordinates, parameters):
    delta = HT1.translation - HT0.translation
    length = cMath.sqrt(delta @ delta)
    axis = (1/length)*delta
    force = (parameters[0]*(length - parameters[2]) + parameters[1]*(axis @ (twist1 - twist0).velocity - parameters[4])
             + parameters[3])
    return np.hstack([force*axis, -force*axis])

#the torsional spring-damper, ObjectConnectorUser on two rigid markers, parameters [stiffness, damping, offset,
#velocityOffset, torque]: as ObjectConnectorTorsionalSpringDamper, the torque k (phi - phi0) + d (omega - omega0) + tau0
#about the z-axis of marker 0, phi the z-angle of the relative rotation A0^T A1 as Tait-Bryan angle, omega the z-component
#of the relative angular velocity in the frame of marker 0; no forces. As the forces of the spring-damper, the torques act
#on the markers: a positive torque turns marker 0 about the axis and marker 1 back. With unlimitedRotations, a Python
#constant of the recording, the angle continues over the turns: the angle in (-pi, pi] plus the turns of 2 pi that bring
#it nearest to the angle of the last step, the data coordinate of a NodeGenericData, which the post-Newton step sets, as
#CObjectConnectorTorsionalSpringDamper does (#3218)
def _TorsionalSpringDamperAngle(HT0, HT1, dataCoordinates, unlimitedRotations, F):
    relative = HT0.Relative(HT1).rotation
    angle = F.atan2(-relative[0, 1], relative[0, 0])
    if unlimitedRotations:
        turns = (dataCoordinates[0] - angle)*(1/(2*np.pi))
        angle = angle + 2*np.pi*(F.round(turns) if F is exudyn.symbolic else round(turns))
    return angle

def _TorsionalSpringDamperFunctions(unlimitedRotations):
    #the user functions of the spring-damper without or with the turns, unlimitedRotations a constant of the recording
    def UFforce(mbs, t, itemNumber, HT0, twist0, HT1, twist1, dataCoordinates, parameters):
        A0 = HT0.rotation
        F = _Functions(A0)
        angle = _TorsionalSpringDamperAngle(HT0, HT1, dataCoordinates, unlimitedRotations, F)
        omega = su.RelativeTwist(HT0, twist0, HT1, twist1).angularVelocity[2]
        torque = parameters[0]*(angle - parameters[2]) + parameters[1]*(omega - parameters[3]) + parameters[4]
        torque0 = [torque*A0[i, 2] for i in range(3)]
        return _Vector([0, 0, 0] + torque0 + [0, 0, 0] + [-x for x in torque0], F)

    def UFpostNewton(mbs, t, itemNumber, HT0, twist0, HT1, twist1, dataCoordinates, dataCoordinatesStartOfStep, parameters):
        #the continuous angle into the data; no error and no recommended step size
        return [0., -1., _TorsionalSpringDamperAngle(HT0, HT1, dataCoordinates, True, _Functions(HT0.rotation))]
    if unlimitedRotations:
        return [('forceUserFunction', UFforce), ('postNewtonStepUserFunction', UFpostNewton)]
    return [('forceUserFunction', UFforce)]

_torsionalSpringDamperFunctions = {unlimited: _TorsionalSpringDamperFunctions(unlimited) for unlimited in [False, True]}

#the sphere-sphere contact, ObjectConnectorUser on two position markers with a NodeGenericData of the gap of the last
#iteration and the impact velocity, parameters [radius0, radius1, stiffness, damping, minimumImpactVelocity,
#impactFactor]: as ObjectContactSphereSphere without plasticity and adhesion, the normal force k delta - d dg/dt on
#sphere 1 along the normal n from sphere 0 to sphere 1, delta = -g, g = |p1 - p0| - r0 - r1, while the gap of the data
#is negative; with an impact model the damping lambda delta dg/dt of the restitution coefficient, lambda =
#impactFactor k/v, v the impact velocity of the data or minimumImpactVelocity. Whether the item has an impact model is
#a Python constant of the recording, as it changes the computation: one force function for both, of one kind, and the
#term not recorded for impactModel 0 (#3203). The post-Newton step switches as
#CObjectContactSphereSphere::PostNewtonStep: the gap into the data, the error |k g| and the recommended step size
#|g0/(dg/dt)| of a switch, the impact velocity -dg/dt when the step begins open and ends in contact (#3197). Written
#with IfThenElse of exudyn.symbolics.utilities, which computes numbers and is recorded.
#With friction, also a constant of the recording, the markers are rigid, the parameters add [dynamicFriction,
#frictionProportionalZone] and the data the tangential speed of the last iteration (#3219): the friction force
#-mu N vT/|vT| at the contact point, vT the tangential relative velocity there with the rotations of the spheres, and
#-mu N vT/zone while the speed of the data is below frictionProportionalZone (stick); the torques of the forces about
#the centers; the post-Newton step sets the speed and adds the error |mu N/zone (|vT| - zone)| of a switch between stick
#and slip, as the built-in contact
def _SphereSphereContact(HT0, twist0, HT1, twist1):
    #the functions, the normal, the distance and the normal velocity of the two spheres
    delta = HT1.translation - HT0.translation
    F = _Functions(delta)
    distance = F.sqrt(delta @ delta)
    normal = (1/distance)*delta
    return (F, normal, distance, normal @ (twist1.velocity - twist0.velocity))

def _Abs(x, F):
    return F.abs(x) if F is exudyn.symbolic else abs(x)

def _TangentialVelocity(normal, gap, twist0, twist1, parameters, withRotations):
    #the tangential relative velocity of sphere 1 at the contact point, with the rotations of the spheres or of the centers
    n = [normal[i] for i in range(3)]
    dv = [twist1.velocity[i] - twist0.velocity[i] for i in range(3)]
    if withRotations:
        c0 = _Cross([twist0.angularVelocity[i] for i in range(3)], [(parameters[0] + 0.5*gap)*x for x in n])
        c1 = _Cross([twist1.angularVelocity[i] for i in range(3)], [(-parameters[1] - 0.5*gap)*x for x in n])
        dv = [dv[i] + c1[i] - c0[i] for i in range(3)]
    vn = _Dot(dv, n)
    return [dv[i] - vn*n[i] for i in range(3)]

def _SphereSphereContactFunctions(restitution, friction):
    #the user functions of the contact without or with an impact model and friction, both constants of the recording
    def NormalForce(F, gap, vNormal, dataCoordinates, parameters):
        force = -parameters[2]*gap - parameters[3]*vNormal
        if restitution:
            vImpact = F.max(parameters[4], dataCoordinates[1]) if F is exudyn.symbolic else max(parameters[4], dataCoordinates[1])
            impact = vImpact > 0
            lambdaImpact = IfThenElse(impact, parameters[5]*parameters[2]/IfThenElse(impact, vImpact, 1.), 0.)
            force = force - lambdaImpact*gap*vNormal
        return force

    def UFforce(mbs, t, itemNumber, HT0, twist0, HT1, twist1, dataCoordinates, parameters):
        (F, normal, distance, vNormal) = _SphereSphereContact(HT0, twist0, HT1, twist1)
        gap = distance - parameters[0] - parameters[1]
        force = NormalForce(F, gap, vNormal, dataCoordinates, parameters)
        inContact = dataCoordinates[0] < 0
        if not friction:
            force = IfThenElse(inContact, force, 0.)
            return np.hstack([-force*normal, force*normal])
        (mu, zone) = (parameters[6], parameters[7])
        vT = _TangentialVelocity(normal, gap, twist0, twist1, parameters, True)
        speed = F.sqrt(_Dot(vT, vT))
        stick = dataCoordinates[2] < zone
        moving = speed > 0
        factor = IfThenElse(stick, -mu*force/IfThenElse(stick, zone, 1.), IfThenElse(moving, -mu*force/IfThenElse(moving, speed, 1.), 0.))
        f1 = [IfThenElse(inContact, force*normal[i] + factor*vT[i], 0.) for i in range(3)]
        t0 = _Cross([(parameters[0] + 0.5*gap)*normal[i] for i in range(3)], [-x for x in f1])
        t1 = _Cross([(-parameters[1] - 0.5*gap)*normal[i] for i in range(3)], f1)
        return _Vector([-x for x in f1] + t0 + f1 + t1, F)

    def UFpostNewton(mbs, t, itemNumber, HT0, twist0, HT1, twist1, dataCoordinates, dataCoordinatesStartOfStep, parameters):
        (F, normal, distance, vNormal) = _SphereSphereContact(HT0, twist0, HT1, twist1)
        gap = distance - parameters[0] - parameters[1]
        (lastGap, gapStartOfStep) = (dataCoordinates[0], dataCoordinatesStartOfStep[0])
        switched = (gap > 0) != (lastGap > 0)
        error = IfThenElse(switched, _Abs(gap*parameters[2], F), 0.)
        stepKnown = (vNormal != 0)*(gapStartOfStep != 0) #a product of conditions, 0 or 1
        stepSize = IfThenElse(switched*stepKnown, _Abs(gapStartOfStep/IfThenElse(stepKnown, vNormal, 1.), F), -1.)
        impactVelocity = IfThenElse((gapStartOfStep > 0)*(gap <= 0), -vNormal, dataCoordinatesStartOfStep[1])
        if not friction:
            return [error, stepSize, gap, impactVelocity]
        (mu, zone) = (parameters[6], parameters[7])
        vT = [IfThenElse(gap < 0, x, y) for (x, y) in zip(_TangentialVelocity(normal, gap, twist0, twist1, parameters, True),
                                                        _TangentialVelocity(normal, gap, twist0, twist1, parameters, False))]
        speed = F.sqrt(_Dot(vT, vT))
        last = dataCoordinates[2]
        switchedFriction = (gap < 0)*(zone != 0)*((speed < zone)*(last > zone) + (speed > zone)*(last < zone))
        normalForce = NormalForce(F, gap, vNormal, dataCoordinates, parameters)
        error = error + IfThenElse(switchedFriction, _Abs(mu*normalForce/IfThenElse(zone != 0, zone, 1.)*(speed - zone), F), 0.)
        return [error, stepSize, gap, impactVelocity, speed]
    return [('forceUserFunction', UFforce), ('postNewtonStepUserFunction', UFpostNewton)]

_sphereSphereContactFunctions = {(restitution, friction): _SphereSphereContactFunctions(restitution, friction)
                                 for restitution in [False, True] for friction in [False, True]}

#the Cartesian spring-damper, ObjectConnectorUser on two position markers, parameters [stiffness (3), damping (3),
#offset (3)]: as ObjectConnectorCartesianSpringDamper, f = k (p1 - p0 - offset) + d (v1 - v0) per global component,
#pulling marker 0 towards marker 1 for a positive component (#3193)
def _UFcartesianSpringDamperForce(mbs, t, itemNumber, HT0, twist0, HT1, twist1, dataCoordinates, parameters):
    (delta, velocity) = (HT1.translation - HT0.translation, (twist1 - twist0).velocity)
    force = [parameters[i]*(delta[i] - parameters[6 + i]) + parameters[3 + i]*velocity[i] for i in range(3)]
    return _Vector(force + [-x for x in force], _Functions(delta))

#the rigid-body spring-damper, ObjectConnectorUser on two rigid markers, parameters [stiffness (36, row by row),
#damping (36), offset (6), rotationMarker0 (9), rotationMarker1 (9)]: as ObjectConnectorRigidBodySpringDamper, the
#joint frame Aj - of marker 0 times rotationMarker0, or the mid-frame of the intrinsic formulation -, in it the relative
#displacement and rotation u - the Tait-Bryan angles of the relative rotation, or the logarithm on SE(3) of the
#relative frame - and the relative velocity and angular velocity v, f = K (u - offset) + D v, and the force Aj f[0:3]
#and torque Aj f[3:6] towards marker 1 on marker 0, the opposite on marker 1; intrinsic, the torque of the offset of
#the force adds to both (#3193). The formulation changes the structure of the computation, so it is a Python constant
#of the recording, not a parameter: one force function of each, both of one kind (#3203)
def _RigidBodySpringDamperForce(HT0, twist0, HT1, twist1, parameters, intrinsic):
    F = _Functions(HT0.rotation)
    (R0, R1) = (_Matrix([[parameters[78 + k + 3*i + j] for j in range(3)] for i in range(3)], F) for k in [0, 9])
    (H0, H1) = (su.HT(HT0.rotation @ R0, HT0.translation), su.HT(HT1.rotation @ R1, HT1.translation))
    relative = H0.Relative(H1)
    if intrinsic:
        motion = relative.LogSE3()
        u = [motion[i] for i in range(6)]
        Aj = (H0*su.HT().SetExpSE3([0.5*x for x in u])).rotation
    else:
        (rotation, Aj) = (relative.GetRxyz(), H0.rotation)
        u = [relative.translation[i] for i in range(3)] + [rotation[i] for i in range(3)]
    relative = su.LocalTwist(su.HT(Aj), twist1 - twist0) #[Aj^T (v1 - v0), Aj^T (omega1 - omega0)], as the built-in connector
    (velocity, angularVelocity) = (relative.velocity, relative.angularVelocity)
    v = [velocity[i] for i in range(3)] + [angularVelocity[i] for i in range(3)]
    f = [sum(parameters[6*i + j]*(u[j] - parameters[72 + j]) + parameters[36 + 6*i + j]*v[j] for j in range(6)) for i in range(6)]
    (force, torque) = (Aj @ _Vector(f[0:3], F), Aj @ _Vector(f[3:6], F))
    offsetTorque = [0, 0, 0]
    if intrinsic:
        offsetTorque = su.Cross(Aj @ _Vector([-0.5*x for x in u[0:3]], F), force, F)
    return _Vector([force[i] for i in range(3)] + [torque[i] - offsetTorque[i] for i in range(3)]
                   + [-force[i] for i in range(3)] + [-torque[i] - offsetTorque[i] for i in range(3)], F)

def _RigidBodySpringDamperFunctions(intrinsic):
    #the user functions of a formulation, intrinsic a constant of the recording
    def UFforce(mbs, t, itemNumber, HT0, twist0, HT1, twist1, dataCoordinates, parameters):
        return _RigidBodySpringDamperForce(HT0, twist0, HT1, twist1, parameters, intrinsic)
    return [('forceUserFunction', UFforce)]

_rigidBodySpringDamperFunctions = {intrinsic: _RigidBodySpringDamperFunctions(intrinsic) for intrinsic in [False, True]}

def _JointJacobianProgram(constraintUserFunction, nParameters, format):
    #the derivative of the constraints of the varied frames by the variations, as Python function of format of
    #(t, R0, p0, R1, p1, parameters, variations), written by exudyn.symbolics.codeExport from one esym.Function
    esym = exudyn.symbolic
    scope = esym.VariableSet() #the names of this function, in a scope of their own (#3208)
    t = scope.Add('t', 0.)
    (R0, p0, R1, p1) = (scope.Add('R0', np.eye(3)), scope.Add('p0', np.zeros(3)), scope.Add('R1', np.eye(3)), scope.Add('p1', np.zeros(3)))
    parameters = scope.Add('parameters', np.zeros(nParameters))
    variations = scope.Add('variations', np.zeros(12))

    def Varied(R, p, k):
        #(I + skew(theta)) R and p + dp by their components, so that the terms of the variations, zero, are removed
        (dp, theta) = ([variations[6*k + i] for i in range(3)], [variations[6*k + 3 + i] for i in range(3)])
        skew = [[None, (-1., 2), (1., 1)], [(1., 2), None, (-1., 0)], [(-1., 1), (1., 0), None]]
        rotation = [[R[i, j] + sum(skew[i][n][0]*theta[skew[i][n][1]]*R[n, j] for n in range(3) if skew[i][n] is not None)
                     for j in range(3)] for i in range(3)]
        return su.HT(esym.Matrix(rotation), esym.Vector([p[i] + dp[i] for i in range(3)]))
    c = constraintUserFunction(None, t, 0, Varied(R0, p0, 0), Varied(R1, p1, 1), parameters)
    c = c if isinstance(c, esym.Vector) else esym.Vector([c[i] for i in range(len(c))])
    jacobian = esym.Function(esym.Jacobian(c, variations), scope, 'jointJacobian')
    return ToFunction(jacobian.GetFlatProgramData(), format)

def JointJacobianUserFunction(constraintUserFunction, numberOfParameters=None):
    """the jacobianUserFunction of an ObjectJointUser from its constraintUserFunction (#3235): the derivative of the
    constraints by the variations [dp0, theta0, dp1, theta1] of the frames of the two markers - their translations and
    global rotation increments, A -> (I + skew(theta)) A, p -> p + dp -, by esym.Jacobian of the constraints of the
    varied frames, at zero variation; the counterpart of the automatic differentiation of the built-in joints. The
    constraint function must compute with numbers and with symbolic values, as with exudyn.symbolics.kinematics, and it
    is called once with mbs None and itemNumber 0 to build the derivative; the jacobianUserFunction computes numbers and
    is recorded

    Args:
        constraintUserFunction: the Python function constraintUserFunction(mbs, t, itemNumber, HT0, HT1, parameters)
        numberOfParameters: the length of the parameters of the joint; None: the length of the parameters of the call,
            which a recording for a kind of items, of parameters of run-time size, does not have

    Returns:
        the Python function jacobianUserFunction(mbs, t, itemNumber, HT0, HT1, parameters), which returns the matrix
        (number of constraints x 12)

    Example:
        def UFconstraint(mbs, t, itemNumber, HT0, HT1, parameters): #a spherical joint
            return HT1.translation - HT0.translation
        mbs.AddObject(ObjectJointUser(markerNumbers=[m0, m1], numberOfConstraints=3,
                                      constraintUserFunction=UFconstraint,
                                      jacobianUserFunction=JointJacobianUserFunction(UFconstraint)))
    """
    programs = {} #per number of parameters and format, built at the first call

    def UFjacobian(mbs, t, itemNumber, HT0, HT1, parameters):
        symbolic = isinstance(HT0.rotation, exudyn.symbolic.Matrix) #while it is recorded
        key = (len(parameters) if numberOfParameters is None else numberOfParameters, symbolic)
        if key not in programs:
            programs[key] = _JointJacobianProgram(constraintUserFunction, key[0], 'symbolic' if symbolic else 'numpy')
        jacobian = programs[key](t, HT0.rotation, HT0.translation, HT1.rotation, HT1.translation, parameters, np.zeros(12))
        if symbolic: #the terms of the variations, zero, removed
            return exudyn.symbolic.Optimize(jacobian, level=2)
        return np.array(jacobian, dtype=float)
    return UFjacobian

#the joints, ObjectJointUser on two rigid markers whose frames are the joint frame: the equations of the built-in joint
#at position level - the global difference of the positions, as the Lagrange multipliers of the built-in joints are
#global -; their derivative by the translations and global rotation increments of the markers by
#JointJacobianUserFunction
def _Column(R, j):
    return [R[i, j] for i in range(3)]

def _Dot(u, v):
    return u[0]*v[0] + u[1]*v[1] + u[2]*v[2]

def _Cross(u, v):
    return [u[1]*v[2] - u[2]*v[1], u[2]*v[0] - u[0]*v[2], u[0]*v[1] - u[1]*v[0]]

def _Distance(HT0, HT1):
    #the components of the global difference of the positions of the markers
    (p0, p1) = (HT0.translation, HT1.translation)
    return [p1[i] - p0[i] for i in range(3)]

#the revolute joint, as ObjectJointRevoluteZ: the relative position, and the z-axis of marker 0 perpendicular to the
#x- and y-axes of marker 1; no parameters
def _UFrevoluteJointConstraint(mbs, t, itemNumber, HT0, HT1, parameters):
    (A0, A1) = (HT0.rotation, HT1.rotation)
    z0 = _Column(A0, 2)
    return _Vector(_Distance(HT0, HT1) + [_Dot(z0, _Column(A1, 0)), _Dot(z0, _Column(A1, 1))], _Functions(A0))

#the prismatic joint, as ObjectJointPrismaticX: the relative position along the y- and z-axes of marker 0, and the
#axes z0.y1, z0.x1, x0.y1; no parameters
def _UFprismaticJointConstraint(mbs, t, itemNumber, HT0, HT1, parameters):
    (A0, A1) = (HT0.rotation, HT1.rotation)
    d = _Distance(HT0, HT1)
    (x0, y0, z0) = (_Column(A0, 0), _Column(A0, 1), _Column(A0, 2))
    (x1, y1) = (_Column(A1, 0), _Column(A1, 1))
    return _Vector([_Dot(y0, d), _Dot(z0, d), _Dot(z0, y1), _Dot(z0, x1), _Dot(x0, y1)], _Functions(A0))

#the spherical joint, as ObjectJointSpherical with all axes constrained: the relative position; no parameters
def _UFsphericalJointConstraint(mbs, t, itemNumber, HT0, HT1, parameters):
    return _Vector(_Distance(HT0, HT1), _Functions(HT0.translation))

#the distance constraint, as ObjectConnectorDistance: |p1 - p0| - distance; parameters [distance]
def _UFdistanceConstraint(mbs, t, itemNumber, HT0, HT1, parameters):
    F = _Functions(HT0.translation)
    d = _Distance(HT0, HT1)
    return _Vector([F.sqrt(_Dot(d, d)) - parameters[0]], F)

#the user functions of each kind of item, which Record records once per kind; a kind of variants - a Python constant
#of the Create function that changes the structure of the computation - has the functions of each variant in the item
#(UserItemCreator._variants), recorded once per variant; its entry here is the variant of the default arguments of the
#Create function (impactModel=0, useIntrinsicFormulation=True, unlimitedRotations=True), which only names the kind, as every item of it keeps
#its own variant
_kindFunctions = {'massPoint': [('massMatrixUserFunction', _UFmassPointMass),
                                ('massIntegralUserFunction', _UFmassPointMassIntegral),
                                ('positionUserFunction', _UFmassPointPosition),
                                ('positionJacobianUserFunction', _UFmassPointPositionJacobian),
                                ('rotationMatrixUserFunction', _UFmassPointRotationMatrix),
                                ('rotationJacobianUserFunction', _UFmassPointRotationJacobian)],
                  'rigidBody': [('massMatrixUserFunction', _UFrigidBodyMass),
                                ('forceUserFunction', _UFrigidBodyForce),
                                ('massIntegralUserFunction', _UFrigidBodyMassIntegral),
                                ('positionUserFunction', _UFrigidBodyPosition),
                                ('positionJacobianUserFunction', _UFrigidBodyPositionJacobian),
                                ('rotationMatrixUserFunction', _UFrigidBodyRotationMatrix),
                                ('rotationJacobianUserFunction', _UFrigidBodyRotationJacobian)],
                  'springDamper': [('forceUserFunction', _UFspringDamperForce)],
                  'torsionalSpringDamper': _torsionalSpringDamperFunctions[True],
                  'sphereSphereContact': _sphereSphereContactFunctions[(False, False)],
                  'cartesianSpringDamper': [('forceUserFunction', _UFcartesianSpringDamperForce)],
                  'rigidBodySpringDamper': _rigidBodySpringDamperFunctions[True],
                  'coordinateConstraint': [],
                  'kinematicTree': [],
                  'revoluteJoint': [('constraintUserFunction', _UFrevoluteJointConstraint),
                                    ('jacobianUserFunction', JointJacobianUserFunction(_UFrevoluteJointConstraint, 0))],
                  'prismaticJoint': [('constraintUserFunction', _UFprismaticJointConstraint),
                                     ('jacobianUserFunction', JointJacobianUserFunction(_UFprismaticJointConstraint, 0))],
                  'sphericalJoint': [('constraintUserFunction', _UFsphericalJointConstraint),
                                     ('jacobianUserFunction', JointJacobianUserFunction(_UFsphericalJointConstraint, 0))],
                  'distanceConstraint': [('constraintUserFunction', _UFdistanceConstraint),
                                         ('jacobianUserFunction', JointJacobianUserFunction(_UFdistanceConstraint, 1))]}
#the number of equations of each kind of joint
_jointConstraints = {'revoluteJoint': 5, 'prismaticJoint': 5, 'sphericalJoint': 3, 'distanceConstraint': 1}

#the functions of a rigid body on Euler parameters, a variant of the kind rigidBody (#3238)
_rigidBodyEPFunctions = [('massMatrixUserFunction', _UFrigidBodyEPMass),
                         ('forceUserFunction', _UFrigidBodyEPForce),
                         ('massIntegralUserFunction', _UFrigidBodyEPMassIntegral),
                         ('positionUserFunction', _UFrigidBodyEPPosition),
                         ('positionJacobianUserFunction', _UFrigidBodyEPPositionJacobian),
                         ('rotationMatrixUserFunction', _UFrigidBodyEPRotationMatrix),
                         ('rotationJacobianUserFunction', _UFrigidBodyEPRotationJacobian)]


def _Numbers(values):
    """the values of parameters given as numbers or expressions, exudyn.symbolic.Real, for the item (#3152, #3159)"""
    return [float(value.Evaluate()) if isinstance(value, exudyn.symbolic.Real) else value for value in values]


def _Refuse(where, name, value, default, reason=''):
    """raise naming an argument the user item does not support, if it differs from its default"""
    if isinstance(value, (list, tuple, np.ndarray)) or isinstance(default, (list, tuple, np.ndarray)):
        differs = np.shape(value) != np.shape(default) or not np.array_equal(value, default)
    else:
        differs = value is not default and value != default
    if differs:
        raise ValueError('UserItemCreator.' + where + ': the argument ' + name + ' is not supported by the user item'
                         + (' (' + reason + ')' if reason else ''))


def _JointGraphics(markers, shape, size, length, color):
    """the graphicsDataUserFunction of a joint of UserItemCreator (#3147), a simplified drawing at its markers in the
    visualization configuration: 'revolute' a cylinder along the z-axis of marker 0, 'prismatic' along its x-axis,
    'spherical' a sphere at marker 0, 'distance' a line - or a cylinder of diameter size > 0 - between the markers"""
    drawColor = list(color) if color[0] >= 0 else graphics.color.grey

    visualization = exudyn.ConfigurationType.Visualization

    def Position(mbs, marker):
        return np.array(mbs.GetMarkerOutput(marker, exudyn.OutputVariableType.Position, configuration=visualization))

    def UFgraphics(mbs, itemNumber):
        p = Position(mbs, markers[0])
        if shape == 'spherical':
            return [graphics.Sphere(point=p, radius=size, color=drawColor, nTiles=8)]
        if shape == 'distance': #the markers may be position markers, without a rotation (#3333)
            p1 = Position(mbs, markers[1])
            if size > 0:
                return [graphics.Cylinder(pAxis=p, vAxis=p1 - p, radius=0.5*size, color=drawColor, nTiles=8)]
            return [graphics.Lines([p, p1], color=drawColor)]
        A = np.array(mbs.GetMarkerOutput(markers[0], exudyn.OutputVariableType.RotationMatrix, configuration=visualization)).reshape(3, 3)
        axis = A[:, 2] if shape == 'revolute' else A[:, 0]
        return [graphics.Cylinder(pAxis=p - 0.5*length*axis, vAxis=length*axis, radius=size, color=drawColor, nTiles=12)]
    return UFgraphics


class ParameterBindings:
    """the symbolic parameters of the user items of a system (#3159): for each item with one, the list of its
    parameters - a number, or an exudyn.symbolic.Real expression of named variables of the scope of the model,
    mbs.symbolicVariables (#3208) -, whose values are the numbers of the item. UserItemCreator keeps them for every user
    item it creates, as parameterBindings; SymbolicSystem(mbs, parameters=creator.parameterBindings) reads them

    Args:
        mbs: the MainSystem of the items

    Example:
        m1 = esym.Real('m1', 2., scope=mbs)
        creator = UserItemCreator(mbs)
        b0 = creator.CreateMassPoint(referencePosition=[1,0,0], mass=m1)
        creator.parameterBindings[b0]             #[m1]
        creator.parameterBindings.Parameters()    #[m1]
    """
    def __init__(self, mbs):
        self.mbs = mbs
        self._items = {}

    def Keep(self, itemNumber, parameters):
        """keep the parameters of an item if an exudyn.symbolic.Real is among them, e.g. of a user item added without
        UserItemCreator

        Args:
            itemNumber: the ObjectIndex or int of the item
            parameters: the list of the parameters of the item, numbers and exudyn.symbolic.Real
        """
        if any(isinstance(value, exudyn.symbolic.Real) for value in parameters):
            self._items[int(itemNumber)] = list(parameters)

    def __getitem__(self, itemNumber):
        return self._items[int(itemNumber)]

    def __contains__(self, itemNumber):
        return int(itemNumber) in self._items

    def __len__(self):
        return len(self._items)

    def items(self):
        """the item numbers and their parameter lists

        Returns:
            the items of the dict, (int, list)
        """
        return self._items.items()

    def _Expressions(self):
        return [value for values in self._items.values() for value in values if isinstance(value, exudyn.symbolic.Real)]

    def Parameters(self):
        """the named variables of the expressions, each once, in the order found; they are variables of
        mbs.symbolicVariables, else it raises

        Returns:
            the list of the named exudyn.symbolic.Real
        """
        expressions = self._Expressions()
        foreign = exudyn.symbolic._VariablesNotInScope(expressions, self.mbs.symbolicVariables)
        if foreign:
            raise ValueError('ParameterBindings: the parameters depend on ' + ', '.join(foreign) + ', which are not '
                             'variables of mbs.symbolicVariables; create them by esym.Real(name, value, scope=mbs) (#3208)')
        names = exudyn.symbolic._VariablesNotInScope(expressions, exudyn.symbolic.VariableSet()) #all of them, in order
        return [self.mbs.symbolicVariables.Get(name) for name in names]

    def Values(self, itemNumber):
        """the numbers of the parameters of an item, the expressions evaluated

        Args:
            itemNumber: the ObjectIndex or int of the item

        Returns:
            the list of numbers
        """
        return _Numbers(self[itemNumber])

    def Check(self):
        """check every item: the number of its parameters, the values of the expressions equal to its numbers, the
        variables of the model's scope; raises ValueError"""
        self.Parameters()
        for (objectNumber, values) in self._items.items():
            numbers = list(self.mbs.GetObject(objectNumber)['parameters'])
            where = 'ParameterBindings: the parameters of object ' + str(objectNumber)
            if len(values) != len(numbers):
                raise ValueError(where + ' are ' + str(len(numbers)) + ' numbers, not ' + str(len(values)))
            for (value, number) in zip(_Numbers(values), numbers):
                if float(value) != float(number):
                    raise ValueError(where + ': the value ' + str(value) + ' differs from the number ' + str(number)
                                     + ' of the item; SetParameterValues of SymbolicSystem sets both, Apply the numbers')

    def Apply(self):
        """write the values of the expressions into the parameters of the items"""
        for objectNumber in self._items:
            self.mbs.SetObjectParameter(objectNumber, 'parameters', self.Values(objectNumber))


class UserItemCreator:
    """creates user items with the Create functions of mbs and their arguments (#3125): ObjectUserBody and
    ObjectConnectorUser with Python user functions instead of the built-in objects, recorded as symbolic user functions
    by Record, one recording per kind of item; see the Details of this module

    Args:
        mbs: the MainSystem where the items are created

    Note:
        Its members: mbs; items, the dict of the item numbers of each kind ('massPoint', 'rigidBody', 'springDamper',
        'torsionalSpringDamper', 'revoluteJoint', 'prismaticJoint', 'sphericalJoint', 'distanceConstraint', 'kinematicTree', ...); loads, the
        list of the loads with a user function created by CreateForce; recordings, the symbolic user functions of
        Record, which must live as long as the system; parameterBindings, the ParameterBindings of the parameters of the
        items with an exudyn.symbolic.Real among them - CreateMassPoint(mass=m1) -, as SymbolicSystem(mbs,
        parameters=...) takes them (#3152, #3159). Example:

        creator = UserItemCreator(mbs) #or creator = mbs: the same script with the built-in items
        b0 = creator.CreateMassPoint(referencePosition=[1,0,0], mass=2, gravity=[0,-9.81,0])
        creator.CreateSpringDamper(itemNumbers=[creator.CreateGround(), b0], stiffness=100, damping=1)
        creator.Record()
        mbs.Assemble()
    """
    def __init__(self, mbs):
        self.mbs = mbs
        self.items = {kind: [] for kind in _kindFunctions}
        self.loads = []
        self.recordings = []
        self._variants = {} #the user functions of an item of a kind of variants, by the int of its number (#3203)
        self._treeVariants = {} #the user functions of the kinematic trees, by their topology (#3508)
        self._trees = {} #the topology, parameters and base offset of each kinematic tree, by the int of its number
        self.markers = [] #the markers of AddKinematicTreeMarker and their user functions (#3513)
        self._treeMarkers = {} #the tree, link, local position and rotation of each marker of AddKinematicTreeMarker
        self.parameterBindings = ParameterBindings(mbs)

    def _AddUserItem(self, kind, item, parameters=None, variant=None):
        """add a user item of a kind (#3159): the item, which has the numbers of its parameters, into mbs, its number
        into items[kind], its parameters - numbers and exudyn.symbolic.Real - into parameterBindings, the user functions
        of its variant"""
        itemNumber = self.mbs.AddObject(item)
        self.items[kind].append(itemNumber)
        if parameters is not None:
            self.parameterBindings.Keep(itemNumber, parameters)
        if variant is not None:
            self._variants[int(itemNumber)] = variant
        return itemNumber

    def CreateGround(self, name='', referencePosition=None, referenceRotationMatrix=None, graphicsDataList=[],
                     graphicsDataUserFunction=0, show=True, referenceHT=None):
        """the built-in ObjectGround, as mbs.CreateGround: it has no coordinates

        Args:
            name: as in mbs.CreateGround
            referencePosition: as in mbs.CreateGround
            referenceRotationMatrix: as in mbs.CreateGround
            graphicsDataList: as in mbs.CreateGround
            graphicsDataUserFunction: as in mbs.CreateGround
            show: as in mbs.CreateGround
            referenceHT: as in mbs.CreateGround

        Returns:
            the ObjectIndex of the ground
        """
        return self.mbs.CreateGround(name=name, referencePosition=referencePosition,
                                     referenceRotationMatrix=referenceRotationMatrix, graphicsDataList=graphicsDataList,
                                     graphicsDataUserFunction=graphicsDataUserFunction, show=show, referenceHT=referenceHT)

    def CreateMassPoint(self, name='', referencePosition=[0., 0., 0.], initialDisplacement=[0., 0., 0.],
                        initialVelocity=[0., 0., 0.], mass=0, gravity=[0., 0., 0.], graphicsDataList=[], drawSize=-1,
                        color=[-1., -1., -1., -1.], show=True, create2D=False, returnDict=False, physicsMass=None):
        """a mass point as ObjectUserBody on a NodePoint, with the nodes, markers and loads of mbs.CreateMassPoint and
        its arguments

        Args:
            name: as in mbs.CreateMassPoint
            referencePosition: as in mbs.CreateMassPoint
            initialDisplacement: as in mbs.CreateMassPoint
            initialVelocity: as in mbs.CreateMassPoint
            mass: as in mbs.CreateMassPoint; the parameter of the user body, a number or a named exudyn.symbolic.Real
            gravity: as in mbs.CreateMassPoint
            graphicsDataList: as in mbs.CreateMassPoint, the graphicsData of the user body
            drawSize: as in mbs.CreateMassPoint
            color: as in mbs.CreateMassPoint
            show: as in mbs.CreateMassPoint
            create2D: refused if True: a planar user mass point does not exist yet
            returnDict: as in mbs.CreateMassPoint
            physicsMass: refused if given: use mass

        Returns:
            the ObjectIndex of the body, or with returnDict the dict of mbs.CreateMassPoint
        """
        _Refuse('CreateMassPoint', 'create2D', create2D, False, 'a planar user mass point does not exist yet')
        _Refuse('CreateMassPoint', 'physicsMass', physicsMass, None, 'use mass')
        mbs = self.mbs
        if len(graphicsDataList) != 0:
            drawSize = 0 #the node is shown (number, basis), but not drawn, as mbs.CreateMassPoint does
        nodeNumber = mbs.AddNode(eii.NodePoint(name='Node:' + name if name != '' else '', referenceCoordinates=referencePosition,
                                               initialCoordinates=initialDisplacement, initialVelocities=initialVelocity,
                                               visualization=eii.VNodePoint(show=show, drawSize=drawSize, color=color)))
        bodyNumber = self._AddUserItem('massPoint', eii.ObjectUserBody(name=name, nodeNumbers=[nodeNumber], parameters=_Numbers([mass]),
                                                      constantMassMatrix=True,
                                                      **{functionName: function for (functionName, function) in _kindFunctions['massPoint']},
                                                      visualization=eii.VObjectUserBody(show=graphicsDataList != [],
                                                                                        graphicsData=graphicsDataList)), [mass])
        result = {'nodeNumber': nodeNumber, 'bodyNumber': bodyNumber}
        if list(gravity) != [0., 0., 0.]:
            result['markerBodyMass'] = mbs.AddMarker(eii.MarkerBodyMass(bodyNumber=bodyNumber))
            result['loadNumber'] = mbs.AddLoad(eii.LoadMassProportional(markerNumber=result['markerBodyMass'], loadVector=gravity))
        return result if returnDict else bodyNumber

    def CreateRigidBody(self, name='', referencePosition=None, referenceRotationMatrix=None, initialVelocity=[0., 0., 0.],
                        initialAngularVelocity=[0., 0., 0.], initialDisplacement=None, initialRotationMatrix=None,
                        inertia=None, gravity=[0., 0., 0.], nodeType=exudyn.NodeType.RotationEulerParameters,
                        graphicsDataList=[], graphicsDataUserFunction=0, drawSize=-1, color=[-1., -1., -1., -1.],
                        show=True, create2D=False, returnDict=False, referenceHT=None, initialHT=None):
        """a rigid body as ObjectUserBody on a NodeRigidBodyEP or a NodeRigidBodyRxyz, with the node, markers and loads
        of mbs.CreateRigidBody and its arguments; on Euler parameters the node has their algebraic equation (#3238)

        Args:
            name: as in mbs.CreateRigidBody
            referencePosition: as in mbs.CreateRigidBody
            referenceRotationMatrix: as in mbs.CreateRigidBody
            initialVelocity: as in mbs.CreateRigidBody
            initialAngularVelocity: as in mbs.CreateRigidBody
            initialDisplacement: as in mbs.CreateRigidBody
            initialRotationMatrix: as in mbs.CreateRigidBody
            inertia: as in mbs.CreateRigidBody; its mass, inertia about the node and center of mass are the parameters
                of the user body, also as expressions of named variables of the model, e.g.
                InertiaCuboid(density=rho, sideLengths=[L, 0.1, 0.1]) with rho and L of mbs.symbolicVariables, kept in
                parameterBindings (#3159)
            gravity: as in mbs.CreateRigidBody
            nodeType: exu.NodeType.RotationEulerParameters (the default) or RotationRxyz; RotationRotationVector is
                refused (a Lie group node)
            graphicsDataList: as in mbs.CreateRigidBody, the graphicsData of the user body; empty: the graphics of inertia
            graphicsDataUserFunction: refused if given: the one of ObjectUserBody has other arguments
            drawSize: as in mbs.CreateRigidBody
            color: as in mbs.CreateRigidBody
            show: as in mbs.CreateRigidBody
            create2D: refused if True: a planar user rigid body does not exist yet
            returnDict: as in mbs.CreateRigidBody
            referenceHT: as in mbs.CreateRigidBody
            initialHT: as in mbs.CreateRigidBody

        Returns:
            the ObjectIndex of the body, or with returnDict the dict of mbs.CreateRigidBody
        """
        where = 'UserItemCreator.CreateRigidBody'
        _Refuse('CreateRigidBody', 'create2D', create2D, False, 'a planar user rigid body does not exist yet')
        _Refuse('CreateRigidBody', 'graphicsDataUserFunction', graphicsDataUserFunction, 0,
                'the one of ObjectUserBody has other arguments')
        if nodeType not in [exudyn.NodeType.RotationEulerParameters, exudyn.NodeType.RotationRxyz]:
            raise ValueError(where + ': the argument nodeType ' + str(nodeType) + ' is not supported by the user item '
                             '(exu.NodeType.RotationEulerParameters or RotationRxyz; the rotation vector node is a Lie '
                             'group node)')
        eulerParameters = nodeType == exudyn.NodeType.RotationEulerParameters
        if inertia is None:
            raise ValueError(where + ': inertia must be given')
        (referencePosition, referenceRotationMatrix) = _FrameFromHT(where, 'referenceHT', referenceHT, 'referencePosition',
                                                                    referencePosition, 'referenceRotationMatrix', referenceRotationMatrix)
        (initialDisplacement, initialRotationMatrix) = _FrameFromHT(where, 'initialHT', initialHT, 'initialDisplacement',
                                                                    initialDisplacement, 'initialRotationMatrix', initialRotationMatrix)
        referencePosition = [0., 0., 0.] if referencePosition is None else list(referencePosition)
        referenceRotationMatrix = np.eye(3) if referenceRotationMatrix is None else np.array(referenceRotationMatrix)
        mbs = self.mbs
        graphicsDataList0 = graphicsDataList
        if len(graphicsDataList) == 0:
            inertiaGraphics = inertia.GetGraphics(color)
            graphicsDataList0 = [inertiaGraphics] if inertiaGraphics is not None else []
        if len(graphicsDataList0) != 0:
            drawSize = 0 #the node is shown (number, basis), but not drawn, as mbs.CreateRigidBody does
        #the node as mbs.CreateRigidBody computes it
        (Rotation2Parameters, AngularVelocity2Parameters_t, NodeClass, VNodeClass) = (
            (RotationMatrix2EulerParameters, AngularVelocity2EulerParameters_t, eii.NodeRigidBodyEP, eii.VNodeRigidBodyEP)
            if eulerParameters else (RotationMatrix2RotXYZ, AngularVelocity2RotXYZ_t, eii.NodeRigidBodyRxyz, eii.VNodeRigidBodyRxyz))
        referenceRotation = np.array(Rotation2Parameters(referenceRotationMatrix))
        initialCoordinates = [0.]*(3 + len(referenceRotation))
        if initialDisplacement is not None or initialRotationMatrix is not None:
            initialDisplacement = [0., 0., 0.] if initialDisplacement is None else initialDisplacement
            initialRotationMatrix = np.eye(3) if initialRotationMatrix is None else initialRotationMatrix
            initialCoordinates = list(initialDisplacement) + list(np.array(Rotation2Parameters(referenceRotationMatrix @ initialRotationMatrix))
                                                                 - referenceRotation)
        nodeNumber = mbs.AddNode(NodeClass(name='Node:' + name if name != '' else '',
                                           referenceCoordinates=referencePosition + list(referenceRotation),
                                           initialCoordinates=initialCoordinates,
                                           initialVelocities=list(initialVelocity) + list(AngularVelocity2Parameters_t(initialAngularVelocity, referenceRotation)),
                                           visualization=VNodeClass(show=show, drawSize=drawSize, color=color)))
        parameters = [inertia.mass] + list(inertia.GetInertia6D()) + list(inertia.com)
        functions = _rigidBodyEPFunctions if eulerParameters else _kindFunctions['rigidBody']
        bodyNumber = self._AddUserItem('rigidBody', eii.ObjectUserBody(name=name, nodeNumbers=[nodeNumber], parameters=_Numbers(parameters),
                                                      centerOfMass=_Numbers(list(inertia.com)),
                                                      **{functionName: function for (functionName, function) in functions},
                                                      visualization=eii.VObjectUserBody(show=show, graphicsData=graphicsDataList0)), parameters,
                                       variant=_rigidBodyEPFunctions if eulerParameters else None)
        result = {'nodeNumber': nodeNumber, 'bodyNumber': bodyNumber}
        if cMath.norm(gravity) != 0.:
            result['markerBodyMass'] = mbs.AddMarker(eii.MarkerBodyMass(bodyNumber=bodyNumber))
            result['loadNumber'] = mbs.AddLoad(eii.LoadMassProportional(markerNumber=result['markerBodyMass'], loadVector=gravity))
        return result if returnDict else bodyNumber

    def CreateSpringDamper(self, name='', itemNumbers=[None, None], localPosition0=[0., 0., 0.], localPosition1=[0., 0., 0.],
                           referenceLength=None, stiffness=0., damping=0., force=0., velocityOffset=0.,
                           springForceUserFunction=0, show=True, drawSize=-1, color=exudyn.graphics.color.default,
                           bodyNumbers=None, bodyOrNodeList=None):
        """a spring-damper as ObjectConnectorUser on the markers of mbs.CreateSpringDamper, with its arguments and its
        force; at the center of a user mass point the marker is on its node, which has the same position; drawn by a
        graphicsDataUserFunction

        Args:
            name: as in mbs.CreateSpringDamper
            itemNumbers: as in mbs.CreateSpringDamper
            localPosition0: as in mbs.CreateSpringDamper
            localPosition1: as in mbs.CreateSpringDamper
            referenceLength: as in mbs.CreateSpringDamper; a number or a named exudyn.symbolic.Real
            stiffness: as in mbs.CreateSpringDamper; a number or a named exudyn.symbolic.Real
            damping: as in mbs.CreateSpringDamper; a number or a named exudyn.symbolic.Real
            force: as in mbs.CreateSpringDamper; a number or a named exudyn.symbolic.Real
            velocityOffset: as in mbs.CreateSpringDamper; a number or a named exudyn.symbolic.Real
            springForceUserFunction: refused if given: the force is the forceUserFunction of the connector
            show: as in mbs.CreateSpringDamper
            drawSize: a line if not positive, else a cylinder of diameter drawSize
            color: the color of the drawing; the default: grey
            bodyNumbers: refused if given: use itemNumbers
            bodyOrNodeList: refused if given: use itemNumbers

        Returns:
            the ObjectIndex of the connector
        """
        _Refuse('CreateSpringDamper', 'springForceUserFunction', springForceUserFunction, 0,
                'the force is the forceUserFunction of the connector')
        _Refuse('CreateSpringDamper', 'bodyNumbers', bodyNumbers, None, 'use itemNumbers')
        _Refuse('CreateSpringDamper', 'bodyOrNodeList', bodyOrNodeList, None, 'use itemNumbers')
        mbs = self.mbs
        [marker0, marker1, p0, p1, A0, A1] = GetMarkersPosRot(mbs, name, itemNumbers, localPosition0, localPosition1,
                                                              getPosition=True, getRotationMatrix=False, useRigidMarker=False)
        if referenceLength is None:
            referenceLength = cMath.norm(np.array(p1) - p0)
        parameters = [stiffness, damping, referenceLength, force, velocityOffset]
        drawColor = list(color) if color[0] >= 0 else graphics.color.grey

        def UFgraphics(mbs, itemNumber):
            positions = [np.array(mbs.GetMarkerOutput(marker, exudyn.OutputVariableType.Position,
                                                      configuration=exudyn.ConfigurationType.Visualization))
                         for marker in [marker0, marker1]]
            if drawSize > 0:
                return [graphics.Cylinder(pAxis=positions[0], vAxis=positions[1] - positions[0], radius=0.5*drawSize,
                                          color=drawColor, nTiles=8)]
            return [graphics.Lines(positions, color=drawColor)]

        connector = self._AddUserItem('springDamper', eii.ObjectConnectorUser(name=name, markerNumbers=[marker0, marker1],
                                                          parameters=_Numbers(parameters),
                                                          forceUserFunction=_UFspringDamperForce,
                                                          visualization=eii.VObjectConnectorUser(show=show, graphicsDataUserFunction=UFgraphics)), parameters)
        return connector

    def CreateSphereSphereContact(self, name='', itemNumbers=[None, None], localPosition0=[0., 0., 0.],
                                  localPosition1=[0., 0., 0.], spheresRadii=[-1, -1], isHollowSphere1=False,
                                  dynamicFriction=0., frictionProportionalZone=1e-3, contactStiffness=0., contactDamping=0.,
                                  contactStiffnessExponent=1, constantPullOffForce=0, contactPlasticityRatio=0,
                                  adhesionCoefficient=0, adhesionExponent=1, restitutionCoefficient=1,
                                  minimumImpactVelocity=0, impactModel=0, dataInitialCoordinates=[0, 0, 0, 0],
                                  activeConnector=True, show=False, color=exudyn.graphics.color.default, bodyNumbers=None,
                                  bodyOrNodeList=None):
        """a sphere-sphere contact as ObjectConnectorUser on the markers of mbs.CreateSphereSphereContact, with the
        normal force of ObjectContactSphereSphere, k delta - d dg/dt, with impactModel 1 or 2 the damping of the
        restitution coefficient - the model 2 is the recommended one -, and with dynamicFriction the friction of the
        built-in contact, regularized below frictionProportionalZone (#3219); switched as the built-in contact by the
        data node in the post-Newton step - contact and no contact, stick and slip -, which is recorded as the force
        (#3187, #3197); drawn as two spheres by a graphicsDataUserFunction

        Args:
            name: as in mbs.CreateSphereSphereContact
            itemNumbers: as in mbs.CreateSphereSphereContact
            localPosition0: as in mbs.CreateSphereSphereContact
            localPosition1: as in mbs.CreateSphereSphereContact
            spheresRadii: as in mbs.CreateSphereSphereContact; numbers or named exudyn.symbolic.Real
            isHollowSphere1: refused if True
            dynamicFriction: as in mbs.CreateSphereSphereContact; not 0: rigid markers on the bodies, the friction force
                and its torques; a number or a named exudyn.symbolic.Real; the items with and without friction share a
                recording each
            frictionProportionalZone: as in mbs.CreateSphereSphereContact, with dynamicFriction
            contactStiffness: as in mbs.CreateSphereSphereContact; a number or a named exudyn.symbolic.Real
            contactDamping: as in mbs.CreateSphereSphereContact; a number or a named exudyn.symbolic.Real
            contactStiffnessExponent: refused if not 1: the linear contact law
            constantPullOffForce: refused if not 0: no adhesion
            contactPlasticityRatio: refused if not 0: no plasticity
            adhesionCoefficient: refused if not 0: no adhesion
            adhesionExponent: refused if not 1: no adhesion
            restitutionCoefficient: as in mbs.CreateSphereSphereContact, with impactModel 1 or 2
            minimumImpactVelocity: as in mbs.CreateSphereSphereContact, with impactModel 1 or 2
            impactModel: 0 (the default), 1 (Hunt-Crossley) or 2 (Gonthier and Carvalho-Martins, recommended), as in
                mbs.CreateSphereSphereContact; the items without and with an impact model share a recording each
            dataInitialCoordinates: as in mbs.CreateSphereSphereContact; the gap and the impact velocity (the components
                0 and 2) go into the data node of the connector, with friction also the tangential speed (component 1);
                the plastic deformation (component 3) must be 0, as there is no plasticity
            activeConnector: refused if False
            show: draw the two spheres
            color: the color of the drawing; the default: grey
            bodyNumbers: refused if given: use itemNumbers
            bodyOrNodeList: refused if given: use itemNumbers

        Returns:
            the ObjectIndex of the connector
        """
        where = 'CreateSphereSphereContact'
        for (argument, value, default, reason) in [
                ('isHollowSphere1', isHollowSphere1, False, ''),
                ('contactStiffnessExponent', contactStiffnessExponent, 1, 'the contact law is linear'),
                ('constantPullOffForce', constantPullOffForce, 0, 'no adhesion'),
                ('contactPlasticityRatio', contactPlasticityRatio, 0, 'no plasticity'),
                ('adhesionCoefficient', adhesionCoefficient, 0, 'no adhesion'),
                ('adhesionExponent', adhesionExponent, 1, 'no adhesion'),
                ('activeConnector', activeConnector, True, ''),
                ('bodyNumbers', bodyNumbers, None, 'use itemNumbers'),
                ('bodyOrNodeList', bodyOrNodeList, None, 'use itemNumbers')]:
            _Refuse(where, argument, value, default, reason)
        if impactModel not in [0, 1, 2]:
            raise ValueError('UserItemCreator.CreateSphereSphereContact: impactModel must be 0, 1 or 2, not ' + str(impactModel))
        if impactModel == 0:
            _Refuse(where, 'restitutionCoefficient', restitutionCoefficient, 1, 'the restitution coefficient needs impactModel 1 or 2')
            _Refuse(where, 'minimumImpactVelocity', minimumImpactVelocity, 0, 'the impact velocity needs impactModel 1 or 2')
        friction = _Numbers([dynamicFriction])[0] != 0
        if friction:
            _Refuse(where, 'dataInitialCoordinates', [dataInitialCoordinates[3]], [0], 'the plastic deformation: there is no plasticity')
        else:
            _Refuse(where, 'dataInitialCoordinates', [dataInitialCoordinates[1], dataInitialCoordinates[3]], [0, 0],
                    'the tangent velocity and the plastic deformation: there is no friction and plasticity')
        #the factor of lambda of CObjectContactSphereSphere for the restitution coefficient e
        e = float(restitutionCoefficient)
        if impactModel != 0 and e <= 0:
            raise ValueError('UserItemCreator.CreateSphereSphereContact: the restitution coefficient must be > 0, not ' + str(e))
        impactFactor = 0.
        if impactModel == 1:
            impactFactor = 1.5*(e - 1.)
        elif impactModel == 2:
            impactFactor = 1.5*(e - 1.)*(11. - e)/(1. + 9.*e) if e > 1./3. else (e*e - 1.)/e
        mbs = self.mbs
        [marker0, marker1, p0, p1, A0, A1] = GetMarkersPosRot(mbs, name, itemNumbers, localPosition0, localPosition1,
                                                              getPosition=True, getRotationMatrix=False, useRigidMarker=friction)
        parameters = [spheresRadii[0], spheresRadii[1], contactStiffness, contactDamping, minimumImpactVelocity, impactFactor]
        if friction:
            parameters += [dynamicFriction, frictionProportionalZone]
        radii = _Numbers(spheresRadii)
        drawColor = list(color) if color[0] >= 0 else graphics.color.grey

        def UFgraphics(mbs, itemNumber):
            return [graphics.Sphere(point=mbs.GetMarkerOutput(marker, exudyn.OutputVariableType.Position,
                                                              configuration=exudyn.ConfigurationType.Visualization),
                                    radius=radius, color=drawColor, nTiles=12)
                    for (marker, radius) in zip([marker0, marker1], radii)]

        functions = _sphereSphereContactFunctions[(impactModel != 0, friction)]
        dataInitial = [dataInitialCoordinates[0], dataInitialCoordinates[2]] + ([dataInitialCoordinates[1]] if friction else [])
        data = mbs.AddNode(eii.NodeGenericData(initialCoordinates=dataInitial, numberOfDataCoordinates=len(dataInitial)))
        markerType = exudyn.MarkerType.Position | exudyn.MarkerType.Orientation if friction else exudyn.MarkerType._None
        connector = self._AddUserItem('sphereSphereContact', eii.ObjectConnectorUser(name=name, markerNumbers=[marker0, marker1], nodeNumber=data,
                                                          requestedMarkerType=markerType,
                                                          parameters=_Numbers(parameters), **dict(functions),
                                                          visualization=eii.VObjectConnectorUser(show=show, graphicsDataUserFunction=UFgraphics)),
                                      parameters, functions)
        return connector

    def CreateTorsionalSpringDamper(self, name='', itemNumbers=[None, None], position=[0., 0., 0.], axis=[0., 0., 0.],
                                    stiffness=0., damping=0., offset=0., velocityOffset=0., torque=0., useGlobalFrame=True,
                                    springTorqueUserFunction=0, unlimitedRotations=True, show=True, drawSize=-1,
                                    color=exudyn.graphics.color.default, bodyNumbers=None, bodyOrNodeList=None):
        """a torsional spring-damper as ObjectConnectorUser on the rigid markers of mbs.CreateTorsionalSpringDamper,
        with its arguments and its torque about the axis; with unlimitedRotations, the angle continues over the turns by
        a data node that the post-Newton step updates, as the built-in item (#3218); drawn by a graphicsDataUserFunction

        Args:
            name: as in mbs.CreateTorsionalSpringDamper
            itemNumbers: as in mbs.CreateTorsionalSpringDamper, two bodies or the ground
            position: as in mbs.CreateTorsionalSpringDamper
            axis: as in mbs.CreateTorsionalSpringDamper
            stiffness: as in mbs.CreateTorsionalSpringDamper; a number or a named exudyn.symbolic.Real
            damping: as in mbs.CreateTorsionalSpringDamper; a number or a named exudyn.symbolic.Real
            offset: as in mbs.CreateTorsionalSpringDamper; a number or a named exudyn.symbolic.Real
            velocityOffset: as in mbs.CreateTorsionalSpringDamper; a number or a named exudyn.symbolic.Real
            torque: as in mbs.CreateTorsionalSpringDamper; a number or a named exudyn.symbolic.Real
            useGlobalFrame: as in mbs.CreateTorsionalSpringDamper
            springTorqueUserFunction: refused if given: the torque is the forceUserFunction of the connector
            unlimitedRotations: as in mbs.CreateTorsionalSpringDamper: True counts the turns in a NodeGenericData; False
                gives the angle in (-pi, pi]; the items with and without share a recording each
            show: as in mbs.CreateTorsionalSpringDamper
            drawSize: the diameter of a cylinder along the axis; not positive: a line
            color: the color of the drawing; the default: grey
            bodyNumbers: refused if given: use itemNumbers
            bodyOrNodeList: refused if given: use itemNumbers

        Returns:
            the ObjectIndex of the connector
        """
        _Refuse('CreateTorsionalSpringDamper', 'springTorqueUserFunction', springTorqueUserFunction, 0,
                'the torque is the forceUserFunction of the connector')
        _Refuse('CreateTorsionalSpringDamper', 'bodyNumbers', bodyNumbers, None, 'use itemNumbers')
        _Refuse('CreateTorsionalSpringDamper', 'bodyOrNodeList', bodyOrNodeList, None, 'use itemNumbers')
        if any(isinstance(item, exudyn.MarkerIndex) for item in itemNumbers):
            raise ValueError('UserItemCreator.CreateTorsionalSpringDamper: the argument itemNumbers with a marker is not '
                             'supported by the user item (give the bodies)')
        mbs = self.mbs
        #the markers as mbs.CreateTorsionalSpringDamper adds them: the frame of the joint, its z-axis the axis
        [p0, A0, p1, A1, marker0, marker1, pJoint] = JointPreCheckCalcBodyMarkers('UserItemCreator.CreateTorsionalSpringDamper', mbs,
                                                                                  name, itemNumbers, position, show, useGlobalFrame)
        B = ComputeOrthonormalBasis(np.array(axis) if useGlobalFrame else A0 @ axis)
        AJ = np.array([-B[:, 2], B[:, 1], B[:, 0]]).T
        markers = [marker0, marker1]
        for (k, (p, A)) in enumerate([(p0, A0), (p1, A1)]):
            if markers[k] is None:
                markers[k] = mbs.AddMarker(eii.MarkerBodyRigid(name='Marker' + str(k) + ':' + name if name != '' else '',
                                                               bodyNumber=itemNumbers[k],
                                                               localHT=exudyn.HT(rotation=A.T @ AJ, translation=A.T @ (np.array(pJoint) - p))))
        length = drawSize if drawSize > 0 else 0.1
        drawColor = list(color) if color[0] >= 0 else graphics.color.grey

        def UFgraphics(mbs, itemNumber):
            p = np.array(mbs.GetMarkerOutput(markers[0], exudyn.OutputVariableType.Position,
                                             configuration=exudyn.ConfigurationType.Visualization))
            A = np.array(mbs.GetMarkerOutput(markers[0], exudyn.OutputVariableType.RotationMatrix,
                                             configuration=exudyn.ConfigurationType.Visualization)).reshape(3, 3)
            if drawSize > 0:
                return [graphics.Cylinder(pAxis=p - 0.5*length*A[:, 2], vAxis=length*A[:, 2], radius=0.5*drawSize,
                                          color=drawColor, nTiles=8)]
            return [graphics.Lines([p - 0.5*length*A[:, 2], p + 0.5*length*A[:, 2]], color=drawColor)]

        functions = _torsionalSpringDamperFunctions[bool(unlimitedRotations)]
        data = (mbs.AddNode(eii.NodeGenericData(initialCoordinates=[0], numberOfDataCoordinates=1)) if unlimitedRotations
                else exudyn.InvalidIndex())
        parameters = [stiffness, damping, offset, velocityOffset, torque]
        connector = self._AddUserItem('torsionalSpringDamper', eii.ObjectConnectorUser(name=name, markerNumbers=markers, nodeNumber=data,
                                                          parameters=_Numbers(parameters),
                                                          requestedMarkerType=exudyn.MarkerType.Position | exudyn.MarkerType.Orientation,
                                                          **dict(functions),
                                                          visualization=eii.VObjectConnectorUser(show=show, graphicsDataUserFunction=UFgraphics)),
                                      parameters, functions)
        return connector

    def _JointMarkers(self, where, name, itemNumbers, position, axis, useGlobalFrame, show, frame):
        """the two rigid markers of a joint at position, as mbs.Create...Joint computes them: their rotation the joint
        frame - frame 'z' its z-axis the axis (revolute), 'x' its x-axis the axis (prismatic), None the body frame; a
        marker of AddKinematicTreeMarker sets the position, and the joint takes a copy turned into its frame (#3517)"""
        if any(isinstance(item, exudyn.MarkerIndex) and int(item) not in self._treeMarkers for item in itemNumbers):
            raise ValueError('UserItemCreator.' + where + ': the argument itemNumbers with a marker other than one of '
                             'AddKinematicTreeMarker is not supported by the user item (give the bodies)')
        mbs = self.mbs
        [p0, A0, p1, A1, _, _, pJoint] = JointPreCheckCalcBodyMarkers('UserItemCreator.' + where, mbs, name, itemNumbers,
                                                                      position, show, useGlobalFrame)
        AJ = np.eye(3)
        if frame is not None:
            B = ComputeOrthonormalBasis(np.array(axis) if useGlobalFrame else A0 @ axis)
            AJ = np.array([-B[:, 2], B[:, 1], B[:, 0]]).T if frame == 'z' else B
        markers = []
        for (k, (p, A)) in enumerate([(p0, A0), (p1, A1)]):
            markerName = 'Marker' + str(k) + ':' + name if name != '' else ''
            if isinstance(itemNumbers[k], exudyn.MarkerIndex): #a tree marker, turned into the joint frame as mbs does
                data = self._treeMarkers[int(itemNumbers[k])]
                markers.append(itemNumbers[k] if frame is None else
                               self.AddKinematicTreeMarker(data['tree'], data['link'], data['localPosition'],
                                                           data['localRotation'] @ A.T @ AJ, name=markerName, show=False))
            else:
                markers.append(mbs.AddMarker(eii.MarkerBodyRigid(name=markerName, bodyNumber=itemNumbers[k],
                                                                 localHT=exudyn.HT(rotation=(A.T @ AJ) if frame is not None else np.eye(3),
                                                                                   translation=A.T @ (np.array(pJoint) - p)))))
        return markers

    def _Joint(self, kind, name, markers, parameters, show, drawing):
        """an ObjectJointUser of a kind of joint on two rigid markers, drawn by the graphicsDataUserFunction drawing"""
        return self._AddUserItem(kind, eii.ObjectJointUser(name=name, markerNumbers=markers, numberOfConstraints=_jointConstraints[kind],
                                                       parameters=_Numbers(parameters),
                                                       **{functionName: function for (functionName, function) in _kindFunctions[kind]},
                                                       visualization=eii.VObjectJointUser(show=show, graphicsDataUserFunction=drawing)), parameters)

    def CreateCartesianSpringDamper(self, name='', itemNumbers=[None, None], localPosition0=[0., 0., 0.],
                                    localPosition1=[0., 0., 0.], stiffness=[0., 0., 0.], damping=[0., 0., 0.],
                                    offset=[0., 0., 0.], springForceUserFunction=0, show=True, drawSize=-1,
                                    color=exudyn.graphics.color.default, bodyNumbers=None, bodyOrNodeList=None):
        """a Cartesian spring-damper as ObjectConnectorUser on the position markers of mbs.CreateCartesianSpringDamper,
        with its arguments and the force of ObjectConnectorCartesianSpringDamper; drawn as a line (#3193)

        Args:
            name: as in mbs.CreateCartesianSpringDamper
            itemNumbers: as in mbs.CreateCartesianSpringDamper
            localPosition0: as in mbs.CreateCartesianSpringDamper
            localPosition1: as in mbs.CreateCartesianSpringDamper
            stiffness: as in mbs.CreateCartesianSpringDamper; numbers or named exudyn.symbolic.Real
            damping: as in mbs.CreateCartesianSpringDamper; numbers or named exudyn.symbolic.Real
            offset: as in mbs.CreateCartesianSpringDamper; numbers or named exudyn.symbolic.Real
            springForceUserFunction: refused if given: the force is the forceUserFunction of the connector
            show: as in mbs.CreateCartesianSpringDamper
            drawSize: not used: a line between the markers
            color: the color of the line; the default: grey
            bodyNumbers: refused if given: use itemNumbers
            bodyOrNodeList: refused if given: use itemNumbers

        Returns:
            the ObjectIndex of the connector
        """
        where = 'CreateCartesianSpringDamper'
        _Refuse(where, 'springForceUserFunction', springForceUserFunction, 0, 'the force is the forceUserFunction of the connector')
        _Refuse(where, 'bodyNumbers', bodyNumbers, None, 'use itemNumbers')
        _Refuse(where, 'bodyOrNodeList', bodyOrNodeList, None, 'use itemNumbers')
        mbs = self.mbs
        [marker0, marker1, p0, p1, A0, A1] = GetMarkersPosRot(mbs, name, itemNumbers, localPosition0, localPosition1,
                                                              getPosition=False, getRotationMatrix=False, useRigidMarker=False)
        parameters = list(stiffness) + list(damping) + list(offset)
        connector = self._AddUserItem('cartesianSpringDamper', eii.ObjectConnectorUser(name=name, markerNumbers=[marker0, marker1], parameters=_Numbers(parameters),
                                                          forceUserFunction=_UFcartesianSpringDamperForce,
                                                          visualization=eii.VObjectConnectorUser(show=show, graphicsDataUserFunction=
                                                              _JointGraphics([marker0, marker1], 'distance', 0, 0, color))), parameters)
        return connector

    def CreateRigidBodySpringDamper(self, name='', itemNumbers=[None, None], localPosition0=[0., 0., 0.],
                                    localPosition1=[0., 0., 0.], stiffness=np.zeros((6, 6)), damping=np.zeros((6, 6)),
                                    offset=[0., 0., 0., 0., 0., 0.], rotationMatrixJoint=np.eye(3), useGlobalFrame=True,
                                    useIntrinsicFormulation=True, springForceTorqueUserFunction=0,
                                    postNewtonStepUserFunction=0, show=True, drawSize=-1, color=exudyn.graphics.color.default,
                                    intrinsicFormulation=None, bodyNumbers=None, bodyOrNodeList=None):
        """a rigid-body spring-damper as ObjectConnectorUser on the rigid markers of mbs.CreateRigidBodySpringDamper, with
        its arguments and the forces and torques of ObjectConnectorRigidBodySpringDamper in both formulations - the
        intrinsic one by the logarithm on SE(3) of the relative frame, the other by the Tait-Bryan angles of the relative
        rotation -; the joint rotations are parameters of the connector; drawn as a line (#3193)

        Args:
            name: as in mbs.CreateRigidBodySpringDamper
            itemNumbers: as in mbs.CreateRigidBodySpringDamper, two bodies, rigid nodes or the ground
            localPosition0: as in mbs.CreateRigidBodySpringDamper
            localPosition1: as in mbs.CreateRigidBodySpringDamper
            stiffness: as in mbs.CreateRigidBodySpringDamper, 6 x 6; numbers or named exudyn.symbolic.Real
            damping: as in mbs.CreateRigidBodySpringDamper, 6 x 6; numbers or named exudyn.symbolic.Real
            offset: as in mbs.CreateRigidBodySpringDamper; numbers or named exudyn.symbolic.Real
            rotationMatrixJoint: as in mbs.CreateRigidBodySpringDamper
            useGlobalFrame: as in mbs.CreateRigidBodySpringDamper
            useIntrinsicFormulation: as in mbs.CreateRigidBodySpringDamper; the items of each formulation share a
                recording
            springForceTorqueUserFunction: refused if given: the forces are the forceUserFunction of the connector
            postNewtonStepUserFunction: refused if given: a post-Newton step needs data coordinates
            show: as in mbs.CreateRigidBodySpringDamper
            drawSize: not used: a line between the markers
            color: the color of the line; the default: grey
            intrinsicFormulation: refused if given: use useIntrinsicFormulation
            bodyNumbers: refused if given: use itemNumbers
            bodyOrNodeList: refused if given: use itemNumbers

        Returns:
            the ObjectIndex of the connector
        """
        where = 'CreateRigidBodySpringDamper'
        for (argument, value, default, reason) in [
                ('springForceTorqueUserFunction', springForceTorqueUserFunction, 0, 'the forces are the forceUserFunction of the connector'),
                ('postNewtonStepUserFunction', postNewtonStepUserFunction, 0, 'a post-Newton step needs data coordinates'),
                ('intrinsicFormulation', intrinsicFormulation, None, 'use useIntrinsicFormulation'),
                ('bodyNumbers', bodyNumbers, None, 'use itemNumbers'),
                ('bodyOrNodeList', bodyOrNodeList, None, 'use itemNumbers')]:
            _Refuse(where, argument, value, default, reason)
        if any(isinstance(item, exudyn.MarkerIndex) for item in itemNumbers):
            raise ValueError('UserItemCreator.CreateRigidBodySpringDamper: the argument itemNumbers with a marker is not '
                             'supported by the user item (give the bodies or nodes)')
        mbs = self.mbs
        [marker0, marker1, p0, p1, A0, A1] = GetMarkersPosRot(mbs, name, itemNumbers, localPosition0, localPosition1,
                                                              getPosition=False, getRotationMatrix=True, useRigidMarker=True)
        rotationMatrixJoint = np.array(rotationMatrixJoint, dtype=float)
        if useGlobalFrame: #as mbs.CreateRigidBodySpringDamper
            (MR0, MR1) = (A0.T @ rotationMatrixJoint, A1.T @ rotationMatrixJoint)
        else:
            (MR0, MR1) = (rotationMatrixJoint, A1.T @ A0 @ rotationMatrixJoint)
        parameters = ([x for row in stiffness for x in row] + [x for row in damping for x in row] + list(offset)
                      + list(MR0.flatten()) + list(MR1.flatten()))
        functions = _rigidBodySpringDamperFunctions[bool(useIntrinsicFormulation)]
        connector = self._AddUserItem('rigidBodySpringDamper', eii.ObjectConnectorUser(name=name, markerNumbers=[marker0, marker1], parameters=_Numbers(parameters),
                                                          requestedMarkerType=exudyn.MarkerType.Position | exudyn.MarkerType.Orientation,
                                                          **dict(functions),
                                                          visualization=eii.VObjectConnectorUser(show=show, graphicsDataUserFunction=
                                                              _JointGraphics([marker0, marker1], 'distance', 0, 0, color))),
                                      parameters, functions)
        return connector

    def CreateCoordinateConstraint(self, name='', itemNumbers=[None, None], coordinates=[None, None], offset=0.,
                                   factor1=1., velocityLevel=False, offsetUserFunction=0, offsetUserFunction_t=0, show=True,
                                   drawSize=-1., color=exudyn.graphics.color.default, includeReferenceCoordinates=[False, False],
                                   factorValue1=None, bodyNumbers=None, bodyOrNodeList=None):
        """a coordinate constraint as ObjectGenericDAE with the equation of ObjectConnectorCoordinate, factor1 q1 - q0 -
        offset = 0, on the coordinates of mbs.CreateCoordinateConstraint: the nodes of the coordinates are its ODE2 nodes,
        a NodeGenericAE its multiplier, the equation its constraintMatrixODE2 and constraintVector (#3193)

        Args:
            name: as in mbs.CreateCoordinateConstraint
            itemNumbers: as in mbs.CreateCoordinateConstraint: a body, a node, or None or a ground object for the ground
            coordinates: as in mbs.CreateCoordinateConstraint
            offset: as in mbs.CreateCoordinateConstraint
            factor1: as in mbs.CreateCoordinateConstraint
            velocityLevel: refused if True: the equation is at position level
            offsetUserFunction: refused if given: the offset is constant
            offsetUserFunction_t: refused if given: the offset is constant
            show: not used: the object draws nothing
            drawSize: not used
            color: not used
            includeReferenceCoordinates: as in mbs.CreateCoordinateConstraint
            factorValue1: refused if given: use factor1
            bodyNumbers: refused if given: use itemNumbers
            bodyOrNodeList: refused if given: use itemNumbers

        Returns:
            the ObjectIndex of the ObjectGenericDAE
        """
        where = 'CreateCoordinateConstraint'
        for (argument, value, default, reason) in [('velocityLevel', velocityLevel, False, 'the equation is at position level'),
                                                   ('offsetUserFunction', offsetUserFunction, 0, 'the offset is constant'),
                                                   ('offsetUserFunction_t', offsetUserFunction_t, 0, 'the offset is constant'),
                                                   ('factorValue1', factorValue1, None, 'use factor1'),
                                                   ('bodyNumbers', bodyNumbers, None, 'use itemNumbers'),
                                                   ('bodyOrNodeList', bodyOrNodeList, None, 'use itemNumbers')]:
            _Refuse(where, argument, value, default, reason)
        mbs = self.mbs
        (nodes, columns, factors) = ([], [], [-1., float(factor1)])
        c0 = float(offset)
        for (item, coordinate, factor, includeReference) in zip(itemNumbers, coordinates, factors, includeReferenceCoordinates):
            if item is None or (isinstance(item, exudyn.ObjectIndex) and mbs.GetObject(item)['objectType'] == 'Ground'):
                continue #the ground: the coordinate is 0
            if isinstance(item, exudyn.NodeIndex):
                (node, nodeCoordinate) = (item, int(coordinate))
            else: #the coordinate of a body counts over its nodes, as mbs.CreateCoordinateConstraint
                objectDict = mbs.GetObject(item)
                (node, nodeCoordinate) = (None, int(coordinate))
                for bodyNode in ([objectDict['nodeNumber']] if 'nodeNumber' in objectDict else objectDict['nodeNumbers']):
                    numberOfCoordinates = len(mbs.systemData.GetNodeLTGODE2(bodyNode))
                    if nodeCoordinate < numberOfCoordinates:
                        node = bodyNode
                        break
                    nodeCoordinate -= numberOfCoordinates
                if node is None:
                    raise ValueError('UserItemCreator.CreateCoordinateConstraint: the body ' + str(item) + ' has no coordinate '
                                     + str(coordinate))
            if node not in nodes:
                nodes.append(node)
            offsetOfNode = sum(len(mbs.systemData.GetNodeLTGODE2(n)) for n in nodes[:nodes.index(node)])
            columns.append((offsetOfNode + nodeCoordinate, factor))
            if includeReference: #the equation in the total coordinates: the reference values into the constant
                c0 -= factor*float(mbs.GetNode(node)['referenceCoordinates'][nodeCoordinate])
        if not nodes:
            raise ValueError('UserItemCreator.CreateCoordinateConstraint: one of the two items must be a body or a node, but '
                             'received: ' + str(itemNumbers))
        n = sum(len(mbs.systemData.GetNodeLTGODE2(node)) for node in nodes)
        constraintMatrix = np.zeros((1, n))
        for (column, factor) in columns:
            constraintMatrix[0, column] += factor
        multiplier = mbs.AddNode(eii.NodeGenericAE(referenceCoordinates=[0], initialCoordinates=[0], numberOfAECoordinates=1))
        return self._AddUserItem('coordinateConstraint', eii.ObjectGenericDAE(name=name, nodeNumbersODE2=nodes, nodeNumbersAE=[multiplier],
                                                        constraintMatrixODE2=constraintMatrix, constraintVector=[c0]))

    def CreateRevoluteJoint(self, name='', itemNumbers=[None, None], position=[], axis=[], useGlobalFrame=True, show=True,
                            axisRadius=0.1, axisLength=0.4, color=exudyn.graphics.color.default, bodyNumbers=None,
                            bodyOrNodeList=None):
        """a revolute joint as ObjectJointUser on the rigid markers of mbs.CreateRevoluteJoint, with its arguments and
        the equations of ObjectJointRevoluteZ; drawn as a cylinder along the axis (#3147)

        Args:
            name: as in mbs.CreateRevoluteJoint
            itemNumbers: as in mbs.CreateRevoluteJoint, two bodies or the ground
            position: as in mbs.CreateRevoluteJoint
            axis: as in mbs.CreateRevoluteJoint
            useGlobalFrame: as in mbs.CreateRevoluteJoint
            show: as in mbs.CreateRevoluteJoint
            axisRadius: the radius of the cylinder of the drawing
            axisLength: the length of the cylinder of the drawing
            color: the color of the drawing; the default: grey
            bodyNumbers: refused if given: use itemNumbers
            bodyOrNodeList: refused if given: use itemNumbers

        Returns:
            the ObjectIndex of the joint
        """
        _Refuse('CreateRevoluteJoint', 'bodyNumbers', bodyNumbers, None, 'use itemNumbers')
        _Refuse('CreateRevoluteJoint', 'bodyOrNodeList', bodyOrNodeList, None, 'use itemNumbers')
        markers = self._JointMarkers('CreateRevoluteJoint', name, itemNumbers, position, axis, useGlobalFrame, show, 'z')
        return self._Joint('revoluteJoint', name, markers, [], show, _JointGraphics(markers, 'revolute', axisRadius, axisLength, color))

    def CreatePrismaticJoint(self, name='', itemNumbers=[None, None], position=[], axis=[], useGlobalFrame=True, show=True,
                             axisRadius=0.1, axisLength=0.4, color=exudyn.graphics.color.default, bodyNumbers=None,
                             bodyOrNodeList=None):
        """a prismatic joint as ObjectJointUser on the rigid markers of mbs.CreatePrismaticJoint, with its arguments and
        the equations of ObjectJointPrismaticX; drawn as a cylinder along the axis (#3147)

        Args:
            name: as in mbs.CreatePrismaticJoint
            itemNumbers: as in mbs.CreatePrismaticJoint, two bodies or the ground
            position: as in mbs.CreatePrismaticJoint
            axis: as in mbs.CreatePrismaticJoint
            useGlobalFrame: as in mbs.CreatePrismaticJoint
            show: as in mbs.CreatePrismaticJoint
            axisRadius: the radius of the cylinder of the drawing
            axisLength: the length of the cylinder of the drawing
            color: the color of the drawing; the default: grey
            bodyNumbers: refused if given: use itemNumbers
            bodyOrNodeList: refused if given: use itemNumbers

        Returns:
            the ObjectIndex of the joint
        """
        _Refuse('CreatePrismaticJoint', 'bodyNumbers', bodyNumbers, None, 'use itemNumbers')
        _Refuse('CreatePrismaticJoint', 'bodyOrNodeList', bodyOrNodeList, None, 'use itemNumbers')
        markers = self._JointMarkers('CreatePrismaticJoint', name, itemNumbers, position, axis, useGlobalFrame, show, 'x')
        return self._Joint('prismaticJoint', name, markers, [], show, _JointGraphics(markers, 'prismatic', axisRadius, axisLength, color))

    def CreateSphericalJoint(self, name='', itemNumbers=[None, None], position=[], constrainedAxes=[1, 1, 1],
                             useGlobalFrame=True, show=True, jointRadius=0.1, color=exudyn.graphics.color.default,
                             bodyNumbers=None, bodyOrNodeList=None):
        """a spherical joint as ObjectJointUser on rigid markers at the points of mbs.CreateSphericalJoint, with its
        arguments and the equations of ObjectJointSpherical; drawn as a sphere (#3147)

        Args:
            name: as in mbs.CreateSphericalJoint
            itemNumbers: as in mbs.CreateSphericalJoint, two bodies or the ground
            position: as in mbs.CreateSphericalJoint
            constrainedAxes: must be [1, 1, 1]: an axis left free has the equation lambda = 0, which ObjectJointUser
                does not give
            useGlobalFrame: as in mbs.CreateSphericalJoint
            show: as in mbs.CreateSphericalJoint
            jointRadius: the radius of the sphere of the drawing
            color: the color of the drawing; the default: grey
            bodyNumbers: refused if given: use itemNumbers
            bodyOrNodeList: refused if given: use itemNumbers

        Returns:
            the ObjectIndex of the joint
        """
        _Refuse('CreateSphericalJoint', 'constrainedAxes', list(constrainedAxes), [1, 1, 1],
                'an axis left free has the equation lambda = 0, which ObjectJointUser does not give')
        _Refuse('CreateSphericalJoint', 'bodyNumbers', bodyNumbers, None, 'use itemNumbers')
        _Refuse('CreateSphericalJoint', 'bodyOrNodeList', bodyOrNodeList, None, 'use itemNumbers')
        markers = self._JointMarkers('CreateSphericalJoint', name, itemNumbers, position, None, useGlobalFrame, show, None)
        return self._Joint('sphericalJoint', name, markers, [], show, _JointGraphics(markers, 'spherical', jointRadius, 0., color))

    def CreateDistanceConstraint(self, name='', itemNumbers=[None, None], localPosition0=[0., 0., 0.],
                                 localPosition1=[0., 0., 0.], distance=None, show=True, drawSize=-1.,
                                 color=exudyn.graphics.color.default, bodyNumbers=None, bodyOrNodeList=None):
        """a distance constraint as ObjectJointUser on rigid markers of the two bodies, with the arguments of
        mbs.CreateDistanceConstraint and the equation of ObjectConnectorDistance; on a user mass point the marker is on
        the body; drawn as a line between the markers (#3147)

        Args:
            name: as in mbs.CreateDistanceConstraint
            itemNumbers: two bodies, the ground or markers - such as those of AddKinematicTreeMarker (#3515) -; a node is
                refused
            localPosition0: as in mbs.CreateDistanceConstraint
            localPosition1: as in mbs.CreateDistanceConstraint
            distance: as in mbs.CreateDistanceConstraint; None: the distance in the reference configuration; 0 is
                refused (mbs.CreateDistanceConstraint creates a spherical joint then)
            show: as in mbs.CreateDistanceConstraint
            drawSize: a line if not positive, else a cylinder of diameter drawSize
            color: the color of the drawing; the default: grey
            bodyNumbers: refused if given: use itemNumbers
            bodyOrNodeList: refused if given: use itemNumbers

        Returns:
            the ObjectIndex of the constraint
        """
        _Refuse('CreateDistanceConstraint', 'bodyNumbers', bodyNumbers, None, 'use itemNumbers')
        _Refuse('CreateDistanceConstraint', 'bodyOrNodeList', bodyOrNodeList, None, 'use itemNumbers')
        if not all(isinstance(item, (exudyn.ObjectIndex, exudyn.MarkerIndex)) for item in itemNumbers):
            raise ValueError('UserItemCreator.CreateDistanceConstraint: the argument itemNumbers must be two bodies, the '
                             'ground or markers; a node is not supported by the user item')
        [marker0, marker1, p0, p1, A0, A1] = GetMarkersPosRot(self.mbs, name, itemNumbers, localPosition0, localPosition1,
                                                              getPosition=distance is None, useRigidMarker=True)
        if distance is None:
            distance = cMath.norm(np.array(p1) - p0)
        if _Numbers([distance])[0] == 0: #the value of a symbolic distance (#3159)
            raise ValueError('UserItemCreator.CreateDistanceConstraint: the distance 0 is not supported by the user item '
                             '(use CreateSphericalJoint)')
        return self._Joint('distanceConstraint', name, [marker0, marker1], [distance], show,
                           _JointGraphics([marker0, marker1], 'distance', drawSize, 0., color))

    def CreateForce(self, name='', itemNumber=None, loadVector=[0., 0., 0.], localPosition=[0., 0., 0.], bodyFixed=False,
                    loadVectorUserFunction=0, show=True, bodyNumber=None):
        """the built-in LoadForceVector of mbs.CreateForce, with its arguments: on a user mass point, its marker acts by
        the Jacobian of the user body

        Args:
            name: as in mbs.CreateForce
            itemNumber: as in mbs.CreateForce
            loadVector: as in mbs.CreateForce
            localPosition: as in mbs.CreateForce
            bodyFixed: as in mbs.CreateForce
            loadVectorUserFunction: as in mbs.CreateForce; a Python function is recorded by Record
            show: as in mbs.CreateForce
            bodyNumber: refused if given: use itemNumber

        Returns:
            the LoadIndex of the force
        """
        _Refuse('CreateForce', 'bodyNumber', bodyNumber, None, 'use itemNumber')
        load = self.mbs.CreateForce(name=name, itemNumber=itemNumber, loadVector=loadVector, localPosition=localPosition,
                                    bodyFixed=bodyFixed, loadVectorUserFunction=loadVectorUserFunction, show=show)
        if callable(loadVectorUserFunction):
            self.loads.append((load, loadVectorUserFunction, 'LoadForceVector'))
        return load

    def CreateTorque(self, name='', itemNumber=None, loadVector=[0., 0., 0.], localPosition=[0., 0., 0.], bodyFixed=False,
                     loadVectorUserFunction=0, show=True, bodyNumber=None):
        """the built-in LoadTorqueVector of mbs.CreateTorque, with its arguments: on a user rigid body, its marker acts by
        the rotation Jacobian of the user body (#3193)

        Args:
            name: as in mbs.CreateTorque
            itemNumber: as in mbs.CreateTorque
            loadVector: as in mbs.CreateTorque
            localPosition: as in mbs.CreateTorque
            bodyFixed: as in mbs.CreateTorque
            loadVectorUserFunction: as in mbs.CreateTorque; a Python function is recorded by Record
            show: as in mbs.CreateTorque
            bodyNumber: refused if given: use itemNumber

        Returns:
            the LoadIndex of the torque
        """
        _Refuse('CreateTorque', 'bodyNumber', bodyNumber, None, 'use itemNumber')
        load = self.mbs.CreateTorque(name=name, itemNumber=itemNumber, loadVector=loadVector, localPosition=localPosition,
                                     bodyFixed=bodyFixed, loadVectorUserFunction=loadVectorUserFunction, show=show)
        if callable(loadVectorUserFunction):
            self.loads.append((load, loadVectorUserFunction, 'LoadTorqueVector'))
        return load

    def CreateKinematicTree(self, name='', listOfTreeLinks=[], referenceCoordinates=None, initialCoordinates=None,
                            initialCoordinates_t=None, gravity=[0., 0., 0.], baseOffset=[0., 0., 0.], linkForces=None,
                            linkTorques=None, jointForceVector=None, jointPositionOffsetVector=None,
                            jointVelocityOffsetVector=None, forceUserFunction=0, jointRadius=0.05, jointWidth=0.12,
                            colors=exudyn.graphics.color.default, colorsJoints=exudyn.graphics.color.default,
                            baseGraphicsDataList=None, linkRoundness=0.2, show=True, baseNodeNumber=None):
        """a kinematic tree as ObjectUserBody on the NodeGenericODE2 of its joints - and a floating base -, with the node and the
        graphics of mbs.CreateKinematicTree and its arguments (#3508): the mass matrix by composite rigid bodies and the
        forces by recursive Newton-Euler - gravity, joint forces, P and D control -, as ObjectKinematicTree computes them;
        the joint types and parents are constants of the user functions, one recording per topology, and the link data,
        the gravity, the joint forces, gains and offsets and the forces and torques per link are the parameters of the
        body; the links are drawn by a graphicsDataUserFunction

        Args:
            name: as in mbs.CreateKinematicTree
            listOfTreeLinks: as in mbs.CreateKinematicTree; the joint types RevoluteX to PrismaticZ
            referenceCoordinates: as in mbs.CreateKinematicTree
            initialCoordinates: as in mbs.CreateKinematicTree
            initialCoordinates_t: as in mbs.CreateKinematicTree
            gravity: as in mbs.CreateKinematicTree
            baseOffset: as in mbs.CreateKinematicTree
            linkForces: as in mbs.CreateKinematicTree; if linkForces or linkTorques is given, the forces and torques
                of the links are parameters of the body, a variant of their own
            linkTorques: as in mbs.CreateKinematicTree
            jointForceVector: as in mbs.CreateKinematicTree
            jointPositionOffsetVector: as in mbs.CreateKinematicTree
            jointVelocityOffsetVector: as in mbs.CreateKinematicTree
            forceUserFunction: refused if given: a Python function cannot be recorded with the tree; forces on the
                joints over time are loads on the coordinates of its node (LoadCoordinate)
            jointRadius: as in mbs.CreateKinematicTree
            jointWidth: as in mbs.CreateKinematicTree
            colors: as in mbs.CreateKinematicTree
            colorsJoints: as in mbs.CreateKinematicTree
            baseGraphicsDataList: as in mbs.CreateKinematicTree
            linkRoundness: as in mbs.CreateKinematicTree
            show: as in mbs.CreateKinematicTree
            baseNodeNumber: None for a fixed base, or a NodeRigidBodyEP as floating base, as baseNodeNumber of
                ObjectKinematicTree (#3511): the root links in its frame, shifted by baseOffset; the mass of the base is a
                body of its own on the node, and the Euler-parameter constraint of the node is handled by the solvers;
                baseGraphicsDataList is not drawn, the body of the base draws it

        Returns:
            the ObjectIndex of the body
        """
        _Refuse('CreateKinematicTree', 'forceUserFunction', forceUserFunction, 0, 'a Python function cannot be recorded '
                'with the tree; forces on the joints over time are loads on the coordinates of its node (LoadCoordinate)')
        data = _KinematicTreeData('UserItemCreator.CreateKinematicTree(...)', listOfTreeLinks, referenceCoordinates,
                                  initialCoordinates, initialCoordinates_t, jointForceVector, jointPositionOffsetVector,
                                  jointVelocityOffsetVector, jointRadius, jointWidth, colors, colorsJoints,
                                  baseGraphicsDataList, linkRoundness)
        mbs = self.mbs
        n = data['nLinks']
        linkLoads = linkForces is not None or linkTorques is not None
        floating = baseNodeNumber is not None
        if floating and mbs.GetNode(baseNodeNumber)['nodeType'] != 'RigidBodyEP':
            raise ValueError('UserItemCreator.CreateKinematicTree: the base node must be a NodeRigidBodyEP, received node '
                             + str(baseNodeNumber) + ' of type ' + str(mbs.GetNode(baseNodeNumber)['nodeType']))
        for (argument, value) in [('linkForces', linkForces), ('linkTorques', linkTorques)]:
            if value is not None and (len(value) != n or any(len(value[k]) != 3 for k in range(n))):
                raise ValueError('UserItemCreator.CreateKinematicTree: ' + argument + ' must have one 3D vector per link ('
                                 + str(n) + ')')
        if len(data['baseGraphicsDataList0']) != 0 and not floating:
            mbs.CreateGround(referencePosition=baseOffset, graphicsDataList=data['baseGraphicsDataList0'])
        nodeNumber = mbs.AddNode(eii.NodeGenericODE2(name='Node:' + name if name != '' else '',
                                                     referenceCoordinates=data['referenceCoordinates'],
                                                     initialCoordinates=data['initialCoordinates'],
                                                     initialCoordinates_t=data['initialCoordinates_t'],
                                                     numberOfODE2Coordinates=n))
        zeros = [0.]*n
        def PerJoint(vector, given=True):
            return [float(value) for value in vector] if given and len(vector) != 0 else zeros
        hasPD = data['hasPDcontrol']
        arguments = dict(jointHTs=data['jointHTs'], linkMasses=data['linkMasses'],
                         linkCOMs=[np.array(data['linkCOMs'][i]) for i in range(n)],
                         linkInertiasCOM=[np.array(data['linkInertiasCOM'][i]) for i in range(n)], gravity=list(gravity),
                         jointForces=PerJoint(data['jointForceVector']), P=PerJoint(data['jointPControlVector'], hasPD),
                         D=PerJoint(data['jointDControlVector'], hasPD), positionOffsets=PerJoint(data['jointPositionOffsetVector'], hasPD),
                         velocityOffsets=PerJoint(data['jointVelocityOffsetVector'], hasPD), linkForces=linkForces,
                         linkTorques=linkTorques, baseOffset=baseOffset if floating else None)
        parameters = _TreeParameters(**arguments)
        topology = (tuple(int(jointType) for jointType in data['jointTypes']), tuple(int(parent) for parent in data['linkParents']),
                    linkLoads, floating)
        if topology not in self._treeVariants:
            self._treeVariants[topology] = _TreeFunctions(data['jointTypes'], data['linkParents'], linkLoads, floating)
        functions = self._treeVariants[topology]
        UFgraphics = _TreeGraphicsFunction(data['jointTypes'], data['linkParents'], baseOffset, data['graphicsDataList'],
                                           linkLoads, floating)
        tree = self._AddUserItem('kinematicTree', eii.ObjectUserBody(name=name, nodeNumbers=[nodeNumber] + ([baseNodeNumber] if floating else []), parameters=parameters,
                                                    **{functionName: function for (functionName, function) in functions},
                                                    visualization=eii.VObjectUserBody(show=show, graphicsDataUserFunction=UFgraphics)),
                                 parameters, variant=functions)
        self._trees[int(tree)] = {'topology': topology, 'parameters': parameters, 'arguments': arguments,
                                  'baseOffset': [0.]*3 if floating else [float(x) for x in baseOffset]}
        return tree

    def GetKinematicTreeParameter(self, objectNumber, parameterName):
        """a parameter of a kinematic tree of CreateKinematicTree by its name of ObjectKinematicTree, as
        SetKinematicTreeParameter sets it (#3519)

        Args:
            objectNumber: the tree, an ObjectIndex returned by CreateKinematicTree of this creator
            parameterName: a name SetKinematicTreeParameter takes

        Returns:
            the value, a list
        """
        (arguments, name) = self._KinematicTreeArgument('GetKinematicTreeParameter', objectNumber, parameterName)
        return arguments[name] if arguments[name] is not None else [[0.]*3 for k in range(len(arguments['linkMasses']))]

    def _KinematicTreeArgument(self, where, objectNumber, parameterName):
        """the kept arguments of a tree and the key of parameterName among them; raises for another object or name"""
        if int(objectNumber) not in self._trees:
            raise ValueError('UserItemCreator.' + where + ': object ' + str(objectNumber)
                             + ' is not a kinematic tree of CreateKinematicTree of this UserItemCreator')
        tree = self._trees[int(objectNumber)]
        names = {'gravity': 'gravity', 'jointForceVector': 'jointForces', 'jointPositionOffsetVector': 'positionOffsets',
                 'jointVelocityOffsetVector': 'velocityOffsets', 'jointPControlVector': 'P', 'jointDControlVector': 'D'}
        linkLoads = tree['topology'][2]
        if linkLoads:
            names.update({'linkForces': 'linkForces', 'linkTorques': 'linkTorques'})
        if parameterName not in names:
            raise ValueError('UserItemCreator.' + where + ': ' + str(parameterName) + ' is not a parameter of the tree; '
                             + ', '.join(names) + ' are' + ('' if linkLoads else ' (linkForces and linkTorques if the tree '
                                                            'was created with them, a variant of its own)'))
        return (tree['arguments'], names[parameterName])

    def SetKinematicTreeParameter(self, objectNumber, parameterName, value):
        """set a parameter of a kinematic tree of CreateKinematicTree, with the name of the parameter of
        ObjectKinematicTree for mbs.SetObjectParameter, in the parameters of the tree and of its markers of
        AddKinematicTreeMarker (#3518); e.g. in a preStepUserFunction for the control of the joints, as
        PreStepControl of exudyn.robotics does with ObjectKinematicTree

        Args:
            objectNumber: the tree, an ObjectIndex returned by CreateKinematicTree of this creator
            parameterName: 'gravity'; one value per joint: 'jointForceVector', 'jointPositionOffsetVector',
                'jointVelocityOffsetVector', 'jointPControlVector', 'jointDControlVector'; a 3D vector per link, if the
                tree was created with them: 'linkForces', 'linkTorques'
            value: the new value
        """
        (arguments, name) = self._KinematicTreeArgument('SetKinematicTreeParameter', objectNumber, parameterName)
        tree = self._trees[int(objectNumber)]
        n = len(arguments['linkMasses'])
        if parameterName == 'gravity':
            value = [float(x) for x in value]
            sizeOK = len(value) == 3
        elif parameterName in ['linkForces', 'linkTorques']:
            value = [[float(x) for x in value[k]] for k in range(len(value))]
            sizeOK = len(value) == n and all(len(v) == 3 for v in value)
        else:
            value = [float(x) for x in value]
            sizeOK = len(value) == n
        if not sizeOK:
            raise ValueError('UserItemCreator.SetKinematicTreeParameter: ' + parameterName + ' has the wrong size for '
                             + 'a tree of ' + str(n) + ' links')
        arguments[name] = value
        tree['parameters'] = _TreeParameters(**arguments)
        self.mbs.SetObjectParameter(objectNumber, 'parameters', tree['parameters'])
        for (marker, data) in self._treeMarkers.items():
            if int(data['tree']) == int(objectNumber):
                self.mbs.SetMarkerParameter(marker, 'parameters', list(tree['parameters']) + tree['baseOffset'] + data['localPosition']
                                            + [float(x) for x in np.array(data['localRotation']).flatten()])

    def AddKinematicTreeMarker(self, objectNumber, linkNumber, localPosition=[0., 0., 0.], localRotation=None, name='',
                               show=True):
        """a rigid marker on a link of a kinematic tree of CreateKinematicTree, as MarkerKinematicTreeRigid on
        ObjectKinematicTree (#3513): a MarkerBodyUser on the tree whose position, rotation - the frame of the link - and
        Jacobians are user functions, recorded by Record with one recording per link and topology; joints, connectors,
        loads and sensors use it as a rigid marker

        Args:
            objectNumber: the tree, an ObjectIndex returned by CreateKinematicTree of this creator
            linkNumber: the link, 0 to the number of links - 1
            localPosition: the position of the marker in the frame of the link
            localRotation: None, or the rotation matrix of the frame of the marker in the frame of the link (#3517); the
                joints of the creator on the marker add a marker turned into the frame of the joint by it
            name: the name of the marker
            show: the marker is drawn

        Returns:
            the MarkerIndex of the marker

        Note:
            The marker gets a copy of the parameters of the tree, followed by the base offset of a fixed base, the local
            position and the local rotation; SetKinematicTreeParameter sets them in the tree and its markers
        """
        if int(objectNumber) not in self._trees:
            raise ValueError('UserItemCreator.AddKinematicTreeMarker: object ' + str(objectNumber)
                             + ' is not a kinematic tree of CreateKinematicTree of this UserItemCreator')
        tree = self._trees[int(objectNumber)]
        (jointTypes, linkParents, linkLoads, floating) = tree['topology']
        if not (isinstance(linkNumber, (int, np.integer)) and 0 <= linkNumber < len(jointTypes)):
            raise ValueError('UserItemCreator.AddKinematicTreeMarker: linkNumber must be an integer from 0 to '
                             + str(len(jointTypes) - 1) + ', received ' + str(linkNumber))
        if len(localPosition) != 3:
            raise ValueError('UserItemCreator.AddKinematicTreeMarker: localPosition must be a 3D vector')
        localRotation = np.eye(3) if localRotation is None else np.array(localRotation, dtype=float)
        if localRotation.shape != (3, 3):
            raise ValueError('UserItemCreator.AddKinematicTreeMarker: localRotation must be a 3 x 3 rotation matrix')
        key = tree['topology'] + (int(linkNumber),)
        if key not in self._treeVariants:
            self._treeVariants[key] = _TreeMarkerFunctions(jointTypes, linkParents, int(linkNumber), linkLoads, floating)
        functions = self._treeVariants[key]
        parameters = (list(tree['parameters']) + tree['baseOffset'] + [float(x) for x in localPosition]
                      + [float(x) for x in localRotation.flatten()])
        marker = self.mbs.AddMarker(eii.MarkerBodyUser(name=name, bodyNumbers=[objectNumber],
                                                       providedMarkerType=exudyn.MarkerType.Position | exudyn.MarkerType.Orientation,
                                                       parameters=parameters,
                                                       **{functionName: function for (functionName, function) in functions},
                                                       visualization=eii.VMarkerBodyUser(show=show)))
        self.markers.append((marker, functions))
        self._treeMarkers[int(marker)] = {'tree': objectNumber, 'link': int(linkNumber),
                                          'localPosition': [float(x) for x in localPosition], 'localRotation': localRotation}
        return marker

    def Record(self):
        """replace the Python user functions of the items by symbolic ones: each user function of a kind recorded once,
        with the first item of the kind, and set in every item of the kind - one recording per kind and variant, as
        SymbolicSystem groups them -; the loadVectorUserFunction of each force of CreateForce recorded on its own. The
        recordings are kept in recordings, as long as this object lives"""
        mbs = self.mbs
        for (kind, items) in self.items.items():
            variants = {} #the items of each variant, by the identity of its functions (#3203)
            for item in items:
                functions = self._variants.get(int(item), _kindFunctions[kind])
                variants.setdefault(id(functions), (functions, []))[1].append(item)
            for (functions, variantItems) in variants.values():
                for (functionName, function) in functions:
                    recording = CreateSymbolicUserFunction(mbs, function, functionName, variantItems[0])
                    self.recordings.append(recording)
                    for item in variantItems:
                        mbs.SetObjectParameter(item, functionName, recording)
        for (load, function, loadType) in self.loads:
            recording = CreateSymbolicUserFunction(mbs, function, 'loadVectorUserFunction', itemTypeName=loadType)
            self.recordings.append(recording)
            mbs.SetLoadParameter(load, 'loadVectorUserFunction', recording)
        self.loads = []
        variants = {} #the markers of each variant of AddKinematicTreeMarker (#3513)
        for (marker, functions) in self.markers:
            variants.setdefault(id(functions), (functions, []))[1].append(marker)
        for (functions, markers) in variants.values():
            for (functionName, function) in functions:
                recording = CreateSymbolicUserFunction(mbs, function, functionName, markers[0])
                self.recordings.append(recording)
                for marker in markers:
                    mbs.SetMarkerParameter(marker, functionName, recording)
        self.markers = []
