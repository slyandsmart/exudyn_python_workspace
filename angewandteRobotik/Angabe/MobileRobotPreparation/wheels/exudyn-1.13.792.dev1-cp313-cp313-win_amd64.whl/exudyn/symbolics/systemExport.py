#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# This is an EXUDYN python utility library
#
# Details:  The equations of motion of a SymbolicSystem as code that runs without Exudyn (#3520). ExportSystem - also
#           SymbolicSystem.Export - writes them as C++ files: the scalar form of exudyn.symbolics.codeExport (one
#           function of all results, a matrix as the values of its pattern), a header with the sizes, the initial
#           state, the parameters and the patterns, a description as JSON and, for a system of ODE2 coordinates only, a
#           driver integrating it by RK4, and with the Jacobians of the forces the generalized-alpha method; or as
#           numpy, the vector code of GetFlatProgram. CompileExport compiles the C++
#           by the compiler of setuptools; CompiledSystem loads an export - the compiled library by ctypes, or the numpy
#           file - as a SymbolicSystemBase, on which the solvers of exudyn.symbolics.solvers run.
#
# Author:   Johannes Gerstmayr
# Date:     2026-11-15 (created)
#
# Copyright:This file is part of Exudyn. Exudyn is free software. You can redistribute it and/or modify it under the terms of the Exudyn license. See 'LICENSE.txt' for more details.
#
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

import ctypes
import json
import os
import numpy as np
import exudyn
from exudyn.symbolics import codeExport
from exudyn.symbolics.systemModel import SymbolicSystemBase

#public API of this module; kept complete by tools/checkAll.py (#2444)
__all__ = ['exportResults', 'exportJacobians', 'ExportSystem', 'CompileExport', 'CompiledSystem']

#the results of SymbolicSystem.Equations() that an export writes
exportResults = ['ODE2RHS', 'massMatrix', 'ODE1RHS', 'algebraicEquations', 'ODE2ReactionForcesLHS']
#the Jacobians an export writes: (result, variable), named result_variable in the export
exportJacobians = [('ODE2RHS', 'q'), ('ODE2RHS', 'q_t')]


def _Sizes(system):
    """the size of each result, (rows, columns) for the mass matrix"""
    return {'ODE2RHS': system.nODE2, 'massMatrix': (system.nODE2, system.nODE2), 'ODE1RHS': system.nODE1,
            'algebraicEquations': system.nAE, 'ODE2ReactionForcesLHS': system.nODE2}


def _CppArray(values, cType='double'):
    """the initializer of a C array; a zero-size array as one 0, which the size constants make unused"""
    values = list(values)
    if not values:
        return '{0}'
    if cType == 'double':
        return '{' + ', '.join(codeExport._CppNumber(float(v)) for v in values) + '}'
    return '{' + ', '.join(str(int(v)) for v in values) + '}'


def _DependsOnState(graph, nodes):
    """True if one of the nodes depends on an input other than the parameters p"""
    dependent = [False]*len(graph.nodes)
    for (k, (op, operands, value)) in enumerate(graph.nodes):
        dependent[k] = (op == 'input' and value[0] != 'p') or any(dependent[i] for i in operands)
    return any(dependent[node] for node in nodes)


def ExportSystem(system, directory, name='Model', language='C++', results=['ODE2RHS', 'massMatrix'], jacobians=[],
                 outputs={}, variables=None, parameters='inputs', driver=False):
    """the equations of a SymbolicSystem as files that run without Exudyn (#3520), in the composed form: one function
    computing all results, so that they share their intermediate values. C++: name.cpp holds the scalar form of
    exudyn.symbolics.codeExport - a function template on the number type and the function name_<results>_double with
    C linkage, of the standard library only -, name.h the sizes, the initial state, the reference coordinates, the
    parameters, the pattern of each matrix and the declarations; for a system of ODE2 coordinates, with nodes of Euler
    parameters as its only algebraic equations, and the results ODE2RHS and massMatrix, name.cpp has the explicit steps
    as well (name_Accelerations, name_Project, name_StepExplicitEuler, name_StepRK4, name_Simulate, the Euler
    parameters by their constraint on acceleration level and projected after each step, as SolveExplicit), and
    nameDriver.cpp (driver=True) is a program integrating the system by name_StepRK4 with constant steps. jacobians:
    the derivatives of ODE2RHS by q and q_t by exudyn.symbolic.Jacobian, a function name_ODE2RHS_q_ODE2RHS_q_t of the
    same arguments, each Jacobian as the values of its pattern; with both and the explicit steps, name.cpp has the
    generalized-alpha method too (name_StepGeneralizedAlpha, name_SimulateGeneralizedAlpha, as SolveGeneralizedAlpha,
    the Euler parameters by their constraint). The template of each function takes any number type, also one of
    automatic differentiation. outputs: user outputs h(q, q_t, t), a third function name_outputs of the same
    arguments, each output a number, a vector or a matrix row by row - expressions of the SystemVariables given as
    variables, or the number of a SensorMarker of the system, converted to the expression of its marker (Position,
    Velocity, RotationMatrix, AngularVelocity). numpy:
    name.py with the vector code of GetFlatProgram(format='numpy') and the function of the same arguments. Both:
    name.json, the description that CompiledSystem reads. The function takes q, q_t and t, then z, y (as Equations()
    has them for the results) and the array p of the parameters, and gives the results in the order asked for, a
    matrix as the values of its pattern (in C++ arrays after the arguments, in Python returned)

    Args:
        system: the SymbolicSystem
        directory: the directory of the files, created if it does not exist
        name: the name of the files and the prefix of the names in them
        language: 'C++' or 'numpy'
        results: the results of SymbolicSystem.Equations() computed by the function, of exportResults
        jacobians: the Jacobians written as a second function, of exportJacobians: ('ODE2RHS', 'q'), ('ODE2RHS', 'q_t');
            ODE2RHS must be in results
        outputs: dict of the names of the outputs (identifiers) and their expressions - exudyn.symbolic Real, Vector or
            Matrix of variables - or the numbers of SensorMarkers; {}: none
        variables: the exudyn.symbolics.systemModel.SystemVariables of the system that the expressions of outputs are
            written in; None: new ones, for outputs given by sensors only
        parameters: 'inputs': the named parameters of the system (parameterBindings) are the input p of the function,
            with their present values in the header; 'numbers': their present values are numbers in the code
        driver: True: write the driver nameDriver.cpp (C++, a system with the explicit steps)

    Returns:
        dict of the paths of the files written: 'header', 'source', 'driver' (C++), 'python' (numpy), 'description'
    """
    results = list(results)
    unknown = [r for r in results if r not in exportResults]
    if unknown or not results or len(set(results)) != len(results):
        raise ValueError('ExportSystem: results must be different names of ' + str(exportResults) + ', not ' + str(results))
    if language not in ['C++', 'numpy']:
        raise ValueError("ExportSystem: language must be 'C++' or 'numpy', not " + str(language))
    if parameters not in ['inputs', 'numbers']:
        raise ValueError("ExportSystem: parameters must be 'inputs' or 'numbers', not " + str(parameters))
    if not str(name).isidentifier():
        raise ValueError('ExportSystem: the name ' + str(name) + ' is not a valid identifier')
    jacobians = [tuple(jacobian) for jacobian in jacobians]
    if (any(jacobian not in exportJacobians for jacobian in jacobians) or len(set(jacobians)) != len(jacobians)
            or (jacobians and 'ODE2RHS' not in results)):
        raise ValueError('ExportSystem: jacobians must be different entries of ' + str(exportJacobians)
                         + ', with ODE2RHS in results, not ' + str(jacobians))
    if system.nData:
        raise ValueError('ExportSystem: the system has data coordinates (post-Newton steps), which are not exported')
    #the explicit steps: ODE2 coordinates, the Euler parameters of nodes their only algebraic equations
    withSteps = (language == 'C++' and sorted(results) == ['ODE2RHS', 'massMatrix'] and not system.nODE1
                 and system.nAE == len(getattr(system, 'eulerParameterNodes', [])))
    if driver and not withSteps:
        raise ValueError('ExportSystem: the driver and the explicit steps integrate ODE2 coordinates with nodes of Euler '
                         'parameters, in C++, with the results ODE2RHS and massMatrix; this system has '
                         + str(system.nODE1) + ' ODE1 and ' + str(system.nAE) + ' algebraic coordinates')

    outputs = dict(outputs)
    if any(not str(key).isidentifier() for key in outputs):
        raise ValueError('ExportSystem: the names of the outputs must be identifiers, not ' + str(list(outputs)))
    if variables is None:
        if any(not _IsSensorNumber(value) for value in outputs.values()):
            raise ValueError('ExportSystem: outputs given as expressions need the SystemVariables they are written in, '
                             'variables=...')
        from exudyn.symbolics.systemModel import SystemVariables #a module that imports this one
        variables = SystemVariables(system)
    if variables.system is not system:
        raise ValueError('ExportSystem: variables are the SystemVariables of another system')
    outputs = {key: (_SensorExpression(system, variables, value) if _IsSensorNumber(value) else value)
               for (key, value) in outputs.items()}
    equations = variables.Equations(**{r: r in results for r in exportResults})
    variableNames = ['q', 'q_t', 't'] + [v for v in ['z', 'y'] if v in equations]
    parameterVariables = list(equations.get('parameters', []))
    data = exudyn.symbolic.GetFlatProgramData([equations[r] for r in results],
                                              arguments=[equations[v] for v in variableNames] + parameterVariables,
                                              resultNames=results)
    arguments = [a for a in data['arguments'] if a['name'] in variableNames]
    parameterNames = [a['name'] for a in data['arguments'] if a['name'] not in variableNames]
    parameterValues = [float(variable.Evaluate()) for variable in parameterVariables]
    withP = parameters == 'inputs' and len(parameterNames) > 0
    functionName = name + '_' + '_'.join(results)

    #the scalar form: also for numpy, for the sizes, the patterns and whether the mass matrix is constant
    graph = codeExport.ScalarGraph()
    inputs = codeExport._ScalarInputs(graph, {'arguments': arguments})
    for (k, parameterName) in enumerate(parameterNames):
        inputs[parameterName] = (graph.Add('input', value=('p', (k,))) if withP
                                 else graph.Add('number', value=parameterValues[k]))
    (graph, scalarResults) = codeExport.Scalarize(data, graph, inputs)
    exportArguments = arguments + ([{'name': 'p', 'kind': 'Vector', 'size': len(parameterNames)}] if withP else [])
    program = codeExport.WriteScalarProgram({'arguments': exportArguments, 'results': data['results']}, 'C++',
                                            name=functionName, sparse=True, graph=graph, results=scalarResults)
    jacobianNames = [result + '_' + variable for (result, variable) in jacobians]
    jacobianFunctionName = name + '_' + '_'.join(jacobianNames)
    jacobianProgram = None
    if jacobians: #a function of their own: the explicit steps do not compute them
        matrices = [exudyn.symbolic.Jacobian(equations[result], equations[variable]) for (result, variable) in jacobians]
        jacobianData = exudyn.symbolic.GetFlatProgramData(matrices, arguments=[equations[v] for v in variableNames]
                                                          + parameterVariables, resultNames=jacobianNames)
        jacobianGraph = codeExport.ScalarGraph()
        jacobianInputs = codeExport._ScalarInputs(jacobianGraph, {'arguments': [a for a in jacobianData['arguments']
                                                                                 if a['name'] in variableNames]})
        for (k, parameterName) in enumerate(parameterNames):
            jacobianInputs[parameterName] = (jacobianGraph.Add('input', value=('p', (k,))) if withP
                                             else jacobianGraph.Add('number', value=parameterValues[k]))
        (jacobianGraph, jacobianResults) = codeExport.Scalarize(jacobianData, jacobianGraph, jacobianInputs)
        jacobianProgram = codeExport.WriteScalarProgram({'arguments': exportArguments, 'results': jacobianData['results']},
                                                        'C++', name=jacobianFunctionName, sparse=True,
                                                        graph=jacobianGraph, results=jacobianResults)
    withImplicit = withSteps and len(jacobians) == 2
    outputNames = list(outputs)
    outputFunctionName = name + '_outputs'
    outputData = outputProgram = None
    if outputs: #a function of its own, the matrices dense
        outputData = exudyn.symbolic.GetFlatProgramData([outputs[key] for key in outputNames],
                                                        arguments=[equations[v] for v in variableNames] + parameterVariables,
                                                        resultNames=outputNames)
        outputGraph = codeExport.ScalarGraph()
        outputInputs = codeExport._ScalarInputs(outputGraph, {'arguments': [a for a in outputData['arguments']
                                                                             if a['name'] in variableNames]})
        for (k, parameterName) in enumerate(parameterNames):
            outputInputs[parameterName] = (outputGraph.Add('input', value=('p', (k,))) if withP
                                           else outputGraph.Add('number', value=parameterValues[k]))
        (outputGraph, outputResults) = codeExport.Scalarize(outputData, outputGraph, outputInputs)
        outputProgram = codeExport.WriteScalarProgram({'arguments': exportArguments, 'results': outputData['results']},
                                                      'C++', name=outputFunctionName, sparse=False,
                                                      graph=outputGraph, results=outputResults)
    massMatrixConstant = ('massMatrix' in results and
                          not _DependsOnState(graph, [node for row in scalarResults[results.index('massMatrix')]
                                                      for node in row]))
    sizes = _Sizes(system)
    patterns = {r: (program['patterns'][r] if r == 'massMatrix' else None) for r in results}
    patterns.update({r: jacobianProgram['patterns'][r] for r in jacobianNames})
    if language == 'numpy': #the vector code: a matrix dense
        patterns = {r: ([(i, j) for i in range(system.nODE2) for j in range(system.nODE2)] if (r == "massMatrix" or r in jacobianNames)
                        else None) for r in results + jacobianNames}

    os.makedirs(directory, exist_ok=True)
    files = {}
    def Path(fileName):
        return os.path.join(directory, fileName)
    (q0, q_t0) = system.InitialState()
    eulerParameterNodes = [{'ltg': [int(i) for i in node['ltg']], 'ltgAE': [int(i) for i in node['ltgAE']]}
                           for node in getattr(system, 'eulerParameterNodes', [])]
    description = {'writtenBy': 'exudyn.symbolics.systemExport ' + exudyn.__version__, 'name': name,
                   'language': language, 'function': functionName, 'results': results,
                   'arguments': [a['name'] for a in exportArguments], 'nODE2': system.nODE2, 'nODE1': system.nODE1,
                   'nAE': system.nAE, 'sizes': {r: sizes[r] for r in results},
                   'patterns': {r: ([list(entry) for entry in patterns[r]] if patterns[r] is not None else None)
                                for r in results + jacobianNames},
                   'jacobians': jacobianNames, 'jacobianFunction': jacobianFunctionName if jacobians else None,
                   'jacobianOperations': jacobianProgram['operations'] if jacobians else 0,
                   'outputs': {key: _OutputShape(outputs[key]) for key in outputNames},
                   'outputFunction': outputFunctionName if outputs else None,
                   'parameters': parameters, 'parameterNames': parameterNames, 'parameterValues': parameterValues,
                   'massMatrixConstant': bool(massMatrixConstant), 'operations': program['operations'],
                   'initialState': {'q': list(map(float, q0)), 'q_t': list(map(float, q_t0)),
                                    'y': list(map(float, system.InitialStateODE1()))},
                   'qRef': list(map(float, system.qRef)), 'eulerParameterNodes': eulerParameterNodes,
                   'exports': ([functionName + '_double'] + ([jacobianFunctionName + '_double'] if jacobians else [])
                               + ([outputFunctionName + '_double'] if outputs else [])
                               + ([name + '_' + f for f in _stepFunctions] if withSteps else [])
                               + ([name + '_' + f for f in _implicitFunctions] if withImplicit else [])
                               if language == 'C++' else [])}

    if language == 'C++':
        declaration = [line for line in program['code'].split('\n') if line.startswith('extern "C" void ')][0]
        guard = name.upper() + '_H_INCLUDED'
        header = ['//written by exudyn.symbolics.systemExport ' + exudyn.__version__ + ': the equations of motion of '
                  + name + ', ' + str(program['operations']) + ' operations',
                  '#ifndef ' + guard, '#define ' + guard, '',
                  '//the sizes: ODE2, ODE1 and algebraic coordinates, parameters',
                  'static const int ' + name + '_nODE2 = ' + str(system.nODE2) + ';',
                  'static const int ' + name + '_nODE1 = ' + str(system.nODE1) + ';',
                  'static const int ' + name + '_nAE = ' + str(system.nAE) + ';',
                  'static const int ' + name + '_nParameters = ' + str(len(parameterNames) if withP else 0) + ';', '',
                  '//the initial state, the reference coordinates (q is relative to them), the initial ODE1 coordinates',
                  'static const double ' + name + '_q0[] = ' + _CppArray(q0) + ';',
                  'static const double ' + name + '_q_t0[] = ' + _CppArray(q_t0) + ';',
                  'static const double ' + name + '_qRef[] = ' + _CppArray(system.qRef) + ';',
                  'static const double ' + name + '_y0[] = ' + _CppArray(system.InitialStateODE1()) + ';', '']
        if withP:
            header += ['//the parameters p of the function and their present values',
                       'static const char* const ' + name + '_parameterNames[] = {'
                       + ', '.join('"' + n + '"' for n in parameterNames) + '};',
                       'static const double ' + name + '_parameterValues[] = ' + _CppArray(parameterValues) + ';', '']
        for r in results + jacobianNames:
            if patterns[r] is not None:
                header += ['//the pattern of ' + r + ': its values are these entries, row by row',
                           'static const int ' + name + '_' + r + '_nonzeros = ' + str(len(patterns[r])) + ';',
                           'static const int ' + name + '_' + r + '_rows[] = '
                           + _CppArray([i for (i, j) in patterns[r]], 'int') + ';',
                           'static const int ' + name + '_' + r + '_columns[] = '
                           + _CppArray([j for (i, j) in patterns[r]], 'int') + ';', '']
        header += ['//the results ' + ', '.join(results) + ' of the arguments ' + ', '.join(description['arguments'])
                   + '; the template ' + functionName + '<Real> is in ' + name + '.cpp',
                   declaration.rstrip() + ';', '']
        if jacobians:
            jacobianDeclaration = [line for line in jacobianProgram['code'].split('\n')
                                   if line.startswith('extern "C" void ')][0]
            header += ['//the Jacobians ' + ', '.join(jacobianNames) + ' of the same arguments; the template '
                       + jacobianFunctionName + '<Real> is in ' + name + '.cpp', jacobianDeclaration.rstrip() + ';', '']
        if outputs:
            outputDeclaration = [line for line in outputProgram['code'].split('\n')
                                 if line.startswith('extern "C" void ')][0]
            header += ['//the outputs ' + ', '.join(outputNames) + ' of the same arguments, a matrix row by row; the template '
                       + outputFunctionName + '<Real> is in ' + name + '.cpp', outputDeclaration.rstrip() + ';', '']
        if withSteps:
            header += [_stepDeclarations.format(name=name)]
        if withImplicit:
            header += [_implicitDeclarations.format(name=name)]
        header += ['#endif', '']
        files['header'] = Path(name + '.h')
        files['source'] = Path(name + '.cpp')
        with open(files['header'], 'w') as file:
            file.write('\n'.join(header))
        with open(files['source'], 'w') as file:
            file.write('#include "' + name + '.h"\n' + program['code']
                       + (_WithoutHelpers(jacobianProgram['code'], program['code']) if jacobians else '')
                       + (_WithoutHelpers(outputProgram['code'], program['code']
                                          + (jacobianProgram['code'] if jacobians else '')) if outputs else '')
                       + (_StepCode(name, functionName, results, withP, eulerParameterNodes) if withSteps else '')
                       + (_ImplicitCode(name, functionName, jacobianFunctionName, results, withP, eulerParameterNodes)
                          if withImplicit else ''))
        if driver:
            files['driver'] = Path(name + 'Driver.cpp')
            with open(files['driver'], 'w') as file:
                file.write(_DriverCode(name))
    else:
        code = codeExport.Write(data, 'numpy', name='_' + functionName)
        parameterArgument = ', p' if withP else ''
        call = ', '.join(description['arguments'][:len(arguments)]
                         + (['*p'] if withP else [repr(v) for v in parameterValues]))
        code += ('\n\ndef ' + functionName + '(' + ', '.join(a['name'] for a in arguments) + parameterArgument + '):\n'
                 '    """the results ' + ', '.join(results) + ' as a tuple; written by exudyn.symbolics.systemExport"""\n'
                 '    values = _' + functionName + '(' + call + ')\n'
                 '    return values if ' + str(len(results) > 1) + ' else (values,)\n')
        if outputs:
            code += '\n\n' + codeExport.Write(outputData, 'numpy', name='_' + outputFunctionName)
            code += ('\n\ndef ' + outputFunctionName + '(' + ', '.join(a['name'] for a in arguments) + parameterArgument
                     + '):\n'
                     '    """the outputs ' + ', '.join(outputNames) + ' as a tuple; written by exudyn.symbolics.systemExport"""\n'
                     '    values = _' + outputFunctionName + '(' + call + ')\n'
                     '    return values if ' + str(len(outputNames) > 1) + ' else (values,)\n')
        if jacobians:
            jacobianData['name'] = '_' + jacobianFunctionName
            code += '\n\n' + codeExport.Write(jacobianData, 'numpy', name='_' + jacobianFunctionName)
            code += ('\n\ndef ' + jacobianFunctionName + '(' + ', '.join(a['name'] for a in arguments) + parameterArgument
                     + '):\n'
                     '    """the Jacobians ' + ', '.join(jacobianNames) + ' as a tuple; written by exudyn.symbolics.systemExport"""\n'
                     '    values = _' + jacobianFunctionName + '(' + call + ')\n'
                     '    return values if ' + str(len(jacobians) > 1) + ' else (values,)\n')
        files['python'] = Path(name + '.py')
        with open(files['python'], 'w') as file:
            file.write(code)
    files['description'] = Path(name + '.json')
    description['files'] = {key: os.path.basename(path) for (key, path) in files.items()}
    with open(files['description'], 'w') as file:
        json.dump(description, file, indent=1)
    return files


def _IsSensorNumber(value):
    """True for a SensorIndex or an int, which name a sensor in outputs"""
    return isinstance(value, (int, np.integer, exudyn.SensorIndex))


def _SensorExpression(system, variables, sensorNumber):
    """the output of a SensorMarker as an expression of the SystemVariables (#3520, D5)"""
    sensor = system.mbs.GetSensor(sensorNumber)
    kind = sensor['sensorType']
    outputType = sensor['outputVariableType']
    functions = {exudyn.OutputVariableType.Position: variables.MarkerPosition,
                 exudyn.OutputVariableType.Velocity: variables.MarkerVelocity,
                 exudyn.OutputVariableType.RotationMatrix: variables.MarkerRotationMatrix,
                 exudyn.OutputVariableType.AngularVelocity: variables.MarkerAngularVelocity}
    if kind != 'Marker' or outputType not in functions:
        raise ValueError('ExportSystem: sensor ' + str(int(sensorNumber)) + ' is a ' + kind + ' sensor of '
                         + str(outputType) + '; converted are SensorMarker of Position, Velocity, RotationMatrix and '
                         'AngularVelocity - give other outputs as expressions of SystemVariables')
    return functions[outputType](sensor['markerNumber'])


def _OutputShape(expression):
    """the shape of an output: [] a number, [n] a vector, [rows, columns] a matrix"""
    if isinstance(expression, exudyn.symbolic.Matrix):
        return [expression.NumberOfRows(), expression.NumberOfColumns()]
    if isinstance(expression, exudyn.symbolic.Vector):
        return [len(expression)]
    return []


def _StepCode(name, functionName, results, withP, eulerParameterNodes):
    """the C++ of the explicit steps: the accelerations, the projection of the Euler parameters, a step of explicit
    Euler and of RK4, and a simulation of steps (#3520, D7 of the design)"""
    ltgEP = [i for node in eulerParameterNodes for i in node['ltg']]
    resultArguments = 'f.data(), values.data()' if results[0] == 'ODE2RHS' else 'values.data(), f.data()'
    return '''
//the explicit steps of {name} (#3520), as exudyn.symbolics.solvers.SolveExplicit computes them: the accelerations from
//M a = f, with the Euler parameters of a node by their constraint on acceleration level, 2 p^T a + 2 p_t^T p_t = 0, in
//[M C^T; C 0] [a; z] = [f; -2 p_t^T p_t], C = 2 p^T, solved by Gauss elimination with partial pivoting; after each
//step the Euler parameters projected onto |p| = 1 and their velocities onto p^T p_t = 0. p: the parameters, nullptr
//for their values in the header. The functions returning int give 0, or 1 for a singular mass matrix
#include <vector>
static const int {name}_nEP = {nEP};
static const int {name}_ltgEP[] = {ltgEP};

extern "C" int {name}_Accelerations(const double* q, const double* q_t, double t, const double* p, double* a)
{{
    const int n = {name}_nODE2, m = {name}_nODE2 + {name}_nEP;
    std::vector<double> f(n), values({name}_massMatrix_nonzeros), A(m*m, 0.), b(m, 0.);
    {pDefault}
    {functionName}_double(q, q_t, t, {pArgument}{resultArguments});
    for (int k = 0; k < {name}_massMatrix_nonzeros; k++) {{ A[{name}_massMatrix_rows[k]*m + {name}_massMatrix_columns[k]] += values[k]; }}
    for (int i = 0; i < n; i++) {{ b[i] = f[i]; }}
    for (int e = 0; e < {name}_nEP; e++)
    {{
        double velocity2 = 0.;
        for (int j = 0; j < 4; j++)
        {{
            const int i = {name}_ltgEP[4*e + j];
            const double parameter = {name}_qRef[i] + q[i];
            A[(n + e)*m + i] = 2.*parameter;
            A[i*m + n + e] = 2.*parameter;
            velocity2 += q_t[i]*q_t[i];
        }}
        b[n + e] = -2.*velocity2;
    }}
    for (int j = 0; j < m; j++) //Gauss elimination with partial pivoting
    {{
        int pivot = j;
        for (int i = j + 1; i < m; i++) {{ if (std::fabs(A[i*m + j]) > std::fabs(A[pivot*m + j])) {{ pivot = i; }} }}
        if (A[pivot*m + j] == 0.) {{ return 1; }}
        if (pivot != j)
        {{
            for (int k = 0; k < m; k++) {{ const double x = A[j*m + k]; A[j*m + k] = A[pivot*m + k]; A[pivot*m + k] = x; }}
            const double x = b[j]; b[j] = b[pivot]; b[pivot] = x;
        }}
        for (int i = j + 1; i < m; i++)
        {{
            const double factor = A[i*m + j]/A[j*m + j];
            if (factor == 0.) {{ continue; }}
            for (int k = j; k < m; k++) {{ A[i*m + k] -= factor*A[j*m + k]; }}
            b[i] -= factor*b[j];
        }}
    }}
    for (int i = m - 1; i >= 0; i--)
    {{
        for (int k = i + 1; k < m; k++) {{ b[i] -= A[i*m + k]*b[k]; }}
        b[i] /= A[i*m + i];
    }}
    for (int i = 0; i < n; i++) {{ a[i] = b[i]; }}
    return 0;
}}

//the Euler parameters of the nodes onto |p| = 1, their velocities onto p^T p_t = 0, in place
extern "C" void {name}_Project(double* q, double* q_t)
{{
    for (int e = 0; e < {name}_nEP; e++)
    {{
        const int* ltg = {name}_ltgEP + 4*e;
        double parameters[4], norm = 0., product = 0.;
        for (int j = 0; j < 4; j++) {{ parameters[j] = {name}_qRef[ltg[j]] + q[ltg[j]]; norm += parameters[j]*parameters[j]; }}
        norm = std::sqrt(norm);
        for (int j = 0; j < 4; j++) {{ parameters[j] /= norm; q[ltg[j]] = parameters[j] - {name}_qRef[ltg[j]]; product += parameters[j]*q_t[ltg[j]]; }}
        for (int j = 0; j < 4; j++) {{ q_t[ltg[j]] -= product*parameters[j]; }}
    }}
}}

//one step of explicit Euler from t to t + h, in place, with the projection
extern "C" int {name}_StepExplicitEuler(double* q, double* q_t, double t, double h, const double* p)
{{
    const int n = {name}_nODE2;
    std::vector<double> a(n);
    if ({name}_Accelerations(q, q_t, t, p, a.data())) {{ return 1; }}
    for (int i = 0; i < n; i++) {{ q[i] += h*q_t[i]; q_t[i] += h*a[i]; }}
    {name}_Project(q, q_t);
    return 0;
}}

//one step of the classical Runge-Kutta method (RK44) from t to t + h, in place, with the projection
extern "C" int {name}_StepRK4(double* q, double* q_t, double t, double h, const double* p)
{{
    const int n = {name}_nODE2;
    std::vector<double> k1(n), k2(n), k3(n), k4(n), g(n), v2(n), v3(n), v4(n);
    int status = {name}_Accelerations(q, q_t, t, p, k1.data());
    for (int i = 0; i < n; i++) {{ g[i] = q[i] + 0.5*h*q_t[i]; v2[i] = q_t[i] + 0.5*h*k1[i]; }}
    status += {name}_Accelerations(g.data(), v2.data(), t + 0.5*h, p, k2.data());
    for (int i = 0; i < n; i++) {{ g[i] = q[i] + 0.5*h*v2[i]; v3[i] = q_t[i] + 0.5*h*k2[i]; }}
    status += {name}_Accelerations(g.data(), v3.data(), t + 0.5*h, p, k3.data());
    for (int i = 0; i < n; i++) {{ g[i] = q[i] + h*v3[i]; v4[i] = q_t[i] + h*k3[i]; }}
    status += {name}_Accelerations(g.data(), v4.data(), t + h, p, k4.data());
    for (int i = 0; i < n; i++)
    {{
        q[i] += h/6.*(q_t[i] + 2.*v2[i] + 2.*v3[i] + v4[i]);
        q_t[i] += h/6.*(k1[i] + 2.*k2[i] + 2.*k3[i] + k4[i]);
    }}
    {name}_Project(q, q_t);
    return status ? 1 : 0;
}}

//steps of explicit Euler (method 0) or RK44 (method 1) from t0, in place; output: the rows [t, q, q_t] of the start,
//of every writeEvery-th step and of the last step, which the caller provides (steps/writeEvery + 2 rows); returns the
//number of rows written, or -1 for a singular mass matrix
extern "C" int {name}_Simulate(int method, double* q, double* q_t, double t0, double h, int steps, const double* p,
                               int writeEvery, double* output)
{{
    const int n = {name}_nODE2;
    int rows = 0;
    {name}_Project(q, q_t);
    auto Write = [&](double t)
    {{
        double* row = output + rows*(2*n + 1);
        row[0] = t;
        for (int i = 0; i < n; i++) {{ row[1 + i] = q[i]; row[1 + n + i] = q_t[i]; }}
        rows++;
    }};
    Write(t0);
    for (int step = 0; step < steps; step++)
    {{
        const double t = t0 + step*h;
        const int status = method == 0 ? {name}_StepExplicitEuler(q, q_t, t, h, p) : {name}_StepRK4(q, q_t, t, h, p);
        if (status) {{ return -1; }}
        if ((step + 1) % writeEvery == 0 || step + 1 == steps) {{ Write(t0 + (step + 1)*h); }}
    }}
    return rows;
}}
'''.format(name=name, functionName=functionName, nEP=len(eulerParameterNodes), ltgEP=_CppArray(ltgEP, 'int'),
           pDefault=('if (!p) { p = ' + name + '_parameterValues; }') if withP else '//no parameters',
           pArgument='p, ' if withP else '', resultArguments=resultArguments)


_stepDeclarations = '''//the explicit steps (#3520): accelerations, the projection of the Euler parameters, the steps, a simulation; p: the
//parameters, nullptr for the values above
extern "C" int {name}_Accelerations(const double* q, const double* q_t, double t, const double* p, double* a);
extern "C" void {name}_Project(double* q, double* q_t);
extern "C" int {name}_StepExplicitEuler(double* q, double* q_t, double t, double h, const double* p);
extern "C" int {name}_StepRK4(double* q, double* q_t, double t, double h, const double* p);
extern "C" int {name}_Simulate(int method, double* q, double* q_t, double t0, double h, int steps, const double* p,
                               int writeEvery, double* output);
'''

_stepFunctions = ['Accelerations', 'Project', 'StepExplicitEuler', 'StepRK4', 'Simulate']
_implicitFunctions = ['StepGeneralizedAlpha', 'SimulateGeneralizedAlpha']

_implicitDeclarations = '''//the implicit steps (#3520): the generalized-alpha method, a step and a simulation; settings: alphaM, alphaF, beta,
//gamma, useNewmark, relativeTolerance, absoluteTolerance, maxIterations, useModifiedNewton, the divisor of the norm of
//the residual; statistics: Newton iterations, Jacobians, the step that failed
extern "C" int {name}_StepGeneralizedAlpha(double* q, double* q_t, double* q_tt, double* aAlgorithmic, double* z,
                                           double t, double h, const double* p, const double* settings, int* statistics);
extern "C" int {name}_SimulateGeneralizedAlpha(double* q, double* q_t, double t0, double h, int steps, const double* p,
                                               const double* settings, int computeInitialAccelerations, int writeEvery,
                                               double* output, int* statistics);
'''


def _WithoutHelpers(code, written):
    """the code of a second program without the includes and the helper functions the first one has written already"""
    for helper in codeExport._cppHelpers.values():
        if helper in written:
            code = code.replace(helper, '')
    return code


def _ImplicitCode(name, functionName, jacobianFunctionName, results, withP, eulerParameterNodes):
    """the C++ of the generalized-alpha method on the exported Jacobians (#3520), after the explicit steps"""
    resultArguments = 'f.data(), values.data()' if results[0] == 'ODE2RHS' else 'values.data(), f.data()'
    ltgAEEP = [int(node['ltgAE'][0]) for node in eulerParameterNodes]
    return _implicitCode.format(name=name, functionName=functionName, jacobianFunctionName=jacobianFunctionName,
                                ltgAEEP=_CppArray(ltgAEEP, 'int'),
                                pDefault=('if (!p) { p = ' + name + '_parameterValues; }') if withP else '//no parameters',
                                pArgument='p, ' if withP else '', resultArguments=resultArguments)


_implicitCode = '''
//the implicit steps of {name} (#3520), as exudyn.symbolics.solvers.SolveGeneralizedAlpha computes them: the
//generalized-alpha method of Arnold and Bruls, Newton's method for the coordinates with the residual
//r = M q_tt - f + C_q^T z, c = p^T p - 1 of the Euler parameters, its Jacobian from the mass matrix and the exported
//Jacobians of f - the derivative of M(q) q_tt by q left out -, the ODE2 rows scaled by beta h^2 and the columns of z by
//1/(beta h^2); no projection, the Euler parameters are constrained
static const int {name}_ltgAEEP[] = {ltgAEEP};

//Gauss elimination with partial pivoting of the dense m x m matrix A, b overwritten by the solution; 1 if singular
static int {name}_SolveDense(int m, std::vector<double>& A, std::vector<double>& b)
{{
    for (int j = 0; j < m; j++)
    {{
        int pivot = j;
        for (int i = j + 1; i < m; i++) {{ if (std::fabs(A[i*m + j]) > std::fabs(A[pivot*m + j])) {{ pivot = i; }} }}
        if (A[pivot*m + j] == 0.) {{ return 1; }}
        if (pivot != j)
        {{
            for (int k = 0; k < m; k++) {{ const double x = A[j*m + k]; A[j*m + k] = A[pivot*m + k]; A[pivot*m + k] = x; }}
            const double x = b[j]; b[j] = b[pivot]; b[pivot] = x;
        }}
        for (int i = j + 1; i < m; i++)
        {{
            const double factor = A[i*m + j]/A[j*m + j];
            if (factor == 0.) {{ continue; }}
            for (int k = j; k < m; k++) {{ A[i*m + k] -= factor*A[j*m + k]; }}
            b[i] -= factor*b[j];
        }}
    }}
    for (int i = m - 1; i >= 0; i--)
    {{
        for (int k = i + 1; k < m; k++) {{ b[i] -= A[i*m + k]*b[k]; }}
        b[i] /= A[i*m + i];
    }}
    return 0;
}}

//the residual of Newton's method, nODE2 + nAE rows
static void {name}_Residual(const double* q, const double* q_t, const double* q_tt, const double* z, double t,
                            const double* p, double* r)
{{
    const int n = {name}_nODE2;
    std::vector<double> f(n), values({name}_massMatrix_nonzeros);
    {functionName}_double(q, q_t, t, {pArgument}{resultArguments});
    for (int i = 0; i < n; i++) {{ r[i] = -f[i]; }}
    for (int k = 0; k < {name}_massMatrix_nonzeros; k++) {{ r[{name}_massMatrix_rows[k]] += values[k]*q_tt[{name}_massMatrix_columns[k]]; }}
    for (int e = 0; e < {name}_nEP; e++)
    {{
        const int row = {name}_ltgAEEP[e];
        double norm2 = 0.;
        for (int j = 0; j < 4; j++)
        {{
            const int i = {name}_ltgEP[4*e + j];
            const double parameter = {name}_qRef[i] + q[i];
            r[i] += 2.*parameter*z[row];
            norm2 += parameter*parameter;
        }}
        r[n + row] = norm2 - 1.;
    }}
}}

//one step of the generalized-alpha method from t - h to t, in place: q, q_t, q_tt, the algorithmic accelerations
//aAlgorithmic and the multipliers z of the Euler parameters; settings: alphaM, alphaF, beta, gamma, useNewmark,
//relativeTolerance, absoluteTolerance, maxIterations, useModifiedNewton, the divisor of the residual norm;
//statistics: the Newton iterations and the Jacobians are added; returns 0, 1 for a singular Jacobian, 2 if Newton's
//method does not converge
extern "C" int {name}_StepGeneralizedAlpha(double* q, double* q_t, double* q_tt, double* aAlgorithmic, double* z,
                                           double t, double h, const double* p, const double* settings, int* statistics)
{{
    {pDefault}
    const int n = {name}_nODE2, m = {name}_nODE2 + {name}_nAE;
    const double alphaM = settings[0], alphaF = settings[1], beta = settings[2], gamma = settings[3];
    const bool newmark = settings[4] != 0., modifiedNewton = settings[8] != 0.;
    const double relativeTolerance = settings[5], absoluteTolerance = settings[6], errorDivisor = settings[9];
    const int maxIterations = (int)settings[7];
    const double betaPrime = (1. - alphaM)/(h*h*beta*(1. - alphaF)), gammaPrime = gamma/(h*beta), scaling = beta*h*h;
    for (int i = 0; i < n; i++) //the predictor
    {{
        if (newmark)
        {{
            q[i] += h*q_t[i] + h*h*(0.5 - beta)*q_tt[i];
            q_t[i] += h*(1. - gamma)*q_tt[i];
        }}
        else
        {{
            q[i] += h*q_t[i] + h*h*(0.5 - beta)*aAlgorithmic[i];
            q_t[i] += h*(1. - gamma)*aAlgorithmic[i];
            aAlgorithmic[i] = (alphaF*q_tt[i] - alphaM*aAlgorithmic[i])/(1. - alphaM);
            q[i] += h*h*beta*aAlgorithmic[i];
            q_t[i] += h*gamma*aAlgorithmic[i];
        }}
        q_tt[i] = 0.;
    }}
    std::vector<double> r(m), J, A, b, f(n), values({name}_massMatrix_nonzeros), Jq({name}_ODE2RHS_q_nonzeros), Jqt({name}_ODE2RHS_q_t_nonzeros);
    auto Norm = [&]() {{ double s = 0.; for (int i = 0; i < m; i++) {{ s += r[i]*r[i]; }} return std::sqrt(s)/errorDivisor; }};
    {name}_Residual(q, q_t, q_tt, z, t, p, r.data());
    double initialResidual = Norm();
    if (initialResidual <= absoluteTolerance) {{ initialResidual = 2.*absoluteTolerance; }} //at least one Newton step
    bool converged = false;
    for (int iteration = 0; iteration < maxIterations; iteration++)
    {{
        if (J.empty() || !modifiedNewton)
        {{
            J.assign(m*m, 0.);
            {functionName}_double(q, q_t, t, {pArgument}{resultArguments});
            {jacobianFunctionName}_double(q, q_t, t, {pArgument}Jq.data(), Jqt.data());
            for (int k = 0; k < {name}_massMatrix_nonzeros; k++) {{ J[{name}_massMatrix_rows[k]*m + {name}_massMatrix_columns[k]] += betaPrime*values[k]; }}
            for (int k = 0; k < {name}_ODE2RHS_q_nonzeros; k++) {{ J[{name}_ODE2RHS_q_rows[k]*m + {name}_ODE2RHS_q_columns[k]] -= Jq[k]; }}
            for (int k = 0; k < {name}_ODE2RHS_q_t_nonzeros; k++) {{ J[{name}_ODE2RHS_q_t_rows[k]*m + {name}_ODE2RHS_q_t_columns[k]] -= gammaPrime*Jqt[k]; }}
            for (int e = 0; e < {name}_nEP; e++)
            {{
                const int row = {name}_ltgAEEP[e];
                for (int j = 0; j < 4; j++)
                {{
                    const int i = {name}_ltgEP[4*e + j];
                    const double parameter = {name}_qRef[i] + q[i];
                    J[i*m + i] += 2.*z[row];
                    J[i*m + n + row] = 2.*parameter/scaling; //the ODE2 rows are scaled below
                    J[(n + row)*m + i] = 2.*parameter;
                }}
            }}
            for (int i = 0; i < n*m; i++) {{ J[i] *= scaling; }}
            statistics[1]++;
        }}
        A = J;
        b = r;
        for (int i = 0; i < n; i++) {{ b[i] *= scaling; }}
        if ({name}_SolveDense(m, A, b)) {{ return 1; }}
        for (int i = 0; i < n; i++) {{ q[i] -= b[i]; q_t[i] -= gammaPrime*b[i]; q_tt[i] -= betaPrime*b[i]; }}
        for (int i = 0; i < {name}_nAE; i++) {{ z[i] -= b[n + i]/scaling; }}
        statistics[0]++;
        {name}_Residual(q, q_t, q_tt, z, t, p, r.data());
        const double residual = Norm();
        if (residual/initialResidual <= relativeTolerance || residual <= absoluteTolerance) {{ converged = true; break; }}
    }}
    if (!converged) {{ return 2; }}
    if (!newmark) {{ for (int i = 0; i < n; i++) {{ aAlgorithmic[i] += (1. - alphaF)/(1. - alphaM)*q_tt[i]; }} }}
    return 0;
}}

//steps of the generalized-alpha method from t0, in place; the initial accelerations by name_Accelerations if
//computeInitialAccelerations, else zero; output: the rows [t, q, q_t, q_tt, z] of the start, of every writeEvery-th
//step and of the last step (steps/writeEvery + 2 rows); statistics: the Newton iterations, the Jacobians and the step
//that failed; returns the number of rows written, -1 for a singular matrix, -2 if Newton's method does not converge
extern "C" int {name}_SimulateGeneralizedAlpha(double* q, double* q_t, double t0, double h, int steps, const double* p,
                                               const double* settings, int computeInitialAccelerations, int writeEvery,
                                               double* output, int* statistics)
{{
    const int n = {name}_nODE2, nAE = {name}_nAE;
    std::vector<double> q_tt(n, 0.), aAlgorithmic, z(nAE, 0.);
    if (computeInitialAccelerations && {name}_Accelerations(q, q_t, t0, p, q_tt.data())) {{ return -1; }}
    aAlgorithmic = q_tt;
    int rows = 0;
    auto Write = [&](double t)
    {{
        double* row = output + rows*(3*n + nAE + 1);
        row[0] = t;
        for (int i = 0; i < n; i++) {{ row[1 + i] = q[i]; row[1 + n + i] = q_t[i]; row[1 + 2*n + i] = q_tt[i]; }}
        for (int i = 0; i < nAE; i++) {{ row[1 + 3*n + i] = z[i]; }}
        rows++;
    }};
    Write(t0);
    for (int step = 0; step < steps; step++)
    {{
        const int status = {name}_StepGeneralizedAlpha(q, q_t, q_tt.data(), aAlgorithmic.data(), z.data(), t0 + (step + 1)*h,
                                                       h, p, settings, statistics);
        if (status) {{ statistics[2] = step + 1; return -status; }}
        if ((step + 1) % writeEvery == 0 || step + 1 == steps) {{ Write(t0 + (step + 1)*h); }}
    }}
    return rows;
}}
'''


def _DriverCode(name):
    """the C++ program integrating the export by its function StepRK4"""
    return '''//written by exudyn.symbolics.systemExport: integrates {name} by the classical Runge-Kutta method (RK44) with
//constant steps, {name}_StepRK4 of {name}.cpp
//usage: {name}Driver endTime numberOfSteps [file]; writes the lines "t q[0] ... q_t[0] ...", the initial state first,
//into the file or to the standard output
#define _CRT_SECURE_NO_WARNINGS //fopen with MSVC
#include "{name}.h"
#include <cstdio>
#include <cstdlib>
#include <vector>

static void Write(FILE* file, double t, const std::vector<double>& q, const std::vector<double>& q_t)
{{
    std::fprintf(file, "%.17g", t);
    for (double x : q) {{ std::fprintf(file, " %.17g", x); }}
    for (double x : q_t) {{ std::fprintf(file, " %.17g", x); }}
    std::fprintf(file, "\\n");
}}

int main(int argc, char** argv)
{{
    if (argc < 3) {{ std::fprintf(stderr, "usage: {name}Driver endTime numberOfSteps [file]\\n"); return 1; }}
    const double endTime = std::atof(argv[1]);
    const int steps = std::atoi(argv[2]);
    FILE* file = argc > 3 ? std::fopen(argv[3], "w") : stdout;
    if (!file) {{ std::fprintf(stderr, "{name}Driver: cannot write %s\\n", argv[3]); return 1; }}
    const double h = endTime/steps;
    std::vector<double> q({name}_q0, {name}_q0 + {name}_nODE2), q_t({name}_q_t0, {name}_q_t0 + {name}_nODE2);
    {name}_Project(q.data(), q_t.data());
    Write(file, 0., q, q_t);
    for (int step = 0; step < steps; step++)
    {{
        if ({name}_StepRK4(q.data(), q_t.data(), step*h, h, nullptr))
        {{
            std::fprintf(stderr, "{name}Driver: the mass matrix is singular\\n");
            return 1;
        }}
        Write(file, (step + 1)*h, q, q_t);
    }}
    if (file != stdout) {{ std::fclose(file); }}
    return 0;
}}
'''.format(name=name)


def _Compiler():
    """the compiler of setuptools and the options for an optimized shared library"""
    try:
        from setuptools._distutils.ccompiler import new_compiler
        from setuptools._distutils.sysconfig import customize_compiler
    except ImportError as error:
        raise RuntimeError('CompileExport: setuptools is needed to find a compiler: pip install setuptools') from error
    compiler = new_compiler()
    customize_compiler(compiler)
    isMSVC = compiler.compiler_type == 'msvc'
    return (compiler, isMSVC, ['/O2', '/EHsc'] if isMSVC else ['-O2', '-fPIC', '-std=c++11'])


def CompileExport(files, driver=None):
    """compile a C++ export of ExportSystem by the compiler that setuptools finds (MSVC on Windows, gcc or clang
    elsewhere): the shared library of name.cpp and, if the export has a driver, the program nameDriver, both in the
    directory of the export; refused with the message of setuptools where no compiler is found. A library that is
    loaded cannot be written again: compile a changed export under another name or in another directory

    Args:
        files: the dict returned by ExportSystem (SymbolicSystem.Export), or the path of the .json file of the export
        driver: True: compile the driver too; None: if the export has one

    Returns:
        files with 'library' and, with the driver, 'program': the paths of the library and of the program
    """
    files = _Files(files)
    with open(files['description']) as file:
        description = json.load(file)
    if description['language'] != 'C++':
        raise ValueError('CompileExport: the export ' + description['name'] + ' is ' + description['language'] + ', not C++')
    directory = os.path.dirname(os.path.abspath(files['description']))
    name = description['name']
    (compiler, isMSVC, options) = _Compiler()
    withDriver = 'driver' in description['files'] if driver is None else driver
    workingDirectory = os.getcwd()
    try: #in the directory of the export: setuptools puts the objects of an absolute path into subdirectories
        os.chdir(directory)
        objects = compiler.compile([name + '.cpp'], extra_postargs=options)
        library = compiler.library_filename(name, lib_type='shared')
        compiler.link_shared_object(objects, library, libraries=[] if isMSVC else ['m'],
                                    export_symbols=description['exports'] if isMSVC else None)
        files['library'] = os.path.join(directory, library)
        if withDriver:
            driverObjects = compiler.compile([name + 'Driver.cpp'], extra_postargs=options)
            compiler.link_executable(driverObjects + objects, name + 'Driver', libraries=[] if isMSVC else ['m'])
            files['program'] = os.path.join(directory, compiler.executable_filename(name + 'Driver'))
    except Exception as error: #CompileError, LinkError, or no compiler found
        raise RuntimeError('CompileExport: ' + name + ' could not be compiled: ' + str(error)) from error
    finally:
        os.chdir(workingDirectory)
    return files


def _Files(files):
    """the dict of the files of an export, from the dict or the path of the .json file"""
    if isinstance(files, dict):
        return dict(files)
    return {'description': str(files)}


class CompiledSystem(SymbolicSystemBase):
    """an export of ExportSystem (SymbolicSystem.Export) as a SymbolicSystemBase (#3520): the C++ export by its compiled
    library through ctypes, the numpy export by its Python file. The solvers of exudyn.symbolics.solvers and
    advancedSolvers run on it as on the SymbolicSystem it was exported from. The results are computed by one call for
    all of them and kept for the next call at the same state. Nodes with Euler parameters have their algebraic
    equation p^T p - 1 = 0 and its reaction 2 p z here, as in SymbolicSystem; other algebraic equations need the
    results algebraicEquations and ODE2ReactionForcesLHS in the export

    Args:
        files: the dict returned by ExportSystem or CompileExport, or the path of the .json file of the export
        library: the path of the compiled library of a C++ export; None: the library of files, or the library of the
            name of the export in its directory
    """
    def __init__(self, files, library=None):
        files = _Files(files)
        with open(files['description']) as file:
            description = json.load(file)
        self.description = description
        directory = os.path.dirname(os.path.abspath(files['description']))
        (self.nODE2, self.nODE1, self.nAE) = (description['nODE2'], description['nODE1'], description['nAE'])
        self.results = description['results']
        self.qRef = np.array(description['qRef'], dtype=float)
        self.eulerParameterNodes = [{'ltg': np.array(node['ltg'], dtype=int), 'ltgAE': np.array(node['ltgAE'], dtype=int)}
                                    for node in description['eulerParameterNodes']]
        self.parameterNames = list(description['parameterNames'])
        self._p = np.array(description['parameterValues'], dtype=float)
        self._withP = 'p' in description['arguments']
        self._argumentNames = description['arguments']
        self._cache = (None, None)
        self._jacobianCache = (None, None)
        self._simulate = None
        self._simulateImplicit = None
        self.jacobians = list(description.get('jacobians', []))
        self.outputNames = list(description.get('outputs', {}))
        self._CallOutputs = None
        patterns = description['patterns']
        self._pattern = None
        if 'massMatrix' in self.results:
            pattern = np.array(patterns['massMatrix'], dtype=int).reshape(-1, 2)
            self._pattern = (pattern[:, 0].copy(), pattern[:, 1].copy())
        sizes = [len(patterns[r]) if patterns[r] is not None else description['sizes'][r] for r in self.results]
        if description['language'] == 'C++':
            if library is None:
                library = files.get('library')
            if library is None:
                import setuptools._distutils.ccompiler as ccompiler
                library = os.path.join(directory, ccompiler.new_compiler().library_filename(description['name'],
                                                                                             lib_type='shared'))
            self._library = ctypes.CDLL(os.path.abspath(library))
            function = getattr(self._library, description['function'] + '_double')
            pointer = ctypes.POINTER(ctypes.c_double)
            function.argtypes = [ctypes.c_double if n == 't' else pointer for n in self._argumentNames] + [pointer]*len(sizes)
            function.restype = None
            self._outputs = [np.zeros(size) for size in sizes]
            outputPointers = [x.ctypes.data_as(pointer) for x in self._outputs]
            def Call(arguments):
                function(*[a if n == 't' else np.ascontiguousarray(a, dtype=float).ctypes.data_as(pointer)
                           for (n, a) in zip(self._argumentNames, arguments)], *outputPointers)
                return [x.copy() for x in self._outputs]
            self._Call = Call
            if self.jacobians:
                jacobianFunction = getattr(self._library, description['jacobianFunction'] + '_double')
                jacobianFunction.argtypes = function.argtypes[:len(self._argumentNames)] + [pointer]*len(self.jacobians)
                jacobianFunction.restype = None
                jacobianOutputs = [np.zeros(len(patterns[r])) for r in self.jacobians]
                jacobianPointers = [x.ctypes.data_as(pointer) for x in jacobianOutputs]
                def CallJacobians(arguments):
                    jacobianFunction(*[a if n == 't' else np.ascontiguousarray(a, dtype=float).ctypes.data_as(pointer)
                                       for (n, a) in zip(self._argumentNames, arguments)], *jacobianPointers)
                    return [x.copy() for x in jacobianOutputs]
                self._CallJacobians = CallJacobians
            if self.outputNames:
                outputFunction = getattr(self._library, description['outputFunction'] + '_double')
                outputFunction.argtypes = function.argtypes[:len(self._argumentNames)] + [pointer]*len(self.outputNames)
                outputFunction.restype = None
                outputBuffers = [np.zeros(int(np.prod(description['outputs'][key]))) for key in self.outputNames]
                userOutputPointers = [x.ctypes.data_as(pointer) for x in outputBuffers]
                def CallOutputs(arguments):
                    outputFunction(*[a if n == 't' else np.ascontiguousarray(a, dtype=float).ctypes.data_as(pointer)
                                     for (n, a) in zip(self._argumentNames, arguments)], *userOutputPointers)
                    return [x.copy() for x in outputBuffers]
                self._CallOutputs = CallOutputs
            if description['name'] + '_SimulateGeneralizedAlpha' in description.get('exports', []):
                self._simulateImplicit = getattr(self._library, description['name'] + '_SimulateGeneralizedAlpha')
                self._simulateImplicit.argtypes = [pointer, pointer, ctypes.c_double, ctypes.c_double, ctypes.c_int,
                                                   pointer, pointer, ctypes.c_int, ctypes.c_int, pointer,
                                                   ctypes.POINTER(ctypes.c_int)]
                self._simulateImplicit.restype = ctypes.c_int
            if description['name'] + '_Simulate' in description.get('exports', []):
                self._simulate = getattr(self._library, description['name'] + '_Simulate')
                self._simulate.argtypes = [ctypes.c_int, pointer, pointer, ctypes.c_double, ctypes.c_double,
                                           ctypes.c_int, pointer, ctypes.c_int, pointer]
                self._simulate.restype = ctypes.c_int
        else:
            space = {}
            with open(os.path.join(directory, description['files']['python'])) as file:
                exec(file.read(), space)
            function = space[description['function']]
            def Call(arguments):
                values = function(*arguments)
                return [np.array(v, dtype=float).reshape(-1) for v in values]
            self._Call = Call
            if self.outputNames:
                outputFunction = space[description['outputFunction']]
                def CallOutputs(arguments):
                    return [np.array(v, dtype=float).reshape(-1) for v in outputFunction(*arguments)]
                self._CallOutputs = CallOutputs
            if self.jacobians:
                jacobianFunction = space[description['jacobianFunction']]
                def CallJacobians(arguments):
                    return [np.array(v, dtype=float).reshape(-1) for v in jacobianFunction(*arguments)]
                self._CallJacobians = CallJacobians

    def Simulate(self, simulationSettings=None, solverType=None):
        """the time integration in the compiled code (#3520), with constant step size - one call for all steps, without
        Python in the loop: the export's name_Simulate, the steps of explicit Euler or RK44, the Euler parameters as
        SolveExplicit treats them, for a C++ export with the explicit steps (see ExportSystem); or
        name_SimulateGeneralizedAlpha, the generalized-alpha method as SolveGeneralizedAlpha computes it on the
        exported Jacobians, for an export with the jacobians as well

        Args:
            simulationSettings: exudyn.SimulationSettings, of which timeIntegration.startTime, endTime and
                numberOfSteps and solution.file.writePeriod are used, for the generalized-alpha method also
                generalizedAlpha.spectralRadius, useNewmark, newmarkBeta, newmarkGamma, computeInitialAccelerations and
                newton.relativeTolerance, absoluteTolerance, maxIterations, useModifiedNewton,
                weightTolerancePerCoordinate; None: the defaults
            solverType: exudyn.DynamicSolverType.ExplicitEuler, RK44 or GeneralizedAlpha; None:
                timeIntegration.solverType

        Returns:
            dict with 'time' (n_out), 'q', 'q_t' (n_out x nODE2) at the start, at the steps that are multiples of the
            write period in steps (rounded, at least 1) and at the last step, and 'steps'; for the generalized-alpha
            method also 'q_tt', 'z' (n_out x nAE), 'newtonIterations' and 'jacobianEvaluations'
        """
        if simulationSettings is None:
            simulationSettings = exudyn.SimulationSettings()
        timeIntegration = simulationSettings.timeIntegration
        solverType = timeIntegration.solverType if solverType is None else solverType
        if solverType == exudyn.DynamicSolverType.GeneralizedAlpha:
            return self._SimulateGeneralizedAlpha(simulationSettings)
        if self._simulate is None:
            raise ValueError('CompiledSystem.Simulate: the export ' + self.description['name'] + ' has no explicit steps '
                             '(a C++ export of ODE2RHS and massMatrix of a system of ODE2 coordinates)')
        methods = {exudyn.DynamicSolverType.ExplicitEuler: 0, exudyn.DynamicSolverType.RK44: 1}
        if solverType not in methods:
            raise ValueError('CompiledSystem.Simulate: solverType must be ExplicitEuler, RK44 or GeneralizedAlpha, not '
                             + str(solverType))
        (tStart, tEnd, steps) = (timeIntegration.startTime, timeIntegration.endTime, int(timeIntegration.numberOfSteps))
        h = (tEnd - tStart)/steps
        writeEvery = max(1, int(round(simulationSettings.solution.file.writePeriod/h)))
        (q, q_t) = self.InitialState()
        rows = steps//writeEvery + 2
        output = np.zeros((rows, 2*self.nODE2 + 1))
        pointer = ctypes.POINTER(ctypes.c_double)
        written = self._simulate(methods[solverType], q.ctypes.data_as(pointer), q_t.ctypes.data_as(pointer), float(tStart),
                                 h, steps, self._p.ctypes.data_as(pointer) if self._withP else None, writeEvery,
                                 output.ctypes.data_as(pointer))
        if written < 0:
            raise ValueError('CompiledSystem.Simulate: the mass matrix is singular')
        output = output[:written]
        n = self.nODE2
        return {'time': output[:, 0], 'q': output[:, 1:1 + n], 'q_t': output[:, 1 + n:], 'steps': steps}

    def _SimulateGeneralizedAlpha(self, simulationSettings):
        """Simulate by the export's name_SimulateGeneralizedAlpha"""
        if self._simulateImplicit is None:
            raise ValueError('CompiledSystem.Simulate: the export ' + self.description['name'] + ' has no implicit steps '
                             "(a C++ export with the explicit steps and jacobians=[('ODE2RHS', 'q'), ('ODE2RHS', 'q_t')])")
        timeIntegration = simulationSettings.timeIntegration
        (generalizedAlpha, newton) = (timeIntegration.generalizedAlpha, timeIntegration.newton)
        if generalizedAlpha.useIndex2Constraints:
            raise ValueError('CompiledSystem.Simulate: useIndex2Constraints is not implemented')
        if generalizedAlpha.useNewmark: #the parameters of SolveGeneralizedAlpha
            (alphaM, alphaF) = (0.5, 0.5)
            (beta, gamma) = (generalizedAlpha.newmarkBeta, generalizedAlpha.newmarkGamma)
        else:
            rho = generalizedAlpha.spectralRadius
            (alphaM, alphaF) = ((2*rho - 1)/(rho + 1), rho/(rho + 1))
            gamma = 0.5 + alphaF - alphaM
            beta = 0.25*(gamma + 0.5)**2
        nSystem = self.nODE2 + self.nAE
        settings = np.array([alphaM, alphaF, beta, gamma, float(generalizedAlpha.useNewmark), newton.relativeTolerance,
                             newton.absoluteTolerance, float(newton.maxIterations), float(newton.useModifiedNewton),
                             np.sqrt(nSystem) if (newton.weightTolerancePerCoordinate and nSystem) else 1.])
        (tStart, tEnd, steps) = (timeIntegration.startTime, timeIntegration.endTime, int(timeIntegration.numberOfSteps))
        h = (tEnd - tStart)/steps
        writeEvery = max(1, int(round(simulationSettings.solution.file.writePeriod/h)))
        (q, q_t) = self.InitialState()
        (n, nAE) = (self.nODE2, self.nAE)
        output = np.zeros((steps//writeEvery + 2, 3*n + nAE + 1))
        statistics = np.zeros(3, dtype=np.int32)
        pointer = ctypes.POINTER(ctypes.c_double)
        written = self._simulateImplicit(q.ctypes.data_as(pointer), q_t.ctypes.data_as(pointer), float(tStart), h, steps,
                                         self._p.ctypes.data_as(pointer) if self._withP else None,
                                         settings.ctypes.data_as(pointer), int(generalizedAlpha.computeInitialAccelerations),
                                         writeEvery, output.ctypes.data_as(pointer),
                                         statistics.ctypes.data_as(ctypes.POINTER(ctypes.c_int)))
        if written == -1:
            raise ValueError('CompiledSystem.Simulate: the mass matrix or the Jacobian is singular, step '
                             + str(int(statistics[2])))
        if written < 0:
            raise ValueError('CompiledSystem.Simulate: Newton did not converge in step ' + str(int(statistics[2]))
                             + ' after ' + str(int(newton.maxIterations)) + ' iterations')
        output = output[:written]
        return {'time': output[:, 0], 'q': output[:, 1:1 + n], 'q_t': output[:, 1 + n:1 + 2*n],
                'q_tt': output[:, 1 + 2*n:1 + 3*n], 'z': output[:, 1 + 3*n:], 'steps': steps,
                'newtonIterations': int(statistics[0]), 'jacobianEvaluations': int(statistics[1])}

    def SetParameterValues(self, values):
        """set named parameters of an export with parameters='inputs'

        Args:
            values: dict of the names of the parameters and their new values
        """
        if not self._withP:
            raise ValueError('CompiledSystem.SetParameterValues: the export has its parameters as numbers')
        for (parameterName, value) in values.items():
            if parameterName not in self.parameterNames:
                raise ValueError('CompiledSystem.SetParameterValues: no parameter named ' + str(parameterName)
                                 + '; the parameters: ' + str(self.parameterNames))
            self._p[self.parameterNames.index(parameterName)] = float(value)
        self._cache = (None, None)

    def _Results(self, q, q_t, t, z=None, y=None):
        """the results of the export at a state, by one call, kept for the same state"""
        state = {'q': q, 'q_t': q_t, 't': float(t), 'z': z if z is not None else np.zeros(self.nAE),
                 'y': y if y is not None else self.InitialStateODE1(), 'p': self._p}
        arguments = [state[n] if n == 't' else np.asarray(state[n], dtype=float) for n in self._argumentNames]
        key = tuple(a if isinstance(a, float) else a.tobytes() for a in arguments)
        if self._cache[0] != key:
            self._cache = (key, dict(zip(self.results, self._Call(arguments))))
        return self._cache[1]

    def _Result(self, result, *state):
        if result not in self.results:
            raise ValueError('CompiledSystem: the export has no ' + result + '; its results: ' + str(self.results))
        return self._Results(*state)[result]

    def InitialState(self):
        """(q0, q_t0) of the export"""
        initial = self.description['initialState']
        return (np.array(initial['q'], dtype=float), np.array(initial['q_t'], dtype=float))

    def InitialStateODE1(self):
        """y0 of the export"""
        return np.array(self.description['initialState']['y'], dtype=float)

    def IsMassMatrixConstant(self):
        """True if the exported mass matrix depends on no coordinate, velocity and time"""
        return self.description['massMatrixConstant']

    def ODE2RHS(self, q=None, q_t=None, t=0., y=None):
        """f(q, q_t, t, y) of the export"""
        (q, q_t, _) = self._State(q, q_t)
        return self._Result('ODE2RHS', q, q_t, t, None, y).copy()

    def MassMatrixTriplets(self, q=None, q_t=None, t=0.):
        """the values of the mass matrix with their rows and columns"""
        (q, q_t, _) = self._State(q, q_t)
        values = self._Result('massMatrix', q, q_t, t)
        return (self._pattern[0], self._pattern[1], values.copy())

    def MassMatrix(self, q=None, q_t=None, t=0., sparse=False):
        """the mass matrix; sparse=True: a scipy.sparse.csr_matrix"""
        (rows, columns, values) = self.MassMatrixTriplets(q, q_t, t)
        if sparse:
            return self._Matrix(rows, columns, values, True)
        matrix = np.zeros((self.nODE2, self.nODE2))
        matrix[rows, columns] = values #each entry once in the pattern
        return matrix

    def Outputs(self, q=None, q_t=None, t=0.):
        """the outputs of the export at a state (#3520): dict of their names and values - a float, a vector, or a matrix

        Args:
            q: the ODE2 coordinates; None: zero
            q_t: the ODE2 velocities; None: zero
            t: the time

        Returns:
            dict of the names of the outputs and their values
        """
        if self._CallOutputs is None:
            raise ValueError('CompiledSystem.Outputs: the export ' + self.description['name'] + ' has no outputs')
        (q, q_t, _) = self._State(q, q_t)
        state = {'q': q, 'q_t': q_t, 't': float(t), 'z': np.zeros(self.nAE), 'y': self.InitialStateODE1(), 'p': self._p}
        values = self._CallOutputs([state[n] if n == 't' else np.asarray(state[n], dtype=float) for n in self._argumentNames])
        result = {}
        for (key, value) in zip(self.outputNames, values):
            shape = self.description['outputs'][key]
            result[key] = float(value[0]) if shape == [] else value.reshape(shape)
        return result

    def OutputsOfSolution(self, solution):
        """the outputs at the rows of a solution of Simulate, SolveExplicit or SolveGeneralizedAlpha: dict of their
        names and arrays, one row per time (a matrix output row by row)

        Args:
            solution: dict with 'time', 'q', 'q_t'

        Returns:
            dict of the names of the outputs and arrays (n_out x size)
        """
        rows = [self.Outputs(q, q_t, t) for (t, q, q_t) in zip(solution['time'], solution['q'], solution['q_t'])]
        return {key: np.array([np.ravel(row[key]) for row in rows]) for key in self.outputNames}

    def _Jacobians(self, q, q_t, t):
        """the exported Jacobians at a state as dense matrices, by one call, kept for the same state"""
        state = {'q': q, 'q_t': q_t, 't': float(t), 'z': np.zeros(self.nAE), 'y': self.InitialStateODE1(), 'p': self._p}
        arguments = [state[n] if n == 't' else np.asarray(state[n], dtype=float) for n in self._argumentNames]
        key = tuple(a if isinstance(a, float) else a.tobytes() for a in arguments)
        if self._jacobianCache[0] != key:
            matrices = {}
            for (jacobian, values) in zip(self.jacobians, self._CallJacobians(arguments)):
                pattern = np.array(self.description['patterns'][jacobian], dtype=int).reshape(-1, 2)
                matrix = np.zeros((self.nODE2, self.nODE2))
                matrix[pattern[:, 0], pattern[:, 1]] = values
                matrices[jacobian] = matrix
            self._jacobianCache = (key, matrices)
        return self._jacobianCache[1]

    def ODE2ResidualLHSJacobian(self, q=None, q_t=None, q_tt=None, t=0., factor_q=1., factor_q_t=0., factor_q_tt=0.,
                                sparse=False, epsilon=1e-6, y=None):
        """the Jacobian of the residual, factor_q dr/dq + factor_q_t dr/dq_t + factor_q_tt dr/dq_tt: with the exported
        Jacobians of ODE2RHS factor_q_tt M - factor_q df/dq - factor_q_t df/dq_t, the derivative of M(q) q_tt by q left
        out; without them, or with ODE1 coordinates, by central differences as SymbolicSystemBase

        Args:
            q: the ODE2 coordinates, of size nODE2; None: zero
            q_t: the ODE2 velocities; None: zero
            q_tt: the ODE2 accelerations; None: zero
            t: the time
            factor_q: the factor of dr/dq
            factor_q_t: the factor of dr/dq_t
            factor_q_tt: the factor of dr/dq_tt
            sparse: True: a scipy.sparse.csr_matrix, else a dense array
            epsilon: the step of the differences, without the exported Jacobians
            y: the ODE1 coordinates, if the forces depend on them

        Returns:
            the matrix (nODE2 x nODE2)
        """
        needed = [jacobian for (jacobian, factor) in [('ODE2RHS_q', factor_q), ('ODE2RHS_q_t', factor_q_t)] if factor != 0.]
        if self.nODE1 or any(jacobian not in self.jacobians for jacobian in needed):
            return SymbolicSystemBase.ODE2ResidualLHSJacobian(self, q, q_t, q_tt, t, factor_q, factor_q_t, factor_q_tt,
                                                              sparse, epsilon, y)
        (q, q_t, q_tt) = self._State(q, q_t, q_tt)
        J = np.zeros((self.nODE2, self.nODE2))
        if factor_q_tt != 0.:
            J += factor_q_tt*self.MassMatrix(q, q_t, t)
        matrices = self._Jacobians(q, q_t, t) if needed else {}
        if factor_q != 0.:
            J -= factor_q*matrices['ODE2RHS_q']
        if factor_q_t != 0.:
            J -= factor_q_t*matrices['ODE2RHS_q_t']
        if sparse:
            import scipy.sparse
            return scipy.sparse.csr_matrix(J)
        return J

    def ODE1RHS(self, q, q_t, y, t):
        """g(q, q_t, y, t) of the export"""
        if not self.nODE1:
            return np.zeros(0)
        return self._Result('ODE1RHS', q, q_t, t, None, y).copy()

    def AlgebraicEquations(self, q, q_t, y, z, t, velocityLevel=False):
        """c(q, q_t, y, z, t): the exported equations and p^T p - 1 of the Euler parameters; not on velocity level"""
        if velocityLevel:
            raise ValueError('CompiledSystem.AlgebraicEquations: the equations on velocity level are not exported')
        c = np.zeros(self.nAE)
        rowsEP = [int(row) for node in self.eulerParameterNodes for row in node['ltgAE']]
        if 'algebraicEquations' in self.results:
            c = self._Result('algebraicEquations', q, q_t, t, z, y).copy()
        elif len(rowsEP) < self.nAE:
            raise ValueError('CompiledSystem.AlgebraicEquations: the export has no algebraicEquations')
        for node in self.eulerParameterNodes:
            p = self.qRef[node['ltg']] + np.asarray(q)[node['ltg']]
            c[node['ltgAE'][0]] = p @ p - 1.
        return c

    def ODE2ReactionForcesLHS(self, q, q_t, y, z, t):
        """C_q^T z: the exported reaction forces and 2 p z of the Euler parameters"""
        rowsEP = [int(row) for node in self.eulerParameterNodes for row in node['ltgAE']]
        if 'ODE2ReactionForcesLHS' in self.results:
            r = self._Result('ODE2ReactionForcesLHS', q, q_t, t, z, y).copy()
        elif len(rowsEP) < self.nAE:
            raise ValueError('CompiledSystem.ODE2ReactionForcesLHS: the export has no ODE2ReactionForcesLHS')
        else:
            r = np.zeros(self.nODE2)
        for node in self.eulerParameterNodes:
            p = self.qRef[node['ltg']] + np.asarray(q)[node['ltg']]
            r[node['ltg']] += 2.*p*z[node['ltgAE'][0]]
        return r

    def __repr__(self):
        description = self.description
        return ('CompiledSystem ' + description['name'] + ' (' + description['language'] + '): ' + str(self.nODE2)
                + ' ODE2, ' + str(self.nODE1) + ' ODE1, ' + str(self.nAE) + ' algebraic coordinates, results '
                + ', '.join(self.results) + ', ' + str(description['operations']) + ' operations')
